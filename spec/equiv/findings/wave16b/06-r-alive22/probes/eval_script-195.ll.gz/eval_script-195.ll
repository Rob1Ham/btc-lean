; ModuleID = 'eval_script-195.bc'
source_filename = "rbitcoin_consensus.feaf38542b4ff5dd-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

%"alloc::vec::Vec<u8>" = type { %"alloc::raw_vec::RawVec<u8>", i64 }
%"alloc::raw_vec::RawVec<u8>" = type { %"alloc::raw_vec::RawVecInner", %"core::marker::PhantomData<u8>" }
%"alloc::raw_vec::RawVecInner" = type { i64, ptr, %"alloc::alloc::Global" }
%"alloc::alloc::Global" = type {}
%"core::marker::PhantomData<u8>" = type {}
%"bitcoin::blockdata::transaction::TxIn" = type { %"bitcoin::blockdata::script::owned::ScriptBuf", %"bitcoin::blockdata::witness::Witness", %"bitcoin::blockdata::transaction::OutPoint", i32 }
%"bitcoin::blockdata::script::owned::ScriptBuf" = type { %"alloc::vec::Vec<u8>" }
%"bitcoin::blockdata::witness::Witness" = type { %"alloc::vec::Vec<u8>", i64, i64 }
%"bitcoin::blockdata::transaction::OutPoint" = type { %"bitcoin::blockdata::transaction::Txid", i32 }
%"bitcoin::blockdata::transaction::Txid" = type { %"bitcoin_hashes::sha256d::Hash" }
%"bitcoin_hashes::sha256d::Hash" = type { [32 x i8] }

@alloc_532002b94befc8a9d927779d10100e7e = external hidden unnamed_addr constant [12 x i8], align 1
@alloc_bbfddc5812f83af444aa1059f17430fb = external hidden unnamed_addr constant [13 x i8], align 1
@alloc_925914e8e9780efb09322acfc270e443 = external hidden unnamed_addr constant [3 x i8], align 1
@alloc_6476b7d94dcf327b4611985ef2e36bf8 = external hidden unnamed_addr constant [11 x i8], align 1
@alloc_fc99526dd087ba82588f50a651d3cd28 = external hidden unnamed_addr constant [9 x i8], align 1
@alloc_a562a5f2e4413e2438e7655a709b4d07 = external hidden unnamed_addr constant [19 x i8], align 1
@alloc_43f0806753e598d0be3212342fe980ba = external hidden unnamed_addr constant [11 x i8], align 1
@alloc_369ee17d61227813032237a0166bc7fe = external hidden unnamed_addr constant [10 x i8], align 1
@alloc_e04d159d34163bf0cc350c478390468e = external hidden unnamed_addr constant [9 x i8], align 1
@alloc_57992395b01facdbc4733c410b510dc6 = external hidden unnamed_addr constant [13 x i8], align 1
@alloc_d5eeb53942d82c403fb4980373f99e0a = external hidden unnamed_addr constant [11 x i8], align 1
@alloc_1ef5ffa3c70b9a1a8714a694c19a3b32 = external hidden unnamed_addr constant [14 x i8], align 1
@alloc_36c2ba1cd7284c88ed7c42994c4bf01e = external hidden unnamed_addr constant [9 x i8], align 1
@alloc_89ddf3c5423fb9ffa41b3154201d3495 = external hidden unnamed_addr constant [7 x i8], align 1
@alloc_c8e178ad39934661b0ab4885a41c8174 = external hidden unnamed_addr constant [16 x i8], align 1
@alloc_adf5eb6322a6d3ed8bfdcac2abff4f1c = external hidden unnamed_addr constant [9 x i8], align 1
@alloc_8c1e39ce3af88a35f82246a7e127f092 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_4a580b9d131f2da61cefd6f54c746d24 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_287b68c41a14dac20c7929fd1b8b2d30 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_0f1b902749b0d0e662e14755b98f5935 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_ebc7827e0b8d77ab9d973903086eec33 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_5f18aeb0c62cc58700b8ae33199cde21 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_0a9965c4a3cbdd1ca52702b024192a21 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_9980f6ffa5c2068096eefc358cf93bc9 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_8d1b6d1d478bbdd9dff5b9296cde158a = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_86034e9c05ba888bc245122becc3bf4d = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_ad16fc515758063a13348c796d5ea08b = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_b17cc5a745b7ec48d37520d8a0e8fab8 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_922b91ee97ebf46e4bed364354c85188 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_2abd712fd970981d4f22d89041be8450 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_666d0333010630b2c6353720186fc8ba = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_c8b2a5aa55c912d16cb979033afb3711 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_0ab2c02aad5382c96b2f89d0e48d7a96 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_258b29efb2df021f7cd25bd9f7592621 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_8a42701a1650e5b5044dc0cbe1c4580c = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_12a3a1b51194abbb5aa46d311bf28d16 = external hidden unnamed_addr constant [7 x i8], align 1
@alloc_b5caa6874f22c115442d07cb19e5dbac = external hidden unnamed_addr constant [7 x i8], align 1
@alloc_3c2cc3bd212fbb745d0642ddde6dce4f = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_5d258eacc014a54fb47cea2410e0d855 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_d978a3349aa7cd3c95063ff43397d969 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_290fd00cfc3b7116260877937e5355a9 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_0a4d61ab70805cc6d586003c1e407b6e = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_4b4e5ff22c0d040e35e90e47094297c4 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_edea9280d8e8d4135f9b6fdbe8bdf45f = external hidden unnamed_addr constant [14 x i8], align 1
@alloc_61f921f288c92b2b8cae67f33bec51d2 = external hidden unnamed_addr constant [17 x i8], align 1
@alloc_b5950a714e85e2d9a1cbf7e97b2f2592 = external hidden unnamed_addr constant [19 x i8], align 1
@alloc_76451f304efea00a147201872a6c61d1 = external hidden unnamed_addr constant [35 x i8], align 1
@alloc_420b47dc024432f6dbc618fef11b0af8 = external hidden unnamed_addr constant [41 x i8], align 1
@alloc_92e8cfa91beedd87ed07014a34c9e885 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_19d013f3a919f93ece092868f0eff1de = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_cc4a58c6e661e532d59f57cfe6103566 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_67582fafe2d63da76bfb1f7a3c421bad = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_69a376d11e669e785360fef06f8c9037 = external hidden unnamed_addr constant [26 x i8], align 1
@alloc_3d04147c16fc2ded597f89a3f653cd9e = external hidden unnamed_addr constant [27 x i8], align 1
@alloc_dcc8064e61d6be54ea73841fdb88c03e = external hidden unnamed_addr constant [16 x i8], align 1
@alloc_bac92b6a7d9efcf42ce1b95a83da0ec1 = external hidden unnamed_addr constant [12 x i8], align 1
@alloc_59bb4bf993f38b9997245f355fb2fced = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_0a97ab6a2b4539a09e7ddc5a0a078f70 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_96962fdbf8678853bad5dee4304bd9a4 = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8
@alloc_c4c777470ef13cf7fecb9356802f26bc = external hidden unnamed_addr constant <{ ptr, [16 x i8] }>, align 8

; Function Attrs: inlinehint nounwind nonlazybind uwtable
declare hidden fastcc noalias noundef nonnull ptr @_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit(i64 noundef range(i64 1, 129), i64 noundef range(i64 1, 641)) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN14bitcoin_hashes4Hash4hash17h0c6cd049fe8a3fa5E(ptr dead_on_unwind noalias noundef nonnull writable align 1 captures(address) dereferenceable(20), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN14bitcoin_hashes4Hash4hash17ha1931f230c6e1e50E(ptr dead_on_unwind noalias noundef nonnull writable align 1 captures(address) dereferenceable(32), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(16) initializes((0, 1)), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
define hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter11eval_script17h9bf99c7ab3467ea9E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %script.0, i64 noundef %script.1, ptr noalias noundef nonnull align 8 dereferenceable(24) %stack, ptr noundef nonnull align 8 %ctx) unnamed_addr #1 personality ptr @rust_eh_personality !dbg !7 {
start:
  %_2988 = alloca [24 x i8], align 8
  %_2876 = alloca [24 x i8], align 8
  %_2584 = alloca [24 x i8], align 8
  %_2565 = alloca [24 x i8], align 8
  %_2546 = alloca [24 x i8], align 8
  %_2521 = alloca [24 x i8], align 8
  %_2502 = alloca [24 x i8], align 8
  %_2477 = alloca [24 x i8], align 8
  %_2458 = alloca [24 x i8], align 8
  %_2390 = alloca [24 x i8], align 8
  %_2371 = alloca [24 x i8], align 8
  %_2340 = alloca [24 x i8], align 8
  %_2321 = alloca [24 x i8], align 8
  %_2296 = alloca [24 x i8], align 8
  %_2277 = alloca [24 x i8], align 8
  %_2240 = alloca [24 x i8], align 8
  %_2215 = alloca [24 x i8], align 8
  %_2188 = alloca [24 x i8], align 8
  %_2163 = alloca [24 x i8], align 8
  %_2138 = alloca [24 x i8], align 8
  %_2113 = alloca [24 x i8], align 8
  %_1996 = alloca [24 x i8], align 8
  %_1960 = alloca [24 x i8], align 8
  %_1937 = alloca [24 x i8], align 8
  %_1921 = alloca [24 x i8], align 8
  %_1876 = alloca [24 x i8], align 8
  %_1824 = alloca [24 x i8], align 8
  %_1688 = alloca [24 x i8], align 8
  %_1672 = alloca [24 x i8], align 8
  %args169 = alloca [16 x i8], align 8
  %_945 = alloca [24 x i8], align 8
  %_923 = alloca [16 x i8], align 8
  %_919 = alloca [24 x i8], align 8
  %_893 = alloca [16 x i8], align 8
  %_889 = alloca [24 x i8], align 8
  %_883 = alloca [24 x i8], align 8
  %_872 = alloca [24 x i8], align 8
  %_862 = alloca [24 x i8], align 8
  %_854 = alloca [24 x i8], align 8
  %_850 = alloca [24 x i8], align 8
  %_843 = alloca [24 x i8], align 8
  %_841 = alloca [24 x i8], align 8
  %digest160 = alloca [32 x i8], align 1
  %_834 = alloca [32 x i8], align 8
  %_829 = alloca [20 x i8], align 1
  %_826 = alloca [24 x i8], align 8
  %_824 = alloca [24 x i8], align 8
  %_820 = alloca [32 x i8], align 8
  %_815 = alloca [32 x i8], align 1
  %_812 = alloca [24 x i8], align 8
  %_810 = alloca [24 x i8], align 8
  %_806 = alloca [32 x i8], align 8
  %_801 = alloca [20 x i8], align 1
  %_798 = alloca [24 x i8], align 8
  %_796 = alloca [24 x i8], align 8
  %_792 = alloca [32 x i8], align 8
  %_786 = alloca [24 x i8], align 8
  %_784 = alloca [24 x i8], align 8
  %digest = alloca [20 x i8], align 1
  %_777 = alloca [32 x i8], align 8
  %_771 = alloca [24 x i8], align 8
  %_769 = alloca [24 x i8], align 8
  %_763 = alloca [32 x i8], align 8
  %_759 = alloca [16 x i8], align 8
  %_753 = alloca [32 x i8], align 8
  %_749 = alloca [16 x i8], align 8
  %_743 = alloca [32 x i8], align 8
  %_739 = alloca [16 x i8], align 8
  %_735 = alloca [24 x i8], align 8
  %_733 = alloca [24 x i8], align 8
  %_727 = alloca [32 x i8], align 8
  %_723 = alloca [16 x i8], align 8
  %_717 = alloca [32 x i8], align 8
  %_713 = alloca [16 x i8], align 8
  %_709 = alloca [24 x i8], align 8
  %_707 = alloca [24 x i8], align 8
  %_701 = alloca [32 x i8], align 8
  %_697 = alloca [16 x i8], align 8
  %_691 = alloca [32 x i8], align 8
  %_687 = alloca [16 x i8], align 8
  %_683 = alloca [24 x i8], align 8
  %_679 = alloca [24 x i8], align 8
  %_675 = alloca [24 x i8], align 8
  %_671 = alloca [24 x i8], align 8
  %_667 = alloca [24 x i8], align 8
  %_658 = alloca [32 x i8], align 8
  %_654 = alloca [16 x i8], align 8
  %_648 = alloca [32 x i8], align 8
  %_644 = alloca [16 x i8], align 8
  %_640 = alloca [24 x i8], align 8
  %_636 = alloca [24 x i8], align 8
  %_634 = alloca [24 x i8], align 8
  %_628 = alloca [32 x i8], align 8
  %_624 = alloca [16 x i8], align 8
  %_618 = alloca [32 x i8], align 8
  %_614 = alloca [16 x i8], align 8
  %_610 = alloca [24 x i8], align 8
  %_608 = alloca [24 x i8], align 8
  %_602 = alloca [32 x i8], align 8
  %_598 = alloca [16 x i8], align 8
  %_592 = alloca [32 x i8], align 8
  %_588 = alloca [16 x i8], align 8
  %_584 = alloca [24 x i8], align 8
  %_580 = alloca [24 x i8], align 8
  %_576 = alloca [24 x i8], align 8
  %_574 = alloca [24 x i8], align 8
  %_568 = alloca [32 x i8], align 8
  %_564 = alloca [16 x i8], align 8
  %_560 = alloca [24 x i8], align 8
  %_558 = alloca [24 x i8], align 8
  %_552 = alloca [32 x i8], align 8
  %_548 = alloca [16 x i8], align 8
  %_544 = alloca [24 x i8], align 8
  %_542 = alloca [24 x i8], align 8
  %_536 = alloca [32 x i8], align 8
  %_532 = alloca [16 x i8], align 8
  %_528 = alloca [24 x i8], align 8
  %_526 = alloca [24 x i8], align 8
  %_520 = alloca [32 x i8], align 8
  %_516 = alloca [16 x i8], align 8
  %_512 = alloca [24 x i8], align 8
  %_510 = alloca [24 x i8], align 8
  %_504 = alloca [32 x i8], align 8
  %_500 = alloca [16 x i8], align 8
  %_496 = alloca [24 x i8], align 8
  %_494 = alloca [24 x i8], align 8
  %_488 = alloca [32 x i8], align 8
  %_484 = alloca [16 x i8], align 8
  %_477 = alloca [32 x i8], align 8
  %_472 = alloca [32 x i8], align 8
  %_467 = alloca [24 x i8], align 8
  %_465 = alloca [24 x i8], align 8
  %_461 = alloca [32 x i8], align 8
  %_456 = alloca [32 x i8], align 8
  %_452 = alloca [24 x i8], align 8
  %_450 = alloca [24 x i8], align 8
  %_442 = alloca [24 x i8], align 8
  %_434 = alloca [24 x i8], align 8
  %v67 = alloca [24 x i8], align 8
  %_426 = alloca [24 x i8], align 8
  %_418 = alloca [24 x i8], align 8
  %_408 = alloca [24 x i8], align 8
  %_404 = alloca [24 x i8], align 8
  %v62 = alloca [24 x i8], align 8
  %_388 = alloca [32 x i8], align 8
  %_384 = alloca [16 x i8], align 8
  %_380 = alloca [24 x i8], align 8
  %v58 = alloca [24 x i8], align 8
  %_363 = alloca [32 x i8], align 8
  %_359 = alloca [16 x i8], align 8
  %_355 = alloca [24 x i8], align 8
  %v54 = alloca [24 x i8], align 8
  %_347 = alloca [24 x i8], align 8
  %_344 = alloca [24 x i8], align 8
  %_342 = alloca [24 x i8], align 8
  %_338 = alloca [32 x i8], align 8
  %_333 = alloca [32 x i8], align 8
  %_328 = alloca [24 x i8], align 8
  %_324 = alloca [24 x i8], align 8
  %v45 = alloca [24 x i8], align 8
  %_317 = alloca [24 x i8], align 8
  %_313 = alloca [32 x i8], align 8
  %_309 = alloca [24 x i8], align 8
  %_307 = alloca [24 x i8], align 8
  %_301 = alloca [24 x i8], align 8
  %v39 = alloca [24 x i8], align 8
  %_290 = alloca [24 x i8], align 8
  %_279 = alloca [24 x i8], align 8
  %_268 = alloca [24 x i8], align 8
  %x2 = alloca [24 x i8], align 8
  %x1 = alloca [24 x i8], align 8
  %_256 = alloca [24 x i8], align 8
  %_251 = alloca [24 x i8], align 8
  %_247 = alloca [24 x i8], align 8
  %b33 = alloca [24 x i8], align 8
  %a32 = alloca [24 x i8], align 8
  %_235 = alloca [24 x i8], align 8
  %_230 = alloca [24 x i8], align 8
  %_225 = alloca [24 x i8], align 8
  %_221 = alloca [24 x i8], align 8
  %c = alloca [24 x i8], align 8
  %b27 = alloca [24 x i8], align 8
  %a26 = alloca [24 x i8], align 8
  %_205 = alloca [24 x i8], align 8
  %_200 = alloca [24 x i8], align 8
  %_196 = alloca [24 x i8], align 8
  %b = alloca [24 x i8], align 8
  %a = alloca [24 x i8], align 8
  %_184 = alloca [24 x i8], align 8
  %_180 = alloca [32 x i8], align 8
  %_175 = alloca [32 x i8], align 8
  %_170 = alloca [24 x i8], align 8
  %v16 = alloca [24 x i8], align 8
  %_165.sroa.5 = alloca [24 x i8], align 8
  %_164.sroa.5 = alloca [24 x i8], align 8
  %v14 = alloca [24 x i8], align 8
  %_160 = alloca [32 x i8], align 8
  %_159.sroa.5 = alloca [24 x i8], align 8
  %_152 = alloca [32 x i8], align 8
  %_146 = alloca [24 x i8], align 8
  %_144 = alloca [24 x i8], align 8
  %args = alloca [16 x i8], align 8
  %_122 = alloca [24 x i8], align 8
  %code = alloca [1 x i8], align 1
  %_40 = alloca [40 x i8], align 8
  %iter1 = alloca [32 x i8], align 8
  %op_count = alloca [8 x i8], align 8
  %altstack = alloca [24 x i8], align 8
  %_6 = getelementptr inbounds nuw i8, ptr %ctx, i64 852, !dbg !14
  %_6.val403 = load i8, ptr %_6, align 4, !dbg !14, !range !16, !noundef !13
  %_0.i = icmp eq i8 %_6.val403, 2, !dbg !17
  br i1 %_0.i, label %bb2, label %bb16.thread, !dbg !14

bb2:                                              ; preds = %start
  tail call void @llvm.experimental.noalias.scope.decl(metadata !23), !dbg !26
  %_338.not.i = icmp eq i64 %script.1, 0, !dbg !27
  br i1 %_338.not.i, label %bb8, label %bb3.i, !dbg !27

bb3.i:                                            ; preds = %bb1.backedge.i, %bb2
  %i.sroa.0.039.i = phi i64 [ %i.sroa.0.0.be.i, %bb1.backedge.i ], [ 0, %bb2 ]
  %0 = getelementptr inbounds nuw i8, ptr %script.0, i64 %i.sroa.0.039.i, !dbg !32
  %1 = load i8, ptr %0, align 1, !dbg !32, !alias.scope !23, !noundef !13
  %_0.i6.not.i.i = icmp eq i8 %1, 0, !dbg !33
  br i1 %_0.i6.not.i.i, label %bb25.i, label %_ZN4core3ops5range11RangeBounds8contains17h01e927bf53f01bd6E.exit.i, !dbg !55

_ZN4core3ops5range11RangeBounds8contains17h01e927bf53f01bd6E.exit.i: ; preds = %bb3.i
  %_0.i.i.i = icmp ult i8 %1, 76, !dbg !56
  br i1 %_0.i.i.i, label %bb4.i, label %bb5.i, !dbg !60

bb5.i:                                            ; preds = %_ZN4core3ops5range11RangeBounds8contains17h01e927bf53f01bd6E.exit.i
  switch i8 %1, label %_ZN18rbitcoin_consensus6script11interpreter13is_op_success17h5c7f8cd81ac30a2eE.exit.i [
    i8 76, label %bb9.i
    i8 77, label %bb8.i
    i8 78, label %bb7.i
    i8 80, label %bb4
    i8 98, label %bb4
    i8 126, label %bb4
    i8 127, label %bb4
    i8 -128, label %bb4
    i8 -127, label %bb4
    i8 -125, label %bb4
    i8 -124, label %bb4
    i8 -123, label %bb4
    i8 -122, label %bb4
    i8 -119, label %bb4
    i8 -118, label %bb4
    i8 -115, label %bb4
    i8 -114, label %bb4
    i8 -107, label %bb4
    i8 -106, label %bb4
    i8 -105, label %bb4
    i8 -104, label %bb4
    i8 -103, label %bb4
  ], !dbg !61

bb4.i:                                            ; preds = %_ZN4core3ops5range11RangeBounds8contains17h01e927bf53f01bd6E.exit.i
  %n10.i = zext nneg i8 %1 to i64, !dbg !62
  %2 = add nuw i64 %i.sroa.0.039.i, 1, !dbg !63
  %3 = tail call i64 @llvm.uadd.sat.i64(i64 %2, i64 %n10.i), !dbg !70
  br label %bb1.backedge.i, !dbg !72

_ZN18rbitcoin_consensus6script11interpreter13is_op_success17h5c7f8cd81ac30a2eE.exit.i: ; preds = %bb5.i
  %4 = add i8 %1, 69, !dbg !75
  %spec.select.i.i = icmp ult i8 %4, 68, !dbg !75
  br i1 %spec.select.i.i, label %bb4, label %bb25.i, !dbg !81

bb9.i:                                            ; preds = %bb5.i
  %_14.i = add nuw i64 %i.sroa.0.039.i, 1, !dbg !82
  %_13.not.i = icmp ult i64 %_14.i, %script.1, !dbg !82
  br i1 %_13.not.i, label %bb12.i, label %bb8, !dbg !82

bb8.i:                                            ; preds = %bb5.i
  %_23.i = add i64 %i.sroa.0.039.i, 2, !dbg !83
  %_22.not.i = icmp ult i64 %_23.i, %script.1, !dbg !83
  br i1 %_22.not.i, label %bb14.i, label %bb8, !dbg !83

bb7.i:                                            ; preds = %bb5.i
  %_38.i = add i64 %i.sroa.0.039.i, 4, !dbg !84
  %_37.not.i = icmp ult i64 %_38.i, %script.1, !dbg !84
  br i1 %_37.not.i, label %bb18.i, label %bb8, !dbg !84

bb12.i:                                           ; preds = %bb9.i
  %5 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_14.i, !dbg !85
  %_17.i = load i8, ptr %5, align 1, !dbg !85, !alias.scope !23, !noundef !13
  %n.i = zext i8 %_17.i to i64, !dbg !85
  %6 = add nuw i64 %i.sroa.0.039.i, 2, !dbg !86
  %7 = tail call i64 @llvm.uadd.sat.i64(i64 %6, i64 %n.i), !dbg !89
  br label %bb1.backedge.i, !dbg !91

bb1.backedge.i:                                   ; preds = %bb25.i, %bb22.i, %bb16.i, %bb12.i, %bb4.i
  %i.sroa.0.0.be.i = phi i64 [ %3, %bb4.i ], [ %18, %bb25.i ], [ %7, %bb12.i ], [ %11, %bb16.i ], [ %17, %bb22.i ]
  %_3.i = icmp ult i64 %i.sroa.0.0.be.i, %script.1, !dbg !27
  br i1 %_3.i, label %bb3.i, label %bb8, !dbg !27

bb14.i:                                           ; preds = %bb8.i
  %_29.i = add nuw i64 %i.sroa.0.039.i, 1, !dbg !92
  %_31.i = icmp ult i64 %_29.i, %script.1, !dbg !93
  br i1 %_31.i, label %bb16.i, label %panic2.i, !dbg !93

panic2.i:                                         ; preds = %bb14.i
  tail call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_29.i, i64 noundef %script.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_59bb4bf993f38b9997245f355fb2fced) #15, !dbg !93, !noalias !23
  unreachable, !dbg !93

bb16.i:                                           ; preds = %bb14.i
  %8 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_29.i, !dbg !93
  %_28.i = load i8, ptr %8, align 1, !dbg !93, !alias.scope !23, !noundef !13
  %9 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_23.i, !dbg !94
  %_32.i = load i8, ptr %9, align 1, !dbg !94, !alias.scope !23, !noundef !13
  %_27.sroa.4.0.insert.ext.i = zext i8 %_32.i to i64, !dbg !95
  %_27.sroa.4.0.insert.shift.i = shl nuw nsw i64 %_27.sroa.4.0.insert.ext.i, 8, !dbg !95
  %_27.sroa.0.0.insert.ext.i = zext i8 %_28.i to i64, !dbg !95
  %_27.sroa.0.0.insert.insert.i = or disjoint i64 %_27.sroa.4.0.insert.shift.i, %_27.sroa.0.0.insert.ext.i, !dbg !95
  %10 = tail call i64 @llvm.uadd.sat.i64(i64 %i.sroa.0.039.i, i64 3), !dbg !96
  %11 = tail call i64 @llvm.uadd.sat.i64(i64 %10, i64 %_27.sroa.0.0.insert.insert.i), !dbg !99
  br label %bb1.backedge.i, !dbg !101

bb18.i:                                           ; preds = %bb7.i
  %_44.i = add nuw i64 %i.sroa.0.039.i, 1, !dbg !102
  %_46.i = icmp ult i64 %_44.i, %script.1, !dbg !103
  br i1 %_46.i, label %bb19.i, label %panic5.i, !dbg !103

bb19.i:                                           ; preds = %bb18.i
  %12 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_44.i, !dbg !103
  %_43.i = load i8, ptr %12, align 1, !dbg !103, !alias.scope !23, !noundef !13
  %_48.i = add nuw i64 %i.sroa.0.039.i, 2, !dbg !104
  %_50.i = icmp ult i64 %_48.i, %script.1, !dbg !105
  br i1 %_50.i, label %bb20.i, label %panic6.i, !dbg !105

panic5.i:                                         ; preds = %bb18.i
  tail call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_44.i, i64 noundef %script.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0a97ab6a2b4539a09e7ddc5a0a078f70) #15, !dbg !103, !noalias !23
  unreachable, !dbg !103

bb20.i:                                           ; preds = %bb19.i
  %_52.i = add nuw i64 %i.sroa.0.039.i, 3, !dbg !106
  %_54.i = icmp ult i64 %_52.i, %script.1, !dbg !107
  br i1 %_54.i, label %bb22.i, label %panic7.i, !dbg !107

panic6.i:                                         ; preds = %bb19.i
  tail call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_48.i, i64 noundef %script.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_96962fdbf8678853bad5dee4304bd9a4) #15, !dbg !105, !noalias !23
  unreachable, !dbg !105

panic7.i:                                         ; preds = %bb20.i
  tail call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_52.i, i64 noundef %script.1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c4c777470ef13cf7fecb9356802f26bc) #15, !dbg !107, !noalias !23
  unreachable, !dbg !107

bb22.i:                                           ; preds = %bb20.i
  %13 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_48.i, !dbg !105
  %_47.i = load i8, ptr %13, align 1, !dbg !105, !alias.scope !23, !noundef !13
  %14 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_52.i, !dbg !107
  %_51.i = load i8, ptr %14, align 1, !dbg !107, !alias.scope !23, !noundef !13
  %15 = getelementptr inbounds nuw i8, ptr %script.0, i64 %_38.i, !dbg !108
  %_55.i = load i8, ptr %15, align 1, !dbg !108, !alias.scope !23, !noundef !13
  %_42.sroa.6.0.insert.ext.i = zext i8 %_55.i to i64, !dbg !109
  %_42.sroa.6.0.insert.shift.i = shl nuw nsw i64 %_42.sroa.6.0.insert.ext.i, 24, !dbg !109
  %_42.sroa.5.0.insert.ext.i = zext i8 %_51.i to i64, !dbg !109
  %_42.sroa.5.0.insert.shift.i = shl nuw nsw i64 %_42.sroa.5.0.insert.ext.i, 16, !dbg !109
  %_42.sroa.4.0.insert.ext.i = zext i8 %_47.i to i64, !dbg !109
  %_42.sroa.4.0.insert.shift.i = shl nuw nsw i64 %_42.sroa.4.0.insert.ext.i, 8, !dbg !109
  %_42.sroa.0.0.insert.ext.i = zext i8 %_43.i to i64, !dbg !109
  %_42.sroa.5.0.insert.insert.i = or disjoint i64 %_42.sroa.4.0.insert.shift.i, %_42.sroa.0.0.insert.ext.i, !dbg !109
  %_42.sroa.4.0.insert.insert.i = or disjoint i64 %_42.sroa.5.0.insert.insert.i, %_42.sroa.5.0.insert.shift.i, !dbg !109
  %_42.sroa.0.0.insert.insert.i = or disjoint i64 %_42.sroa.4.0.insert.insert.i, %_42.sroa.6.0.insert.shift.i, !dbg !109
  %16 = tail call i64 @llvm.uadd.sat.i64(i64 %i.sroa.0.039.i, i64 5), !dbg !110
  %17 = tail call i64 @llvm.uadd.sat.i64(i64 %16, i64 %_42.sroa.0.0.insert.insert.i), !dbg !113
  br label %bb1.backedge.i, !dbg !115

bb25.i:                                           ; preds = %_ZN18rbitcoin_consensus6script11interpreter13is_op_success17h5c7f8cd81ac30a2eE.exit.i, %bb3.i
  %18 = add i64 %i.sroa.0.039.i, 1, !dbg !116
  br label %bb1.backedge.i, !dbg !117

bb4:                                              ; preds = %_ZN18rbitcoin_consensus6script11interpreter13is_op_success17h5c7f8cd81ac30a2eE.exit.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i, %bb5.i
  %19 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !118
  store i8 0, ptr %19, align 8, !dbg !118
  store i64 -9223372036854775797, ptr %_0, align 8, !dbg !118
  br label %bb449, !dbg !119

bb8:                                              ; preds = %bb1.backedge.i, %bb7.i, %bb8.i, %bb9.i, %bb2
  %20 = getelementptr inbounds nuw i8, ptr %stack, i64 16, !dbg !121
  %_11 = load i64, ptr %20, align 8, !dbg !121, !noundef !13
  %_962 = icmp ult i64 %_11, 384307168202282326, !dbg !128
  tail call void @llvm.assume(i1 %_962), !dbg !130
  %_10 = icmp samesign ugt i64 %_11, 1000, !dbg !131
  br i1 %_10, label %bb9, label %bb10, !dbg !131

bb16.thread:                                      ; preds = %start
  %_233573 = icmp ult i64 %script.1, 10001
  br i1 %_233573, label %bb21.thread, label %bb18, !dbg !132

bb21.thread:                                      ; preds = %bb16.thread
  call void @llvm.lifetime.start.p0(ptr nonnull %altstack), !dbg !133
  store i64 0, ptr %altstack, align 8, !dbg !134
  %21 = getelementptr inbounds nuw i8, ptr %altstack, i64 8, !dbg !134
  store ptr inttoptr (i64 8 to ptr), ptr %21, align 8, !dbg !134
  %22 = getelementptr inbounds nuw i8, ptr %altstack, i64 16, !dbg !134
  store i64 0, ptr %22, align 8, !dbg !134
  call void @llvm.lifetime.start.p0(ptr nonnull %op_count), !dbg !137
  store i64 0, ptr %op_count, align 8, !dbg !140
  %23 = getelementptr inbounds nuw i8, ptr %ctx, i64 861, !dbg !141
  %24 = load i8, ptr %23, align 1, !dbg !141, !range !144, !noundef !13
  %_35 = trunc nuw i8 %24 to i1, !dbg !141
  %_0.i445 = icmp eq i8 %_6.val403, 1
  %spec.select = and i1 %_0.i445, %_35, !dbg !141
  br label %bb30, !dbg !141

bb10:                                             ; preds = %bb8
  %25 = getelementptr inbounds nuw i8, ptr %stack, i64 8, !dbg !145
  %_985 = load ptr, ptr %25, align 8, !dbg !145, !nonnull !13, !noundef !13
  %_989.idx = mul nuw nsw i64 %_11, 24, !dbg !165
  %_989 = getelementptr inbounds nuw i8, ptr %_985, i64 %_989.idx, !dbg !165
  %_9962705 = icmp eq i64 %_11, 0, !dbg !184
  br i1 %_9962705, label %bb21, label %bb498, !dbg !189

bb9:                                              ; preds = %bb8
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !198, !noalias !238
  %26 = tail call noundef dereferenceable_or_null(10) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 10, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !241, !noalias !238
  %27 = icmp eq ptr %26, null, !dbg !255
  br i1 %27, label %bb495, label %bb496, !dbg !257

bb11:                                             ; preds = %bb498
  %_1002 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.02706, i64 24, !dbg !258
  %_996 = icmp eq ptr %_1002, %_989, !dbg !184
  br i1 %_996, label %bb21, label %bb498, !dbg !189

bb498:                                            ; preds = %bb11, %bb10
  %iter.sroa.0.02706 = phi ptr [ %_1002, %bb11 ], [ %_985, %bb10 ]
  %28 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.02706, i64 16, !dbg !262
  %_18 = load i64, ptr %28, align 8, !dbg !262, !noundef !13
  %_1004 = icmp sgt i64 %_18, -1, !dbg !266
  tail call void @llvm.assume(i1 %_1004), !dbg !268
  %_17 = icmp samesign ugt i64 %_18, 520, !dbg !269
  br i1 %_17, label %bb13, label %bb11, !dbg !269

bb13:                                             ; preds = %bb498
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !270, !noalias !292
  %29 = tail call noundef dereferenceable_or_null(9) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 9, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !295, !noalias !292
  %30 = icmp eq ptr %29, null, !dbg !300
  br i1 %30, label %bb502, label %bb503, !dbg !301

bb502:                                            ; preds = %bb13
  tail call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 9) #17, !dbg !302
  unreachable, !dbg !302

bb503:                                            ; preds = %bb13
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %29, ptr noundef nonnull align 1 dereferenceable(9) @alloc_e04d159d34163bf0cc350c478390468e, i64 9, i1 false), !dbg !304
  store i64 9, ptr %_0, align 8, !dbg !316
  %_19.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !316
  store ptr %29, ptr %_19.sroa.4.0._0.sroa_idx, align 8, !dbg !316
  %_19.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !316
  store i64 9, ptr %_19.sroa.5.0._0.sroa_idx, align 8, !dbg !316
  br label %bb449, !dbg !119

bb21:                                             ; preds = %bb11, %bb10
  call void @llvm.lifetime.start.p0(ptr nonnull %altstack), !dbg !133
  store i64 0, ptr %altstack, align 8, !dbg !134
  %31 = getelementptr inbounds nuw i8, ptr %altstack, i64 8, !dbg !134
  store ptr inttoptr (i64 8 to ptr), ptr %31, align 8, !dbg !134
  %32 = getelementptr inbounds nuw i8, ptr %altstack, i64 16, !dbg !134
  store i64 0, ptr %32, align 8, !dbg !134
  call void @llvm.lifetime.start.p0(ptr nonnull %op_count), !dbg !137
  store i64 0, ptr %op_count, align 8, !dbg !140
  br label %bb30, !dbg !317

bb18:                                             ; preds = %bb16.thread
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !318, !noalias !340
  %33 = tail call noundef dereferenceable_or_null(16) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 16, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !343, !noalias !340
  %34 = icmp eq ptr %33, null, !dbg !348
  br i1 %34, label %bb508, label %bb509, !dbg !349

bb30:                                             ; preds = %bb21, %bb21.thread
  %35 = phi ptr [ %32, %bb21 ], [ %22, %bb21.thread ]
  %36 = phi ptr [ %31, %bb21 ], [ %21, %bb21.thread ]
  %minimal_if.sroa.0.0 = phi i1 [ true, %bb21 ], [ %spec.select, %bb21.thread ], !dbg !350
  %_1052 = getelementptr inbounds nuw i8, ptr %script.0, i64 %script.1, !dbg !351
  call void @llvm.lifetime.start.p0(ptr nonnull %iter1), !dbg !374
  store i64 0, ptr %iter1, align 8, !dbg !374
  %_38.sroa.2.0.iter1.sroa_idx = getelementptr inbounds nuw i8, ptr %iter1, i64 8, !dbg !374
  store ptr %script.0, ptr %_38.sroa.2.0.iter1.sroa_idx, align 8, !dbg !374
  %_38.sroa.2.sroa.2.0._38.sroa.2.0.iter1.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %iter1, i64 16, !dbg !374
  store ptr %_1052, ptr %_38.sroa.2.sroa.2.0._38.sroa.2.0.iter1.sroa_idx.sroa_idx, align 8, !dbg !374
  %_38.sroa.2.sroa.3.0._38.sroa.2.0.iter1.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %iter1, i64 24, !dbg !374
  store i8 0, ptr %_38.sroa.2.sroa.3.0._38.sroa.2.0.iter1.sroa_idx.sroa_idx, align 8, !dbg !374
  call void @llvm.lifetime.start.p0(ptr nonnull %_40), !dbg !375
  call void @"_ZN118_$LT$bitcoin..blockdata..script..instruction..InstructionIndices$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h6d281e0b32b4cb98E"(ptr noalias noundef nonnull sret([40 x i8]) align 8 captures(address) dereferenceable(40) %_40, ptr noalias noundef nonnull align 8 dereferenceable(32) %iter1) #16, !dbg !375
  %37 = load i32, ptr %_40, align 8, !dbg !375, !range !377, !noundef !13
  %.not27082711 = icmp eq i32 %37, 6, !dbg !375
  br i1 %.not27082711, label %bb34.thread, label %bb33.lr.ph.lr.ph, !dbg !375

bb34.thread:                                      ; preds = %bb30
  call void @llvm.lifetime.end.p0(ptr nonnull %_40), !dbg !378
  call void @llvm.lifetime.end.p0(ptr nonnull %iter1), !dbg !379
  br label %bb400, !dbg !380

bb33.lr.ph.lr.ph:                                 ; preds = %bb30
  %item.sroa.3.sroa.2.0.item.sroa.3.0._40.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_40, i64 8
  %item.sroa.3.sroa.3.0.item.sroa.3.0._40.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_40, i64 16
  %item.sroa.3.sroa.3.sroa.3.0.item.sroa.3.sroa.3.0.item.sroa.3.0._40.sroa_idx.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_40, i64 24
  %38 = getelementptr inbounds nuw i8, ptr %ctx, i64 856
  %39 = getelementptr inbounds nuw i8, ptr %stack, i64 16
  %40 = getelementptr inbounds nuw i8, ptr %stack, i64 8
  %41 = getelementptr inbounds nuw i8, ptr %ctx, i64 863
  %42 = getelementptr inbounds nuw i8, ptr %ctx, i64 854
  %43 = getelementptr inbounds nuw i8, ptr %_923, i64 8
  %44 = getelementptr inbounds nuw i8, ptr %ctx, i64 464
  %45 = getelementptr inbounds nuw i8, ptr %ctx, i64 160
  %46 = getelementptr inbounds nuw i8, ptr %ctx, i64 853
  %47 = getelementptr inbounds nuw i8, ptr %_893, i64 8
  %_1324 = getelementptr inbounds nuw i8, ptr %ctx, i64 848
  %_2758 = getelementptr inbounds nuw i8, ptr %ctx, i64 128
  %48 = getelementptr inbounds nuw i8, ptr %ctx, i64 136
  %49 = getelementptr inbounds nuw i8, ptr %_834, i64 8
  %_2725.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_834, i64 16
  %_2725.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_834, i64 24
  %50 = getelementptr inbounds nuw i8, ptr %_843, i64 8
  %51 = getelementptr inbounds nuw i8, ptr %_843, i64 16
  %52 = getelementptr inbounds nuw i8, ptr %_820, i64 8
  %_2692.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_820, i64 16
  %_2692.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_820, i64 24
  %53 = getelementptr inbounds nuw i8, ptr %_826, i64 8
  %54 = getelementptr inbounds nuw i8, ptr %_826, i64 16
  %55 = getelementptr inbounds nuw i8, ptr %_806, i64 8
  %_2659.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_806, i64 16
  %_2659.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_806, i64 24
  %56 = getelementptr inbounds nuw i8, ptr %_812, i64 8
  %57 = getelementptr inbounds nuw i8, ptr %_812, i64 16
  %58 = getelementptr inbounds nuw i8, ptr %_792, i64 8
  %_2626.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_792, i64 16
  %_2626.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_792, i64 24
  %59 = getelementptr inbounds nuw i8, ptr %_798, i64 8
  %60 = getelementptr inbounds nuw i8, ptr %_798, i64 16
  %61 = getelementptr inbounds nuw i8, ptr %_777, i64 8
  %_2593.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_777, i64 16
  %_2593.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_777, i64 24
  %62 = getelementptr inbounds nuw i8, ptr %_786, i64 8
  %63 = getelementptr inbounds nuw i8, ptr %_786, i64 16
  %64 = getelementptr inbounds nuw i8, ptr %_743, i64 8
  %_2530.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_743, i64 16
  %_2530.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_743, i64 24
  %65 = getelementptr inbounds nuw i8, ptr %_739, i64 8
  %66 = getelementptr inbounds nuw i8, ptr %_753, i64 8
  %_2549.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_753, i64 16
  %_2549.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_753, i64 24
  %67 = getelementptr inbounds nuw i8, ptr %_749, i64 8
  %68 = getelementptr inbounds nuw i8, ptr %_763, i64 8
  %_2568.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_763, i64 16
  %_2568.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_763, i64 24
  %69 = getelementptr inbounds nuw i8, ptr %_759, i64 8
  %70 = getelementptr inbounds nuw i8, ptr %_717, i64 8
  %_2486.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_717, i64 16
  %_2486.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_717, i64 24
  %71 = getelementptr inbounds nuw i8, ptr %_713, i64 8
  %72 = getelementptr inbounds nuw i8, ptr %_727, i64 8
  %_2505.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_727, i64 16
  %_2505.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_727, i64 24
  %73 = getelementptr inbounds nuw i8, ptr %_723, i64 8
  %74 = getelementptr inbounds nuw i8, ptr %_691, i64 8
  %_2442.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_691, i64 16
  %_2442.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_691, i64 24
  %75 = getelementptr inbounds nuw i8, ptr %_687, i64 8
  %76 = getelementptr inbounds nuw i8, ptr %_701, i64 8
  %_2461.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_701, i64 16
  %_2461.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_701, i64 24
  %77 = getelementptr inbounds nuw i8, ptr %_697, i64 8
  %78 = getelementptr inbounds nuw i8, ptr %_648, i64 8
  %_2355.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_648, i64 16
  %_2355.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_648, i64 24
  %79 = getelementptr inbounds nuw i8, ptr %_644, i64 8
  %80 = getelementptr inbounds nuw i8, ptr %_658, i64 8
  %_2374.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_658, i64 16
  %_2374.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_658, i64 24
  %81 = getelementptr inbounds nuw i8, ptr %_654, i64 8
  %82 = getelementptr inbounds nuw i8, ptr %_618, i64 8
  %_2305.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_618, i64 16
  %_2305.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_618, i64 24
  %83 = getelementptr inbounds nuw i8, ptr %_614, i64 8
  %84 = getelementptr inbounds nuw i8, ptr %_628, i64 8
  %_2324.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_628, i64 16
  %_2324.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_628, i64 24
  %85 = getelementptr inbounds nuw i8, ptr %_624, i64 8
  %86 = getelementptr inbounds nuw i8, ptr %_592, i64 8
  %_2261.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_592, i64 16
  %_2261.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_592, i64 24
  %87 = getelementptr inbounds nuw i8, ptr %_588, i64 8
  %88 = getelementptr inbounds nuw i8, ptr %_602, i64 8
  %_2280.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_602, i64 16
  %_2280.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_602, i64 24
  %89 = getelementptr inbounds nuw i8, ptr %_598, i64 8
  %90 = getelementptr inbounds nuw i8, ptr %_568, i64 8
  %_2224.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_568, i64 16
  %_2224.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_568, i64 24
  %91 = getelementptr inbounds nuw i8, ptr %_564, i64 8
  %92 = getelementptr inbounds nuw i8, ptr %_552, i64 8
  %_2199.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_552, i64 16
  %_2199.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_552, i64 24
  %93 = getelementptr inbounds nuw i8, ptr %_548, i64 8
  %94 = getelementptr inbounds nuw i8, ptr %_536, i64 8
  %_2172.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_536, i64 16
  %_2172.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_536, i64 24
  %95 = getelementptr inbounds nuw i8, ptr %_532, i64 8
  %96 = getelementptr inbounds nuw i8, ptr %_520, i64 8
  %_2147.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_520, i64 16
  %_2147.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_520, i64 24
  %97 = getelementptr inbounds nuw i8, ptr %_516, i64 8
  %98 = getelementptr inbounds nuw i8, ptr %_504, i64 8
  %_2122.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_504, i64 16
  %_2122.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_504, i64 24
  %99 = getelementptr inbounds nuw i8, ptr %_500, i64 8
  %100 = getelementptr inbounds nuw i8, ptr %_488, i64 8
  %_2097.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_488, i64 16
  %_2097.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_488, i64 24
  %101 = getelementptr inbounds nuw i8, ptr %_484, i64 8
  %102 = getelementptr inbounds nuw i8, ptr %_472, i64 8
  %_2055.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_472, i64 16
  %_2055.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_472, i64 24
  %103 = getelementptr inbounds nuw i8, ptr %_477, i64 8
  %_2062.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_477, i64 16
  %_2062.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_477, i64 24
  %104 = getelementptr inbounds nuw i8, ptr %_456, i64 8
  %_2026.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_456, i64 16
  %_2026.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_456, i64 24
  %105 = getelementptr inbounds nuw i8, ptr %_461, i64 8
  %_2033.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_461, i64 16
  %_2033.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_461, i64 24
  %106 = getelementptr inbounds nuw i8, ptr %_388, i64 8
  %_1860.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_388, i64 16
  %_1860.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_388, i64 24
  %107 = getelementptr inbounds nuw i8, ptr %_384, i64 8
  %108 = getelementptr inbounds nuw i8, ptr %_363, i64 8
  %_1808.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_363, i64 16
  %_1808.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_363, i64 24
  %109 = getelementptr inbounds nuw i8, ptr %_359, i64 8
  %110 = getelementptr inbounds nuw i8, ptr %_333, i64 8
  %_1768.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_333, i64 16
  %_1768.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_333, i64 24
  %111 = getelementptr inbounds nuw i8, ptr %_338, i64 8
  %_1775.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_338, i64 16
  %top.sroa.6.0._344.sroa_idx = getelementptr inbounds nuw i8, ptr %_344, i64 8
  %top.sroa.7.0._344.sroa_idx = getelementptr inbounds nuw i8, ptr %_344, i64 16
  %112 = getelementptr inbounds nuw i8, ptr %_313, i64 8
  %_1735.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_313, i64 16
  %113 = getelementptr inbounds nuw i8, ptr %_175, i64 8
  %_1491.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_175, i64 16
  %114 = getelementptr inbounds nuw i8, ptr %_180, i64 8
  %_1498.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_180, i64 16
  %115 = getelementptr inbounds nuw i8, ptr %_160, i64 8
  %116 = getelementptr inbounds nuw i8, ptr %_152, i64 8
  %_1438.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_152, i64 16
  %_1438.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_152, i64 24
  %117 = getelementptr inbounds nuw i8, ptr %_146, i64 8
  %118 = getelementptr inbounds nuw i8, ptr %_146, i64 16
  br label %bb33.lr.ph, !dbg !375

bb33.lr.ph:                                       ; preds = %bb398, %bb33.lr.ph.lr.ph
  %119 = phi i32 [ %37, %bb33.lr.ph.lr.ph ], [ %176, %bb398 ]
  %opcode_pos.sroa.0.0.ph2715 = phi i32 [ 0, %bb33.lr.ph.lr.ph ], [ %134, %bb398 ]
  %cond_stack.sroa.0.0.ph2714 = phi i64 [ 0, %bb33.lr.ph.lr.ph ], [ %cond_stack.sroa.0.1, %bb398 ]
  %cond_stack.sroa.14.0.ph2713 = phi i64 [ undef, %bb33.lr.ph.lr.ph ], [ %cond_stack.sroa.14.1, %bb398 ]
  %cond_stack.sroa.19.0.ph2712 = phi i64 [ 0, %bb33.lr.ph.lr.ph ], [ %cond_stack.sroa.19.1, %bb398 ]
  %_2.not.i = icmp eq i64 %cond_stack.sroa.0.0.ph2714, 0
  br label %bb33, !dbg !375

bb33:                                             ; preds = %bb395, %bb33.lr.ph
  %120 = phi i32 [ %119, %bb33.lr.ph ], [ %138, %bb395 ]
  %opcode_pos.sroa.0.02709 = phi i32 [ %opcode_pos.sroa.0.0.ph2715, %bb33.lr.ph ], [ %134, %bb395 ]
  %item.sroa.3.sroa.2.0.copyload = load i64, ptr %item.sroa.3.sroa.2.0.item.sroa.3.0._40.sroa_idx.sroa_idx, align 8, !dbg !381
  %item.sroa.3.sroa.3.sroa.0.0.copyload = load ptr, ptr %item.sroa.3.sroa.3.0.item.sroa.3.0._40.sroa_idx.sroa_idx, align 8, !dbg !381
  %item.sroa.3.sroa.3.sroa.3.0.copyload = load i64, ptr %item.sroa.3.sroa.3.sroa.3.0.item.sroa.3.sroa.3.0.item.sroa.3.0._40.sroa_idx.sroa_idx.sroa_idx, align 8, !dbg !381
  %.not320 = icmp eq i32 %120, 5, !dbg !382
  br i1 %.not320, label %bb512, label %bb511, !dbg !389

bb34:                                             ; preds = %bb398, %bb395
  %cond_stack.sroa.19.0.ph.lcssa2701 = phi i64 [ %cond_stack.sroa.19.0.ph2712, %bb395 ], [ %cond_stack.sroa.19.1, %bb398 ]
  call void @llvm.lifetime.end.p0(ptr nonnull %_40), !dbg !378
  call void @llvm.lifetime.end.p0(ptr nonnull %iter1), !dbg !379
  %_0.i446 = icmp eq i64 %cond_stack.sroa.19.0.ph.lcssa2701, 0, !dbg !390
  br i1 %_0.i446, label %bb400, label %bb401, !dbg !380

bb401:                                            ; preds = %bb34
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !394, !noalias !416
  %121 = call noundef dereferenceable_or_null(13) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 13, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !419, !noalias !416
  %122 = icmp eq ptr %121, null, !dbg !424
  br i1 %122, label %bb1022, label %bb1023, !dbg !425

bb400:                                            ; preds = %bb34, %bb34.thread
  %123 = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !426
  store i8 1, ptr %123, align 8, !dbg !426
  store i64 -9223372036854775797, ptr %_0, align 8, !dbg !426
  call void @llvm.lifetime.end.p0(ptr nonnull %op_count), !dbg !427
  call void @llvm.experimental.noalias.scope.decl(metadata !428), !dbg !431
  %_1.val.i = load ptr, ptr %36, align 8, !dbg !432, !alias.scope !428, !nonnull !13, !noundef !13
  %_1.val1.i = load i64, ptr %35, align 8, !dbg !432, !alias.scope !428, !noundef !13
  call void @llvm.experimental.noalias.scope.decl(metadata !435), !dbg !438
  %_73.i.i.i = icmp eq i64 %_1.val1.i, 0, !dbg !442
  br i1 %_73.i.i.i, label %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i", label %bb2.i.i.i, !dbg !442

bb2.i.i.i:                                        ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i", %bb400
  %_3.sroa.0.04.i.i.i = phi i64 [ %124, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i" ], [ 0, %bb400 ]
  %_6.i.i.i = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1.val.i, i64 %_3.sroa.0.04.i.i.i, !dbg !442
  %124 = add nuw i64 %_3.sroa.0.04.i.i.i, 1, !dbg !442
  call void @llvm.experimental.noalias.scope.decl(metadata !445), !dbg !442
  %_1.val.i.i.i.i = load i64, ptr %_6.i.i.i, align 8, !dbg !448, !range !451, !alias.scope !452, !noalias !428, !noundef !13
  %125 = icmp eq i64 %_1.val.i.i.i.i, 0, !dbg !453
  br i1 %125, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i", label %bb2.i.i.i.i.i.i.i, !dbg !453

bb2.i.i.i.i.i.i.i:                                ; preds = %bb2.i.i.i
  %126 = getelementptr inbounds nuw i8, ptr %_6.i.i.i, i64 8, !dbg !448
  %_1.val1.i.i.i.i = load ptr, ptr %126, align 8, !dbg !448, !alias.scope !452, !noalias !428, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i.i.i.i, i64 noundef %_1.val.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !464, !noalias !473
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i", !dbg !474

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i": ; preds = %bb2.i.i.i.i.i.i.i, %bb2.i.i.i
  %_7.i.i.i = icmp eq i64 %124, %_1.val1.i, !dbg !442
  br i1 %_7.i.i.i, label %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i", label %bb2.i.i.i, !dbg !442

"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i": ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i", %bb400
  %_1.val2.i = load i64, ptr %altstack, align 8, !dbg !432, !range !451, !alias.scope !428, !noundef !13
  %127 = icmp eq i64 %_1.val2.i, 0, !dbg !475
  br i1 %127, label %"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit", label %bb2.i.i.i.i, !dbg !475

bb2.i.i.i.i:                                      ; preds = %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i"
  %alloc_size.i.i.i.i.i = mul nuw i64 %_1.val2.i, 24, !dbg !482
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val.i, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #16, !dbg !485, !noalias !428
  br label %"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit", !dbg !490

"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit": ; preds = %bb2.i.i.i.i, %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i"
  call void @llvm.lifetime.end.p0(ptr nonnull %altstack), !dbg !431
  br label %bb449, !dbg !491

bb1022:                                           ; preds = %bb401
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 13) #17, !dbg !492
  unreachable, !dbg !492

bb1023:                                           ; preds = %bb401
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %121, ptr noundef nonnull align 1 dereferenceable(13) @alloc_57992395b01facdbc4733c410b510dc6, i64 13, i1 false), !dbg !494
  store i64 13, ptr %_0, align 8, !dbg !500
  %_954.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !500
  store ptr %121, ptr %_954.sroa.4.0._0.sroa_idx, align 8, !dbg !500
  %_954.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !500
  store i64 13, ptr %_954.sroa.5.0._0.sroa_idx, align 8, !dbg !500
  br label %bb446, !dbg !501

bb446:                                            ; preds = %bb445, %bb1023
  call void @llvm.lifetime.end.p0(ptr nonnull %op_count), !dbg !427
  call void @llvm.experimental.noalias.scope.decl(metadata !503), !dbg !431
  %_1.val.i454 = load ptr, ptr %36, align 8, !dbg !506, !alias.scope !503, !nonnull !13, !noundef !13
  %_1.val1.i455 = load i64, ptr %35, align 8, !dbg !506, !alias.scope !503, !noundef !13
  call void @llvm.experimental.noalias.scope.decl(metadata !508), !dbg !511
  %_73.i.i.i456 = icmp eq i64 %_1.val1.i455, 0, !dbg !513
  br i1 %_73.i.i.i456, label %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i465", label %bb2.i.i.i457, !dbg !513

bb2.i.i.i457:                                     ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i463", %bb446
  %_3.sroa.0.04.i.i.i458 = phi i64 [ %128, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i463" ], [ 0, %bb446 ]
  %_6.i.i.i459 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1.val.i454, i64 %_3.sroa.0.04.i.i.i458, !dbg !513
  %128 = add nuw i64 %_3.sroa.0.04.i.i.i458, 1, !dbg !513
  call void @llvm.experimental.noalias.scope.decl(metadata !515), !dbg !513
  %_1.val.i.i.i.i460 = load i64, ptr %_6.i.i.i459, align 8, !dbg !518, !range !451, !alias.scope !520, !noalias !503, !noundef !13
  %129 = icmp eq i64 %_1.val.i.i.i.i460, 0, !dbg !521
  br i1 %129, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i463", label %bb2.i.i.i.i.i.i.i461, !dbg !521

bb2.i.i.i.i.i.i.i461:                             ; preds = %bb2.i.i.i457
  %130 = getelementptr inbounds nuw i8, ptr %_6.i.i.i459, i64 8, !dbg !518
  %_1.val1.i.i.i.i462 = load ptr, ptr %130, align 8, !dbg !518, !alias.scope !520, !noalias !503, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i.i.i.i462, i64 noundef %_1.val.i.i.i.i460, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !526, !noalias !531
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i463", !dbg !532

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i463": ; preds = %bb2.i.i.i.i.i.i.i461, %bb2.i.i.i457
  %_7.i.i.i464 = icmp eq i64 %128, %_1.val1.i455, !dbg !513
  br i1 %_7.i.i.i464, label %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i465", label %bb2.i.i.i457, !dbg !513

"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i465": ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit.i.i.i463", %bb446
  %_1.val2.i466 = load i64, ptr %altstack, align 8, !dbg !506, !range !451, !alias.scope !503, !noundef !13
  %131 = icmp eq i64 %_1.val2.i466, 0, !dbg !533
  br i1 %131, label %"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit469", label %bb2.i.i.i.i467, !dbg !533

bb2.i.i.i.i467:                                   ; preds = %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i465"
  %alloc_size.i.i.i.i.i468 = mul nuw i64 %_1.val2.i466, 24, !dbg !538
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val.i454, i64 noundef %alloc_size.i.i.i.i.i468, i64 noundef range(i64 1, -9223372036854775807) 8) #16, !dbg !540, !noalias !503
  br label %"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit469", !dbg !545

"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit469": ; preds = %bb2.i.i.i.i467, %"_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E.exit.i465"
  call void @llvm.lifetime.end.p0(ptr nonnull %altstack), !dbg !431
  br label %bb449, !dbg !119

bb449:                                            ; preds = %bb496, %bb509, %"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit469", %"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE.exit", %bb503, %bb4
  ret void, !dbg !491

bb511:                                            ; preds = %bb33
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !546, !noalias !573
  %132 = call noundef dereferenceable_or_null(12) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 12, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !578, !noalias !573
  %133 = icmp eq ptr %132, null, !dbg !583
  br i1 %133, label %bb5.i470, label %"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17h0dacae20f2481f43E.exit", !dbg !584

bb5.i470:                                         ; preds = %bb511
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 12) #17, !dbg !585, !noalias !587
  unreachable, !dbg !585

"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17h0dacae20f2481f43E.exit": ; preds = %bb511
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(12) %132, ptr noundef nonnull align 1 dereferenceable(12) @alloc_bac92b6a7d9efcf42ce1b95a83da0ec1, i64 12, i1 false), !dbg !588, !noalias !587
  store i64 12, ptr %_0, align 8, !dbg !594
  %_1066.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !594
  store ptr %132, ptr %_1066.sroa.2.0._0.sroa_idx, align 8, !dbg !594
  %_1066.sroa.2.sroa.2.0._1066.sroa.2.0._0.sroa_idx.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !594
  store i64 12, ptr %_1066.sroa.2.sroa.2.0._1066.sroa.2.0._0.sroa_idx.sroa_idx, align 8, !dbg !594
  br label %bb445, !dbg !602

bb512:                                            ; preds = %bb33
  %134 = call i32 @llvm.uadd.sat.i32(i32 %opcode_pos.sroa.0.02709, i32 1), !dbg !604
  %135 = icmp eq ptr %item.sroa.3.sroa.3.sroa.0.0.copyload, null, !dbg !610
  br i1 %135, label %bb36, label %bb37, !dbg !612

bb36:                                             ; preds = %bb512
  %ins.sroa.3.8.extract.trunc = trunc i64 %item.sroa.3.sroa.3.sroa.3.0.copyload to i8, !dbg !613
  call void @llvm.lifetime.start.p0(ptr nonnull %code), !dbg !614
  store i8 %ins.sroa.3.8.extract.trunc, ptr %code, align 1, !dbg !616
  %_71 = icmp ult i8 %ins.sroa.3.8.extract.trunc, 97
  %or.cond.not = or i1 %_0.i, %_71, !dbg !622
  br i1 %or.cond.not, label %bb51, label %bb48, !dbg !622

bb37:                                             ; preds = %bb512
  %_54 = icmp ugt i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, 520, !dbg !624
  br i1 %_54, label %bb38, label %bb39, !dbg !624

bb39:                                             ; preds = %bb37
  br i1 %_2.not.i, label %bb40, label %bb395, !dbg !627

bb38:                                             ; preds = %bb37
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !628, !noalias !650
  %136 = call noundef dereferenceable_or_null(14) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 14, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !653, !noalias !650
  %137 = icmp eq ptr %136, null, !dbg !658
  br i1 %137, label %bb518, label %bb519, !dbg !659

bb395:                                            ; preds = %bb394, %bb534, %bb39
  call void @llvm.lifetime.end.p0(ptr nonnull %_40), !dbg !378
  call void @llvm.lifetime.start.p0(ptr nonnull %_40), !dbg !375
  call void @"_ZN118_$LT$bitcoin..blockdata..script..instruction..InstructionIndices$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h6d281e0b32b4cb98E"(ptr noalias noundef nonnull sret([40 x i8]) align 8 captures(address) dereferenceable(40) %_40, ptr noalias noundef nonnull align 8 dereferenceable(32) %iter1) #16, !dbg !375
  %138 = load i32, ptr %_40, align 8, !dbg !375, !range !377, !noundef !13
  %.not = icmp eq i32 %138, 6, !dbg !375
  br i1 %.not, label %bb34, label %bb33, !dbg !375

bb40:                                             ; preds = %bb39
  %139 = load i8, ptr %38, align 8, !dbg !660, !range !144, !noundef !13
  %_58 = trunc nuw i8 %139 to i1, !dbg !660
  br i1 %_58, label %bb41, label %bb18.i478, !dbg !660

bb18.i478:                                        ; preds = %bb40
  %_67 = load i64, ptr %35, align 8, !dbg !661, !noundef !13
  %_1111 = icmp ult i64 %_67, 384307168202282326, !dbg !663
  call void @llvm.assume(i1 %_1111), !dbg !665
  %140 = icmp eq i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, 0, !dbg !666
  br i1 %140, label %bb529, label %bb3.i479, !dbg !666

bb3.i479.sink.split:                              ; preds = %_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E.exit, %bb15.i, %bb11.i, %bb8.i488, %bb6.i
  %_673578 = load i64, ptr %35, align 8, !dbg !661, !noundef !13
  %_11113579 = icmp ult i64 %_673578, 384307168202282326, !dbg !663
  call void @llvm.assume(i1 %_11113579), !dbg !665
  br label %bb3.i479, !dbg !680

bb3.i479:                                         ; preds = %bb3.i479.sink.split, %bb18.i478
  %_671707 = phi i64 [ %_67, %bb18.i478 ], [ %_673578, %bb3.i479.sink.split ]
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !680, !noalias !681
  %141 = call noundef ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef %item.sroa.3.sroa.3.sroa.3.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !684, !noalias !681
  %142 = icmp eq ptr %141, null, !dbg !689
  br i1 %142, label %bb531, label %bb528, !dbg !690

bb41:                                             ; preds = %bb40
  %_1087 = icmp ult i64 %item.sroa.3.sroa.2.0.copyload, %script.1, !dbg !691
  br i1 %_1087, label %bb520, label %bb522, !dbg !691

bb520:                                            ; preds = %bb41
  %_1089 = getelementptr inbounds nuw i8, ptr %script.0, i64 %item.sroa.3.sroa.2.0.copyload, !dbg !699
  %_1090 = load i8, ptr %_1089, align 1, !dbg !700, !noundef !13
  br label %bb522, !dbg !706

bb522:                                            ; preds = %bb520, %bb41
  %opcode.sroa.0.0 = phi i8 [ %_1090, %bb520 ], [ 0, %bb41 ], !dbg !709
  switch i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, label %bb10.i489 [
    i64 0, label %bb1.i
    i64 1, label %bb4.i486
  ], !dbg !710

bb1.i:                                            ; preds = %bb522
  %143 = icmp eq i8 %opcode.sroa.0.0, 0, !dbg !714
  br i1 %143, label %bb18.i478.thread1708, label %bb44, !dbg !715

bb18.i478.thread1708:                             ; preds = %bb1.i
  %_671709 = load i64, ptr %35, align 8, !dbg !661, !noundef !13
  %_11111710 = icmp ult i64 %_671709, 384307168202282326, !dbg !663
  call void @llvm.assume(i1 %_11111710), !dbg !665
  br label %bb529, !dbg !666

bb4.i486:                                         ; preds = %bb522
  %_4.i = load i8, ptr %item.sroa.3.sroa.3.sroa.0.0.copyload, align 1, !dbg !716, !alias.scope !717, !noundef !13
  %144 = add i8 %_4.i, -1, !dbg !716
  %or.cond.i = icmp ult i8 %144, 16, !dbg !716
  br i1 %or.cond.i, label %bb6.i, label %bb7.i487, !dbg !716

bb6.i:                                            ; preds = %bb4.i486
  %_7.i = add nuw nsw i8 %_4.i, 80, !dbg !720
  %145 = icmp eq i8 %opcode.sroa.0.0, %_7.i, !dbg !721
  br i1 %145, label %bb3.i479.sink.split, label %bb44, !dbg !715

bb7.i487:                                         ; preds = %bb4.i486
  %146 = icmp eq i8 %_4.i, -127, !dbg !722
  br i1 %146, label %bb8.i488, label %bb11.i, !dbg !722

bb8.i488:                                         ; preds = %bb7.i487
  %147 = icmp eq i8 %opcode.sroa.0.0, 79, !dbg !723
  br i1 %147, label %bb3.i479.sink.split, label %bb44, !dbg !715

bb10.i489:                                        ; preds = %bb522
  %_10.i = icmp samesign ult i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, 76, !dbg !724
  br i1 %_10.i, label %bb11.i, label %bb12.i490, !dbg !724

bb12.i490:                                        ; preds = %bb10.i489
  %_12.i = icmp samesign ult i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, 256, !dbg !725
  br i1 %_12.i, label %_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E.exit, label %bb15.i, !dbg !725

bb11.i:                                           ; preds = %bb10.i489, %bb7.i487
  %_11.i = zext i8 %opcode.sroa.0.0 to i64, !dbg !726
  %148 = icmp eq i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, %_11.i, !dbg !726
  br i1 %148, label %bb3.i479.sink.split, label %bb44, !dbg !715

bb15.i:                                           ; preds = %bb12.i490
  %149 = icmp eq i8 %opcode.sroa.0.0, 77, !dbg !727
  br i1 %149, label %bb3.i479.sink.split, label %bb44, !dbg !715

_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E.exit: ; preds = %bb12.i490
  %150 = icmp eq i8 %opcode.sroa.0.0, 76, !dbg !728
  br i1 %150, label %bb3.i479.sink.split, label %bb44, !dbg !715

bb44:                                             ; preds = %_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E.exit, %bb15.i, %bb11.i, %bb8.i488, %bb6.i, %bb1.i
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !729, !noalias !751
  %151 = call noundef dereferenceable_or_null(11) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 11, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !754, !noalias !751
  %152 = icmp eq ptr %151, null, !dbg !759
  br i1 %152, label %bb526, label %bb527, !dbg !760

bb526:                                            ; preds = %bb44
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 11) #17, !dbg !761
  unreachable, !dbg !761

bb527:                                            ; preds = %bb44
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(11) %151, ptr noundef nonnull align 1 dereferenceable(11) @alloc_d5eeb53942d82c403fb4980373f99e0a, i64 11, i1 false), !dbg !763
  store i64 11, ptr %_0, align 8, !dbg !769
  %_63.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !769
  store ptr %151, ptr %_63.sroa.4.0._0.sroa_idx, align 8, !dbg !769
  %_63.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !769
  store i64 11, ptr %_63.sroa.5.0._0.sroa_idx, align 8, !dbg !769
  br label %bb445, !dbg !770

bb531:                                            ; preds = %bb3.i479
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 %item.sroa.3.sroa.3.sroa.3.0.copyload) #17, !dbg !772
  unreachable, !dbg !772

bb529:                                            ; preds = %bb528, %bb18.i478.thread1708, %bb18.i478
  %_671706 = phi i64 [ %_671707, %bb528 ], [ %_671709, %bb18.i478.thread1708 ], [ %_67, %bb18.i478 ]
  %153 = phi ptr [ %141, %bb528 ], [ inttoptr (i64 1 to ptr), %bb18.i478.thread1708 ], [ inttoptr (i64 1 to ptr), %bb18.i478 ]
  call void @llvm.experimental.noalias.scope.decl(metadata !774), !dbg !777
  %_7.i499 = load i64, ptr %39, align 8, !dbg !778, !alias.scope !774, !noalias !783, !noundef !13
  %_11.i500 = icmp ult i64 %_7.i499, 384307168202282326, !dbg !786
  call void @llvm.assume(i1 %_11.i500), !dbg !788
  %154 = add nuw nsw i64 %_7.i499, %_671706, !dbg !789
  %_4.i501 = icmp samesign ugt i64 %154, 999, !dbg !792
  br i1 %_4.i501, label %bb1.i504, label %bb2.i502, !dbg !792

bb2.i502:                                         ; preds = %bb529
  %self1.i.i = load i64, ptr %stack, align 8, !dbg !793, !range !451, !alias.scope !803, !noalias !806, !noundef !13
  %_4.i.i = icmp eq i64 %_7.i499, %self1.i.i, !dbg !808
  br i1 %_4.i.i, label %bb1.i.i, label %bb534, !dbg !808

bb1.i.i:                                          ; preds = %bb2.i502
  call void @_RNvMs3_NtCslNYArtu3iFV_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VechEE8grow_oneCsjrHSEGnQ3l9_3std(ptr noalias noundef nonnull align 8 dereferenceable(24) %stack) #18, !dbg !809, !noalias !806
  br label %bb534, !dbg !810

bb1.i504:                                         ; preds = %bb529
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !811, !noalias !834
  %155 = call noundef dereferenceable_or_null(10) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 10, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !837, !noalias !834
  %156 = icmp eq ptr %155, null, !dbg !842
  br i1 %156, label %bb10.i506, label %bb11.i505, !dbg !843

bb10.i506:                                        ; preds = %bb1.i504
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 10) #17, !dbg !844, !noalias !846
  unreachable, !dbg !844

bb11.i505:                                        ; preds = %bb1.i504
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(10) %155, ptr noundef nonnull align 1 dereferenceable(10) @alloc_369ee17d61227813032237a0166bc7fe, i64 10, i1 false), !dbg !847, !noalias !846
  %157 = icmp eq i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, 0, !dbg !853
  br i1 %157, label %bb533, label %bb2.i.i.i.i.i, !dbg !853

bb2.i.i.i.i.i:                                    ; preds = %bb11.i505
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %153, i64 noundef %item.sroa.3.sroa.3.sroa.3.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !859, !noalias !864
  br label %bb533, !dbg !867

bb528:                                            ; preds = %bb3.i479
  call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %141, ptr nonnull align 1 %item.sroa.3.sroa.3.sroa.0.0.copyload, i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, i1 false), !dbg !868
  br label %bb529, !dbg !874

bb533:                                            ; preds = %bb2.i.i.i.i.i, %bb11.i505
  store i64 10, ptr %_0, align 8, !dbg !875
  %_1132.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !875
  store ptr %155, ptr %_1132.sroa.2.0._0.sroa_idx, align 8, !dbg !875
  %_1132.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !875
  store i64 10, ptr %_1132.sroa.3.0._0.sroa_idx, align 8, !dbg !875
  br label %bb445, !dbg !770

bb534:                                            ; preds = %bb1.i.i, %bb2.i502
  %_14.i.i = load ptr, ptr %40, align 8, !dbg !881, !alias.scope !803, !noalias !806, !nonnull !13, !noundef !13
  %end.i.i = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_14.i.i, i64 %_7.i499, !dbg !890
  store i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, ptr %end.i.i, align 8, !dbg !893, !noalias !897
  %_68.sroa.5.0.end.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %end.i.i, i64 8, !dbg !893
  store ptr %153, ptr %_68.sroa.5.0.end.i.i.sroa_idx, align 8, !dbg !893, !noalias !897
  %_68.sroa.8.0.end.i.i.sroa_idx = getelementptr inbounds nuw i8, ptr %end.i.i, i64 16, !dbg !893
  store i64 %item.sroa.3.sroa.3.sroa.3.0.copyload, ptr %_68.sroa.8.0.end.i.i.sroa_idx, align 8, !dbg !893, !noalias !897
  %158 = add nuw nsw i64 %_7.i499, 1, !dbg !898
  store i64 %158, ptr %39, align 8, !dbg !898, !alias.scope !803, !noalias !806
  br label %bb395, !dbg !899

bb518:                                            ; preds = %bb38
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 14) #17, !dbg !900
  unreachable, !dbg !900

bb519:                                            ; preds = %bb38
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(14) %136, ptr noundef nonnull align 1 dereferenceable(14) @alloc_1ef5ffa3c70b9a1a8714a694c19a3b32, i64 14, i1 false), !dbg !902
  store i64 14, ptr %_0, align 8, !dbg !908
  %_56.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !908
  store ptr %136, ptr %_56.sroa.4.0._0.sroa_idx, align 8, !dbg !908
  %_56.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !908
  store i64 14, ptr %_56.sroa.5.0._0.sroa_idx, align 8, !dbg !908
  br label %bb445, !dbg !770

bb51:                                             ; preds = %bb48, %bb36
  switch i8 %ins.sroa.3.8.extract.trunc, label %bb86 [
    i8 99, label %bb56
    i8 100, label %bb55
    i8 103, label %bb54
    i8 104, label %bb53
    i8 101, label %bb87
    i8 102, label %bb87
  ], !dbg !909

bb48:                                             ; preds = %bb36
  %159 = load i64, ptr %op_count, align 8, !dbg !910, !noundef !13
  %160 = add i64 %159, 1, !dbg !910
  store i64 %160, ptr %op_count, align 8, !dbg !910
  %_72 = icmp ugt i64 %160, 201, !dbg !911
  br i1 %_72, label %bb49, label %bb51, !dbg !911

bb49:                                             ; preds = %bb48
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !912, !noalias !934
  %161 = call noundef dereferenceable_or_null(8) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 8, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !937, !noalias !934
  %162 = icmp eq ptr %161, null, !dbg !942
  br i1 %162, label %bb538, label %bb539, !dbg !943

bb56:                                             ; preds = %bb51
  br i1 %_2.not.i, label %bb57, label %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit, !dbg !944

bb55:                                             ; preds = %bb51
  br i1 %_2.not.i, label %bb67, label %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578, !dbg !946

bb54:                                             ; preds = %bb51
  %_0.i515 = icmp eq i64 %cond_stack.sroa.19.0.ph2712, 0, !dbg !948
  br i1 %_0.i515, label %bb78, label %bb79, !dbg !950

bb53:                                             ; preds = %bb51
  %_0.i516 = icmp eq i64 %cond_stack.sroa.19.0.ph2712, 0, !dbg !951
  br i1 %_0.i516, label %bb82, label %bb83, !dbg !953

bb57:                                             ; preds = %bb56
  call void @llvm.experimental.noalias.scope.decl(metadata !954), !dbg !957
  %_3.i517 = load i64, ptr %39, align 8, !dbg !958, !alias.scope !954, !noalias !963, !noundef !13
  %163 = icmp eq i64 %_3.i517, 0, !dbg !958
  br i1 %163, label %bb1.i523, label %bb541, !dbg !958

bb1.i523:                                         ; preds = %bb57
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !965, !noalias !993
  %164 = call noundef dereferenceable_or_null(11) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 11, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !998, !noalias !993
  %165 = icmp eq ptr %164, null, !dbg !1003
  br i1 %165, label %bb5.i.i, label %bb540, !dbg !1004

bb5.i.i:                                          ; preds = %bb1.i523
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 11) #17, !dbg !1005, !noalias !1007
  unreachable, !dbg !1005

bb65:                                             ; preds = %bb2.i.i.i.i536, %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit
  %spec.select1718 = select i1 %_0.sroa.0.0.i532, i64 %cond_stack.sroa.14.0.ph2713, i64 %cond_stack.sroa.19.0.ph2712, !dbg !1008
  %not._0.sroa.0.0.i532 = xor i1 %_0.sroa.0.0.i532, true, !dbg !1008
  %spec.select1719 = zext i1 %not._0.sroa.0.0.i532 to i64, !dbg !1008
  br label %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit, !dbg !1008

_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit: ; preds = %bb65, %bb56
  %cond_stack.sroa.14.2 = phi i64 [ %spec.select1718, %bb65 ], [ %cond_stack.sroa.14.0.ph2713, %bb56 ]
  %cond_stack.sroa.0.2 = phi i64 [ %spec.select1719, %bb65 ], [ 1, %bb56 ], !dbg !1011
  %166 = add i64 %cond_stack.sroa.19.0.ph2712, 1, !dbg !1012
  br label %bb398, !dbg !1013

bb540:                                            ; preds = %bb1.i523
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(11) %164, ptr noundef nonnull align 1 dereferenceable(11) @alloc_43f0806753e598d0be3212342fe980ba, i64 11, i1 false), !dbg !1015, !noalias !1007
  store i64 11, ptr %_0, align 8, !dbg !1021
  %_1158.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1021
  store ptr %164, ptr %_1158.sroa.2.0._0.sroa_idx, align 8, !dbg !1021
  %_1158.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1021
  store i64 11, ptr %_1158.sroa.3.0._0.sroa_idx, align 8, !dbg !1021
  br label %bb443, !dbg !1027

bb541:                                            ; preds = %bb57
  %167 = add nsw i64 %_3.i517, -1, !dbg !1029
  store i64 %167, ptr %39, align 8, !dbg !1029, !alias.scope !954, !noalias !963
  %_11.i519 = load i64, ptr %stack, align 8, !dbg !1030, !range !451, !alias.scope !954, !noalias !963, !noundef !13
  %_4.i520 = icmp samesign ult i64 %167, %_11.i519, !dbg !1037
  call void @llvm.assume(i1 %_4.i520), !dbg !1038
  %_12.i521 = load ptr, ptr %40, align 8, !dbg !1043, !alias.scope !954, !noalias !963, !nonnull !13, !noundef !13
  %_13.i = icmp ult i64 %_3.i517, 384307168202282327, !dbg !1052
  call void @llvm.assume(i1 %_13.i), !dbg !1056
  %_8.i = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_12.i521, i64 %167, !dbg !1057
  %_78.sroa.5.8.copyload1209 = load i64, ptr %_8.i, align 8, !dbg !1060, !noalias !954
  %_78.sroa.9.8._8.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 8, !dbg !1060
  %_78.sroa.9.8.copyload1211 = load ptr, ptr %_78.sroa.9.8._8.i.sroa_idx, align 8, !dbg !1060, !noalias !954, !nonnull !13, !noundef !13
  %_78.sroa.10.8._8.i.sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i, i64 16, !dbg !1060
  %_78.sroa.10.8.copyload1213 = load i64, ptr %_78.sroa.10.8._8.i.sroa_idx, align 8, !dbg !1060, !noalias !954
  br i1 %minimal_if.sroa.0.0, label %bb59, label %bb62, !dbg !1063

bb62:                                             ; preds = %bb541
  %_10.not.i = icmp eq i64 %_78.sroa.10.8.copyload1213, 0, !dbg !1065
  br i1 %_10.not.i, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit, label %bb6.i527, !dbg !1065

bb6.i527:                                         ; preds = %_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit, %bb62
  %168 = getelementptr i8, ptr %_78.sroa.9.8.copyload1211, i64 %_78.sroa.10.8.copyload1213, !dbg !1072
  %_12.i528 = getelementptr i8, ptr %168, i64 -1, !dbg !1072
  %_14.i529 = load i8, ptr %_12.i528, align 1, !dbg !1073, !alias.scope !1080, !noundef !13
  %_6.i530 = and i8 %_14.i529, 127, !dbg !1083
  %169 = icmp eq i8 %_6.i530, 0, !dbg !1088
  br i1 %169, label %bb1.i.i533, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit, !dbg !1088

bb1.i.i533:                                       ; preds = %bb13.i.i, %bb6.i527
  %_221.i.i = phi ptr [ %_22.i.i, %bb13.i.i ], [ %_78.sroa.9.8.copyload1211, %bb6.i527 ]
  %_12.i.not.not.i.not.not = icmp ne ptr %_221.i.i, %_12.i528, !dbg !1089
  br i1 %_12.i.not.not.i.not.not, label %bb13.i.i, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit, !dbg !1099

bb13.i.i:                                         ; preds = %bb1.i.i533
  %_22.i.i = getelementptr inbounds nuw i8, ptr %_221.i.i, i64 1, !dbg !1100
  %ptr.val.i.i = load i8, ptr %_221.i.i, align 1, !dbg !1103, !alias.scope !1080, !noalias !1104, !noundef !13
  %_0.i.i.i534 = icmp eq i8 %ptr.val.i.i, 0, !dbg !1107
  br i1 %_0.i.i.i534, label %bb1.i.i533, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit, !dbg !1103

_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit: ; preds = %bb59, %bb13.i.i, %bb1.i.i533, %bb6.i527, %bb62
  %_0.sroa.0.0.i532 = phi i1 [ false, %bb62 ], [ true, %bb6.i527 ], [ false, %bb59 ], [ %_12.i.not.not.i.not.not, %bb13.i.i ], [ %_12.i.not.not.i.not.not, %bb1.i.i533 ], !dbg !1112
  %170 = icmp eq i64 %_78.sroa.5.8.copyload1209, 0, !dbg !1113
  br i1 %170, label %bb65, label %bb2.i.i.i.i536, !dbg !1113

bb2.i.i.i.i536:                                   ; preds = %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_78.sroa.9.8.copyload1211, i64 noundef %_78.sroa.5.8.copyload1209, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1119, !noalias !1124
  br label %bb65, !dbg !1127

bb59:                                             ; preds = %bb541
  switch i64 %_78.sroa.10.8.copyload1213, label %bb61 [
    i64 0, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit
    i64 1, label %_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit
  ], !dbg !1128

_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit: ; preds = %bb59
  %171 = load i8, ptr %_78.sroa.9.8.copyload1211, align 1, !dbg !1131, !alias.scope !1148
  %172 = icmp eq i8 %171, 1, !dbg !1131
  br i1 %172, label %bb6.i527, label %bb61, !dbg !1151

bb61:                                             ; preds = %_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit, %bb59
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1152, !noalias !1174
  %173 = call noundef dereferenceable_or_null(9) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 9, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1177, !noalias !1174
  %174 = icmp eq ptr %173, null, !dbg !1182
  br i1 %174, label %bb545, label %bb546, !dbg !1183

bb545:                                            ; preds = %bb61
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 9) #17, !dbg !1184
  unreachable, !dbg !1184

bb546:                                            ; preds = %bb61
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %173, ptr noundef nonnull align 1 dereferenceable(9) @alloc_36c2ba1cd7284c88ed7c42994c4bf01e, i64 9, i1 false), !dbg !1186
  store i64 9, ptr %_0, align 8, !dbg !1192
  %_84.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1192
  store ptr %173, ptr %_84.sroa.4.0._0.sroa_idx, align 8, !dbg !1192
  %_84.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1192
  store i64 9, ptr %_84.sroa.5.0._0.sroa_idx, align 8, !dbg !1192
  %175 = icmp eq i64 %_78.sroa.5.8.copyload1209, 0, !dbg !1193
  br i1 %175, label %bb443, label %bb2.i.i.i.i551, !dbg !1193

bb2.i.i.i.i551:                                   ; preds = %bb546
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_78.sroa.9.8.copyload1211, i64 noundef %_78.sroa.5.8.copyload1209, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1199, !noalias !1204
  br label %bb443, !dbg !1207

bb398:                                            ; preds = %bb386, %bb101, %bb102, %bb98.thread, %bb98, %bb83, %bb2.i619, %bb79, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit
  %cond_stack.sroa.19.1 = phi i64 [ %180, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578 ], [ %194, %bb83 ], [ %cond_stack.sroa.19.0.ph2712, %bb79 ], [ %cond_stack.sroa.19.0.ph2712, %bb2.i619 ], [ %166, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit ], [ %cond_stack.sroa.19.0.ph2712, %bb98 ], [ %cond_stack.sroa.19.0.ph2712, %bb102 ], [ %cond_stack.sroa.19.0.ph2712, %bb101 ], [ %cond_stack.sroa.19.0.ph2712, %bb386 ], [ %cond_stack.sroa.19.0.ph2712, %bb98.thread ], !dbg !1011
  %cond_stack.sroa.14.1 = phi i64 [ %cond_stack.sroa.14.3, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578 ], [ %cond_stack.sroa.14.0.ph2713, %bb83 ], [ %top.i, %bb79 ], [ %cond_stack.sroa.14.0.ph2713, %bb2.i619 ], [ %cond_stack.sroa.14.2, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit ], [ %cond_stack.sroa.14.0.ph2713, %bb98 ], [ %cond_stack.sroa.14.0.ph2713, %bb102 ], [ %cond_stack.sroa.14.0.ph2713, %bb101 ], [ %cond_stack.sroa.14.0.ph2713, %bb386 ], [ %cond_stack.sroa.14.0.ph2713, %bb98.thread ]
  %cond_stack.sroa.0.1 = phi i64 [ %cond_stack.sroa.0.3, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578 ], [ %spec.select1723, %bb83 ], [ 1, %bb79 ], [ %spec.select1722, %bb2.i619 ], [ %cond_stack.sroa.0.2, %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit ], [ 1, %bb98.thread ], [ 0, %bb386 ], [ 0, %bb101 ], [ 0, %bb102 ], [ 1, %bb98 ], !dbg !1011
  call void @llvm.lifetime.end.p0(ptr nonnull %code), !dbg !1208
  call void @llvm.lifetime.end.p0(ptr nonnull %_40), !dbg !378
  call void @llvm.lifetime.start.p0(ptr nonnull %_40), !dbg !375
  call void @"_ZN118_$LT$bitcoin..blockdata..script..instruction..InstructionIndices$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h6d281e0b32b4cb98E"(ptr noalias noundef nonnull sret([40 x i8]) align 8 captures(address) dereferenceable(40) %_40, ptr noalias noundef nonnull align 8 dereferenceable(32) %iter1) #16, !dbg !375
  %176 = load i32, ptr %_40, align 8, !dbg !375, !range !377, !noundef !13
  %.not2708 = icmp eq i32 %176, 6, !dbg !375
  br i1 %.not2708, label %bb34, label %bb33.lr.ph, !dbg !375

bb443:                                            ; preds = %bb539, %bb587, %bb1003, %bb1008, %bb1014, %bb996, %bb992, %bb972, %bb980, %bb985, %bb991, %bb965, %bb961, %bb958, %bb959, %bb951, %bb952, %bb944, %bb945, %bb938, %bb936, %bb2.i.i.i.i1099, %bb933, %bb928, %bb2.i.i.i.i1083, %bb926, %bb921, %bb2.i.i.i.i1067, %bb919, %bb914, %bb2.i.i.i.i1051, %bb912, %bb907, %bb2.i.i.i.i1035, %bb905, %bb900, %bb898, %bb2.i.i.i.i1019, %bb895, %bb893, %bb2.i.i.i.i1011, %bb890, %bb888, %bb2.i.i.i.i1003, %bb885, %bb883, %bb881, %bb2.i.i.i.i994, %bb878, %bb876, %bb2.i.i.i.i986, %bb873, %bb871, %bb869, %bb2.i.i.i.i978, %bb866, %bb864, %bb2.i.i.i.i970, %bb861, %bb859, %bb857, %bb855, %bb853, %bb851, %bb849, %bb848, %bb2.i.i.i.i954, %bb841, %bb839, %bb2.i.i.i.i946, %bb836, %bb834, %bb832, %bb830, %bb2.i.i.i.i938, %bb827, %bb825, %bb2.i.i.i.i930, %bb822, %bb820, %bb818, %bb2.i.i.i.i922, %bb815, %bb813, %bb2.i.i.i.i914, %bb810, %bb808, %bb806, %bb804, %bb802, %bb2.i.i.i.i906, %bb799, %bb797, %bb795, %bb2.i.i.i.i898, %bb792, %bb790, %bb788, %bb2.i.i.i.i890, %bb781, %bb779, %bb777, %bb2.i.i.i.i882, %bb774, %bb772, %bb770, %bb2.i.i.i.i874, %bb766, %bb764, %bb762, %bb2.i.i.i.i866, %bb758, %bb756, %bb2.i.i.i.i862, %bb429, %bb744, %bb2.i.i.i.i838, %bb431, %bb734, %bb732, %bb728, %bb723, %bb720, %bb715, %bb707, %bb704, %bb705, %bb2.i.i.i.i810, %bb697, %bb695, %bb691, %bb693, %bb2.i.i.i.i794, %bb684, %bb682, %bb680, %bb677, %bb675, %bb2.i.i.i.i786, %bb673, %bb671, %bb669, %bb667, %bb663, %bb661, %bb659, %bb657, %bb651, %bb643, %bb633, %bb631, %bb2.i.i.i.i751, %bb629, %bb625, %bb623, %bb2.i.i.i.i747, %bb621, %bb2.i.i.i.i743, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit741", %bb614, %bb612, %bb2.i.i.i.i735, %bb610, %bb606, %bb604, %bb602, %bb600, %bb580, %bb596, %bb2.i.i.i.i719, %bb595, %bb589, %bb100, %bb584, %bb578, %bb90, %bb569, %bb563, %bb558, %bb2.i.i.i.i612, %bb553, %bb547, %bb2.i.i.i.i551, %bb546, %bb540
  call void @llvm.lifetime.end.p0(ptr nonnull %code), !dbg !1208
  br label %bb445, !dbg !1209

bb67:                                             ; preds = %bb55
  call void @llvm.experimental.noalias.scope.decl(metadata !1211), !dbg !1214
  %_3.i554 = load i64, ptr %39, align 8, !dbg !1215, !alias.scope !1211, !noalias !1218, !noundef !13
  %177 = icmp eq i64 %_3.i554, 0, !dbg !1215
  br i1 %177, label %bb1.i563, label %bb548, !dbg !1215

bb1.i563:                                         ; preds = %bb67
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1220, !noalias !1234
  %178 = call noundef dereferenceable_or_null(11) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 11, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1239, !noalias !1234
  %179 = icmp eq ptr %178, null, !dbg !1244
  br i1 %179, label %bb5.i.i567, label %bb547, !dbg !1245

bb5.i.i567:                                       ; preds = %bb1.i563
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 11) #17, !dbg !1246, !noalias !1247
  unreachable, !dbg !1246

bb75:                                             ; preds = %bb2.i.i.i.i595, %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593
  %spec.select1720 = select i1 %184, i64 %cond_stack.sroa.14.0.ph2713, i64 %cond_stack.sroa.19.0.ph2712, !dbg !1248
  %not. = xor i1 %184, true, !dbg !1248
  %spec.select1721 = zext i1 %not. to i64, !dbg !1248
  br label %_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578, !dbg !1248

_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE.exit578: ; preds = %bb75, %bb55
  %cond_stack.sroa.14.3 = phi i64 [ %spec.select1720, %bb75 ], [ %cond_stack.sroa.14.0.ph2713, %bb55 ]
  %cond_stack.sroa.0.3 = phi i64 [ %spec.select1721, %bb75 ], [ 1, %bb55 ], !dbg !1011
  %180 = add i64 %cond_stack.sroa.19.0.ph2712, 1, !dbg !1250
  br label %bb398, !dbg !1013

bb547:                                            ; preds = %bb1.i563
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(11) %178, ptr noundef nonnull align 1 dereferenceable(11) @alloc_43f0806753e598d0be3212342fe980ba, i64 11, i1 false), !dbg !1251, !noalias !1247
  store i64 11, ptr %_0, align 8, !dbg !1254
  %_1192.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1254
  store ptr %178, ptr %_1192.sroa.2.0._0.sroa_idx, align 8, !dbg !1254
  %_1192.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1254
  store i64 11, ptr %_1192.sroa.3.0._0.sroa_idx, align 8, !dbg !1254
  br label %bb443, !dbg !1260

bb548:                                            ; preds = %bb67
  %181 = add nsw i64 %_3.i554, -1, !dbg !1262
  store i64 %181, ptr %39, align 8, !dbg !1262, !alias.scope !1211, !noalias !1218
  %_11.i556 = load i64, ptr %stack, align 8, !dbg !1263, !range !451, !alias.scope !1211, !noalias !1218, !noundef !13
  %_4.i557 = icmp samesign ult i64 %181, %_11.i556, !dbg !1267
  call void @llvm.assume(i1 %_4.i557), !dbg !1268
  %_12.i558 = load ptr, ptr %40, align 8, !dbg !1270, !alias.scope !1211, !noalias !1218, !nonnull !13, !noundef !13
  %_13.i559 = icmp ult i64 %_3.i554, 384307168202282327, !dbg !1275
  call void @llvm.assume(i1 %_13.i559), !dbg !1277
  %_8.i560 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_12.i558, i64 %181, !dbg !1278
  %_93.sroa.5.8.copyload1222 = load i64, ptr %_8.i560, align 8, !dbg !1280, !noalias !1211
  %_93.sroa.9.8._8.i560.sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i560, i64 8, !dbg !1280
  %_93.sroa.9.8.copyload1224 = load ptr, ptr %_93.sroa.9.8._8.i560.sroa_idx, align 8, !dbg !1280, !noalias !1211, !nonnull !13, !noundef !13
  %_93.sroa.10.8._8.i560.sroa_idx = getelementptr inbounds nuw i8, ptr %_8.i560, i64 16, !dbg !1280
  %_93.sroa.10.8.copyload1226 = load i64, ptr %_93.sroa.10.8._8.i560.sroa_idx, align 8, !dbg !1280, !noalias !1211
  br i1 %minimal_if.sroa.0.0, label %bb69, label %bb72, !dbg !1282

bb72:                                             ; preds = %bb548
  %_10.not.i579 = icmp eq i64 %_93.sroa.10.8.copyload1226, 0, !dbg !1284
  br i1 %_10.not.i579, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593, label %bb6.i580, !dbg !1284

bb6.i580:                                         ; preds = %_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit602, %bb72
  %182 = getelementptr i8, ptr %_93.sroa.9.8.copyload1224, i64 %_93.sroa.10.8.copyload1226, !dbg !1287
  %_12.i581 = getelementptr i8, ptr %182, i64 -1, !dbg !1287
  %_14.i582 = load i8, ptr %_12.i581, align 1, !dbg !1288, !alias.scope !1290, !noundef !13
  %_6.i583 = and i8 %_14.i582, 127, !dbg !1293
  %183 = icmp eq i8 %_6.i583, 0, !dbg !1295
  br i1 %183, label %bb1.i.i586, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593, !dbg !1295

bb1.i.i586:                                       ; preds = %bb13.i.i589, %bb6.i580
  %_221.i.i587 = phi ptr [ %_22.i.i590, %bb13.i.i589 ], [ %_93.sroa.9.8.copyload1224, %bb6.i580 ]
  %_12.i.not.not.i588 = icmp eq ptr %_221.i.i587, %_12.i581, !dbg !1296
  br i1 %_12.i.not.not.i588, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593, label %bb13.i.i589, !dbg !1300

bb13.i.i589:                                      ; preds = %bb1.i.i586
  %_22.i.i590 = getelementptr inbounds nuw i8, ptr %_221.i.i587, i64 1, !dbg !1301
  %ptr.val.i.i591 = load i8, ptr %_221.i.i587, align 1, !dbg !1303, !alias.scope !1290, !noalias !1304, !noundef !13
  %_0.i.i.i592 = icmp eq i8 %ptr.val.i.i591, 0, !dbg !1307
  br i1 %_0.i.i.i592, label %bb1.i.i586, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593, !dbg !1303

_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593: ; preds = %bb69, %bb13.i.i589, %bb1.i.i586, %bb6.i580, %bb72
  %184 = phi i1 [ true, %bb72 ], [ false, %bb6.i580 ], [ true, %bb69 ], [ %_12.i.not.not.i588, %bb13.i.i589 ], [ %_12.i.not.not.i588, %bb1.i.i586 ], !dbg !1309
  %185 = icmp eq i64 %_93.sroa.5.8.copyload1222, 0, !dbg !1310
  br i1 %185, label %bb75, label %bb2.i.i.i.i595, !dbg !1310

bb2.i.i.i.i595:                                   ; preds = %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_93.sroa.9.8.copyload1224, i64 noundef %_93.sroa.5.8.copyload1222, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1316, !noalias !1321
  br label %bb75, !dbg !1324

bb69:                                             ; preds = %bb548
  switch i64 %_93.sroa.10.8.copyload1226, label %bb71 [
    i64 0, label %_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE.exit593
    i64 1, label %_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit602
  ], !dbg !1325

_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit602: ; preds = %bb69
  %186 = load i8, ptr %_93.sroa.9.8.copyload1224, align 1, !dbg !1327, !alias.scope !1332
  %187 = icmp eq i8 %186, 1, !dbg !1327
  br i1 %187, label %bb6.i580, label %bb71, !dbg !1335

bb71:                                             ; preds = %_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE.exit602, %bb69
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1336, !noalias !1358
  %188 = call noundef dereferenceable_or_null(9) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 9, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1361, !noalias !1358
  %189 = icmp eq ptr %188, null, !dbg !1366
  br i1 %189, label %bb552, label %bb553, !dbg !1367

bb552:                                            ; preds = %bb71
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 9) #17, !dbg !1368
  unreachable, !dbg !1368

bb553:                                            ; preds = %bb71
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %188, ptr noundef nonnull align 1 dereferenceable(9) @alloc_36c2ba1cd7284c88ed7c42994c4bf01e, i64 9, i1 false), !dbg !1370
  store i64 9, ptr %_0, align 8, !dbg !1376
  %_99.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1376
  store ptr %188, ptr %_99.sroa.4.0._0.sroa_idx, align 8, !dbg !1376
  %_99.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1376
  store i64 9, ptr %_99.sroa.5.0._0.sroa_idx, align 8, !dbg !1376
  %190 = icmp eq i64 %_93.sroa.5.8.copyload1222, 0, !dbg !1377
  br i1 %190, label %bb443, label %bb2.i.i.i.i612, !dbg !1377

bb2.i.i.i.i612:                                   ; preds = %bb553
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_93.sroa.9.8.copyload1224, i64 noundef %_93.sroa.5.8.copyload1222, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1383, !noalias !1388
  br label %bb443, !dbg !1391

bb79:                                             ; preds = %bb54
  %top.i = add i64 %cond_stack.sroa.19.0.ph2712, -1, !dbg !1392
  %191 = trunc nuw i64 %cond_stack.sroa.0.0.ph2714 to i1, !dbg !1395
  br i1 %191, label %bb2.i619, label %bb398, !dbg !1395

bb2.i619:                                         ; preds = %bb79
  %_8.i620 = icmp ne i64 %cond_stack.sroa.14.0.ph2713, %top.i, !dbg !1397
  %spec.select1722 = zext i1 %_8.i620 to i64, !dbg !1397
  br label %bb398, !dbg !1397

bb78:                                             ; preds = %bb54
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1398, !noalias !1420
  %192 = call noundef dereferenceable_or_null(7) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 7, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1423, !noalias !1420
  %193 = icmp eq ptr %192, null, !dbg !1428
  br i1 %193, label %bb557, label %bb558, !dbg !1429

bb557:                                            ; preds = %bb78
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 7) #17, !dbg !1430
  unreachable, !dbg !1430

bb558:                                            ; preds = %bb78
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %192, ptr noundef nonnull align 1 dereferenceable(7) @alloc_89ddf3c5423fb9ffa41b3154201d3495, i64 7, i1 false), !dbg !1432
  store i64 7, ptr %_0, align 8, !dbg !1438
  %_107.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1438
  store ptr %192, ptr %_107.sroa.4.0._0.sroa_idx, align 8, !dbg !1438
  %_107.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1438
  store i64 7, ptr %_107.sroa.5.0._0.sroa_idx, align 8, !dbg !1438
  br label %bb443, !dbg !1013

bb83:                                             ; preds = %bb53
  %194 = add i64 %cond_stack.sroa.19.0.ph2712, -1, !dbg !1439
  %195 = trunc nuw i64 %cond_stack.sroa.0.0.ph2714 to i1, !dbg !1442
  %_2.i = icmp eq i64 %cond_stack.sroa.14.0.ph2713, %194
  %or.cond.i632 = select i1 %195, i1 %_2.i, i1 false, !dbg !1442
  %spec.select1723 = select i1 %or.cond.i632, i64 0, i64 %cond_stack.sroa.0.0.ph2714, !dbg !1442
  br label %bb398, !dbg !1442

bb82:                                             ; preds = %bb53
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1446, !noalias !1468
  %196 = call noundef dereferenceable_or_null(8) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 8, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1471, !noalias !1468
  %197 = icmp eq ptr %196, null, !dbg !1476
  br i1 %197, label %bb562, label %bb563, !dbg !1477

bb562:                                            ; preds = %bb82
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 8) #17, !dbg !1478
  unreachable, !dbg !1478

bb563:                                            ; preds = %bb82
  store i64 5064654358916845647, ptr %196, align 1, !dbg !1480
  store i64 8, ptr %_0, align 8, !dbg !1486
  %_113.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1486
  store ptr %196, ptr %_113.sroa.4.0._0.sroa_idx, align 8, !dbg !1486
  %_113.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1486
  store i64 8, ptr %_113.sroa.5.0._0.sroa_idx, align 8, !dbg !1486
  br label %bb443, !dbg !1013

bb87:                                             ; preds = %bb51, %bb51
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1487, !noalias !1509
  %198 = call noundef dereferenceable_or_null(8) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 8, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1512, !noalias !1509
  %199 = icmp eq ptr %198, null, !dbg !1517
  br i1 %199, label %bb568, label %bb569, !dbg !1518

bb86:                                             ; preds = %bb51
  %_6.val392 = load i8, ptr %_6, align 4, !dbg !1519, !range !16, !noundef !13
  %_0.i651 = icmp eq i8 %_6.val392, 2, !dbg !1523
  br i1 %_0.i651, label %bb98, label %bb88, !dbg !1522

bb568:                                            ; preds = %bb87
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 8) #17, !dbg !1525
  unreachable, !dbg !1525

bb569:                                            ; preds = %bb87
  store i64 5064669713710141519, ptr %198, align 1, !dbg !1527
  store i64 8, ptr %_0, align 8, !dbg !1533
  %_117.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1533
  store ptr %198, ptr %_117.sroa.4.0._0.sroa_idx, align 8, !dbg !1533
  %_117.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1533
  store i64 8, ptr %_117.sroa.5.0._0.sroa_idx, align 8, !dbg !1533
  br label %bb443, !dbg !1013

bb88:                                             ; preds = %bb86
  switch i8 %ins.sroa.3.8.extract.trunc, label %bb98 [
    i8 126, label %bb90
    i8 127, label %bb90
    i8 -128, label %bb90
    i8 -127, label %bb90
    i8 -125, label %bb90
    i8 -124, label %bb90
    i8 -123, label %bb90
    i8 -122, label %bb90
    i8 -115, label %bb90
    i8 -114, label %bb90
    i8 -107, label %bb90
    i8 -106, label %bb90
    i8 -105, label %bb90
    i8 -104, label %bb90
    i8 -103, label %bb90
    i8 -85, label %bb93
  ], !dbg !1534

bb90:                                             ; preds = %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88, %bb88
  call void @llvm.lifetime.start.p0(ptr nonnull %_122), !dbg !1540
  call void @llvm.lifetime.start.p0(ptr nonnull %args), !dbg !1541
  store ptr %code, ptr %args, align 8, !dbg !1541
  %_127.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 8, !dbg !1541
  store ptr @_RNvXse_NtNtCsgEmfK2I1SDS_4core3fmt3numhNtB7_8LowerHex3fmt, ptr %_127.sroa.4.0..sroa_idx, align 8, !dbg !1541
  call void @_RNvNvNtCslNYArtu3iFV_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_122, ptr noundef nonnull @alloc_3d04147c16fc2ded597f89a3f653cd9e, ptr noundef nonnull %args) #16, !dbg !1545
  call void @llvm.lifetime.end.p0(ptr nonnull %args), !dbg !1556
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_122, i64 24, i1 false), !dbg !1557
  call void @llvm.lifetime.end.p0(ptr nonnull %_122), !dbg !1558
  br label %bb443, !dbg !1013

bb93:                                             ; preds = %bb88
  %200 = load i8, ptr %41, align 1, !dbg !1559, !range !144, !noundef !13
  %_129 = trunc nuw i8 %200 to i1, !dbg !1559
  %_0.i655 = icmp eq i8 %_6.val392, 0
  %or.cond = and i1 %_0.i655, %_129, !dbg !1559
  br i1 %or.cond, label %bb96, label %bb98.thread, !dbg !1559

bb98:                                             ; preds = %bb88, %bb86
  br i1 %_2.not.i, label %bb99, label %bb398, !dbg !1560

bb98.thread:                                      ; preds = %bb93
  br i1 %_2.not.i, label %bb108, label %bb398, !dbg !1560

bb96:                                             ; preds = %bb93
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1561, !noalias !1583
  %201 = call noundef dereferenceable_or_null(16) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 16, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1586, !noalias !1583
  %202 = icmp eq ptr %201, null, !dbg !1591
  br i1 %202, label %bb577, label %bb578, !dbg !1592

bb577:                                            ; preds = %bb96
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 16) #17, !dbg !1593
  unreachable, !dbg !1593

bb578:                                            ; preds = %bb96
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(16) %201, ptr noundef nonnull align 1 dereferenceable(16) @alloc_c8e178ad39934661b0ab4885a41c8174, i64 16, i1 false), !dbg !1595
  store i64 16, ptr %_0, align 8, !dbg !1601
  %_132.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1601
  store ptr %201, ptr %_132.sroa.4.0._0.sroa_idx, align 8, !dbg !1601
  %_132.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1601
  store i64 16, ptr %_132.sroa.5.0._0.sroa_idx, align 8, !dbg !1601
  br label %bb443, !dbg !1013

bb99:                                             ; preds = %bb98
  %203 = load i8, ptr %38, align 8, !dbg !1602, !range !144, !noundef !13
  %rm = trunc nuw i8 %203 to i1, !dbg !1602
  %204 = icmp eq i8 %ins.sroa.3.8.extract.trunc, 79, !dbg !1603
  br i1 %204, label %bb158, label %bb157, !dbg !1603

bb158:                                            ; preds = %bb99
  %_137 = load i64, ptr %35, align 8, !dbg !1605, !noundef !13
  %_1397 = icmp ult i64 %_137, 384307168202282326, !dbg !1607
  call void @llvm.assume(i1 %_1397), !dbg !1609
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1610
  %205 = call noundef dereferenceable_or_null(1) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 1, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1623
  %206 = icmp eq ptr %205, null, !dbg !1625
  br i1 %206, label %bb2.i665, label %_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit.exit, !dbg !1626, !prof !1627

bb2.i665:                                         ; preds = %bb158
  call void @_RNvNtCslNYArtu3iFV_5alloc5alloc18handle_alloc_error(i64 noundef 1, i64 noundef 1) #17, !dbg !1628
  unreachable, !dbg !1628

_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit.exit: ; preds = %bb158
  store i8 -127, ptr %205, align 1, !dbg !1622
  call void @llvm.experimental.noalias.scope.decl(metadata !1629), !dbg !1632
  %_7.i666 = load i64, ptr %39, align 8, !dbg !1633, !alias.scope !1629, !noalias !1636, !noundef !13
  %_11.i667 = icmp ult i64 %_7.i666, 384307168202282326, !dbg !1639
  call void @llvm.assume(i1 %_11.i667), !dbg !1640
  %207 = add nuw nsw i64 %_7.i666, %_137, !dbg !1641
  %_4.i668 = icmp samesign ugt i64 %207, 999, !dbg !1643
  br i1 %_4.i668, label %bb1.i677, label %bb2.i669, !dbg !1643

bb2.i669:                                         ; preds = %_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit.exit
  %self1.i.i670 = load i64, ptr %stack, align 8, !dbg !1644, !range !451, !alias.scope !1649, !noalias !1652, !noundef !13
  %_4.i.i671 = icmp eq i64 %_7.i666, %self1.i.i670, !dbg !1654
  br i1 %_4.i.i671, label %bb1.i.i676, label %bb585, !dbg !1654

bb1.i.i676:                                       ; preds = %bb2.i669
  call void @_RNvMs3_NtCslNYArtu3iFV_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VechEE8grow_oneCsjrHSEGnQ3l9_3std(ptr noalias noundef nonnull align 8 dereferenceable(24) %stack) #18, !dbg !1655, !noalias !1652
  br label %bb585, !dbg !1656

bb1.i677:                                         ; preds = %_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit.exit
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !1657, !noalias !1669
  %208 = call noundef dereferenceable_or_null(10) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 10, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1672, !noalias !1669
  %209 = icmp eq ptr %208, null, !dbg !1677
  br i1 %209, label %bb10.i684, label %bb584, !dbg !1678

bb10.i684:                                        ; preds = %bb1.i677
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 10) #17, !dbg !1679, !noalias !1680
  unreachable, !dbg !1679

bb157:                                            ; preds = %bb99
  %210 = add i8 %ins.sroa.3.8.extract.trunc, -81, !dbg !1681
  %or.cond1724 = icmp ult i8 %210, 16, !dbg !1681
  br i1 %or.cond1724, label %bb160, label %bb161, !dbg !1681

bb584:                                            ; preds = %bb1.i677
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(10) %208, ptr noundef nonnull align 1 dereferenceable(10) @alloc_369ee17d61227813032237a0166bc7fe, i64 10, i1 false), !dbg !1685, !noalias !1680
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %205, i64 noundef 1, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !1688, !noalias !1697
  store i64 10, ptr %_0, align 8, !dbg !1700
  %_1415.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !1700
  store ptr %208, ptr %_1415.sroa.2.0._0.sroa_idx, align 8, !dbg !1700
  %_1415.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !1700
  store i64 10, ptr %_1415.sroa.3.0._0.sroa_idx, align 8, !dbg !1700
  br label %bb443, !dbg !1706

bb585:                                            ; preds = %bb1.i.i676, %bb2.i669
  %_14.i.i673 = load ptr, ptr %40, align 8, !dbg !1708, !alias.scope !1649, !noalias !1652, !nonnull !13, !noundef !13
  %end.i.i674 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_14.i.i673, i64 %_7.i666, !dbg !1713
  store i64 1, ptr %end.i.i674, align 8, !dbg !1715, !noalias !1717
  %_138.sroa.5.0.end.i.i674.sroa_idx = getelementptr inbounds nuw i8, ptr %end.i.i674, i64 8, !dbg !1715
  store ptr %205, ptr %_138.sroa.5.0.end.i.i674.sroa_idx, align 8, !dbg !1715, !noalias !1717
  %_138.sroa.7.0.end.i.i674.sroa_idx = getelementptr inbounds nuw i8, ptr %end.i.i674, i64 16, !dbg !1715
  store i64 1, ptr %_138.sroa.7.0.end.i.i674.sroa_idx, align 8, !dbg !1715, !noalias !1717
  %211 = add nuw nsw i64 %_7.i666, 1, !dbg !1718
  store i64 %211, ptr %39, align 8, !dbg !1718, !alias.scope !1649, !noalias !1652
  br label %bb394, !dbg !1719

bb394:                                            ; preds = %bb588, %_ZN18rbitcoin_consensus6script11interpreter15sequence_csv_ok17h5764dc0d818dfb98E.exit, %bb986, %bb960, %bb953, %bb946, %bb939, %bb937, %bb2.i.i.i.i1103, %bb934, %bb2.i.i.i.i1087, %bb927, %bb2.i.i.i.i1071, %bb920, %bb2.i.i.i.i1055, %bb913, %bb2.i.i.i.i1039, %bb906, %bb899, %bb882, %bb870, %bb858, %bb856, %bb854, %bb852, %bb850, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit960", %bb833, %bb831, %bb819, %bb807, %bb805, %bb803, %bb796, %bb789, %bb778, %bb771, %bb763, %bb2.i.i.i.i854, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit852", %bb2.i.i.i.i834, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit832", %bb733, %bb726, %bb718, %bb713, %bb706, %bb694, %bb681, %bb676, %bb668, %bb2.i.i.i.i782, %bb662, %bb660, %bb658, %bb1.i.i773, %bb653, %bb649, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit761", %bb632, %bb624, %bb613, %bb2.i.i.i.i731, %bb605, %bb601, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E.exit", %bb2.i.i.i.i715, %bb165, %bb108, %bb161, %bb161, %bb161, %bb161, %bb161, %bb161, %bb161, %bb161, %bb161, %bb585
  call void @llvm.lifetime.end.p0(ptr nonnull %code), !dbg !1208
  br label %bb395, !dbg !1720

bb161:                                            ; preds = %bb157
  switch i8 %ins.sroa.3.8.extract.trunc, label %bb100 [
    i8 97, label %bb394
    i8 105, label %bb156
    i8 107, label %bb155
    i8 108, label %bb154
    i8 109, label %bb153
    i8 110, label %bb152
    i8 111, label %bb151
    i8 112, label %bb150
    i8 113, label %bb149
    i8 114, label %bb148
    i8 115, label %bb147
    i8 116, label %bb146
    i8 117, label %bb145
    i8 118, label %bb144
    i8 119, label %bb143
    i8 120, label %bb142
    i8 121, label %bb141
    i8 122, label %bb140
    i8 123, label %bb139
    i8 124, label %bb138
    i8 125, label %bb137
    i8 -126, label %bb136
    i8 -121, label %bb135
    i8 -120, label %bb134
    i8 -117, label %bb133
    i8 -116, label %bb132
    i8 -113, label %bb131
    i8 -112, label %bb130
    i8 -111, label %bb129
    i8 -110, label %bb128
    i8 -109, label %bb127
    i8 -108, label %bb126
    i8 -102, label %bb125
    i8 -101, label %bb124
    i8 -100, label %bb123
    i8 -99, label %bb122
    i8 -98, label %bb121
    i8 -97, label %bb120
    i8 -96, label %bb119
    i8 -95, label %bb118
    i8 -94, label %bb117
    i8 -93, label %bb116
    i8 -92, label %bb115
    i8 -91, label %bb114
    i8 -90, label %bb113
    i8 -89, label %bb112
    i8 -88, label %bb111
    i8 -87, label %bb110
    i8 -86, label %bb109
    i8 -85, label %bb108
    i8 -84, label %bb107
    i8 -83, label %bb106
    i8 -70, label %bb105
    i8 -82, label %bb104
    i8 -81, label %bb103
    i8 -79, label %bb102
    i8 -78, label %bb101
    i8 -80, label %bb394
    i8 -77, label %bb394
    i8 -76, label %bb394
    i8 -75, label %bb394
    i8 -74, label %bb394
    i8 -73, label %bb394
    i8 -72, label %bb394
    i8 -71, label %bb394
  ], !dbg !1603

bb160:                                            ; preds = %bb157
  call void @llvm.lifetime.start.p0(ptr nonnull %_144), !dbg !1721
  %_145 = load i64, ptr %35, align 8, !dbg !1723, !noundef !13
  %_1417 = icmp ult i64 %_145, 384307168202282326, !dbg !1725
  call void @llvm.assume(i1 %_1417), !dbg !1727
  call void @llvm.lifetime.start.p0(ptr nonnull %_146), !dbg !1728
  %_1418 = call fastcc noundef ptr @_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit(i64 noundef 1, i64 noundef 1) #19, !dbg !1729
  %_148 = add nsw i8 %ins.sroa.3.8.extract.trunc, -80, !dbg !1730
  store i8 %_148, ptr %_1418, align 1, !dbg !1728
  store i64 1, ptr %_146, align 8, !dbg !1731
  store ptr %_1418, ptr %117, align 8, !dbg !1731
  store i64 1, ptr %118, align 8, !dbg !1731
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_144, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_145, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_146) #16, !dbg !1721
  call void @llvm.lifetime.end.p0(ptr nonnull %_146), !dbg !1743
  %212 = load i64, ptr %_144, align 8, !dbg !1744, !range !1747, !noundef !13
  %.not387 = icmp eq i64 %212, -9223372036854775797, !dbg !1744
  br i1 %.not387, label %bb588, label %bb587, !dbg !1748

bb100:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_945), !dbg !1749
  call void @llvm.lifetime.start.p0(ptr nonnull %args169), !dbg !1750
  store ptr %code, ptr %args169, align 8, !dbg !1750
  %_950.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args169, i64 8, !dbg !1750
  store ptr @_RNvXse_NtNtCsgEmfK2I1SDS_4core3fmt3numhNtB7_8LowerHex3fmt, ptr %_950.sroa.4.0..sroa_idx, align 8, !dbg !1750
  call void @_RNvNvNtCslNYArtu3iFV_5alloc3fmt6format12format_inner(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_945, ptr noundef nonnull @alloc_69a376d11e669e785360fef06f8c9037, ptr noundef nonnull %args169) #16, !dbg !1753
  call void @llvm.lifetime.end.p0(ptr nonnull %args169), !dbg !1758
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_945, i64 24, i1 false), !dbg !1759
  call void @llvm.lifetime.end.p0(ptr nonnull %_945), !dbg !1760
  br label %bb443, !dbg !1761

bb156:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_152), !dbg !1762
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_152, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1762
  %_1437 = load i64, ptr %_152, align 8, !dbg !1763, !range !1765, !noundef !13
  %213 = trunc nuw i64 %_1437 to i1, !dbg !1766
  %_1439.sroa.0.0.copyload = load i64, ptr %116, align 8, !dbg !1767
  %_1439.sroa.5.0.copyload = load ptr, ptr %_1438.sroa.5.0..sroa_idx, align 8, !dbg !1767
  %_1439.sroa.6.0.copyload = load i64, ptr %_1438.sroa.6.0..sroa_idx, align 8, !dbg !1767
  call void @llvm.lifetime.end.p0(ptr nonnull %_152), !dbg !1768
  br i1 %213, label %bb589, label %bb590, !dbg !1766

bb155:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_159.sroa.5), !dbg !1769
  call void @llvm.lifetime.start.p0(ptr nonnull %_160), !dbg !1769
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_160, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1769
  %_1467 = load i64, ptr %_160, align 8, !dbg !1770, !range !1765, !noundef !13
  %214 = trunc nuw i64 %_1467 to i1, !dbg !1771
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_159.sroa.5, ptr noundef nonnull align 8 dereferenceable(24) %115, i64 24, i1 false), !dbg !1772
  call void @llvm.lifetime.end.p0(ptr nonnull %_160), !dbg !1773
  br i1 %214, label %bb596, label %bb597, !dbg !1771

bb154:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_164.sroa.5), !dbg !1774
  call void @llvm.lifetime.start.p0(ptr nonnull %_165.sroa.5), !dbg !1774
  %_1386 = load i64, ptr %35, align 8, !dbg !1775, !noundef !13
  %215 = icmp eq i64 %_1386, 0, !dbg !1775
  br i1 %215, label %bb580, label %bb581, !dbg !1775

bb153:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_175), !dbg !1778
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_175, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1778
  %_1490 = load i64, ptr %_175, align 8, !dbg !1779, !range !1765, !noundef !13
  %216 = trunc nuw i64 %_1490 to i1, !dbg !1780
  %_1492.sroa.0.0.copyload = load i64, ptr %113, align 8, !dbg !1781
  %_1492.sroa.5.0.copyload = load ptr, ptr %_1491.sroa.5.0..sroa_idx, align 8, !dbg !1781
  br i1 %216, label %bb602, label %bb603, !dbg !1780

bb152:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_184), !dbg !1782
  %_1384 = load i64, ptr %39, align 8, !dbg !1783, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_184, i64 noundef %_1384, i64 noundef 2) #16, !dbg !1782
  %217 = load i64, ptr %_184, align 8, !dbg !1787, !range !1747, !noundef !13
  %.not383 = icmp eq i64 %217, -9223372036854775797, !dbg !1787
  br i1 %.not383, label %bb607, label %bb606, !dbg !1788

bb151:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_205), !dbg !1789
  %_1380 = load i64, ptr %39, align 8, !dbg !1790, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_205, i64 noundef %_1380, i64 noundef 3) #16, !dbg !1789
  %218 = load i64, ptr %_205, align 8, !dbg !1794, !range !1747, !noundef !13
  %.not379 = icmp eq i64 %218, -9223372036854775797, !dbg !1794
  br i1 %.not379, label %bb615, label %bb614, !dbg !1795

bb150:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_235), !dbg !1796
  %_1376 = load i64, ptr %39, align 8, !dbg !1797, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_235, i64 noundef %_1376, i64 noundef 4) #16, !dbg !1796
  %219 = load i64, ptr %_235, align 8, !dbg !1801, !range !1747, !noundef !13
  %.not376 = icmp eq i64 %219, -9223372036854775797, !dbg !1801
  br i1 %.not376, label %bb626, label %bb625, !dbg !1802

bb149:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_256), !dbg !1803
  %_1372 = load i64, ptr %39, align 8, !dbg !1804, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_256, i64 noundef %_1372, i64 noundef 6) #16, !dbg !1803
  %220 = load i64, ptr %_256, align 8, !dbg !1808, !range !1747, !noundef !13
  %.not375 = icmp eq i64 %220, -9223372036854775797, !dbg !1808
  br i1 %.not375, label %bb634, label %bb633, !dbg !1809

bb148:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_279), !dbg !1810
  %_1368 = load i64, ptr %39, align 8, !dbg !1811, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_279, i64 noundef %_1368, i64 noundef 4) #16, !dbg !1810
  %221 = load i64, ptr %_279, align 8, !dbg !1815, !range !1747, !noundef !13
  %.not374 = icmp eq i64 %221, -9223372036854775797, !dbg !1815
  br i1 %.not374, label %bb644, label %bb643, !dbg !1816

bb147:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_290), !dbg !1817
  %_1364 = load i64, ptr %39, align 8, !dbg !1818, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_290, i64 noundef %_1364, i64 noundef 1) #16, !dbg !1817
  %222 = load i64, ptr %_290, align 8, !dbg !1822, !range !1747, !noundef !13
  %.not372 = icmp eq i64 %222, -9223372036854775797, !dbg !1822
  br i1 %.not372, label %bb652, label %bb651, !dbg !1823

bb146:                                            ; preds = %bb161
  %_305 = load i64, ptr %39, align 8, !dbg !1824, !noundef !13
  %_1361 = icmp ult i64 %_305, 384307168202282326, !dbg !1826
  call void @llvm.assume(i1 %_1361), !dbg !1828
  call void @llvm.lifetime.start.p0(ptr nonnull %_307), !dbg !1829
  %_308 = load i64, ptr %35, align 8, !dbg !1831, !noundef !13
  %_1727 = icmp ult i64 %_308, 384307168202282326, !dbg !1833
  call void @llvm.assume(i1 %_1727), !dbg !1835
  call void @llvm.lifetime.start.p0(ptr nonnull %_309), !dbg !1836
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_309, i64 noundef %_305) #16, !dbg !1836
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_307, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_308, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_309) #16, !dbg !1829
  call void @llvm.lifetime.end.p0(ptr nonnull %_309), !dbg !1837
  %223 = load i64, ptr %_307, align 8, !dbg !1838, !range !1747, !noundef !13
  %.not371 = icmp eq i64 %223, -9223372036854775797, !dbg !1838
  br i1 %.not371, label %bb660, label %bb659, !dbg !1839

bb145:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_313), !dbg !1840
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_313, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1840
  %_1734 = load i64, ptr %_313, align 8, !dbg !1841, !range !1765, !noundef !13
  %224 = trunc nuw i64 %_1734 to i1, !dbg !1842
  %_1736.sroa.0.0.copyload = load i64, ptr %112, align 8, !dbg !1843
  %_1736.sroa.5.0.copyload = load ptr, ptr %_1735.sroa.5.0..sroa_idx, align 8, !dbg !1843
  br i1 %224, label %bb661, label %bb662, !dbg !1842

bb144:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_317), !dbg !1844
  %_1359 = load i64, ptr %39, align 8, !dbg !1845, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_317, i64 noundef %_1359, i64 noundef 1) #16, !dbg !1844
  %225 = load i64, ptr %_317, align 8, !dbg !1849, !range !1747, !noundef !13
  %.not369 = icmp eq i64 %225, -9223372036854775797, !dbg !1849
  br i1 %.not369, label %bb664, label %bb663, !dbg !1850

bb143:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_328), !dbg !1851
  %_1355 = load i64, ptr %39, align 8, !dbg !1852, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_328, i64 noundef %_1355, i64 noundef 2) #16, !dbg !1851
  %226 = load i64, ptr %_328, align 8, !dbg !1856, !range !1747, !noundef !13
  %.not367 = icmp eq i64 %226, -9223372036854775797, !dbg !1856
  br i1 %.not367, label %bb670, label %bb669, !dbg !1857

bb142:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_347), !dbg !1858
  %_1351 = load i64, ptr %39, align 8, !dbg !1859, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_347, i64 noundef %_1351, i64 noundef 2) #16, !dbg !1858
  %227 = load i64, ptr %_347, align 8, !dbg !1863, !range !1747, !noundef !13
  %.not365 = icmp eq i64 %227, -9223372036854775797, !dbg !1863
  br i1 %.not365, label %bb678, label %bb677, !dbg !1864

bb141:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_359), !dbg !1865
  call void @llvm.lifetime.start.p0(ptr nonnull %_363), !dbg !1866
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_363, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1866
  %_1807 = load i64, ptr %_363, align 8, !dbg !1867, !range !1765, !noundef !13
  %228 = trunc nuw i64 %_1807 to i1, !dbg !1868
  %_1809.sroa.0.0.copyload = load i64, ptr %108, align 8, !dbg !1869
  %_1809.sroa.5.0.copyload = load ptr, ptr %_1808.sroa.5.0..sroa_idx, align 8, !dbg !1869
  %_1809.sroa.6.0.copyload = load i64, ptr %_1808.sroa.6.0..sroa_idx, align 8, !dbg !1869
  call void @llvm.lifetime.end.p0(ptr nonnull %_363), !dbg !1870
  br i1 %228, label %bb682, label %bb683, !dbg !1868

bb140:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_384), !dbg !1871
  call void @llvm.lifetime.start.p0(ptr nonnull %_388), !dbg !1872
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_388, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1872
  %_1859 = load i64, ptr %_388, align 8, !dbg !1873, !range !1765, !noundef !13
  %229 = trunc nuw i64 %_1859 to i1, !dbg !1874
  %_1861.sroa.0.0.copyload = load i64, ptr %106, align 8, !dbg !1875
  %_1861.sroa.5.0.copyload = load ptr, ptr %_1860.sroa.5.0..sroa_idx, align 8, !dbg !1875
  %_1861.sroa.6.0.copyload = load i64, ptr %_1860.sroa.6.0..sroa_idx, align 8, !dbg !1875
  call void @llvm.lifetime.end.p0(ptr nonnull %_388), !dbg !1876
  br i1 %229, label %bb695, label %bb696, !dbg !1874

bb139:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_408), !dbg !1877
  %_1347 = load i64, ptr %39, align 8, !dbg !1878, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_408, i64 noundef %_1347, i64 noundef 3) #16, !dbg !1877
  %230 = load i64, ptr %_408, align 8, !dbg !1882, !range !1747, !noundef !13
  %.not362 = icmp eq i64 %230, -9223372036854775797, !dbg !1882
  br i1 %.not362, label %bb708, label %bb707, !dbg !1883

bb138:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_418), !dbg !1884
  %_1343 = load i64, ptr %39, align 8, !dbg !1885, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_418, i64 noundef %_1343, i64 noundef 2) #16, !dbg !1884
  %231 = load i64, ptr %_418, align 8, !dbg !1889, !range !1747, !noundef !13
  %.not361 = icmp eq i64 %231, -9223372036854775797, !dbg !1889
  br i1 %.not361, label %bb716, label %bb715, !dbg !1890

bb137:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_426), !dbg !1891
  %_1339 = load i64, ptr %39, align 8, !dbg !1892, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_426, i64 noundef %_1339, i64 noundef 2) #16, !dbg !1891
  %232 = load i64, ptr %_426, align 8, !dbg !1896, !range !1747, !noundef !13
  %.not359 = icmp eq i64 %232, -9223372036854775797, !dbg !1896
  br i1 %.not359, label %bb721, label %bb720, !dbg !1897

bb136:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_442), !dbg !1898
  %_1335 = load i64, ptr %39, align 8, !dbg !1899, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_442, i64 noundef %_1335, i64 noundef 1) #16, !dbg !1898
  %233 = load i64, ptr %_442, align 8, !dbg !1903, !range !1747, !noundef !13
  %.not357 = icmp eq i64 %233, -9223372036854775797, !dbg !1903
  br i1 %.not357, label %bb729, label %bb728, !dbg !1904

bb135:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_456), !dbg !1905
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_456, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1905
  %_2025 = load i64, ptr %_456, align 8, !dbg !1906, !range !1765, !noundef !13
  %234 = trunc nuw i64 %_2025 to i1, !dbg !1907
  %_2027.sroa.0.0.copyload = load i64, ptr %104, align 8, !dbg !1908
  %_2027.sroa.5.0.copyload = load ptr, ptr %_2026.sroa.5.0..sroa_idx, align 8, !dbg !1908
  %_2027.sroa.6.0.copyload = load i64, ptr %_2026.sroa.6.0..sroa_idx, align 8, !dbg !1908
  call void @llvm.lifetime.end.p0(ptr nonnull %_456), !dbg !1909
  br i1 %234, label %bb734, label %bb735, !dbg !1907

bb134:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_472), !dbg !1910
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_472, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1910
  %_2054 = load i64, ptr %_472, align 8, !dbg !1911, !range !1765, !noundef !13
  %235 = trunc nuw i64 %_2054 to i1, !dbg !1912
  %_2056.sroa.0.0.copyload = load i64, ptr %102, align 8, !dbg !1913
  %_2056.sroa.5.0.copyload = load ptr, ptr %_2055.sroa.5.0..sroa_idx, align 8, !dbg !1913
  %_2056.sroa.6.0.copyload = load i64, ptr %_2055.sroa.6.0..sroa_idx, align 8, !dbg !1913
  call void @llvm.lifetime.end.p0(ptr nonnull %_472), !dbg !1914
  br i1 %235, label %bb744, label %bb745, !dbg !1912

bb133:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_484), !dbg !1915
  call void @llvm.lifetime.start.p0(ptr nonnull %_488), !dbg !1916
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_488, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1916
  %_2096 = load i64, ptr %_488, align 8, !dbg !1917, !range !1765, !noundef !13
  %236 = trunc nuw i64 %_2096 to i1, !dbg !1918
  %_2098.sroa.0.0.copyload = load i64, ptr %100, align 8, !dbg !1919
  %_2098.sroa.5.0.copyload = load ptr, ptr %_2097.sroa.5.0..sroa_idx, align 8, !dbg !1919
  %_2098.sroa.6.0.copyload = load i64, ptr %_2097.sroa.6.0..sroa_idx, align 8, !dbg !1919
  call void @llvm.lifetime.end.p0(ptr nonnull %_488), !dbg !1920
  br i1 %236, label %bb756, label %bb757, !dbg !1918

bb132:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_500), !dbg !1921
  call void @llvm.lifetime.start.p0(ptr nonnull %_504), !dbg !1922
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_504, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1922
  %_2121 = load i64, ptr %_504, align 8, !dbg !1923, !range !1765, !noundef !13
  %237 = trunc nuw i64 %_2121 to i1, !dbg !1924
  %_2123.sroa.0.0.copyload = load i64, ptr %98, align 8, !dbg !1925
  %_2123.sroa.5.0.copyload = load ptr, ptr %_2122.sroa.5.0..sroa_idx, align 8, !dbg !1925
  %_2123.sroa.6.0.copyload = load i64, ptr %_2122.sroa.6.0..sroa_idx, align 8, !dbg !1925
  call void @llvm.lifetime.end.p0(ptr nonnull %_504), !dbg !1926
  br i1 %237, label %bb764, label %bb765, !dbg !1924

bb131:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_516), !dbg !1927
  call void @llvm.lifetime.start.p0(ptr nonnull %_520), !dbg !1928
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_520, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1928
  %_2146 = load i64, ptr %_520, align 8, !dbg !1929, !range !1765, !noundef !13
  %238 = trunc nuw i64 %_2146 to i1, !dbg !1930
  %_2148.sroa.0.0.copyload = load i64, ptr %96, align 8, !dbg !1931
  %_2148.sroa.5.0.copyload = load ptr, ptr %_2147.sroa.5.0..sroa_idx, align 8, !dbg !1931
  %_2148.sroa.6.0.copyload = load i64, ptr %_2147.sroa.6.0..sroa_idx, align 8, !dbg !1931
  call void @llvm.lifetime.end.p0(ptr nonnull %_520), !dbg !1932
  br i1 %238, label %bb772, label %bb773, !dbg !1930

bb130:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_532), !dbg !1933
  call void @llvm.lifetime.start.p0(ptr nonnull %_536), !dbg !1934
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_536, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1934
  %_2171 = load i64, ptr %_536, align 8, !dbg !1935, !range !1765, !noundef !13
  %239 = trunc nuw i64 %_2171 to i1, !dbg !1936
  %_2173.sroa.0.0.copyload = load i64, ptr %94, align 8, !dbg !1937
  %_2173.sroa.5.0.copyload = load ptr, ptr %_2172.sroa.5.0..sroa_idx, align 8, !dbg !1937
  %_2173.sroa.6.0.copyload = load i64, ptr %_2172.sroa.6.0..sroa_idx, align 8, !dbg !1937
  call void @llvm.lifetime.end.p0(ptr nonnull %_536), !dbg !1938
  br i1 %239, label %bb779, label %bb780, !dbg !1936

bb129:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_548), !dbg !1939
  call void @llvm.lifetime.start.p0(ptr nonnull %_552), !dbg !1940
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_552, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1940
  %_2198 = load i64, ptr %_552, align 8, !dbg !1941, !range !1765, !noundef !13
  %240 = trunc nuw i64 %_2198 to i1, !dbg !1942
  %_2200.sroa.0.0.copyload = load i64, ptr %92, align 8, !dbg !1943
  %_2200.sroa.5.0.copyload = load ptr, ptr %_2199.sroa.5.0..sroa_idx, align 8, !dbg !1943
  %_2200.sroa.6.0.copyload = load i64, ptr %_2199.sroa.6.0..sroa_idx, align 8, !dbg !1943
  call void @llvm.lifetime.end.p0(ptr nonnull %_552), !dbg !1944
  br i1 %240, label %bb790, label %bb791, !dbg !1942

bb128:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_564), !dbg !1945
  call void @llvm.lifetime.start.p0(ptr nonnull %_568), !dbg !1946
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_568, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1946
  %_2223 = load i64, ptr %_568, align 8, !dbg !1947, !range !1765, !noundef !13
  %241 = trunc nuw i64 %_2223 to i1, !dbg !1948
  %_2225.sroa.0.0.copyload = load i64, ptr %90, align 8, !dbg !1949
  %_2225.sroa.5.0.copyload = load ptr, ptr %_2224.sroa.5.0..sroa_idx, align 8, !dbg !1949
  %_2225.sroa.6.0.copyload = load i64, ptr %_2224.sroa.6.0..sroa_idx, align 8, !dbg !1949
  call void @llvm.lifetime.end.p0(ptr nonnull %_568), !dbg !1950
  br i1 %241, label %bb797, label %bb798, !dbg !1948

bb127:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_580), !dbg !1951
  %_581 = load i64, ptr %35, align 8, !dbg !1952, !noundef !13
  %_1332 = icmp ult i64 %_581, 384307168202282326, !dbg !1954
  call void @llvm.assume(i1 %_1332), !dbg !1956
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9bin_arith17hd7711d4ba5bd900eE(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_580, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_581, i1 noundef zeroext %rm) #16, !dbg !1951
  %242 = load i64, ptr %_580, align 8, !dbg !1957, !range !1747, !noundef !13
  %.not348 = icmp eq i64 %242, -9223372036854775797, !dbg !1957
  br i1 %.not348, label %bb805, label %bb804, !dbg !1958

bb126:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_584), !dbg !1959
  %_585 = load i64, ptr %35, align 8, !dbg !1960, !noundef !13
  %_1331 = icmp ult i64 %_585, 384307168202282326, !dbg !1962
  call void @llvm.assume(i1 %_1331), !dbg !1964
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9bin_arith17h413fa78bc0791c0dE(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_584, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_585, i1 noundef zeroext %rm) #16, !dbg !1959
  %243 = load i64, ptr %_584, align 8, !dbg !1965, !range !1747, !noundef !13
  %.not347 = icmp eq i64 %243, -9223372036854775797, !dbg !1965
  br i1 %.not347, label %bb807, label %bb806, !dbg !1966

bb125:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_588), !dbg !1967
  call void @llvm.lifetime.start.p0(ptr nonnull %_592), !dbg !1968
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_592, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1968
  %_2260 = load i64, ptr %_592, align 8, !dbg !1969, !range !1765, !noundef !13
  %244 = trunc nuw i64 %_2260 to i1, !dbg !1970
  %_2262.sroa.0.0.copyload = load i64, ptr %86, align 8, !dbg !1971
  %_2262.sroa.5.0.copyload = load ptr, ptr %_2261.sroa.5.0..sroa_idx, align 8, !dbg !1971
  %_2262.sroa.6.0.copyload = load i64, ptr %_2261.sroa.6.0..sroa_idx, align 8, !dbg !1971
  call void @llvm.lifetime.end.p0(ptr nonnull %_592), !dbg !1972
  br i1 %244, label %bb808, label %bb809, !dbg !1970

bb124:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_614), !dbg !1973
  call void @llvm.lifetime.start.p0(ptr nonnull %_618), !dbg !1974
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_618, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1974
  %_2304 = load i64, ptr %_618, align 8, !dbg !1975, !range !1765, !noundef !13
  %245 = trunc nuw i64 %_2304 to i1, !dbg !1976
  %_2306.sroa.0.0.copyload = load i64, ptr %82, align 8, !dbg !1977
  %_2306.sroa.5.0.copyload = load ptr, ptr %_2305.sroa.5.0..sroa_idx, align 8, !dbg !1977
  %_2306.sroa.6.0.copyload = load i64, ptr %_2305.sroa.6.0..sroa_idx, align 8, !dbg !1977
  call void @llvm.lifetime.end.p0(ptr nonnull %_618), !dbg !1978
  br i1 %245, label %bb820, label %bb821, !dbg !1976

bb123:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_640), !dbg !1979
  %_641 = load i64, ptr %35, align 8, !dbg !1980, !noundef !13
  %_1330 = icmp ult i64 %_641, 384307168202282326, !dbg !1982
  call void @llvm.assume(i1 %_1330), !dbg !1984
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h4011a77626a82398E(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_640, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_641, i1 noundef zeroext %rm) #16, !dbg !1979
  %246 = load i64, ptr %_640, align 8, !dbg !1985, !range !1747, !noundef !13
  %.not344 = icmp eq i64 %246, -9223372036854775797, !dbg !1985
  br i1 %.not344, label %bb833, label %bb832, !dbg !1986

bb122:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_644), !dbg !1987
  call void @llvm.lifetime.start.p0(ptr nonnull %_648), !dbg !1988
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_648, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !1988
  %_2354 = load i64, ptr %_648, align 8, !dbg !1989, !range !1765, !noundef !13
  %247 = trunc nuw i64 %_2354 to i1, !dbg !1990
  %_2356.sroa.0.0.copyload = load i64, ptr %78, align 8, !dbg !1991
  %_2356.sroa.5.0.copyload = load ptr, ptr %_2355.sroa.5.0..sroa_idx, align 8, !dbg !1991
  %_2356.sroa.6.0.copyload = load i64, ptr %_2355.sroa.6.0..sroa_idx, align 8, !dbg !1991
  call void @llvm.lifetime.end.p0(ptr nonnull %_648), !dbg !1992
  br i1 %247, label %bb834, label %bb835, !dbg !1990

bb121:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_667), !dbg !1993
  %_668 = load i64, ptr %35, align 8, !dbg !1994, !noundef !13
  %_1329 = icmp ult i64 %_668, 384307168202282326, !dbg !1996
  call void @llvm.assume(i1 %_1329), !dbg !1998
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17hf6aeffa5975d17bcE(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_667, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_668, i1 noundef zeroext %rm) #16, !dbg !1993
  %248 = load i64, ptr %_667, align 8, !dbg !1999, !range !1747, !noundef !13
  %.not343 = icmp eq i64 %248, -9223372036854775797, !dbg !1999
  br i1 %.not343, label %bb850, label %bb849, !dbg !2000

bb120:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_671), !dbg !2001
  %_672 = load i64, ptr %35, align 8, !dbg !2002, !noundef !13
  %_1328 = icmp ult i64 %_672, 384307168202282326, !dbg !2004
  call void @llvm.assume(i1 %_1328), !dbg !2006
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h553f7ce6705c6daaE(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_671, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_672, i1 noundef zeroext %rm) #16, !dbg !2001
  %249 = load i64, ptr %_671, align 8, !dbg !2007, !range !1747, !noundef !13
  %.not342 = icmp eq i64 %249, -9223372036854775797, !dbg !2007
  br i1 %.not342, label %bb852, label %bb851, !dbg !2008

bb119:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_675), !dbg !2009
  %_676 = load i64, ptr %35, align 8, !dbg !2010, !noundef !13
  %_1327 = icmp ult i64 %_676, 384307168202282326, !dbg !2012
  call void @llvm.assume(i1 %_1327), !dbg !2014
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17ha2aa4046e5746b0aE(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_675, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_676, i1 noundef zeroext %rm) #16, !dbg !2009
  %250 = load i64, ptr %_675, align 8, !dbg !2015, !range !1747, !noundef !13
  %.not341 = icmp eq i64 %250, -9223372036854775797, !dbg !2015
  br i1 %.not341, label %bb854, label %bb853, !dbg !2016

bb118:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_679), !dbg !2017
  %_680 = load i64, ptr %35, align 8, !dbg !2018, !noundef !13
  %_1326 = icmp ult i64 %_680, 384307168202282326, !dbg !2020
  call void @llvm.assume(i1 %_1326), !dbg !2022
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h2f973f8e0b9535c3E(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_679, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_680, i1 noundef zeroext %rm) #16, !dbg !2017
  %251 = load i64, ptr %_679, align 8, !dbg !2023, !range !1747, !noundef !13
  %.not340 = icmp eq i64 %251, -9223372036854775797, !dbg !2023
  br i1 %.not340, label %bb856, label %bb855, !dbg !2024

bb117:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_683), !dbg !2025
  %_684 = load i64, ptr %35, align 8, !dbg !2026, !noundef !13
  %_1325 = icmp ult i64 %_684, 384307168202282326, !dbg !2028
  call void @llvm.assume(i1 %_1325), !dbg !2030
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h90c71f3b60f04393E(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_683, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_684, i1 noundef zeroext %rm) #16, !dbg !2025
  %252 = load i64, ptr %_683, align 8, !dbg !2031, !range !1747, !noundef !13
  %.not339 = icmp eq i64 %252, -9223372036854775797, !dbg !2031
  br i1 %.not339, label %bb858, label %bb857, !dbg !2032

bb116:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_687), !dbg !2033
  call void @llvm.lifetime.start.p0(ptr nonnull %_691), !dbg !2034
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_691, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2034
  %_2441 = load i64, ptr %_691, align 8, !dbg !2035, !range !1765, !noundef !13
  %253 = trunc nuw i64 %_2441 to i1, !dbg !2036
  %_2443.sroa.0.0.copyload = load i64, ptr %74, align 8, !dbg !2037
  %_2443.sroa.5.0.copyload = load ptr, ptr %_2442.sroa.5.0..sroa_idx, align 8, !dbg !2037
  %_2443.sroa.6.0.copyload = load i64, ptr %_2442.sroa.6.0..sroa_idx, align 8, !dbg !2037
  call void @llvm.lifetime.end.p0(ptr nonnull %_691), !dbg !2038
  br i1 %253, label %bb859, label %bb860, !dbg !2036

bb115:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_713), !dbg !2039
  call void @llvm.lifetime.start.p0(ptr nonnull %_717), !dbg !2040
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_717, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2040
  %_2485 = load i64, ptr %_717, align 8, !dbg !2041, !range !1765, !noundef !13
  %254 = trunc nuw i64 %_2485 to i1, !dbg !2042
  %_2487.sroa.0.0.copyload = load i64, ptr %70, align 8, !dbg !2043
  %_2487.sroa.5.0.copyload = load ptr, ptr %_2486.sroa.5.0..sroa_idx, align 8, !dbg !2043
  %_2487.sroa.6.0.copyload = load i64, ptr %_2486.sroa.6.0..sroa_idx, align 8, !dbg !2043
  call void @llvm.lifetime.end.p0(ptr nonnull %_717), !dbg !2044
  br i1 %254, label %bb871, label %bb872, !dbg !2042

bb114:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_739), !dbg !2045
  call void @llvm.lifetime.start.p0(ptr nonnull %_743), !dbg !2046
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_743, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2046
  %_2529 = load i64, ptr %_743, align 8, !dbg !2047, !range !1765, !noundef !13
  %255 = trunc nuw i64 %_2529 to i1, !dbg !2048
  %_2531.sroa.0.0.copyload = load i64, ptr %64, align 8, !dbg !2049
  %_2531.sroa.5.0.copyload = load ptr, ptr %_2530.sroa.5.0..sroa_idx, align 8, !dbg !2049
  %_2531.sroa.6.0.copyload = load i64, ptr %_2530.sroa.6.0..sroa_idx, align 8, !dbg !2049
  call void @llvm.lifetime.end.p0(ptr nonnull %_743), !dbg !2050
  br i1 %255, label %bb883, label %bb884, !dbg !2048

bb113:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_777), !dbg !2051
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_777, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2051
  %_2592 = load i64, ptr %_777, align 8, !dbg !2052, !range !1765, !noundef !13
  %256 = trunc nuw i64 %_2592 to i1, !dbg !2053
  %_2594.sroa.0.0.copyload = load i64, ptr %61, align 8, !dbg !2054
  %_2594.sroa.5.0.copyload = load ptr, ptr %_2593.sroa.5.0..sroa_idx, align 8, !dbg !2054
  %_2594.sroa.6.0.copyload = load i64, ptr %_2593.sroa.6.0..sroa_idx, align 8, !dbg !2054
  call void @llvm.lifetime.end.p0(ptr nonnull %_777), !dbg !2055
  br i1 %256, label %bb900, label %bb901, !dbg !2053

bb112:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_792), !dbg !2056
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_792, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2056
  %_2625 = load i64, ptr %_792, align 8, !dbg !2057, !range !1765, !noundef !13
  %257 = trunc nuw i64 %_2625 to i1, !dbg !2058
  %_2627.sroa.0.0.copyload = load i64, ptr %58, align 8, !dbg !2059
  %_2627.sroa.5.0.copyload = load ptr, ptr %_2626.sroa.5.0..sroa_idx, align 8, !dbg !2059
  %_2627.sroa.6.0.copyload = load i64, ptr %_2626.sroa.6.0..sroa_idx, align 8, !dbg !2059
  call void @llvm.lifetime.end.p0(ptr nonnull %_792), !dbg !2060
  br i1 %257, label %bb907, label %bb908, !dbg !2058

bb111:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_806), !dbg !2061
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_806, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2061
  %_2658 = load i64, ptr %_806, align 8, !dbg !2062, !range !1765, !noundef !13
  %258 = trunc nuw i64 %_2658 to i1, !dbg !2063
  %_2660.sroa.0.0.copyload = load i64, ptr %55, align 8, !dbg !2064
  %_2660.sroa.5.0.copyload = load ptr, ptr %_2659.sroa.5.0..sroa_idx, align 8, !dbg !2064
  %_2660.sroa.6.0.copyload = load i64, ptr %_2659.sroa.6.0..sroa_idx, align 8, !dbg !2064
  call void @llvm.lifetime.end.p0(ptr nonnull %_806), !dbg !2065
  br i1 %258, label %bb914, label %bb915, !dbg !2063

bb110:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_820), !dbg !2066
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_820, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2066
  %_2691 = load i64, ptr %_820, align 8, !dbg !2067, !range !1765, !noundef !13
  %259 = trunc nuw i64 %_2691 to i1, !dbg !2068
  %_2693.sroa.0.0.copyload = load i64, ptr %52, align 8, !dbg !2069
  %_2693.sroa.5.0.copyload = load ptr, ptr %_2692.sroa.5.0..sroa_idx, align 8, !dbg !2069
  %_2693.sroa.6.0.copyload = load i64, ptr %_2692.sroa.6.0..sroa_idx, align 8, !dbg !2069
  call void @llvm.lifetime.end.p0(ptr nonnull %_820), !dbg !2070
  br i1 %259, label %bb921, label %bb922, !dbg !2068

bb109:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_834), !dbg !2071
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_834, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2071
  %_2724 = load i64, ptr %_834, align 8, !dbg !2072, !range !1765, !noundef !13
  %260 = trunc nuw i64 %_2724 to i1, !dbg !2073
  %_2726.sroa.0.0.copyload = load i64, ptr %49, align 8, !dbg !2074
  %_2726.sroa.5.0.copyload = load ptr, ptr %_2725.sroa.5.0..sroa_idx, align 8, !dbg !2074
  %_2726.sroa.6.0.copyload = load i64, ptr %_2725.sroa.6.0..sroa_idx, align 8, !dbg !2074
  call void @llvm.lifetime.end.p0(ptr nonnull %_834), !dbg !2075
  br i1 %260, label %bb928, label %bb929, !dbg !2073

bb108:                                            ; preds = %bb161, %bb98.thread
  store i32 %opcode_pos.sroa.0.02709, ptr %_1324, align 8, !dbg !2076
  %261 = call i64 @llvm.uadd.sat.i64(i64 %item.sroa.3.sroa.2.0.copyload, i64 1), !dbg !2089
  store i64 1, ptr %_2758, align 8, !dbg !2092
  store i64 %261, ptr %48, align 8, !dbg !2092
  br label %bb394, !dbg !2102

bb107:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_850), !dbg !2103
  %_851 = load i64, ptr %35, align 8, !dbg !2104, !noundef !13
  %_1322 = icmp ult i64 %_851, 384307168202282326, !dbg !2106
  call void @llvm.assume(i1 %_1322), !dbg !2108
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11op_checksig17h9fc43a5a76d407e8E(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_850, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_851, ptr noundef nonnull align 8 %ctx, i1 noundef zeroext false) #16, !dbg !2103
  %262 = load i64, ptr %_850, align 8, !dbg !2109, !range !1747, !noundef !13
  %.not330 = icmp eq i64 %262, -9223372036854775797, !dbg !2109
  br i1 %.not330, label %bb937, label %bb936, !dbg !2110

bb106:                                            ; preds = %bb161
  call void @llvm.lifetime.start.p0(ptr nonnull %_854), !dbg !2111
  %_855 = load i64, ptr %35, align 8, !dbg !2112, !noundef !13
  %_1321 = icmp ult i64 %_855, 384307168202282326, !dbg !2114
  call void @llvm.assume(i1 %_1321), !dbg !2116
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11op_checksig17h9fc43a5a76d407e8E(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_854, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_855, ptr noundef nonnull align 8 %ctx, i1 noundef zeroext true) #16, !dbg !2111
  %263 = load i64, ptr %_854, align 8, !dbg !2117, !range !1747, !noundef !13
  %.not329 = icmp eq i64 %263, -9223372036854775797, !dbg !2117
  br i1 %.not329, label %bb939, label %bb938, !dbg !2118

bb105:                                            ; preds = %bb161
  br i1 %_0.i651, label %bb361, label %bb360, !dbg !2119

bb104:                                            ; preds = %bb161
  br i1 %_0.i651, label %bb365, label %bb364, !dbg !2120

bb103:                                            ; preds = %bb161
  br i1 %_0.i651, label %bb369, label %bb368, !dbg !2121

bb102:                                            ; preds = %bb161
  %264 = load i8, ptr %46, align 1, !dbg !2122, !range !144, !noundef !13
  %_887 = trunc nuw i8 %264 to i1, !dbg !2122
  br i1 %_887, label %bb371, label %bb398, !dbg !2122

bb101:                                            ; preds = %bb161
  %265 = load i8, ptr %42, align 2, !dbg !2123, !range !144, !noundef !13
  %_917 = trunc nuw i8 %265 to i1, !dbg !2123
  br i1 %_917, label %bb382, label %bb398, !dbg !2123

bb589:                                            ; preds = %bb156
  store i64 %_1439.sroa.0.0.copyload, ptr %_0, align 8, !dbg !2124
  %_1446.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !2124
  store ptr %_1439.sroa.5.0.copyload, ptr %_1446.sroa.2.0._0.sroa_idx, align 8, !dbg !2124
  %_1446.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !2124
  store i64 %_1439.sroa.6.0.copyload, ptr %_1446.sroa.3.0._0.sroa_idx, align 8, !dbg !2124
  br label %bb443, !dbg !1706

bb590:                                            ; preds = %bb156
  %_10.not.i691 = icmp eq i64 %_1439.sroa.6.0.copyload, 0, !dbg !2130
  br i1 %_10.not.i691, label %bb166, label %bb6.i692, !dbg !2130

bb6.i692:                                         ; preds = %bb590
  %266 = getelementptr i8, ptr %_1439.sroa.5.0.copyload, i64 %_1439.sroa.6.0.copyload, !dbg !2134
  %_12.i693 = getelementptr i8, ptr %266, i64 -1, !dbg !2134
  %_14.i694 = load i8, ptr %_12.i693, align 1, !dbg !2135, !alias.scope !2137, !noundef !13
  %_6.i695 = and i8 %_14.i694, 127, !dbg !2140
  %267 = icmp eq i8 %_6.i695, 0, !dbg !2142
  br i1 %267, label %bb1.i.i698, label %bb165, !dbg !2142

bb1.i.i698:                                       ; preds = %bb13.i.i701, %bb6.i692
  %_221.i.i699 = phi ptr [ %_22.i.i702, %bb13.i.i701 ], [ %_1439.sroa.5.0.copyload, %bb6.i692 ]
  %_12.i.not.not.i700 = icmp eq ptr %_221.i.i699, %_12.i693, !dbg !2143
  br i1 %_12.i.not.not.i700, label %bb166, label %bb13.i.i701, !dbg !2147

bb13.i.i701:                                      ; preds = %bb1.i.i698
  %_22.i.i702 = getelementptr inbounds nuw i8, ptr %_221.i.i699, i64 1, !dbg !2148
  %ptr.val.i.i703 = load i8, ptr %_221.i.i699, align 1, !dbg !2150, !alias.scope !2137, !noalias !2151, !noundef !13
  %_0.i.i.i704 = icmp eq i8 %ptr.val.i.i703, 0, !dbg !2154
  br i1 %_0.i.i.i704, label %bb1.i.i698, label %bb165, !dbg !2150

bb166:                                            ; preds = %bb1.i.i698, %bb590
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !2156, !noalias !2178
  %268 = call noundef dereferenceable_or_null(9) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 9, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2181, !noalias !2178
  %269 = icmp eq ptr %268, null, !dbg !2186
  br i1 %269, label %bb594, label %bb595, !dbg !2187

bb165:                                            ; preds = %bb13.i.i701, %bb6.i692
  %270 = icmp eq i64 %_1439.sroa.0.0.copyload, 0, !dbg !2188
  br i1 %270, label %bb394, label %bb2.i.i.i.i715, !dbg !2188

bb2.i.i.i.i715:                                   ; preds = %bb165
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1439.sroa.5.0.copyload, i64 noundef %_1439.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2194, !noalias !2199
  br label %bb394, !dbg !2202

bb594:                                            ; preds = %bb166
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 9) #17, !dbg !2203
  unreachable, !dbg !2203

bb595:                                            ; preds = %bb166
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %268, ptr noundef nonnull align 1 dereferenceable(9) @alloc_adf5eb6322a6d3ed8bfdcac2abff4f1c, i64 9, i1 false), !dbg !2205
  store i64 9, ptr %_0, align 8, !dbg !2211
  %_157.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !2211
  store ptr %268, ptr %_157.sroa.4.0._0.sroa_idx, align 8, !dbg !2211
  %_157.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !2211
  store i64 9, ptr %_157.sroa.5.0._0.sroa_idx, align 8, !dbg !2211
  %271 = icmp eq i64 %_1439.sroa.0.0.copyload, 0, !dbg !2212
  br i1 %271, label %bb443, label %bb2.i.i.i.i719, !dbg !2212

bb2.i.i.i.i719:                                   ; preds = %bb595
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1439.sroa.5.0.copyload, i64 noundef %_1439.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2218, !noalias !2223
  br label %bb443, !dbg !2226

bb596:                                            ; preds = %bb155
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_159.sroa.5, i64 24, i1 false), !dbg !1773
  call void @llvm.lifetime.end.p0(ptr nonnull %_159.sroa.5), !dbg !2227
  br label %bb443, !dbg !1706

bb597:                                            ; preds = %bb155
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v14, ptr noundef nonnull align 8 dereferenceable(24) %_159.sroa.5, i64 24, i1 false), !dbg !1769
  call void @llvm.lifetime.end.p0(ptr nonnull %_159.sroa.5), !dbg !2227
  %len.i = load i64, ptr %35, align 8, !dbg !2228, !alias.scope !2233, !noalias !2236, !noundef !13
  %self1.i = load i64, ptr %altstack, align 8, !dbg !2238, !range !451, !alias.scope !2233, !noalias !2236, !noundef !13
  %_4.i722 = icmp eq i64 %len.i, %self1.i, !dbg !2241
  br i1 %_4.i722, label %bb1.i725, label %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E.exit", !dbg !2241

bb1.i725:                                         ; preds = %bb597
  call void @_RNvMs3_NtCslNYArtu3iFV_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VechEE8grow_oneCsjrHSEGnQ3l9_3std(ptr noalias noundef nonnull align 8 dereferenceable(24) %altstack) #18, !dbg !2242, !noalias !2236
  br label %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E.exit", !dbg !2243

"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E.exit": ; preds = %bb1.i725, %bb597
  %_14.i724 = load ptr, ptr %36, align 8, !dbg !2244, !alias.scope !2233, !noalias !2236, !nonnull !13, !noundef !13
  %end.i = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_14.i724, i64 %len.i, !dbg !2249
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %end.i, ptr noundef nonnull readonly align 8 dereferenceable(24) %v14, i64 24, i1 false), !dbg !2251
  %272 = add i64 %len.i, 1, !dbg !2253
  store i64 %272, ptr %35, align 8, !dbg !2253, !alias.scope !2233, !noalias !2236
  br label %bb394, !dbg !2254

bb580:                                            ; preds = %bb154
  call fastcc void @"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17heb075e8674a2226aE"(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_165.sroa.5) #19, !dbg !2255
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_164.sroa.5, ptr noundef nonnull align 8 dereferenceable(24) %_165.sroa.5, i64 24, i1 false), !dbg !2258
  call void @llvm.lifetime.end.p0(ptr nonnull %_165.sroa.5), !dbg !2259
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_164.sroa.5, i64 24, i1 false), !dbg !2259
  call void @llvm.lifetime.end.p0(ptr nonnull %_164.sroa.5), !dbg !2260
  br label %bb443, !dbg !1706

bb581:                                            ; preds = %bb154
  %273 = add nsw i64 %_1386, -1, !dbg !2261
  store i64 %273, ptr %35, align 8, !dbg !2261
  %_1394 = load i64, ptr %altstack, align 8, !dbg !2262, !range !451, !noundef !13
  %_1387 = icmp samesign ult i64 %273, %_1394, !dbg !2271
  call void @llvm.assume(i1 %_1387), !dbg !2272
  %_1395 = load ptr, ptr %36, align 8, !dbg !2275, !nonnull !13, !noundef !13
  %_1396 = icmp ult i64 %_1386, 384307168202282327, !dbg !2283
  call void @llvm.assume(i1 %_1396), !dbg !2286
  %_1391 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1395, i64 %273, !dbg !2287
  call void @llvm.lifetime.end.p0(ptr nonnull %_165.sroa.5), !dbg !2259
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %v16, ptr noundef nonnull align 8 dereferenceable(24) %_1391, i64 24, i1 false), !dbg !1774
  call void @llvm.lifetime.end.p0(ptr nonnull %_164.sroa.5), !dbg !2260
  call void @llvm.lifetime.start.p0(ptr nonnull %_170), !dbg !2290
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_170, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %273, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v16) #16, !dbg !2290
  %274 = load i64, ptr %_170, align 8, !dbg !2292, !range !1747, !noundef !13
  %.not386 = icmp eq i64 %274, -9223372036854775797, !dbg !2292
  br i1 %.not386, label %bb601, label %bb600, !dbg !2293

bb600:                                            ; preds = %bb581
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_170, i64 24, i1 false), !dbg !2294
  call void @llvm.lifetime.end.p0(ptr nonnull %_170), !dbg !2295
  br label %bb443, !dbg !2296

bb601:                                            ; preds = %bb581
  call void @llvm.lifetime.end.p0(ptr nonnull %_170), !dbg !2295
  br label %bb394, !dbg !2296

bb602:                                            ; preds = %bb153
  %_1492.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_175, i64 24, !dbg !2297
  %_1492.sroa.6.0.copyload = load i64, ptr %_1492.sroa.6.0..sroa_idx, align 8, !dbg !2297
  call void @llvm.lifetime.end.p0(ptr nonnull %_175), !dbg !2298
  store i64 %_1492.sroa.0.0.copyload, ptr %_0, align 8, !dbg !2299
  %_1495.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !2299
  store ptr %_1492.sroa.5.0.copyload, ptr %_1495.sroa.2.0._0.sroa_idx, align 8, !dbg !2299
  %_1495.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !2299
  store i64 %_1492.sroa.6.0.copyload, ptr %_1495.sroa.3.0._0.sroa_idx, align 8, !dbg !2299
  br label %bb443, !dbg !1706

bb603:                                            ; preds = %bb153
  call void @llvm.lifetime.end.p0(ptr nonnull %_175), !dbg !2298
  %275 = icmp eq i64 %_1492.sroa.0.0.copyload, 0, !dbg !2305
  br i1 %275, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit729", label %bb2.i.i.i.i727, !dbg !2305

bb2.i.i.i.i727:                                   ; preds = %bb603
  %276 = icmp ne ptr %_1492.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %276)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1492.sroa.5.0.copyload, i64 noundef %_1492.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2311, !noalias !2316
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit729", !dbg !2319

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit729": ; preds = %bb2.i.i.i.i727, %bb603
  call void @llvm.lifetime.start.p0(ptr nonnull %_180), !dbg !2320
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_180, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !2320
  %_1497 = load i64, ptr %_180, align 8, !dbg !2321, !range !1765, !noundef !13
  %277 = trunc nuw i64 %_1497 to i1, !dbg !2322
  %_1499.sroa.0.0.copyload = load i64, ptr %114, align 8, !dbg !2323
  %_1499.sroa.5.0.copyload = load ptr, ptr %_1498.sroa.5.0..sroa_idx, align 8, !dbg !2323
  br i1 %277, label %bb604, label %bb605, !dbg !2322

bb604:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit729"
  %_1499.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_180, i64 24, !dbg !2324
  %_1499.sroa.6.0.copyload = load i64, ptr %_1499.sroa.6.0..sroa_idx, align 8, !dbg !2324
  call void @llvm.lifetime.end.p0(ptr nonnull %_180), !dbg !2325
  store i64 %_1499.sroa.0.0.copyload, ptr %_0, align 8, !dbg !2326
  %_1502.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !2326
  store ptr %_1499.sroa.5.0.copyload, ptr %_1502.sroa.2.0._0.sroa_idx, align 8, !dbg !2326
  %_1502.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !2326
  store i64 %_1499.sroa.6.0.copyload, ptr %_1502.sroa.3.0._0.sroa_idx, align 8, !dbg !2326
  br label %bb443, !dbg !1706

bb605:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit729"
  call void @llvm.lifetime.end.p0(ptr nonnull %_180), !dbg !2325
  %278 = icmp eq i64 %_1499.sroa.0.0.copyload, 0, !dbg !2332
  br i1 %278, label %bb394, label %bb2.i.i.i.i731, !dbg !2332

bb2.i.i.i.i731:                                   ; preds = %bb605
  %279 = icmp ne ptr %_1499.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %279)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1499.sroa.5.0.copyload, i64 noundef %_1499.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2338, !noalias !2343
  br label %bb394, !dbg !2346

bb606:                                            ; preds = %bb152
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_184, i64 24, i1 false), !dbg !2347
  call void @llvm.lifetime.end.p0(ptr nonnull %_184), !dbg !2348
  br label %bb443, !dbg !1706

bb607:                                            ; preds = %bb152
  call void @llvm.lifetime.end.p0(ptr nonnull %_184), !dbg !2348
  %_190 = load i64, ptr %39, align 8, !dbg !2349, !noundef !13
  %_1507 = icmp ult i64 %_190, 384307168202282326, !dbg !2351
  call void @llvm.assume(i1 %_1507), !dbg !2353
  %_189 = add nsw i64 %_190, -2, !dbg !2354
  %_1515 = icmp samesign ugt i64 %_190, 1, !dbg !2355
  br i1 %_1515, label %bb608, label %panic, !dbg !2355

bb608:                                            ; preds = %bb607
  %_1514 = load ptr, ptr %40, align 8, !dbg !2364, !nonnull !13, !noundef !13
  %_188 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1514, i64 %_189, !dbg !2376
  %280 = getelementptr i8, ptr %_188, i64 8, !dbg !2377
  %_188.val = load ptr, ptr %280, align 8, !dbg !2377, !nonnull !13, !noundef !13
  %281 = getelementptr i8, ptr %_188, i64 16, !dbg !2377
  %_188.val422 = load i64, ptr %281, align 8, !dbg !2377, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %a, ptr nonnull %_188.val, i64 %_188.val422) #16, !dbg !2377
  %_194 = load i64, ptr %39, align 8, !dbg !2378, !noundef !13
  %_1516 = icmp ult i64 %_194, 384307168202282326, !dbg !2381
  call void @llvm.assume(i1 %_1516), !dbg !2383
  %_193 = add nsw i64 %_194, -1, !dbg !2384
  %_1521.not = icmp eq i64 %_194, 0, !dbg !2385
  br i1 %_1521.not, label %panic172, label %bb609, !dbg !2385

panic:                                            ; preds = %bb607
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_189, i64 noundef %_190, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8c1e39ce3af88a35f82246a7e127f092) #15, !dbg !2355
  unreachable, !dbg !2355

bb609:                                            ; preds = %bb608
  %_1520 = load ptr, ptr %40, align 8, !dbg !2391, !nonnull !13, !noundef !13
  %_192 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1520, i64 %_193, !dbg !2403
  %282 = getelementptr i8, ptr %_192, i64 8, !dbg !2404
  %_192.val = load ptr, ptr %282, align 8, !dbg !2404, !nonnull !13, !noundef !13
  %283 = getelementptr i8, ptr %_192, i64 16, !dbg !2404
  %_192.val421 = load i64, ptr %283, align 8, !dbg !2404, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %b, ptr nonnull %_192.val, i64 %_192.val421) #16, !dbg !2404
  call void @llvm.lifetime.start.p0(ptr nonnull %_196), !dbg !2405
  %_197 = load i64, ptr %35, align 8, !dbg !2407, !noundef !13
  %_1522 = icmp ult i64 %_197, 384307168202282326, !dbg !2409
  call void @llvm.assume(i1 %_1522), !dbg !2411
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_196, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_197, ptr noalias noundef align 8 captures(address) dereferenceable(24) %a) #16, !dbg !2405
  %284 = load i64, ptr %_196, align 8, !dbg !2412, !range !1747, !noundef !13
  %.not384 = icmp eq i64 %284, -9223372036854775797, !dbg !2412
  br i1 %.not384, label %bb611, label %bb610, !dbg !2413

panic172:                                         ; preds = %bb608
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_193, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4a580b9d131f2da61cefd6f54c746d24) #15, !dbg !2385
  unreachable, !dbg !2385

bb610:                                            ; preds = %bb609
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_196, i64 24, i1 false), !dbg !2414
  call void @llvm.lifetime.end.p0(ptr nonnull %_196), !dbg !2415
  %_1.val.i734 = load i64, ptr %b, align 8, !dbg !2416, !range !451, !noundef !13
  %285 = icmp eq i64 %_1.val.i734, 0, !dbg !2418
  br i1 %285, label %bb443, label %bb2.i.i.i.i735, !dbg !2418

bb2.i.i.i.i735:                                   ; preds = %bb610
  %286 = getelementptr inbounds nuw i8, ptr %b, i64 8, !dbg !2416
  %_1.val1.i736 = load ptr, ptr %286, align 8, !dbg !2416, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i736, i64 noundef %_1.val.i734, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2423, !noalias !2428
  br label %bb443, !dbg !2431

bb611:                                            ; preds = %bb609
  call void @llvm.lifetime.end.p0(ptr nonnull %_196), !dbg !2415
  call void @llvm.lifetime.start.p0(ptr nonnull %_200), !dbg !2432
  %_201 = load i64, ptr %35, align 8, !dbg !2433, !noundef !13
  %_1526 = icmp ult i64 %_201, 384307168202282326, !dbg !2435
  call void @llvm.assume(i1 %_1526), !dbg !2437
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_200, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_201, ptr noalias noundef align 8 captures(address) dereferenceable(24) %b) #16, !dbg !2432
  %287 = load i64, ptr %_200, align 8, !dbg !2438, !range !1747, !noundef !13
  %.not385 = icmp eq i64 %287, -9223372036854775797, !dbg !2438
  br i1 %.not385, label %bb613, label %bb612, !dbg !2439

bb612:                                            ; preds = %bb611
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_200, i64 24, i1 false), !dbg !2440
  call void @llvm.lifetime.end.p0(ptr nonnull %_200), !dbg !2441
  br label %bb443, !dbg !2442

bb613:                                            ; preds = %bb611
  call void @llvm.lifetime.end.p0(ptr nonnull %_200), !dbg !2441
  br label %bb394, !dbg !2444

bb614:                                            ; preds = %bb151
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_205, i64 24, i1 false), !dbg !2445
  call void @llvm.lifetime.end.p0(ptr nonnull %_205), !dbg !2446
  br label %bb443, !dbg !1706

bb615:                                            ; preds = %bb151
  call void @llvm.lifetime.end.p0(ptr nonnull %_205), !dbg !2446
  %_211 = load i64, ptr %39, align 8, !dbg !2447, !noundef !13
  %_1539 = icmp ult i64 %_211, 384307168202282326, !dbg !2449
  call void @llvm.assume(i1 %_1539), !dbg !2451
  %_210 = add nsw i64 %_211, -3, !dbg !2452
  %_1547 = icmp samesign ugt i64 %_211, 2, !dbg !2453
  br i1 %_1547, label %bb616, label %panic173, !dbg !2453

bb616:                                            ; preds = %bb615
  %_1546 = load ptr, ptr %40, align 8, !dbg !2459, !nonnull !13, !noundef !13
  %_209 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1546, i64 %_210, !dbg !2471
  %288 = getelementptr i8, ptr %_209, i64 8, !dbg !2472
  %_209.val = load ptr, ptr %288, align 8, !dbg !2472, !nonnull !13, !noundef !13
  %289 = getelementptr i8, ptr %_209, i64 16, !dbg !2472
  %_209.val420 = load i64, ptr %289, align 8, !dbg !2472, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %a26, ptr nonnull %_209.val, i64 %_209.val420) #16, !dbg !2472
  %_215 = load i64, ptr %39, align 8, !dbg !2473, !noundef !13
  %_1548 = icmp ult i64 %_215, 384307168202282326, !dbg !2476
  call void @llvm.assume(i1 %_1548), !dbg !2478
  %_214 = add nsw i64 %_215, -2, !dbg !2479
  %_1553 = icmp samesign ugt i64 %_215, 1, !dbg !2480
  br i1 %_1553, label %bb617, label %panic174, !dbg !2480

panic173:                                         ; preds = %bb615
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_210, i64 noundef %_211, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_287b68c41a14dac20c7929fd1b8b2d30) #15, !dbg !2453
  unreachable, !dbg !2453

bb617:                                            ; preds = %bb616
  %_1552 = load ptr, ptr %40, align 8, !dbg !2486, !nonnull !13, !noundef !13
  %_213 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1552, i64 %_214, !dbg !2498
  %290 = getelementptr i8, ptr %_213, i64 8, !dbg !2499
  %_213.val = load ptr, ptr %290, align 8, !dbg !2499, !nonnull !13, !noundef !13
  %291 = getelementptr i8, ptr %_213, i64 16, !dbg !2499
  %_213.val419 = load i64, ptr %291, align 8, !dbg !2499, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %b27, ptr nonnull %_213.val, i64 %_213.val419) #16, !dbg !2499
  %_219 = load i64, ptr %39, align 8, !dbg !2500, !noundef !13
  %_1554 = icmp ult i64 %_219, 384307168202282326, !dbg !2503
  call void @llvm.assume(i1 %_1554), !dbg !2505
  %_218 = add nsw i64 %_219, -1, !dbg !2506
  %_1559.not = icmp eq i64 %_219, 0, !dbg !2507
  br i1 %_1559.not, label %panic175, label %bb618, !dbg !2507

panic174:                                         ; preds = %bb616
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_214, i64 noundef %_215, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0f1b902749b0d0e662e14755b98f5935) #15, !dbg !2480
  unreachable, !dbg !2480

bb618:                                            ; preds = %bb617
  %_1558 = load ptr, ptr %40, align 8, !dbg !2513, !nonnull !13, !noundef !13
  %_217 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1558, i64 %_218, !dbg !2525
  %292 = getelementptr i8, ptr %_217, i64 8, !dbg !2526
  %_217.val = load ptr, ptr %292, align 8, !dbg !2526, !nonnull !13, !noundef !13
  %293 = getelementptr i8, ptr %_217, i64 16, !dbg !2526
  %_217.val418 = load i64, ptr %293, align 8, !dbg !2526, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %c, ptr nonnull %_217.val, i64 %_217.val418) #16, !dbg !2526
  call void @llvm.lifetime.start.p0(ptr nonnull %_221), !dbg !2527
  %_222 = load i64, ptr %35, align 8, !dbg !2529, !noundef !13
  %_1560 = icmp ult i64 %_222, 384307168202282326, !dbg !2531
  call void @llvm.assume(i1 %_1560), !dbg !2533
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_221, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_222, ptr noalias noundef align 8 captures(address) dereferenceable(24) %a26) #16, !dbg !2527
  %294 = load i64, ptr %_221, align 8, !dbg !2534, !range !1747, !noundef !13
  %.not380 = icmp eq i64 %294, -9223372036854775797, !dbg !2534
  br i1 %.not380, label %bb620, label %bb619, !dbg !2535

panic175:                                         ; preds = %bb617
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_218, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ebc7827e0b8d77ab9d973903086eec33) #15, !dbg !2507
  unreachable, !dbg !2507

bb619:                                            ; preds = %bb618
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_221, i64 24, i1 false), !dbg !2536
  call void @llvm.lifetime.end.p0(ptr nonnull %_221), !dbg !2537
  %_1.val.i738 = load i64, ptr %c, align 8, !dbg !2538, !range !451, !noundef !13
  %295 = icmp eq i64 %_1.val.i738, 0, !dbg !2540
  br i1 %295, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit741", label %bb2.i.i.i.i739, !dbg !2540

bb2.i.i.i.i739:                                   ; preds = %bb619
  %296 = getelementptr inbounds nuw i8, ptr %c, i64 8, !dbg !2538
  %_1.val1.i740 = load ptr, ptr %296, align 8, !dbg !2538, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i740, i64 noundef %_1.val.i738, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2545, !noalias !2550
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit741", !dbg !2553

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit741": ; preds = %bb2.i.i.i.i739, %bb619
  %_1.val.i742 = load i64, ptr %b27, align 8, !dbg !2554, !range !451, !noundef !13
  %297 = icmp eq i64 %_1.val.i742, 0, !dbg !2556
  br i1 %297, label %bb443, label %bb2.i.i.i.i743, !dbg !2556

bb2.i.i.i.i743:                                   ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit741"
  %298 = getelementptr inbounds nuw i8, ptr %b27, i64 8, !dbg !2554
  %_1.val1.i744 = load ptr, ptr %298, align 8, !dbg !2554, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i744, i64 noundef %_1.val.i742, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2561, !noalias !2566
  br label %bb443, !dbg !2569

bb620:                                            ; preds = %bb618
  call void @llvm.lifetime.end.p0(ptr nonnull %_221), !dbg !2537
  call void @llvm.lifetime.start.p0(ptr nonnull %_225), !dbg !2570
  %_226 = load i64, ptr %35, align 8, !dbg !2571, !noundef !13
  %_1564 = icmp ult i64 %_226, 384307168202282326, !dbg !2573
  call void @llvm.assume(i1 %_1564), !dbg !2575
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_225, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_226, ptr noalias noundef align 8 captures(address) dereferenceable(24) %b27) #16, !dbg !2570
  %299 = load i64, ptr %_225, align 8, !dbg !2576, !range !1747, !noundef !13
  %.not381 = icmp eq i64 %299, -9223372036854775797, !dbg !2576
  br i1 %.not381, label %bb622, label %bb621, !dbg !2577

bb621:                                            ; preds = %bb620
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_225, i64 24, i1 false), !dbg !2578
  call void @llvm.lifetime.end.p0(ptr nonnull %_225), !dbg !2579
  %_1.val.i746 = load i64, ptr %c, align 8, !dbg !2580, !range !451, !noundef !13
  %300 = icmp eq i64 %_1.val.i746, 0, !dbg !2582
  br i1 %300, label %bb443, label %bb2.i.i.i.i747, !dbg !2582

bb2.i.i.i.i747:                                   ; preds = %bb621
  %301 = getelementptr inbounds nuw i8, ptr %c, i64 8, !dbg !2580
  %_1.val1.i748 = load ptr, ptr %301, align 8, !dbg !2580, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i748, i64 noundef %_1.val.i746, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2587, !noalias !2592
  br label %bb443, !dbg !2595

bb622:                                            ; preds = %bb620
  call void @llvm.lifetime.end.p0(ptr nonnull %_225), !dbg !2579
  call void @llvm.lifetime.start.p0(ptr nonnull %_230), !dbg !2596
  %_231 = load i64, ptr %35, align 8, !dbg !2597, !noundef !13
  %_1571 = icmp ult i64 %_231, 384307168202282326, !dbg !2599
  call void @llvm.assume(i1 %_1571), !dbg !2601
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_230, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_231, ptr noalias noundef align 8 captures(address) dereferenceable(24) %c) #16, !dbg !2596
  %302 = load i64, ptr %_230, align 8, !dbg !2602, !range !1747, !noundef !13
  %.not382 = icmp eq i64 %302, -9223372036854775797, !dbg !2602
  br i1 %.not382, label %bb624, label %bb623, !dbg !2603

bb623:                                            ; preds = %bb622
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_230, i64 24, i1 false), !dbg !2604
  call void @llvm.lifetime.end.p0(ptr nonnull %_230), !dbg !2605
  br label %bb443, !dbg !2606

bb624:                                            ; preds = %bb622
  call void @llvm.lifetime.end.p0(ptr nonnull %_230), !dbg !2605
  br label %bb394, !dbg !2608

bb625:                                            ; preds = %bb150
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_235, i64 24, i1 false), !dbg !2609
  call void @llvm.lifetime.end.p0(ptr nonnull %_235), !dbg !2610
  br label %bb443, !dbg !1706

bb626:                                            ; preds = %bb150
  call void @llvm.lifetime.end.p0(ptr nonnull %_235), !dbg !2610
  %_241 = load i64, ptr %39, align 8, !dbg !2611, !noundef !13
  %_1584 = icmp ult i64 %_241, 384307168202282326, !dbg !2613
  call void @llvm.assume(i1 %_1584), !dbg !2615
  %_240 = add nsw i64 %_241, -4, !dbg !2616
  %_1592 = icmp samesign ugt i64 %_241, 3, !dbg !2617
  br i1 %_1592, label %bb627, label %panic176, !dbg !2617

bb627:                                            ; preds = %bb626
  %_1591 = load ptr, ptr %40, align 8, !dbg !2623, !nonnull !13, !noundef !13
  %_239 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1591, i64 %_240, !dbg !2635
  %303 = getelementptr i8, ptr %_239, i64 8, !dbg !2636
  %_239.val = load ptr, ptr %303, align 8, !dbg !2636, !nonnull !13, !noundef !13
  %304 = getelementptr i8, ptr %_239, i64 16, !dbg !2636
  %_239.val417 = load i64, ptr %304, align 8, !dbg !2636, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %a32, ptr nonnull %_239.val, i64 %_239.val417) #16, !dbg !2636
  %_245 = load i64, ptr %39, align 8, !dbg !2637, !noundef !13
  %_1593 = icmp ult i64 %_245, 384307168202282326, !dbg !2640
  call void @llvm.assume(i1 %_1593), !dbg !2642
  %_244 = add nsw i64 %_245, -3, !dbg !2643
  %_1598 = icmp samesign ugt i64 %_245, 2, !dbg !2644
  br i1 %_1598, label %bb628, label %panic177, !dbg !2644

panic176:                                         ; preds = %bb626
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_240, i64 noundef %_241, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5f18aeb0c62cc58700b8ae33199cde21) #15, !dbg !2617
  unreachable, !dbg !2617

bb628:                                            ; preds = %bb627
  %_1597 = load ptr, ptr %40, align 8, !dbg !2650, !nonnull !13, !noundef !13
  %_243 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1597, i64 %_244, !dbg !2662
  %305 = getelementptr i8, ptr %_243, i64 8, !dbg !2663
  %_243.val = load ptr, ptr %305, align 8, !dbg !2663, !nonnull !13, !noundef !13
  %306 = getelementptr i8, ptr %_243, i64 16, !dbg !2663
  %_243.val416 = load i64, ptr %306, align 8, !dbg !2663, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %b33, ptr nonnull %_243.val, i64 %_243.val416) #16, !dbg !2663
  call void @llvm.lifetime.start.p0(ptr nonnull %_247), !dbg !2664
  %_248 = load i64, ptr %35, align 8, !dbg !2666, !noundef !13
  %_1599 = icmp ult i64 %_248, 384307168202282326, !dbg !2668
  call void @llvm.assume(i1 %_1599), !dbg !2670
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_247, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_248, ptr noalias noundef align 8 captures(address) dereferenceable(24) %a32) #16, !dbg !2664
  %307 = load i64, ptr %_247, align 8, !dbg !2671, !range !1747, !noundef !13
  %.not377 = icmp eq i64 %307, -9223372036854775797, !dbg !2671
  br i1 %.not377, label %bb630, label %bb629, !dbg !2672

panic177:                                         ; preds = %bb627
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_244, i64 noundef %_245, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0a9965c4a3cbdd1ca52702b024192a21) #15, !dbg !2644
  unreachable, !dbg !2644

bb629:                                            ; preds = %bb628
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_247, i64 24, i1 false), !dbg !2673
  call void @llvm.lifetime.end.p0(ptr nonnull %_247), !dbg !2674
  %_1.val.i750 = load i64, ptr %b33, align 8, !dbg !2675, !range !451, !noundef !13
  %308 = icmp eq i64 %_1.val.i750, 0, !dbg !2677
  br i1 %308, label %bb443, label %bb2.i.i.i.i751, !dbg !2677

bb2.i.i.i.i751:                                   ; preds = %bb629
  %309 = getelementptr inbounds nuw i8, ptr %b33, i64 8, !dbg !2675
  %_1.val1.i752 = load ptr, ptr %309, align 8, !dbg !2675, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i752, i64 noundef %_1.val.i750, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2682, !noalias !2687
  br label %bb443, !dbg !2690

bb630:                                            ; preds = %bb628
  call void @llvm.lifetime.end.p0(ptr nonnull %_247), !dbg !2674
  call void @llvm.lifetime.start.p0(ptr nonnull %_251), !dbg !2691
  %_252 = load i64, ptr %35, align 8, !dbg !2692, !noundef !13
  %_1603 = icmp ult i64 %_252, 384307168202282326, !dbg !2694
  call void @llvm.assume(i1 %_1603), !dbg !2696
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_251, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_252, ptr noalias noundef align 8 captures(address) dereferenceable(24) %b33) #16, !dbg !2691
  %310 = load i64, ptr %_251, align 8, !dbg !2697, !range !1747, !noundef !13
  %.not378 = icmp eq i64 %310, -9223372036854775797, !dbg !2697
  br i1 %.not378, label %bb632, label %bb631, !dbg !2698

bb631:                                            ; preds = %bb630
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_251, i64 24, i1 false), !dbg !2699
  call void @llvm.lifetime.end.p0(ptr nonnull %_251), !dbg !2700
  br label %bb443, !dbg !2701

bb632:                                            ; preds = %bb630
  call void @llvm.lifetime.end.p0(ptr nonnull %_251), !dbg !2700
  br label %bb394, !dbg !2703

bb633:                                            ; preds = %bb149
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_256, i64 24, i1 false), !dbg !2704
  call void @llvm.lifetime.end.p0(ptr nonnull %_256), !dbg !2705
  br label %bb443, !dbg !1706

bb634:                                            ; preds = %bb149
  call void @llvm.lifetime.end.p0(ptr nonnull %_256), !dbg !2705
  %n = load i64, ptr %39, align 8, !dbg !2706, !noundef !13
  %_1616 = icmp ult i64 %n, 384307168202282326, !dbg !2708
  call void @llvm.assume(i1 %_1616), !dbg !2710
  %_262 = add nsw i64 %n, -6, !dbg !2711
  %_1624 = icmp samesign ugt i64 %n, 5, !dbg !2713
  br i1 %_1624, label %bb635, label %panic178, !dbg !2713

bb635:                                            ; preds = %bb634
  %_1623 = load ptr, ptr %40, align 8, !dbg !2719, !nonnull !13, !noundef !13
  %_261 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1623, i64 %_262, !dbg !2731
  %311 = getelementptr i8, ptr %_261, i64 8, !dbg !2732
  %_261.val = load ptr, ptr %311, align 8, !dbg !2732, !nonnull !13, !noundef !13
  %312 = getelementptr i8, ptr %_261, i64 16, !dbg !2732
  %_261.val415 = load i64, ptr %312, align 8, !dbg !2732, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %x1, ptr nonnull %_261.val, i64 %_261.val415) #16, !dbg !2732
  %_265 = add nsw i64 %n, -5, !dbg !2733
  %_1627 = load i64, ptr %39, align 8, !dbg !2735, !noundef !13
  %_1629 = icmp ult i64 %_265, %_1627, !dbg !2741
  br i1 %_1629, label %bb636, label %panic179, !dbg !2741

panic178:                                         ; preds = %bb634
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_262, i64 noundef %n, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9980f6ffa5c2068096eefc358cf93bc9) #15, !dbg !2713
  unreachable, !dbg !2713

bb636:                                            ; preds = %bb635
  %_1628 = load ptr, ptr %40, align 8, !dbg !2745, !nonnull !13, !noundef !13
  %_264 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1628, i64 %_265, !dbg !2754
  %313 = getelementptr i8, ptr %_264, i64 8, !dbg !2755
  %_264.val = load ptr, ptr %313, align 8, !dbg !2755, !nonnull !13, !noundef !13
  %314 = getelementptr i8, ptr %_264, i64 16, !dbg !2755
  %_264.val414 = load i64, ptr %314, align 8, !dbg !2755, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %x2, ptr nonnull %_264.val, i64 %_264.val414) #16, !dbg !2755
  %_271 = add nsw i64 %n, -4
  call void @llvm.lifetime.start.p0(ptr nonnull %_268), !dbg !2756
  %_1636 = load i64, ptr %39, align 8, !dbg !2760, !noundef !13
  %_1638 = icmp ult i64 %_271, %_1636, !dbg !2766
  br i1 %_1638, label %bb639, label %panic182, !dbg !2766

panic179:                                         ; preds = %bb635
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_265, i64 noundef %_1627, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8d1b6d1d478bbdd9dff5b9296cde158a) #15, !dbg !2741
  unreachable, !dbg !2741

bb640:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.3"
  %_1643 = load ptr, ptr %40, align 8, !dbg !2770, !nonnull !13, !noundef !13
  %_274 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1643, i64 %_270.2, !dbg !2787
  call void @llvm.experimental.noalias.scope.decl(metadata !2793), !dbg !2796
  %_1.val.i754 = load i64, ptr %_274, align 8, !dbg !2797, !range !451, !alias.scope !2793, !noundef !13
  %315 = icmp eq i64 %_1.val.i754, 0, !dbg !2799
  br i1 %315, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit757", label %bb2.i.i.i.i755, !dbg !2799

bb2.i.i.i.i755:                                   ; preds = %bb640
  %316 = getelementptr inbounds nuw i8, ptr %_274, i64 8, !dbg !2797
  %_1.val1.i756 = load ptr, ptr %316, align 8, !dbg !2797, !alias.scope !2793, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i756, i64 noundef %_1.val.i754, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2804, !noalias !2793
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit757", !dbg !2809

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit757": ; preds = %bb2.i.i.i.i755, %bb640
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_274, ptr noundef nonnull align 8 dereferenceable(24) %x1, i64 24, i1 false), !dbg !2796
  %_1654 = load i64, ptr %39, align 8, !dbg !2810, !noundef !13
  %_1656 = icmp ult i64 %_270.3, %_1654, !dbg !2816
  br i1 %_1656, label %bb642, label %panic181, !dbg !2816

panic180:                                         ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.3"
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_270.2, i64 noundef %_1642, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_86034e9c05ba888bc245122becc3bf4d) #15, !dbg !2820
  unreachable, !dbg !2820

bb642:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit757"
  %_1655 = load ptr, ptr %40, align 8, !dbg !2821, !nonnull !13, !noundef !13
  %_276 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1655, i64 %_270.3, !dbg !2830
  call void @llvm.experimental.noalias.scope.decl(metadata !2831), !dbg !2834
  %_1.val.i758 = load i64, ptr %_276, align 8, !dbg !2835, !range !451, !alias.scope !2831, !noundef !13
  %317 = icmp eq i64 %_1.val.i758, 0, !dbg !2837
  br i1 %317, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit761", label %bb2.i.i.i.i759, !dbg !2837

bb2.i.i.i.i759:                                   ; preds = %bb642
  %318 = getelementptr inbounds nuw i8, ptr %_276, i64 8, !dbg !2835
  %_1.val1.i760 = load ptr, ptr %318, align 8, !dbg !2835, !alias.scope !2831, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i760, i64 noundef %_1.val.i758, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2842, !noalias !2831
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit761", !dbg !2847

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit761": ; preds = %bb2.i.i.i.i759, %bb642
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_276, ptr noundef nonnull align 8 dereferenceable(24) %x2, i64 24, i1 false), !dbg !2834
  br label %bb394, !dbg !2848

panic181:                                         ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit757"
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_270.3, i64 noundef %_1654, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_ad16fc515758063a13348c796d5ea08b) #15, !dbg !2816
  unreachable, !dbg !2816

bb639:                                            ; preds = %bb636
  %_1637 = load ptr, ptr %40, align 8, !dbg !2849, !nonnull !13, !noundef !13
  %_269 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1637, i64 %_271, !dbg !2858
  %319 = getelementptr i8, ptr %_269, i64 8, !dbg !2859
  %_269.val = load ptr, ptr %319, align 8, !dbg !2859, !nonnull !13, !noundef !13
  %320 = getelementptr i8, ptr %_269, i64 16, !dbg !2859
  %_269.val413 = load i64, ptr %320, align 8, !dbg !2859, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_268, ptr nonnull %_269.val, i64 %_269.val413) #16, !dbg !2859
  %_1648 = load i64, ptr %39, align 8, !dbg !2860, !noundef !13
  %_1650 = icmp ult i64 %_262, %_1648, !dbg !2866
  br i1 %_1650, label %bb641, label %panic183, !dbg !2866

panic182:                                         ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2", %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1", %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765", %bb636
  %_270.lcssa = phi i64 [ %_271, %bb636 ], [ %_270.1, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765" ], [ %_270.2, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1" ], [ %_270.3, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2" ], !dbg !2870
  %_1636.lcssa = phi i64 [ %_1636, %bb636 ], [ %_1636.1, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765" ], [ %_1636.2, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1" ], [ %_1636.3, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2" ], !dbg !2760
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_270.lcssa, i64 noundef %_1636.lcssa, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_b17cc5a745b7ec48d37520d8a0e8fab8) #15, !dbg !2766
  unreachable, !dbg !2766

bb641:                                            ; preds = %bb639
  %_1649 = load ptr, ptr %40, align 8, !dbg !2871, !nonnull !13, !noundef !13
  %_272 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1649, i64 %_262, !dbg !2880
  call void @llvm.experimental.noalias.scope.decl(metadata !2881), !dbg !2884
  %_1.val.i762 = load i64, ptr %_272, align 8, !dbg !2885, !range !451, !alias.scope !2881, !noundef !13
  %321 = icmp eq i64 %_1.val.i762, 0, !dbg !2887
  br i1 %321, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765", label %bb2.i.i.i.i763, !dbg !2887

bb2.i.i.i.i763:                                   ; preds = %bb641
  %322 = getelementptr inbounds nuw i8, ptr %_272, i64 8, !dbg !2885
  %_1.val1.i764 = load ptr, ptr %322, align 8, !dbg !2885, !alias.scope !2881, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i764, i64 noundef %_1.val.i762, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2892, !noalias !2881
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765", !dbg !2897

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765": ; preds = %bb2.i.i.i.i763, %bb641
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_272, ptr noundef nonnull align 8 dereferenceable(24) %_268, i64 24, i1 false), !dbg !2884
  call void @llvm.lifetime.end.p0(ptr nonnull %_268), !dbg !2898
  call void @llvm.lifetime.start.p0(ptr nonnull %_268), !dbg !2756
  %_270.1 = add nsw i64 %n, -3, !dbg !2870
  %_1636.1 = load i64, ptr %39, align 8, !dbg !2760, !noundef !13
  %_1638.1 = icmp ult i64 %_270.1, %_1636.1, !dbg !2766
  br i1 %_1638.1, label %bb639.1, label %panic182, !dbg !2766

bb639.1:                                          ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765"
  %_1637.1 = load ptr, ptr %40, align 8, !dbg !2849, !nonnull !13, !noundef !13
  %_269.1 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1637.1, i64 %_270.1, !dbg !2858
  %323 = getelementptr i8, ptr %_269.1, i64 8, !dbg !2859
  %_269.val.1 = load ptr, ptr %323, align 8, !dbg !2859, !nonnull !13, !noundef !13
  %324 = getelementptr i8, ptr %_269.1, i64 16, !dbg !2859
  %_269.val413.1 = load i64, ptr %324, align 8, !dbg !2859, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_268, ptr nonnull %_269.val.1, i64 %_269.val413.1) #16, !dbg !2859
  %_273.1 = add nsw i64 %n, -5, !dbg !2899
  %_1648.1 = load i64, ptr %39, align 8, !dbg !2860, !noundef !13
  %_1650.1 = icmp ult i64 %_273.1, %_1648.1, !dbg !2866
  br i1 %_1650.1, label %bb641.1, label %panic183, !dbg !2866

bb641.1:                                          ; preds = %bb639.1
  %_1649.1 = load ptr, ptr %40, align 8, !dbg !2871, !nonnull !13, !noundef !13
  %_272.1 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1649.1, i64 %_273.1, !dbg !2880
  call void @llvm.experimental.noalias.scope.decl(metadata !2900), !dbg !2884
  %_1.val.i762.1 = load i64, ptr %_272.1, align 8, !dbg !2885, !range !451, !alias.scope !2900, !noundef !13
  %325 = icmp eq i64 %_1.val.i762.1, 0, !dbg !2887
  br i1 %325, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1", label %bb2.i.i.i.i763.1, !dbg !2887

bb2.i.i.i.i763.1:                                 ; preds = %bb641.1
  %326 = getelementptr inbounds nuw i8, ptr %_272.1, i64 8, !dbg !2885
  %_1.val1.i764.1 = load ptr, ptr %326, align 8, !dbg !2885, !alias.scope !2900, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i764.1, i64 noundef %_1.val.i762.1, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2892, !noalias !2900
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1", !dbg !2897

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1": ; preds = %bb2.i.i.i.i763.1, %bb641.1
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_272.1, ptr noundef nonnull align 8 dereferenceable(24) %_268, i64 24, i1 false), !dbg !2884
  call void @llvm.lifetime.end.p0(ptr nonnull %_268), !dbg !2898
  call void @llvm.lifetime.start.p0(ptr nonnull %_268), !dbg !2756
  %_270.2 = add nsw i64 %n, -2, !dbg !2870
  %_1636.2 = load i64, ptr %39, align 8, !dbg !2760, !noundef !13
  %_1638.2 = icmp ult i64 %_270.2, %_1636.2, !dbg !2766
  br i1 %_1638.2, label %bb639.2, label %panic182, !dbg !2766

bb639.2:                                          ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.1"
  %_1637.2 = load ptr, ptr %40, align 8, !dbg !2849, !nonnull !13, !noundef !13
  %_269.2 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1637.2, i64 %_270.2, !dbg !2858
  %327 = getelementptr i8, ptr %_269.2, i64 8, !dbg !2859
  %_269.val.2 = load ptr, ptr %327, align 8, !dbg !2859, !nonnull !13, !noundef !13
  %328 = getelementptr i8, ptr %_269.2, i64 16, !dbg !2859
  %_269.val413.2 = load i64, ptr %328, align 8, !dbg !2859, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_268, ptr nonnull %_269.val.2, i64 %_269.val413.2) #16, !dbg !2859
  %_273.2 = add nsw i64 %n, -4, !dbg !2899
  %_1648.2 = load i64, ptr %39, align 8, !dbg !2860, !noundef !13
  %_1650.2 = icmp ult i64 %_273.2, %_1648.2, !dbg !2866
  br i1 %_1650.2, label %bb641.2, label %panic183, !dbg !2866

bb641.2:                                          ; preds = %bb639.2
  %_1649.2 = load ptr, ptr %40, align 8, !dbg !2871, !nonnull !13, !noundef !13
  %_272.2 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1649.2, i64 %_273.2, !dbg !2880
  call void @llvm.experimental.noalias.scope.decl(metadata !2902), !dbg !2884
  %_1.val.i762.2 = load i64, ptr %_272.2, align 8, !dbg !2885, !range !451, !alias.scope !2902, !noundef !13
  %329 = icmp eq i64 %_1.val.i762.2, 0, !dbg !2887
  br i1 %329, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2", label %bb2.i.i.i.i763.2, !dbg !2887

bb2.i.i.i.i763.2:                                 ; preds = %bb641.2
  %330 = getelementptr inbounds nuw i8, ptr %_272.2, i64 8, !dbg !2885
  %_1.val1.i764.2 = load ptr, ptr %330, align 8, !dbg !2885, !alias.scope !2902, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i764.2, i64 noundef %_1.val.i762.2, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2892, !noalias !2902
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2", !dbg !2897

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2": ; preds = %bb2.i.i.i.i763.2, %bb641.2
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_272.2, ptr noundef nonnull align 8 dereferenceable(24) %_268, i64 24, i1 false), !dbg !2884
  call void @llvm.lifetime.end.p0(ptr nonnull %_268), !dbg !2898
  call void @llvm.lifetime.start.p0(ptr nonnull %_268), !dbg !2756
  %_270.3 = add nsw i64 %n, -1, !dbg !2870
  %_1636.3 = load i64, ptr %39, align 8, !dbg !2760, !noundef !13
  %_1638.3 = icmp ult i64 %_270.3, %_1636.3, !dbg !2766
  br i1 %_1638.3, label %bb639.3, label %panic182, !dbg !2766

bb639.3:                                          ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.2"
  %_1637.3 = load ptr, ptr %40, align 8, !dbg !2849, !nonnull !13, !noundef !13
  %_269.3 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1637.3, i64 %_270.3, !dbg !2858
  %331 = getelementptr i8, ptr %_269.3, i64 8, !dbg !2859
  %_269.val.3 = load ptr, ptr %331, align 8, !dbg !2859, !nonnull !13, !noundef !13
  %332 = getelementptr i8, ptr %_269.3, i64 16, !dbg !2859
  %_269.val413.3 = load i64, ptr %332, align 8, !dbg !2859, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %_268, ptr nonnull %_269.val.3, i64 %_269.val413.3) #16, !dbg !2859
  %_273.3 = add nsw i64 %n, -3, !dbg !2899
  %_1648.3 = load i64, ptr %39, align 8, !dbg !2860, !noundef !13
  %_1650.3 = icmp ult i64 %_273.3, %_1648.3, !dbg !2866
  br i1 %_1650.3, label %bb641.3, label %panic183, !dbg !2866

bb641.3:                                          ; preds = %bb639.3
  %_1649.3 = load ptr, ptr %40, align 8, !dbg !2871, !nonnull !13, !noundef !13
  %_272.3 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1649.3, i64 %_273.3, !dbg !2880
  call void @llvm.experimental.noalias.scope.decl(metadata !2904), !dbg !2884
  %_1.val.i762.3 = load i64, ptr %_272.3, align 8, !dbg !2885, !range !451, !alias.scope !2904, !noundef !13
  %333 = icmp eq i64 %_1.val.i762.3, 0, !dbg !2887
  br i1 %333, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.3", label %bb2.i.i.i.i763.3, !dbg !2887

bb2.i.i.i.i763.3:                                 ; preds = %bb641.3
  %334 = getelementptr inbounds nuw i8, ptr %_272.3, i64 8, !dbg !2885
  %_1.val1.i764.3 = load ptr, ptr %334, align 8, !dbg !2885, !alias.scope !2904, !nonnull !13, !noundef !13
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val1.i764.3, i64 noundef %_1.val.i762.3, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !2892, !noalias !2904
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.3", !dbg !2897

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit765.3": ; preds = %bb2.i.i.i.i763.3, %bb641.3
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_272.3, ptr noundef nonnull align 8 dereferenceable(24) %_268, i64 24, i1 false), !dbg !2884
  call void @llvm.lifetime.end.p0(ptr nonnull %_268), !dbg !2898
  %_1642 = load i64, ptr %39, align 8, !dbg !2906, !noundef !13
  %_1644 = icmp ult i64 %_270.2, %_1642, !dbg !2820
  br i1 %_1644, label %bb640, label %panic180, !dbg !2820

panic183:                                         ; preds = %bb639.3, %bb639.2, %bb639.1, %bb639
  %_273.lcssa = phi i64 [ %_262, %bb639 ], [ %_273.1, %bb639.1 ], [ %_273.2, %bb639.2 ], [ %_273.3, %bb639.3 ], !dbg !2899
  %_1648.lcssa = phi i64 [ %_1648, %bb639 ], [ %_1648.1, %bb639.1 ], [ %_1648.2, %bb639.2 ], [ %_1648.3, %bb639.3 ], !dbg !2860
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_273.lcssa, i64 noundef %_1648.lcssa, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_922b91ee97ebf46e4bed364354c85188) #15, !dbg !2866
  unreachable, !dbg !2866

bb643:                                            ; preds = %bb148
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_279, i64 24, i1 false), !dbg !2907
  call void @llvm.lifetime.end.p0(ptr nonnull %_279), !dbg !2908
  br label %bb443, !dbg !1706

bb644:                                            ; preds = %bb148
  call void @llvm.lifetime.end.p0(ptr nonnull %_279), !dbg !2908
  %n184 = load i64, ptr %39, align 8, !dbg !2909, !noundef !13
  %_1660 = icmp ult i64 %n184, 384307168202282326, !dbg !2911
  call void @llvm.assume(i1 %_1660), !dbg !2913
  %_284 = add nsw i64 %n184, -4, !dbg !2914
  %_1669 = icmp samesign ugt i64 %n184, 3, !dbg !2916
  br i1 %_1669, label %bb646, label %panic185, !dbg !2916

panic185:                                         ; preds = %bb644
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_284, i64 noundef %n184, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_2abd712fd970981d4f22d89041be8450) #15, !dbg !2916
  unreachable, !dbg !2916

bb646:                                            ; preds = %bb644
  %_1667 = load ptr, ptr %40, align 8, !dbg !2919, !nonnull !13, !noundef !13
  %_1668 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1667, i64 %_284, !dbg !2931
  %335 = getelementptr %"alloc::vec::Vec<u8>", ptr %_1667, i64 %n184, !dbg !2932
  %_1670 = getelementptr i8, ptr %335, i64 -48, !dbg !2932
  call void @llvm.lifetime.start.p0(ptr nonnull %_1672), !dbg !2934
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1672, ptr noundef nonnull align 8 dereferenceable(24) %_1668, i64 24, i1 false), !dbg !2938
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1668, ptr noundef nonnull align 8 dereferenceable(24) %_1670, i64 24, i1 false), !dbg !2942
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1670, ptr noundef nonnull align 8 dereferenceable(24) %_1672, i64 24, i1 false), !dbg !2945
  call void @llvm.lifetime.end.p0(ptr nonnull %_1672), !dbg !2947
  %_1683 = load ptr, ptr %40, align 8, !dbg !2948, !nonnull !13, !noundef !13
  %_1682 = load i64, ptr %39, align 8, !dbg !2960, !noundef !13
  %_287 = add nsw i64 %n184, -3, !dbg !2961
  %_288 = add nsw i64 %n184, -1, !dbg !2962
  %_1685 = icmp ult i64 %_287, %_1682, !dbg !2963
  br i1 %_1685, label %bb648, label %panic187, !dbg !2963

bb648:                                            ; preds = %bb646
  %_1687 = icmp ult i64 %_288, %_1682, !dbg !2965
  br i1 %_1687, label %bb649, label %panic188, !dbg !2965

panic187:                                         ; preds = %bb646
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_287, i64 noundef %_1682, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_666d0333010630b2c6353720186fc8ba) #15, !dbg !2963
  unreachable, !dbg !2963

bb649:                                            ; preds = %bb648
  %_1684 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1683, i64 %_287, !dbg !2967
  %_1686 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1683, i64 %_288, !dbg !2968
  call void @llvm.lifetime.start.p0(ptr nonnull %_1688), !dbg !2969
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1688, ptr noundef nonnull align 8 dereferenceable(24) %_1684, i64 24, i1 false), !dbg !2973
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1684, ptr noundef nonnull align 8 dereferenceable(24) %_1686, i64 24, i1 false), !dbg !2977
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1686, ptr noundef nonnull align 8 dereferenceable(24) %_1688, i64 24, i1 false), !dbg !2979
  call void @llvm.lifetime.end.p0(ptr nonnull %_1688), !dbg !2981
  br label %bb394, !dbg !2982

panic188:                                         ; preds = %bb648
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_288, i64 noundef %_1682, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_666d0333010630b2c6353720186fc8ba) #15, !dbg !2965
  unreachable, !dbg !2965

bb651:                                            ; preds = %bb147
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_290, i64 24, i1 false), !dbg !2983
  call void @llvm.lifetime.end.p0(ptr nonnull %_290), !dbg !2984
  br label %bb443, !dbg !1706

bb652:                                            ; preds = %bb147
  call void @llvm.lifetime.end.p0(ptr nonnull %_290), !dbg !2984
  %_1701 = load i64, ptr %39, align 8, !dbg !2985, !noundef !13
  %_1706.not = icmp eq i64 %_1701, 0, !dbg !2989
  br i1 %_1706.not, label %bb654, label %bb653, !dbg !2989, !prof !1627

bb654:                                            ; preds = %bb652
  call void @_RNvNtCsgEmfK2I1SDS_4core6option13unwrap_failed(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_c8b2a5aa55c912d16cb979033afb3711) #15, !dbg !2993
  unreachable, !dbg !2993

bb653:                                            ; preds = %bb652
  %_1702 = load ptr, ptr %40, align 8, !dbg !2996, !nonnull !13, !noundef !13
  %336 = getelementptr %"alloc::vec::Vec<u8>", ptr %_1702, i64 %_1701, !dbg !3005
  %337 = getelementptr i8, ptr %336, i64 -8, !dbg !3006
  %_1711 = load i64, ptr %337, align 8, !dbg !3006, !noundef !13
  %_10.not.i766 = icmp eq i64 %_1711, 0, !dbg !3013
  br i1 %_10.not.i766, label %bb394, label %bb6.i767, !dbg !3013

bb6.i767:                                         ; preds = %bb653
  %338 = getelementptr i8, ptr %336, i64 -16, !dbg !3016
  %_1712 = load ptr, ptr %338, align 8, !dbg !3016, !nonnull !13, !noundef !13
  %339 = getelementptr i8, ptr %_1712, i64 %_1711, !dbg !3029
  %_12.i768 = getelementptr i8, ptr %339, i64 -1, !dbg !3029
  %_14.i769 = load i8, ptr %_12.i768, align 1, !dbg !3030, !alias.scope !3032, !noundef !13
  %_6.i770 = and i8 %_14.i769, 127, !dbg !3035
  %340 = icmp eq i8 %_6.i770, 0, !dbg !3037
  br i1 %340, label %bb1.i.i773, label %bb655, !dbg !3037

bb1.i.i773:                                       ; preds = %bb13.i.i776, %bb6.i767
  %_221.i.i774 = phi ptr [ %_22.i.i777, %bb13.i.i776 ], [ %_1712, %bb6.i767 ]
  %_12.i.not.not.i775 = icmp eq ptr %_221.i.i774, %_12.i768, !dbg !3038
  br i1 %_12.i.not.not.i775, label %bb394, label %bb13.i.i776, !dbg !3042

bb13.i.i776:                                      ; preds = %bb1.i.i773
  %_22.i.i777 = getelementptr inbounds nuw i8, ptr %_221.i.i774, i64 1, !dbg !3043
  %ptr.val.i.i778 = load i8, ptr %_221.i.i774, align 1, !dbg !3045, !alias.scope !3032, !noalias !3046, !noundef !13
  %_0.i.i.i779 = icmp eq i8 %ptr.val.i.i778, 0, !dbg !3049
  br i1 %_0.i.i.i779, label %bb1.i.i773, label %bb655, !dbg !3045

bb655:                                            ; preds = %bb13.i.i776, %bb6.i767
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %v39, ptr nonnull %_1712, i64 %_1711) #16, !dbg !3051
  call void @llvm.lifetime.start.p0(ptr nonnull %_301), !dbg !3052
  %_302 = load i64, ptr %35, align 8, !dbg !3054, !noundef !13
  %_1720 = icmp ult i64 %_302, 384307168202282326, !dbg !3056
  call void @llvm.assume(i1 %_1720), !dbg !3058
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_301, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_302, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v39) #16, !dbg !3052
  %341 = load i64, ptr %_301, align 8, !dbg !3059, !range !1747, !noundef !13
  %.not373 = icmp eq i64 %341, -9223372036854775797, !dbg !3059
  br i1 %.not373, label %bb658, label %bb657, !dbg !3060

bb657:                                            ; preds = %bb655
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_301, i64 24, i1 false), !dbg !3061
  call void @llvm.lifetime.end.p0(ptr nonnull %_301), !dbg !3062
  br label %bb443, !dbg !1706

bb658:                                            ; preds = %bb655
  call void @llvm.lifetime.end.p0(ptr nonnull %_301), !dbg !3062
  br label %bb394, !dbg !3063

bb659:                                            ; preds = %bb146
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_307, i64 24, i1 false), !dbg !3064
  call void @llvm.lifetime.end.p0(ptr nonnull %_307), !dbg !3065
  br label %bb443, !dbg !1706

bb660:                                            ; preds = %bb146
  call void @llvm.lifetime.end.p0(ptr nonnull %_307), !dbg !3065
  br label %bb394, !dbg !3066

bb661:                                            ; preds = %bb145
  %_1736.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_313, i64 24, !dbg !3067
  %_1736.sroa.6.0.copyload = load i64, ptr %_1736.sroa.6.0..sroa_idx, align 8, !dbg !3067
  call void @llvm.lifetime.end.p0(ptr nonnull %_313), !dbg !3068
  store i64 %_1736.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3069
  %_1739.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3069
  store ptr %_1736.sroa.5.0.copyload, ptr %_1739.sroa.2.0._0.sroa_idx, align 8, !dbg !3069
  %_1739.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3069
  store i64 %_1736.sroa.6.0.copyload, ptr %_1739.sroa.3.0._0.sroa_idx, align 8, !dbg !3069
  br label %bb443, !dbg !1706

bb662:                                            ; preds = %bb145
  call void @llvm.lifetime.end.p0(ptr nonnull %_313), !dbg !3068
  %342 = icmp eq i64 %_1736.sroa.0.0.copyload, 0, !dbg !3075
  br i1 %342, label %bb394, label %bb2.i.i.i.i782, !dbg !3075

bb2.i.i.i.i782:                                   ; preds = %bb662
  %343 = icmp ne ptr %_1736.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %343)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1736.sroa.5.0.copyload, i64 noundef %_1736.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3081, !noalias !3086
  br label %bb394, !dbg !3089

bb663:                                            ; preds = %bb144
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_317, i64 24, i1 false), !dbg !3090
  call void @llvm.lifetime.end.p0(ptr nonnull %_317), !dbg !3091
  br label %bb443, !dbg !1706

bb664:                                            ; preds = %bb144
  call void @llvm.lifetime.end.p0(ptr nonnull %_317), !dbg !3091
  %_1746 = load i64, ptr %39, align 8, !dbg !3092, !noundef !13
  %_1751.not = icmp eq i64 %_1746, 0, !dbg !3096
  br i1 %_1751.not, label %bb666, label %bb665, !dbg !3096, !prof !1627

bb666:                                            ; preds = %bb664
  call void @_RNvNtCsgEmfK2I1SDS_4core6option13unwrap_failed(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0ab2c02aad5382c96b2f89d0e48d7a96) #15, !dbg !3099
  unreachable, !dbg !3099

bb665:                                            ; preds = %bb664
  %_1747 = load ptr, ptr %40, align 8, !dbg !3101, !nonnull !13, !noundef !13
  %344 = getelementptr %"alloc::vec::Vec<u8>", ptr %_1747, i64 %_1746, !dbg !3110
  %345 = getelementptr i8, ptr %344, i64 -16, !dbg !3111
  %_1752.val = load ptr, ptr %345, align 8, !dbg !3111, !nonnull !13, !noundef !13
  %346 = getelementptr i8, ptr %344, i64 -8, !dbg !3111
  %_1752.val411 = load i64, ptr %346, align 8, !dbg !3111, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %v45, ptr nonnull %_1752.val, i64 %_1752.val411) #16, !dbg !3111
  call void @llvm.lifetime.start.p0(ptr nonnull %_324), !dbg !3112
  %_325 = load i64, ptr %35, align 8, !dbg !3114, !noundef !13
  %_1754 = icmp ult i64 %_325, 384307168202282326, !dbg !3116
  call void @llvm.assume(i1 %_1754), !dbg !3118
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_324, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_325, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v45) #16, !dbg !3112
  %347 = load i64, ptr %_324, align 8, !dbg !3119, !range !1747, !noundef !13
  %.not370 = icmp eq i64 %347, -9223372036854775797, !dbg !3119
  br i1 %.not370, label %bb668, label %bb667, !dbg !3120

bb667:                                            ; preds = %bb665
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_324, i64 24, i1 false), !dbg !3121
  call void @llvm.lifetime.end.p0(ptr nonnull %_324), !dbg !3122
  br label %bb443, !dbg !1706

bb668:                                            ; preds = %bb665
  call void @llvm.lifetime.end.p0(ptr nonnull %_324), !dbg !3122
  br label %bb394, !dbg !3123

bb669:                                            ; preds = %bb143
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_328, i64 24, i1 false), !dbg !3124
  call void @llvm.lifetime.end.p0(ptr nonnull %_328), !dbg !3125
  br label %bb443, !dbg !1706

bb670:                                            ; preds = %bb143
  call void @llvm.lifetime.end.p0(ptr nonnull %_328), !dbg !3125
  call void @llvm.lifetime.start.p0(ptr nonnull %_333), !dbg !3126
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_333, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !3126
  %_1767 = load i64, ptr %_333, align 8, !dbg !3127, !range !1765, !noundef !13
  %348 = trunc nuw i64 %_1767 to i1, !dbg !3128
  %_1769.sroa.0.0.copyload = load i64, ptr %110, align 8, !dbg !3129
  %_1769.sroa.5.0.copyload = load ptr, ptr %_1768.sroa.5.0..sroa_idx, align 8, !dbg !3129
  %_1769.sroa.6.0.copyload = load i64, ptr %_1768.sroa.6.0..sroa_idx, align 8, !dbg !3129
  call void @llvm.lifetime.end.p0(ptr nonnull %_333), !dbg !3130
  br i1 %348, label %bb671, label %bb672, !dbg !3128

bb671:                                            ; preds = %bb670
  store i64 %_1769.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3131
  %_1772.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3131
  store ptr %_1769.sroa.5.0.copyload, ptr %_1772.sroa.2.0._0.sroa_idx, align 8, !dbg !3131
  %_1772.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3131
  store i64 %_1769.sroa.6.0.copyload, ptr %_1772.sroa.3.0._0.sroa_idx, align 8, !dbg !3131
  br label %bb443, !dbg !1706

bb672:                                            ; preds = %bb670
  call void @llvm.lifetime.start.p0(ptr nonnull %_338), !dbg !3137
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_338, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !3137
  %_1774 = load i64, ptr %_338, align 8, !dbg !3139, !range !1765, !noundef !13
  %349 = trunc nuw i64 %_1774 to i1, !dbg !3140
  %_1776.sroa.0.0.copyload = load i64, ptr %111, align 8, !dbg !3141
  %_1776.sroa.5.0.copyload = load ptr, ptr %_1775.sroa.5.0..sroa_idx, align 8, !dbg !3141
  br i1 %349, label %bb673, label %bb674, !dbg !3140

bb673:                                            ; preds = %bb672
  %_1776.sroa.6.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_338, i64 24, !dbg !3142
  %_1776.sroa.6.0.copyload = load i64, ptr %_1776.sroa.6.0..sroa_idx, align 8, !dbg !3142
  call void @llvm.lifetime.end.p0(ptr nonnull %_338), !dbg !3143
  store i64 %_1776.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3144
  %_1779.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3144
  store ptr %_1776.sroa.5.0.copyload, ptr %_1779.sroa.2.0._0.sroa_idx, align 8, !dbg !3144
  %_1779.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3144
  store i64 %_1776.sroa.6.0.copyload, ptr %_1779.sroa.3.0._0.sroa_idx, align 8, !dbg !3144
  %350 = icmp eq i64 %_1769.sroa.0.0.copyload, 0, !dbg !3150
  br i1 %350, label %bb443, label %bb2.i.i.i.i786, !dbg !3150

bb2.i.i.i.i786:                                   ; preds = %bb673
  %351 = icmp ne ptr %_1769.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %351)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1769.sroa.5.0.copyload, i64 noundef %_1769.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3156, !noalias !3161
  br label %bb443, !dbg !3164

bb674:                                            ; preds = %bb672
  call void @llvm.lifetime.end.p0(ptr nonnull %_338), !dbg !3143
  %352 = icmp eq i64 %_1776.sroa.0.0.copyload, 0, !dbg !3165
  br i1 %352, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit792", label %bb2.i.i.i.i790, !dbg !3165

bb2.i.i.i.i790:                                   ; preds = %bb674
  %353 = icmp ne ptr %_1776.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %353)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1776.sroa.5.0.copyload, i64 noundef %_1776.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3171, !noalias !3176
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit792", !dbg !3179

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit792": ; preds = %bb2.i.i.i.i790, %bb674
  call void @llvm.lifetime.start.p0(ptr nonnull %_342), !dbg !3180
  %_343 = load i64, ptr %35, align 8, !dbg !3181, !noundef !13
  %_1781 = icmp ult i64 %_343, 384307168202282326, !dbg !3183
  call void @llvm.assume(i1 %_1781), !dbg !3185
  call void @llvm.lifetime.start.p0(ptr nonnull %_344), !dbg !3186
  store i64 %_1769.sroa.0.0.copyload, ptr %_344, align 8, !dbg !3186
  store ptr %_1769.sroa.5.0.copyload, ptr %top.sroa.6.0._344.sroa_idx, align 8, !dbg !3186
  store i64 %_1769.sroa.6.0.copyload, ptr %top.sroa.7.0._344.sroa_idx, align 8, !dbg !3186
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_342, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_343, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_344) #16, !dbg !3180
  call void @llvm.lifetime.end.p0(ptr nonnull %_344), !dbg !3187
  %354 = load i64, ptr %_342, align 8, !dbg !3188, !range !1747, !noundef !13
  %.not368 = icmp eq i64 %354, -9223372036854775797, !dbg !3188
  br i1 %.not368, label %bb676, label %bb675, !dbg !3189

bb675:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit792"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_342, i64 24, i1 false), !dbg !3190
  call void @llvm.lifetime.end.p0(ptr nonnull %_342), !dbg !3191
  br label %bb443, !dbg !3192

bb676:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit792"
  call void @llvm.lifetime.end.p0(ptr nonnull %_342), !dbg !3191
  br label %bb394, !dbg !3194

bb677:                                            ; preds = %bb142
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_347, i64 24, i1 false), !dbg !3195
  call void @llvm.lifetime.end.p0(ptr nonnull %_347), !dbg !3196
  br label %bb443, !dbg !1706

bb678:                                            ; preds = %bb142
  call void @llvm.lifetime.end.p0(ptr nonnull %_347), !dbg !3196
  %_353 = load i64, ptr %39, align 8, !dbg !3197, !noundef !13
  %_1791 = icmp ult i64 %_353, 384307168202282326, !dbg !3199
  call void @llvm.assume(i1 %_1791), !dbg !3201
  %_352 = add nsw i64 %_353, -2, !dbg !3202
  %_1799 = icmp samesign ugt i64 %_353, 1, !dbg !3203
  br i1 %_1799, label %bb679, label %panic189, !dbg !3203

bb679:                                            ; preds = %bb678
  %_1798 = load ptr, ptr %40, align 8, !dbg !3209, !nonnull !13, !noundef !13
  %_351 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1798, i64 %_352, !dbg !3221
  %355 = getelementptr i8, ptr %_351, i64 8, !dbg !3222
  %_351.val = load ptr, ptr %355, align 8, !dbg !3222, !nonnull !13, !noundef !13
  %356 = getelementptr i8, ptr %_351, i64 16, !dbg !3222
  %_351.val410 = load i64, ptr %356, align 8, !dbg !3222, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %v54, ptr nonnull %_351.val, i64 %_351.val410) #16, !dbg !3222
  call void @llvm.lifetime.start.p0(ptr nonnull %_355), !dbg !3223
  %_356 = load i64, ptr %35, align 8, !dbg !3225, !noundef !13
  %_1800 = icmp ult i64 %_356, 384307168202282326, !dbg !3227
  call void @llvm.assume(i1 %_1800), !dbg !3229
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_355, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_356, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v54) #16, !dbg !3223
  %357 = load i64, ptr %_355, align 8, !dbg !3230, !range !1747, !noundef !13
  %.not366 = icmp eq i64 %357, -9223372036854775797, !dbg !3230
  br i1 %.not366, label %bb681, label %bb680, !dbg !3231

panic189:                                         ; preds = %bb678
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_352, i64 noundef %_353, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_258b29efb2df021f7cd25bd9f7592621) #15, !dbg !3203
  unreachable, !dbg !3203

bb680:                                            ; preds = %bb679
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_355, i64 24, i1 false), !dbg !3232
  call void @llvm.lifetime.end.p0(ptr nonnull %_355), !dbg !3233
  br label %bb443, !dbg !1706

bb681:                                            ; preds = %bb679
  call void @llvm.lifetime.end.p0(ptr nonnull %_355), !dbg !3233
  br label %bb394, !dbg !3234

bb682:                                            ; preds = %bb141
  store i64 %_1809.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3235
  %_1816.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3235
  store ptr %_1809.sroa.5.0.copyload, ptr %_1816.sroa.2.0._0.sroa_idx, align 8, !dbg !3235
  %_1816.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3235
  store i64 %_1809.sroa.6.0.copyload, ptr %_1816.sroa.3.0._0.sroa_idx, align 8, !dbg !3235
  call void @llvm.lifetime.end.p0(ptr nonnull %_359), !dbg !3241
  br label %bb443, !dbg !1706

bb683:                                            ; preds = %bb141
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_359, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_1809.sroa.5.0.copyload, i64 noundef %_1809.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1865
  %358 = load i8, ptr %_359, align 8, !dbg !3242, !range !144, !noundef !13
  %359 = trunc nuw i8 %358 to i1, !dbg !3242
  br i1 %359, label %bb684, label %bb685, !dbg !3244

bb684:                                            ; preds = %bb683
  %360 = getelementptr inbounds nuw i8, ptr %_359, i64 1, !dbg !3245
  %361 = load i8, ptr %360, align 1, !dbg !3245, !range !144, !noundef !13
  %_1820 = trunc nuw i8 %361 to i1, !dbg !3245
  call void @llvm.lifetime.end.p0(ptr nonnull %_359), !dbg !3241
  call void @llvm.lifetime.start.p0(ptr nonnull %_1824), !dbg !3246
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_1824, i1 noundef zeroext %_1820) #16, !dbg !3246
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_1824, i64 24, i1 false), !dbg !3253
  call void @llvm.lifetime.end.p0(ptr nonnull %_1824), !dbg !3254
  %362 = icmp eq i64 %_1809.sroa.0.0.copyload, 0, !dbg !3255
  br i1 %362, label %bb443, label %bb2.i.i.i.i794, !dbg !3255

bb2.i.i.i.i794:                                   ; preds = %bb684
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1809.sroa.5.0.copyload, i64 noundef %_1809.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3261, !noalias !3266
  br label %bb443, !dbg !3269

bb685:                                            ; preds = %bb683
  %_1819 = load i64, ptr %109, align 8, !dbg !3270, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_359), !dbg !3241
  %363 = icmp eq i64 %_1809.sroa.0.0.copyload, 0, !dbg !3271
  br i1 %363, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit800", label %bb2.i.i.i.i798, !dbg !3271

bb2.i.i.i.i798:                                   ; preds = %bb685
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1809.sroa.5.0.copyload, i64 noundef %_1809.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3277, !noalias !3282
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit800", !dbg !3285

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit800": ; preds = %bb2.i.i.i.i798, %bb685
  %_368 = icmp slt i64 %_1819, 0, !dbg !3286
  br i1 %_368, label %bb225, label %bb223, !dbg !3286

bb223:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit800"
  %_371 = load i64, ptr %39, align 8, !dbg !3288, !noundef !13
  %_1826 = icmp ult i64 %_371, 384307168202282326, !dbg !3290
  call void @llvm.assume(i1 %_1826), !dbg !3292
  %_369.not = icmp samesign ult i64 %_1819, %_371, !dbg !3293
  br i1 %_369.not, label %bb226, label %bb225, !dbg !3293

bb225:                                            ; preds = %bb223, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit800"
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !3294, !noalias !3316
  %364 = call noundef dereferenceable_or_null(7) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 7, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3319, !noalias !3316
  %365 = icmp eq ptr %364, null, !dbg !3324
  br i1 %365, label %bb690, label %bb691, !dbg !3325

bb226:                                            ; preds = %bb223
  %366 = xor i64 %_1819, -1, !dbg !3326
  %_376 = add nsw i64 %_371, %366, !dbg !3326
  %_1851 = icmp ult i64 %_376, %_371, !dbg !3327
  br i1 %_1851, label %bb692, label %panic191, !dbg !3327

bb692:                                            ; preds = %bb226
  %_1850 = load ptr, ptr %40, align 8, !dbg !3333, !nonnull !13, !noundef !13
  %_375 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1850, i64 %_376, !dbg !3345
  %367 = getelementptr i8, ptr %_375, i64 8, !dbg !3346
  %_375.val = load ptr, ptr %367, align 8, !dbg !3346, !nonnull !13, !noundef !13
  %368 = getelementptr i8, ptr %_375, i64 16, !dbg !3346
  %_375.val409 = load i64, ptr %368, align 8, !dbg !3346, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %v58, ptr nonnull %_375.val, i64 %_375.val409) #16, !dbg !3346
  call void @llvm.lifetime.start.p0(ptr nonnull %_380), !dbg !3347
  %_381 = load i64, ptr %35, align 8, !dbg !3349, !noundef !13
  %_1852 = icmp ult i64 %_381, 384307168202282326, !dbg !3351
  call void @llvm.assume(i1 %_1852), !dbg !3353
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_380, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_381, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v58) #16, !dbg !3347
  %369 = load i64, ptr %_380, align 8, !dbg !3354, !range !1747, !noundef !13
  %.not364 = icmp eq i64 %369, -9223372036854775797, !dbg !3354
  br i1 %.not364, label %bb694, label %bb693, !dbg !3355

panic191:                                         ; preds = %bb226
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_376, i64 noundef %_371, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_8a42701a1650e5b5044dc0cbe1c4580c) #15, !dbg !3327
  unreachable, !dbg !3327

bb693:                                            ; preds = %bb692
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_380, i64 24, i1 false), !dbg !3356
  call void @llvm.lifetime.end.p0(ptr nonnull %_380), !dbg !3357
  br label %bb443, !dbg !3358

bb694:                                            ; preds = %bb692
  call void @llvm.lifetime.end.p0(ptr nonnull %_380), !dbg !3357
  br label %bb394, !dbg !3360

bb690:                                            ; preds = %bb225
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 7) #17, !dbg !3361
  unreachable, !dbg !3361

bb691:                                            ; preds = %bb225
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %364, ptr noundef nonnull align 1 dereferenceable(7) @alloc_12a3a1b51194abbb5aa46d311bf28d16, i64 7, i1 false), !dbg !3363
  store i64 7, ptr %_0, align 8, !dbg !3369
  %_372.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3369
  store ptr %364, ptr %_372.sroa.4.0._0.sroa_idx, align 8, !dbg !3369
  %_372.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3369
  store i64 7, ptr %_372.sroa.5.0._0.sroa_idx, align 8, !dbg !3369
  br label %bb443, !dbg !3358

bb695:                                            ; preds = %bb140
  store i64 %_1861.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3370
  %_1868.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3370
  store ptr %_1861.sroa.5.0.copyload, ptr %_1868.sroa.2.0._0.sroa_idx, align 8, !dbg !3370
  %_1868.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3370
  store i64 %_1861.sroa.6.0.copyload, ptr %_1868.sroa.3.0._0.sroa_idx, align 8, !dbg !3370
  call void @llvm.lifetime.end.p0(ptr nonnull %_384), !dbg !3376
  br label %bb443, !dbg !1706

bb696:                                            ; preds = %bb140
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_384, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_1861.sroa.5.0.copyload, i64 noundef %_1861.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1871
  %370 = load i8, ptr %_384, align 8, !dbg !3377, !range !144, !noundef !13
  %371 = trunc nuw i8 %370 to i1, !dbg !3377
  br i1 %371, label %bb697, label %bb698, !dbg !3378

bb697:                                            ; preds = %bb696
  %372 = getelementptr inbounds nuw i8, ptr %_384, i64 1, !dbg !3379
  %373 = load i8, ptr %372, align 1, !dbg !3379, !range !144, !noundef !13
  %_1872 = trunc nuw i8 %373 to i1, !dbg !3379
  call void @llvm.lifetime.end.p0(ptr nonnull %_384), !dbg !3376
  call void @llvm.lifetime.start.p0(ptr nonnull %_1876), !dbg !3380
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_1876, i1 noundef zeroext %_1872) #16, !dbg !3380
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_1876, i64 24, i1 false), !dbg !3386
  call void @llvm.lifetime.end.p0(ptr nonnull %_1876), !dbg !3387
  %374 = icmp eq i64 %_1861.sroa.0.0.copyload, 0, !dbg !3388
  br i1 %374, label %bb443, label %bb2.i.i.i.i810, !dbg !3388

bb2.i.i.i.i810:                                   ; preds = %bb697
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1861.sroa.5.0.copyload, i64 noundef %_1861.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3394, !noalias !3399
  br label %bb443, !dbg !3402

bb698:                                            ; preds = %bb696
  %_1871 = load i64, ptr %107, align 8, !dbg !3403, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_384), !dbg !3376
  %375 = icmp eq i64 %_1861.sroa.0.0.copyload, 0, !dbg !3404
  br i1 %375, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit816", label %bb2.i.i.i.i814, !dbg !3404

bb2.i.i.i.i814:                                   ; preds = %bb698
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1861.sroa.5.0.copyload, i64 noundef %_1861.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3410, !noalias !3415
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit816", !dbg !3418

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit816": ; preds = %bb2.i.i.i.i814, %bb698
  %_393 = icmp slt i64 %_1871, 0, !dbg !3419
  br i1 %_393, label %bb233, label %bb231, !dbg !3419

bb231:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit816"
  %_396 = load i64, ptr %39, align 8, !dbg !3421, !noundef !13
  %_1878 = icmp ult i64 %_396, 384307168202282326, !dbg !3423
  call void @llvm.assume(i1 %_1878), !dbg !3425
  %_394.not = icmp samesign ult i64 %_1871, %_396, !dbg !3426
  br i1 %_394.not, label %bb234, label %bb233, !dbg !3426

bb233:                                            ; preds = %bb231, %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit816"
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !3427, !noalias !3449
  %376 = call noundef dereferenceable_or_null(7) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 7, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3452, !noalias !3449
  %377 = icmp eq ptr %376, null, !dbg !3457
  br i1 %377, label %bb703, label %bb704, !dbg !3458

bb234:                                            ; preds = %bb231
  %378 = xor i64 %_1871, -1, !dbg !3459
  %idx = add nsw i64 %_396, %378, !dbg !3459
  call fastcc void @"_ZN5alloc3vec16Vec$LT$T$C$A$GT$6remove17h5557be3c5b5ee181E"(ptr noalias noundef align 8 captures(none) dereferenceable(24) %v62, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %idx) #16, !dbg !3460
  call void @llvm.lifetime.start.p0(ptr nonnull %_404), !dbg !3462
  %_405 = load i64, ptr %35, align 8, !dbg !3464, !noundef !13
  %_1899 = icmp ult i64 %_405, 384307168202282326, !dbg !3466
  call void @llvm.assume(i1 %_1899), !dbg !3468
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_404, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_405, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v62) #16, !dbg !3462
  %379 = load i64, ptr %_404, align 8, !dbg !3469, !range !1747, !noundef !13
  %.not363 = icmp eq i64 %379, -9223372036854775797, !dbg !3469
  br i1 %.not363, label %bb706, label %bb705, !dbg !3470

bb705:                                            ; preds = %bb234
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_404, i64 24, i1 false), !dbg !3471
  call void @llvm.lifetime.end.p0(ptr nonnull %_404), !dbg !3472
  br label %bb443, !dbg !3473

bb706:                                            ; preds = %bb234
  call void @llvm.lifetime.end.p0(ptr nonnull %_404), !dbg !3472
  br label %bb394, !dbg !3475

bb703:                                            ; preds = %bb233
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 7) #17, !dbg !3476
  unreachable, !dbg !3476

bb704:                                            ; preds = %bb233
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(7) %376, ptr noundef nonnull align 1 dereferenceable(7) @alloc_b5caa6874f22c115442d07cb19e5dbac, i64 7, i1 false), !dbg !3478
  store i64 7, ptr %_0, align 8, !dbg !3484
  %_397.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3484
  store ptr %376, ptr %_397.sroa.4.0._0.sroa_idx, align 8, !dbg !3484
  %_397.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3484
  store i64 7, ptr %_397.sroa.5.0._0.sroa_idx, align 8, !dbg !3484
  br label %bb443, !dbg !3473

bb707:                                            ; preds = %bb139
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_408, i64 24, i1 false), !dbg !3485
  call void @llvm.lifetime.end.p0(ptr nonnull %_408), !dbg !3486
  br label %bb443, !dbg !1706

bb708:                                            ; preds = %bb139
  call void @llvm.lifetime.end.p0(ptr nonnull %_408), !dbg !3486
  %n195 = load i64, ptr %39, align 8, !dbg !3487, !noundef !13
  %_1909 = icmp ult i64 %n195, 384307168202282326, !dbg !3489
  call void @llvm.assume(i1 %_1909), !dbg !3491
  %_413 = add nsw i64 %n195, -3, !dbg !3492
  %_414 = add nsw i64 %n195, -2, !dbg !3494
  %_1918 = icmp samesign ugt i64 %n195, 2, !dbg !3495
  br i1 %_1918, label %bb710, label %panic196, !dbg !3495

panic196:                                         ; preds = %bb708
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_413, i64 noundef %n195, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_3c2cc3bd212fbb745d0642ddde6dce4f) #15, !dbg !3495
  unreachable, !dbg !3495

bb710:                                            ; preds = %bb708
  %_1916 = load ptr, ptr %40, align 8, !dbg !3497, !nonnull !13, !noundef !13
  %_1917 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1916, i64 %_413, !dbg !3509
  %_1919 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1916, i64 %_414, !dbg !3510
  call void @llvm.lifetime.start.p0(ptr nonnull %_1921), !dbg !3512
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1921, ptr noundef nonnull align 8 dereferenceable(24) %_1917, i64 24, i1 false), !dbg !3516
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1917, ptr noundef nonnull align 8 dereferenceable(24) %_1919, i64 24, i1 false), !dbg !3520
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1919, ptr noundef nonnull align 8 dereferenceable(24) %_1921, i64 24, i1 false), !dbg !3522
  call void @llvm.lifetime.end.p0(ptr nonnull %_1921), !dbg !3524
  %_1932 = load ptr, ptr %40, align 8, !dbg !3525, !nonnull !13, !noundef !13
  %_1931 = load i64, ptr %39, align 8, !dbg !3537, !noundef !13
  %_416 = add nsw i64 %n195, -1, !dbg !3538
  %_1934 = icmp ult i64 %_414, %_1931, !dbg !3539
  br i1 %_1934, label %bb712, label %panic198, !dbg !3539

bb712:                                            ; preds = %bb710
  %_1936 = icmp ult i64 %_416, %_1931, !dbg !3541
  br i1 %_1936, label %bb713, label %panic199, !dbg !3541

panic198:                                         ; preds = %bb710
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_414, i64 noundef %_1931, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5d258eacc014a54fb47cea2410e0d855) #15, !dbg !3539
  unreachable, !dbg !3539

bb713:                                            ; preds = %bb712
  %_1933 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1932, i64 %_414, !dbg !3543
  %_1935 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1932, i64 %_416, !dbg !3544
  call void @llvm.lifetime.start.p0(ptr nonnull %_1937), !dbg !3545
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1937, ptr noundef nonnull align 8 dereferenceable(24) %_1933, i64 24, i1 false), !dbg !3549
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1933, ptr noundef nonnull align 8 dereferenceable(24) %_1935, i64 24, i1 false), !dbg !3553
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1935, ptr noundef nonnull align 8 dereferenceable(24) %_1937, i64 24, i1 false), !dbg !3555
  call void @llvm.lifetime.end.p0(ptr nonnull %_1937), !dbg !3557
  br label %bb394, !dbg !3558

panic199:                                         ; preds = %bb712
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_416, i64 noundef %_1931, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_5d258eacc014a54fb47cea2410e0d855) #15, !dbg !3541
  unreachable, !dbg !3541

bb715:                                            ; preds = %bb138
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_418, i64 24, i1 false), !dbg !3559
  call void @llvm.lifetime.end.p0(ptr nonnull %_418), !dbg !3560
  br label %bb443, !dbg !1706

bb716:                                            ; preds = %bb138
  call void @llvm.lifetime.end.p0(ptr nonnull %_418), !dbg !3560
  %n200 = load i64, ptr %39, align 8, !dbg !3561, !noundef !13
  %_1948 = icmp ult i64 %n200, 384307168202282326, !dbg !3563
  call void @llvm.assume(i1 %_1948), !dbg !3565
  %_423 = add nsw i64 %n200, -1, !dbg !3566
  %_424 = add nsw i64 %n200, -2, !dbg !3568
  switch i64 %n200, label %bb718 [
    i64 0, label %panic201
    i64 1, label %panic202
  ], !dbg !3569

panic201:                                         ; preds = %bb716
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_423, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d978a3349aa7cd3c95063ff43397d969) #15, !dbg !3569
  unreachable, !dbg !3569

bb718:                                            ; preds = %bb716
  %_1955 = load ptr, ptr %40, align 8, !dbg !3571, !nonnull !13, !noundef !13
  %_1956 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1955, i64 %_423, !dbg !3583
  %_1958 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1955, i64 %_424, !dbg !3584
  call void @llvm.lifetime.start.p0(ptr nonnull %_1960), !dbg !3586
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1960, ptr noundef nonnull align 8 dereferenceable(24) %_1956, i64 24, i1 false), !dbg !3590
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1956, ptr noundef nonnull align 8 dereferenceable(24) %_1958, i64 24, i1 false), !dbg !3594
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1958, ptr noundef nonnull align 8 dereferenceable(24) %_1960, i64 24, i1 false), !dbg !3596
  call void @llvm.lifetime.end.p0(ptr nonnull %_1960), !dbg !3598
  br label %bb394, !dbg !3599

panic202:                                         ; preds = %bb716
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_424, i64 noundef 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_d978a3349aa7cd3c95063ff43397d969) #15, !dbg !3600
  unreachable, !dbg !3600

bb720:                                            ; preds = %bb137
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_426, i64 24, i1 false), !dbg !3601
  call void @llvm.lifetime.end.p0(ptr nonnull %_426), !dbg !3602
  br label %bb443, !dbg !1706

bb721:                                            ; preds = %bb137
  call void @llvm.lifetime.end.p0(ptr nonnull %_426), !dbg !3602
  %_432 = load i64, ptr %39, align 8, !dbg !3603, !noundef !13
  %_1971 = icmp ult i64 %_432, 384307168202282326, !dbg !3605
  call void @llvm.assume(i1 %_1971), !dbg !3607
  %_431 = add nsw i64 %_432, -1, !dbg !3608
  %_1979.not = icmp eq i64 %_432, 0, !dbg !3609
  br i1 %_1979.not, label %panic203, label %bb722, !dbg !3609

bb722:                                            ; preds = %bb721
  %_1978 = load ptr, ptr %40, align 8, !dbg !3615, !nonnull !13, !noundef !13
  %_430 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1978, i64 %_431, !dbg !3627
  %380 = getelementptr i8, ptr %_430, i64 8, !dbg !3628
  %_430.val = load ptr, ptr %380, align 8, !dbg !3628, !nonnull !13, !noundef !13
  %381 = getelementptr i8, ptr %_430, i64 16, !dbg !3628
  %_430.val408 = load i64, ptr %381, align 8, !dbg !3628, !noundef !13
  call fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr noalias noundef align 8 captures(address) dereferenceable(24) %v67, ptr nonnull %_430.val, i64 %_430.val408) #16, !dbg !3628
  call void @llvm.lifetime.start.p0(ptr nonnull %_434), !dbg !3629
  %_435 = load i64, ptr %35, align 8, !dbg !3631, !noundef !13
  %_1980 = icmp ult i64 %_435, 384307168202282326, !dbg !3633
  call void @llvm.assume(i1 %_1980), !dbg !3635
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_434, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_435, ptr noalias noundef align 8 captures(address) dereferenceable(24) %v67) #16, !dbg !3629
  %382 = load i64, ptr %_434, align 8, !dbg !3636, !range !1747, !noundef !13
  %.not360 = icmp eq i64 %382, -9223372036854775797, !dbg !3636
  br i1 %.not360, label %bb724, label %bb723, !dbg !3637

panic203:                                         ; preds = %bb721
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_431, i64 noundef 0, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_290fd00cfc3b7116260877937e5355a9) #15, !dbg !3609
  unreachable, !dbg !3609

bb723:                                            ; preds = %bb722
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_434, i64 24, i1 false), !dbg !3638
  call void @llvm.lifetime.end.p0(ptr nonnull %_434), !dbg !3639
  br label %bb443, !dbg !1706

bb724:                                            ; preds = %bb722
  call void @llvm.lifetime.end.p0(ptr nonnull %_434), !dbg !3639
  %n204 = load i64, ptr %39, align 8, !dbg !3640, !noundef !13
  %_1984 = icmp ult i64 %n204, 384307168202282326, !dbg !3642
  call void @llvm.assume(i1 %_1984), !dbg !3644
  %_439 = add nsw i64 %n204, -3, !dbg !3645
  %_1993 = icmp samesign ugt i64 %n204, 2, !dbg !3647
  br i1 %_1993, label %bb726, label %panic205, !dbg !3647

panic205:                                         ; preds = %bb724
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_439, i64 noundef %n204, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_0a4d61ab70805cc6d586003c1e407b6e) #15, !dbg !3647
  unreachable, !dbg !3647

bb726:                                            ; preds = %bb724
  %_1991 = load ptr, ptr %40, align 8, !dbg !3649, !nonnull !13, !noundef !13
  %_1992 = getelementptr inbounds nuw %"alloc::vec::Vec<u8>", ptr %_1991, i64 %_439, !dbg !3661
  %383 = getelementptr %"alloc::vec::Vec<u8>", ptr %_1991, i64 %n204, !dbg !3662
  %_1994 = getelementptr i8, ptr %383, i64 -48, !dbg !3662
  call void @llvm.lifetime.start.p0(ptr nonnull %_1996), !dbg !3664
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1996, ptr noundef nonnull align 8 dereferenceable(24) %_1992, i64 24, i1 false), !dbg !3668
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1992, ptr noundef nonnull align 8 dereferenceable(24) %_1994, i64 24, i1 false), !dbg !3672
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_1994, ptr noundef nonnull align 8 dereferenceable(24) %_1996, i64 24, i1 false), !dbg !3674
  call void @llvm.lifetime.end.p0(ptr nonnull %_1996), !dbg !3676
  br label %bb394, !dbg !3677

bb728:                                            ; preds = %bb136
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_442, i64 24, i1 false), !dbg !3678
  call void @llvm.lifetime.end.p0(ptr nonnull %_442), !dbg !3679
  br label %bb443, !dbg !1706

bb729:                                            ; preds = %bb136
  call void @llvm.lifetime.end.p0(ptr nonnull %_442), !dbg !3679
  %_2009 = load i64, ptr %39, align 8, !dbg !3680, !noundef !13
  %_2014.not = icmp eq i64 %_2009, 0, !dbg !3684
  br i1 %_2014.not, label %bb731, label %bb730, !dbg !3684, !prof !1627

bb731:                                            ; preds = %bb729
  call void @_RNvNtCsgEmfK2I1SDS_4core6option13unwrap_failed(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4b4e5ff22c0d040e35e90e47094297c4) #15, !dbg !3687
  unreachable, !dbg !3687

bb730:                                            ; preds = %bb729
  %_2010 = load ptr, ptr %40, align 8, !dbg !3689, !nonnull !13, !noundef !13
  %384 = getelementptr %"alloc::vec::Vec<u8>", ptr %_2010, i64 %_2009, !dbg !3698
  %385 = getelementptr i8, ptr %384, i64 -8, !dbg !3699
  %_446 = load i64, ptr %385, align 8, !dbg !3699, !noundef !13
  %_2017 = icmp sgt i64 %_446, -1, !dbg !3701
  call void @llvm.assume(i1 %_2017), !dbg !3703
  call void @llvm.lifetime.start.p0(ptr nonnull %_450), !dbg !3704
  %_451 = load i64, ptr %35, align 8, !dbg !3706, !noundef !13
  %_2018 = icmp ult i64 %_451, 384307168202282326, !dbg !3708
  call void @llvm.assume(i1 %_2018), !dbg !3710
  call void @llvm.lifetime.start.p0(ptr nonnull %_452), !dbg !3711
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_452, i64 noundef %_446) #16, !dbg !3711
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_450, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_451, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_452) #16, !dbg !3704
  call void @llvm.lifetime.end.p0(ptr nonnull %_452), !dbg !3712
  %386 = load i64, ptr %_450, align 8, !dbg !3713, !range !1747, !noundef !13
  %.not358 = icmp eq i64 %386, -9223372036854775797, !dbg !3713
  br i1 %.not358, label %bb733, label %bb732, !dbg !3714

bb732:                                            ; preds = %bb730
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_450, i64 24, i1 false), !dbg !3715
  call void @llvm.lifetime.end.p0(ptr nonnull %_450), !dbg !3716
  br label %bb443, !dbg !1706

bb733:                                            ; preds = %bb730
  call void @llvm.lifetime.end.p0(ptr nonnull %_450), !dbg !3716
  br label %bb394, !dbg !3717

bb734:                                            ; preds = %bb135
  store i64 %_2027.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3718
  %_2030.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3718
  store ptr %_2027.sroa.5.0.copyload, ptr %_2030.sroa.2.0._0.sroa_idx, align 8, !dbg !3718
  %_2030.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3718
  store i64 %_2027.sroa.6.0.copyload, ptr %_2030.sroa.3.0._0.sroa_idx, align 8, !dbg !3718
  br label %bb443, !dbg !1706

bb735:                                            ; preds = %bb135
  call void @llvm.lifetime.start.p0(ptr nonnull %_461), !dbg !3724
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_461, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !3724
  %_2032 = load i64, ptr %_461, align 8, !dbg !3726, !range !1765, !noundef !13
  %387 = trunc nuw i64 %_2032 to i1, !dbg !3727
  %_2034.sroa.0.0.copyload = load i64, ptr %105, align 8, !dbg !3728
  %_2034.sroa.5.0.copyload = load ptr, ptr %_2033.sroa.5.0..sroa_idx, align 8, !dbg !3728
  %_2034.sroa.6.0.copyload = load i64, ptr %_2033.sroa.6.0..sroa_idx, align 8, !dbg !3728
  call void @llvm.lifetime.end.p0(ptr nonnull %_461), !dbg !3729
  br i1 %387, label %bb736, label %bb737, !dbg !3727

bb736:                                            ; preds = %bb735
  store i64 %_2034.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3730
  %_2038.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3730
  store ptr %_2034.sroa.5.0.copyload, ptr %_2038.sroa.2.0._0.sroa_idx, align 8, !dbg !3730
  %_2038.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3730
  store i64 %_2034.sroa.6.0.copyload, ptr %_2038.sroa.3.0._0.sroa_idx, align 8, !dbg !3730
  br label %bb431, !dbg !3736

bb737:                                            ; preds = %bb735
  call void @llvm.lifetime.start.p0(ptr nonnull %_465), !dbg !3738
  %_466 = load i64, ptr %35, align 8, !dbg !3740, !noundef !13
  %_2036 = icmp ult i64 %_466, 384307168202282326, !dbg !3742
  call void @llvm.assume(i1 %_2036), !dbg !3744
  call void @llvm.lifetime.start.p0(ptr nonnull %_467), !dbg !3745
  %_2046 = icmp eq i64 %_2027.sroa.6.0.copyload, %_2034.sroa.6.0.copyload, !dbg !3746
  br i1 %_2046, label %bb738, label %bb740, !dbg !3746

bb738:                                            ; preds = %bb737
  %388 = icmp ne ptr %_2034.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %388)
  %389 = icmp ne ptr %_2027.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %389)
  %bcmp355 = call i32 @bcmp(ptr nonnull %_2027.sroa.5.0.copyload, ptr nonnull %_2034.sroa.5.0.copyload, i64 %_2027.sroa.6.0.copyload), !dbg !3758
  %390 = icmp eq i32 %bcmp355, 0, !dbg !3758
  br label %bb740, !dbg !3763

bb740:                                            ; preds = %bb738, %bb737
  %_468.sroa.0.0 = phi i1 [ %390, %bb738 ], [ false, %bb737 ], !dbg !3764
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_467, i1 noundef zeroext %_468.sroa.0.0) #16, !dbg !3745
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_465, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_466, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_467) #16, !dbg !3738
  call void @llvm.lifetime.end.p0(ptr nonnull %_467), !dbg !3765
  %391 = load i64, ptr %_465, align 8, !dbg !3766, !range !1747, !noundef !13
  %.not356 = icmp eq i64 %391, -9223372036854775797, !dbg !3766
  br i1 %.not356, label %bb743, label %bb742, !dbg !3767

bb742:                                            ; preds = %bb740
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_465, i64 24, i1 false), !dbg !3768
  call void @llvm.lifetime.end.p0(ptr nonnull %_465), !dbg !3769
  %392 = icmp eq i64 %_2034.sroa.0.0.copyload, 0, !dbg !3770
  br i1 %392, label %bb431, label %bb2.i.i.i.i826, !dbg !3770

bb2.i.i.i.i826:                                   ; preds = %bb742
  %393 = icmp ne ptr %_2034.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %393)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2034.sroa.5.0.copyload, i64 noundef %_2034.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3776, !noalias !3781
  br label %bb431, !dbg !3784

bb743:                                            ; preds = %bb740
  call void @llvm.lifetime.end.p0(ptr nonnull %_465), !dbg !3769
  %394 = icmp eq i64 %_2034.sroa.0.0.copyload, 0, !dbg !3785
  br i1 %394, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit832", label %bb2.i.i.i.i830, !dbg !3785

bb2.i.i.i.i830:                                   ; preds = %bb743
  %395 = icmp ne ptr %_2034.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %395)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2034.sroa.5.0.copyload, i64 noundef %_2034.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3791, !noalias !3796
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit832", !dbg !3799

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit832": ; preds = %bb2.i.i.i.i830, %bb743
  %396 = icmp eq i64 %_2027.sroa.0.0.copyload, 0, !dbg !3800
  br i1 %396, label %bb394, label %bb2.i.i.i.i834, !dbg !3800

bb2.i.i.i.i834:                                   ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit832"
  %397 = icmp ne ptr %_2027.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %397)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2027.sroa.5.0.copyload, i64 noundef %_2027.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3806, !noalias !3811
  br label %bb394, !dbg !3814

bb431:                                            ; preds = %bb2.i.i.i.i826, %bb742, %bb736
  %398 = icmp eq i64 %_2027.sroa.0.0.copyload, 0, !dbg !3815
  br i1 %398, label %bb443, label %bb2.i.i.i.i838, !dbg !3815

bb2.i.i.i.i838:                                   ; preds = %bb431
  %399 = icmp ne ptr %_2027.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %399)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2027.sroa.5.0.copyload, i64 noundef %_2027.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3821, !noalias !3826
  br label %bb443, !dbg !3829

bb744:                                            ; preds = %bb134
  store i64 %_2056.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3830
  %_2059.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3830
  store ptr %_2056.sroa.5.0.copyload, ptr %_2059.sroa.2.0._0.sroa_idx, align 8, !dbg !3830
  %_2059.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3830
  store i64 %_2056.sroa.6.0.copyload, ptr %_2059.sroa.3.0._0.sroa_idx, align 8, !dbg !3830
  br label %bb443, !dbg !1706

bb745:                                            ; preds = %bb134
  call void @llvm.lifetime.start.p0(ptr nonnull %_477), !dbg !3836
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_477, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !3836
  %_2061 = load i64, ptr %_477, align 8, !dbg !3838, !range !1765, !noundef !13
  %400 = trunc nuw i64 %_2061 to i1, !dbg !3839
  %_2063.sroa.0.0.copyload = load i64, ptr %103, align 8, !dbg !3840
  %_2063.sroa.5.0.copyload = load ptr, ptr %_2062.sroa.5.0..sroa_idx, align 8, !dbg !3840
  %_2063.sroa.6.0.copyload = load i64, ptr %_2062.sroa.6.0..sroa_idx, align 8, !dbg !3840
  call void @llvm.lifetime.end.p0(ptr nonnull %_477), !dbg !3841
  br i1 %400, label %bb746, label %bb747, !dbg !3839

bb746:                                            ; preds = %bb745
  store i64 %_2063.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3842
  %_2075.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3842
  store ptr %_2063.sroa.5.0.copyload, ptr %_2075.sroa.2.0._0.sroa_idx, align 8, !dbg !3842
  %_2075.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3842
  store i64 %_2063.sroa.6.0.copyload, ptr %_2075.sroa.3.0._0.sroa_idx, align 8, !dbg !3842
  br label %bb429, !dbg !3848

bb747:                                            ; preds = %bb745
  %_2072 = icmp eq i64 %_2056.sroa.6.0.copyload, %_2063.sroa.6.0.copyload, !dbg !3850
  br i1 %_2072, label %bb748, label %bb253, !dbg !3850

bb748:                                            ; preds = %bb747
  %401 = icmp ne ptr %_2063.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %401)
  %402 = icmp ne ptr %_2056.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %402)
  %bcmp = call i32 @bcmp(ptr nonnull %_2056.sroa.5.0.copyload, ptr nonnull %_2063.sroa.5.0.copyload, i64 %_2056.sroa.6.0.copyload), !dbg !3858
  %_2071.not = icmp eq i32 %bcmp, 0, !dbg !3858
  br i1 %_2071.not, label %bb254, label %bb253, !dbg !3856

bb253:                                            ; preds = %bb748, %bb747
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !3862, !noalias !3884
  %403 = call noundef dereferenceable_or_null(14) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 14, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3887, !noalias !3884
  %404 = icmp eq ptr %403, null, !dbg !3892
  br i1 %404, label %bb754, label %bb755, !dbg !3893

bb254:                                            ; preds = %bb748
  %405 = icmp eq i64 %_2063.sroa.0.0.copyload, 0, !dbg !3894
  br i1 %405, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit852", label %bb2.i.i.i.i850, !dbg !3894

bb2.i.i.i.i850:                                   ; preds = %bb254
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2063.sroa.5.0.copyload, i64 noundef %_2063.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3900, !noalias !3905
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit852", !dbg !3908

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit852": ; preds = %bb2.i.i.i.i850, %bb254
  %406 = icmp eq i64 %_2056.sroa.0.0.copyload, 0, !dbg !3909
  br i1 %406, label %bb394, label %bb2.i.i.i.i854, !dbg !3909

bb2.i.i.i.i854:                                   ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit852"
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2056.sroa.5.0.copyload, i64 noundef %_2056.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3915, !noalias !3920
  br label %bb394, !dbg !3923

bb754:                                            ; preds = %bb253
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 14) #17, !dbg !3924
  unreachable, !dbg !3924

bb755:                                            ; preds = %bb253
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(14) %403, ptr noundef nonnull align 1 dereferenceable(14) @alloc_edea9280d8e8d4135f9b6fdbe8bdf45f, i64 14, i1 false), !dbg !3926
  store i64 14, ptr %_0, align 8, !dbg !3932
  %_481.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3932
  store ptr %403, ptr %_481.sroa.4.0._0.sroa_idx, align 8, !dbg !3932
  %_481.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3932
  store i64 14, ptr %_481.sroa.5.0._0.sroa_idx, align 8, !dbg !3932
  %407 = icmp eq i64 %_2063.sroa.0.0.copyload, 0, !dbg !3933
  br i1 %407, label %bb429, label %bb2.i.i.i.i858, !dbg !3933

bb2.i.i.i.i858:                                   ; preds = %bb755
  %408 = icmp ne ptr %_2063.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %408)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2063.sroa.5.0.copyload, i64 noundef %_2063.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3939, !noalias !3944
  br label %bb429, !dbg !3947

bb429:                                            ; preds = %bb2.i.i.i.i858, %bb755, %bb746
  %409 = icmp eq i64 %_2056.sroa.0.0.copyload, 0, !dbg !3948
  br i1 %409, label %bb443, label %bb2.i.i.i.i862, !dbg !3948

bb2.i.i.i.i862:                                   ; preds = %bb429
  %410 = icmp ne ptr %_2056.sroa.5.0.copyload, null
  call void @llvm.assume(i1 %410)
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2056.sroa.5.0.copyload, i64 noundef %_2056.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3954, !noalias !3959
  br label %bb443, !dbg !3962

bb756:                                            ; preds = %bb133
  store i64 %_2098.sroa.0.0.copyload, ptr %_0, align 8, !dbg !3963
  %_2105.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !3963
  store ptr %_2098.sroa.5.0.copyload, ptr %_2105.sroa.2.0._0.sroa_idx, align 8, !dbg !3963
  %_2105.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !3963
  store i64 %_2098.sroa.6.0.copyload, ptr %_2105.sroa.3.0._0.sroa_idx, align 8, !dbg !3963
  call void @llvm.lifetime.end.p0(ptr nonnull %_484), !dbg !3969
  br label %bb443, !dbg !1706

bb757:                                            ; preds = %bb133
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_484, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2098.sroa.5.0.copyload, i64 noundef %_2098.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1915
  %411 = load i8, ptr %_484, align 8, !dbg !3970, !range !144, !noundef !13
  %412 = trunc nuw i8 %411 to i1, !dbg !3970
  br i1 %412, label %bb758, label %bb759, !dbg !3971

bb758:                                            ; preds = %bb757
  %413 = getelementptr inbounds nuw i8, ptr %_484, i64 1, !dbg !3972
  %414 = load i8, ptr %413, align 1, !dbg !3972, !range !144, !noundef !13
  %_2109 = trunc nuw i8 %414 to i1, !dbg !3972
  call void @llvm.lifetime.end.p0(ptr nonnull %_484), !dbg !3969
  call void @llvm.lifetime.start.p0(ptr nonnull %_2113), !dbg !3973
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2113, i1 noundef zeroext %_2109) #16, !dbg !3973
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2113, i64 24, i1 false), !dbg !3979
  call void @llvm.lifetime.end.p0(ptr nonnull %_2113), !dbg !3980
  %415 = icmp eq i64 %_2098.sroa.0.0.copyload, 0, !dbg !3981
  br i1 %415, label %bb443, label %bb2.i.i.i.i866, !dbg !3981

bb2.i.i.i.i866:                                   ; preds = %bb758
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2098.sroa.5.0.copyload, i64 noundef %_2098.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !3987, !noalias !3992
  br label %bb443, !dbg !3995

bb759:                                            ; preds = %bb757
  %_2108 = load i64, ptr %101, align 8, !dbg !3996, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_484), !dbg !3969
  %416 = icmp eq i64 %_2098.sroa.0.0.copyload, 0, !dbg !3997
  br i1 %416, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit872", label %bb2.i.i.i.i870, !dbg !3997

bb2.i.i.i.i870:                                   ; preds = %bb759
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2098.sroa.5.0.copyload, i64 noundef %_2098.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4003, !noalias !4008
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit872", !dbg !4011

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit872": ; preds = %bb2.i.i.i.i870, %bb759
  call void @llvm.lifetime.start.p0(ptr nonnull %_494), !dbg !4012
  %_495 = load i64, ptr %35, align 8, !dbg !4014, !noundef !13
  %_3083 = icmp ult i64 %_495, 384307168202282326, !dbg !4016
  call void @llvm.assume(i1 %_3083), !dbg !4018
  call void @llvm.lifetime.start.p0(ptr nonnull %_496), !dbg !4019
  %417 = call i64 @llvm.sadd.sat.i64(i64 %_2108, i64 1), !dbg !4020
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_496, i64 noundef %417) #16, !dbg !4019
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_494, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_495, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_496) #16, !dbg !4012
  call void @llvm.lifetime.end.p0(ptr nonnull %_496), !dbg !4025
  %418 = load i64, ptr %_494, align 8, !dbg !4026, !range !1747, !noundef !13
  %.not354 = icmp eq i64 %418, -9223372036854775797, !dbg !4026
  br i1 %.not354, label %bb763, label %bb762, !dbg !4027

bb762:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit872"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_494, i64 24, i1 false), !dbg !4028
  call void @llvm.lifetime.end.p0(ptr nonnull %_494), !dbg !4029
  br label %bb443, !dbg !4030

bb763:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit872"
  call void @llvm.lifetime.end.p0(ptr nonnull %_494), !dbg !4029
  br label %bb394, !dbg !4032

bb764:                                            ; preds = %bb132
  store i64 %_2123.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4033
  %_2130.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4033
  store ptr %_2123.sroa.5.0.copyload, ptr %_2130.sroa.2.0._0.sroa_idx, align 8, !dbg !4033
  %_2130.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4033
  store i64 %_2123.sroa.6.0.copyload, ptr %_2130.sroa.3.0._0.sroa_idx, align 8, !dbg !4033
  call void @llvm.lifetime.end.p0(ptr nonnull %_500), !dbg !4039
  br label %bb443, !dbg !1706

bb765:                                            ; preds = %bb132
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_500, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2123.sroa.5.0.copyload, i64 noundef %_2123.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1921
  %419 = load i8, ptr %_500, align 8, !dbg !4040, !range !144, !noundef !13
  %420 = trunc nuw i8 %419 to i1, !dbg !4040
  br i1 %420, label %bb766, label %bb767, !dbg !4041

bb766:                                            ; preds = %bb765
  %421 = getelementptr inbounds nuw i8, ptr %_500, i64 1, !dbg !4042
  %422 = load i8, ptr %421, align 1, !dbg !4042, !range !144, !noundef !13
  %_2134 = trunc nuw i8 %422 to i1, !dbg !4042
  call void @llvm.lifetime.end.p0(ptr nonnull %_500), !dbg !4039
  call void @llvm.lifetime.start.p0(ptr nonnull %_2138), !dbg !4043
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2138, i1 noundef zeroext %_2134) #16, !dbg !4043
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2138, i64 24, i1 false), !dbg !4049
  call void @llvm.lifetime.end.p0(ptr nonnull %_2138), !dbg !4050
  %423 = icmp eq i64 %_2123.sroa.0.0.copyload, 0, !dbg !4051
  br i1 %423, label %bb443, label %bb2.i.i.i.i874, !dbg !4051

bb2.i.i.i.i874:                                   ; preds = %bb766
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2123.sroa.5.0.copyload, i64 noundef %_2123.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4057, !noalias !4062
  br label %bb443, !dbg !4065

bb767:                                            ; preds = %bb765
  %_2133 = load i64, ptr %99, align 8, !dbg !4066, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_500), !dbg !4039
  %424 = icmp eq i64 %_2123.sroa.0.0.copyload, 0, !dbg !4067
  br i1 %424, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit880", label %bb2.i.i.i.i878, !dbg !4067

bb2.i.i.i.i878:                                   ; preds = %bb767
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2123.sroa.5.0.copyload, i64 noundef %_2123.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4073, !noalias !4078
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit880", !dbg !4081

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit880": ; preds = %bb2.i.i.i.i878, %bb767
  call void @llvm.lifetime.start.p0(ptr nonnull %_510), !dbg !4082
  %_511 = load i64, ptr %35, align 8, !dbg !4084, !noundef !13
  %_3084 = icmp ult i64 %_511, 384307168202282326, !dbg !4086
  call void @llvm.assume(i1 %_3084), !dbg !4088
  call void @llvm.lifetime.start.p0(ptr nonnull %_512), !dbg !4089
  %425 = call i64 @llvm.sadd.sat.i64(i64 %_2133, i64 -1), !dbg !4090
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_512, i64 noundef %425) #16, !dbg !4089
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_510, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_511, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_512) #16, !dbg !4082
  call void @llvm.lifetime.end.p0(ptr nonnull %_512), !dbg !4093
  %426 = load i64, ptr %_510, align 8, !dbg !4094, !range !1747, !noundef !13
  %.not353 = icmp eq i64 %426, -9223372036854775797, !dbg !4094
  br i1 %.not353, label %bb771, label %bb770, !dbg !4095

bb770:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit880"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_510, i64 24, i1 false), !dbg !4096
  call void @llvm.lifetime.end.p0(ptr nonnull %_510), !dbg !4097
  br label %bb443, !dbg !4098

bb771:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit880"
  call void @llvm.lifetime.end.p0(ptr nonnull %_510), !dbg !4097
  br label %bb394, !dbg !4100

bb772:                                            ; preds = %bb131
  store i64 %_2148.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4101
  %_2155.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4101
  store ptr %_2148.sroa.5.0.copyload, ptr %_2155.sroa.2.0._0.sroa_idx, align 8, !dbg !4101
  %_2155.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4101
  store i64 %_2148.sroa.6.0.copyload, ptr %_2155.sroa.3.0._0.sroa_idx, align 8, !dbg !4101
  call void @llvm.lifetime.end.p0(ptr nonnull %_516), !dbg !4107
  br label %bb443, !dbg !1706

bb773:                                            ; preds = %bb131
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_516, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2148.sroa.5.0.copyload, i64 noundef %_2148.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1927
  %427 = load i8, ptr %_516, align 8, !dbg !4108, !range !144, !noundef !13
  %428 = trunc nuw i8 %427 to i1, !dbg !4108
  br i1 %428, label %bb774, label %bb775, !dbg !4109

bb774:                                            ; preds = %bb773
  %429 = getelementptr inbounds nuw i8, ptr %_516, i64 1, !dbg !4110
  %430 = load i8, ptr %429, align 1, !dbg !4110, !range !144, !noundef !13
  %_2159 = trunc nuw i8 %430 to i1, !dbg !4110
  call void @llvm.lifetime.end.p0(ptr nonnull %_516), !dbg !4107
  call void @llvm.lifetime.start.p0(ptr nonnull %_2163), !dbg !4111
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2163, i1 noundef zeroext %_2159) #16, !dbg !4111
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2163, i64 24, i1 false), !dbg !4117
  call void @llvm.lifetime.end.p0(ptr nonnull %_2163), !dbg !4118
  %431 = icmp eq i64 %_2148.sroa.0.0.copyload, 0, !dbg !4119
  br i1 %431, label %bb443, label %bb2.i.i.i.i882, !dbg !4119

bb2.i.i.i.i882:                                   ; preds = %bb774
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2148.sroa.5.0.copyload, i64 noundef %_2148.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4125, !noalias !4130
  br label %bb443, !dbg !4133

bb775:                                            ; preds = %bb773
  %_2158 = load i64, ptr %97, align 8, !dbg !4134, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_516), !dbg !4107
  %432 = icmp eq i64 %_2148.sroa.0.0.copyload, 0, !dbg !4135
  br i1 %432, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit888", label %bb2.i.i.i.i886, !dbg !4135

bb2.i.i.i.i886:                                   ; preds = %bb775
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2148.sroa.5.0.copyload, i64 noundef %_2148.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4141, !noalias !4146
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit888", !dbg !4149

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit888": ; preds = %bb2.i.i.i.i886, %bb775
  call void @llvm.lifetime.start.p0(ptr nonnull %_526), !dbg !4150
  %_527 = load i64, ptr %35, align 8, !dbg !4152, !noundef !13
  %_3085 = icmp ult i64 %_527, 384307168202282326, !dbg !4154
  call void @llvm.assume(i1 %_3085), !dbg !4156
  call void @llvm.lifetime.start.p0(ptr nonnull %_528), !dbg !4157
  %_529 = sub i64 0, %_2158, !dbg !4158
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_528, i64 noundef %_529) #16, !dbg !4157
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_526, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_527, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_528) #16, !dbg !4150
  call void @llvm.lifetime.end.p0(ptr nonnull %_528), !dbg !4159
  %433 = load i64, ptr %_526, align 8, !dbg !4160, !range !1747, !noundef !13
  %.not352 = icmp eq i64 %433, -9223372036854775797, !dbg !4160
  br i1 %.not352, label %bb778, label %bb777, !dbg !4161

bb777:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit888"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_526, i64 24, i1 false), !dbg !4162
  call void @llvm.lifetime.end.p0(ptr nonnull %_526), !dbg !4163
  br label %bb443, !dbg !4164

bb778:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit888"
  call void @llvm.lifetime.end.p0(ptr nonnull %_526), !dbg !4163
  br label %bb394, !dbg !4166

bb779:                                            ; preds = %bb130
  store i64 %_2173.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4167
  %_2180.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4167
  store ptr %_2173.sroa.5.0.copyload, ptr %_2180.sroa.2.0._0.sroa_idx, align 8, !dbg !4167
  %_2180.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4167
  store i64 %_2173.sroa.6.0.copyload, ptr %_2180.sroa.3.0._0.sroa_idx, align 8, !dbg !4167
  call void @llvm.lifetime.end.p0(ptr nonnull %_532), !dbg !4173
  br label %bb443, !dbg !1706

bb780:                                            ; preds = %bb130
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_532, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2173.sroa.5.0.copyload, i64 noundef %_2173.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1933
  %434 = load i8, ptr %_532, align 8, !dbg !4174, !range !144, !noundef !13
  %435 = trunc nuw i8 %434 to i1, !dbg !4174
  br i1 %435, label %bb781, label %bb782, !dbg !4175

bb781:                                            ; preds = %bb780
  %436 = getelementptr inbounds nuw i8, ptr %_532, i64 1, !dbg !4176
  %437 = load i8, ptr %436, align 1, !dbg !4176, !range !144, !noundef !13
  %_2184 = trunc nuw i8 %437 to i1, !dbg !4176
  call void @llvm.lifetime.end.p0(ptr nonnull %_532), !dbg !4173
  call void @llvm.lifetime.start.p0(ptr nonnull %_2188), !dbg !4177
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2188, i1 noundef zeroext %_2184) #16, !dbg !4177
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2188, i64 24, i1 false), !dbg !4183
  call void @llvm.lifetime.end.p0(ptr nonnull %_2188), !dbg !4184
  %438 = icmp eq i64 %_2173.sroa.0.0.copyload, 0, !dbg !4185
  br i1 %438, label %bb443, label %bb2.i.i.i.i890, !dbg !4185

bb2.i.i.i.i890:                                   ; preds = %bb781
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2173.sroa.5.0.copyload, i64 noundef %_2173.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4191, !noalias !4196
  br label %bb443, !dbg !4199

bb782:                                            ; preds = %bb780
  %_2183 = load i64, ptr %95, align 8, !dbg !4200, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_532), !dbg !4173
  %439 = icmp eq i64 %_2173.sroa.0.0.copyload, 0, !dbg !4201
  br i1 %439, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit896", label %bb2.i.i.i.i894, !dbg !4201

bb2.i.i.i.i894:                                   ; preds = %bb782
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2173.sroa.5.0.copyload, i64 noundef %_2173.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4207, !noalias !4212
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit896", !dbg !4215

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit896": ; preds = %bb2.i.i.i.i894, %bb782
  call void @llvm.lifetime.start.p0(ptr nonnull %_542), !dbg !4216
  %_543 = load i64, ptr %35, align 8, !dbg !4218, !noundef !13
  %_3086 = icmp ult i64 %_543, 384307168202282326, !dbg !4220
  call void @llvm.assume(i1 %_3086), !dbg !4222
  call void @llvm.lifetime.start.p0(ptr nonnull %_544), !dbg !4223
  %_545.sroa.0.0 = call i64 @llvm.abs.i64(i64 %_2183, i1 false), !dbg !4224
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_544, i64 noundef %_545.sroa.0.0) #16, !dbg !4223
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_542, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_543, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_544) #16, !dbg !4216
  call void @llvm.lifetime.end.p0(ptr nonnull %_544), !dbg !4227
  %440 = load i64, ptr %_542, align 8, !dbg !4228, !range !1747, !noundef !13
  %.not351 = icmp eq i64 %440, -9223372036854775797, !dbg !4228
  br i1 %.not351, label %bb789, label %bb788, !dbg !4229

bb788:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit896"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_542, i64 24, i1 false), !dbg !4230
  call void @llvm.lifetime.end.p0(ptr nonnull %_542), !dbg !4231
  br label %bb443, !dbg !4232

bb789:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit896"
  call void @llvm.lifetime.end.p0(ptr nonnull %_542), !dbg !4231
  br label %bb394, !dbg !4234

bb790:                                            ; preds = %bb129
  store i64 %_2200.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4235
  %_2207.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4235
  store ptr %_2200.sroa.5.0.copyload, ptr %_2207.sroa.2.0._0.sroa_idx, align 8, !dbg !4235
  %_2207.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4235
  store i64 %_2200.sroa.6.0.copyload, ptr %_2207.sroa.3.0._0.sroa_idx, align 8, !dbg !4235
  call void @llvm.lifetime.end.p0(ptr nonnull %_548), !dbg !4241
  br label %bb443, !dbg !1706

bb791:                                            ; preds = %bb129
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_548, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2200.sroa.5.0.copyload, i64 noundef %_2200.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1939
  %441 = load i8, ptr %_548, align 8, !dbg !4242, !range !144, !noundef !13
  %442 = trunc nuw i8 %441 to i1, !dbg !4242
  br i1 %442, label %bb792, label %bb793, !dbg !4243

bb792:                                            ; preds = %bb791
  %443 = getelementptr inbounds nuw i8, ptr %_548, i64 1, !dbg !4244
  %444 = load i8, ptr %443, align 1, !dbg !4244, !range !144, !noundef !13
  %_2211 = trunc nuw i8 %444 to i1, !dbg !4244
  call void @llvm.lifetime.end.p0(ptr nonnull %_548), !dbg !4241
  call void @llvm.lifetime.start.p0(ptr nonnull %_2215), !dbg !4245
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2215, i1 noundef zeroext %_2211) #16, !dbg !4245
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2215, i64 24, i1 false), !dbg !4251
  call void @llvm.lifetime.end.p0(ptr nonnull %_2215), !dbg !4252
  %445 = icmp eq i64 %_2200.sroa.0.0.copyload, 0, !dbg !4253
  br i1 %445, label %bb443, label %bb2.i.i.i.i898, !dbg !4253

bb2.i.i.i.i898:                                   ; preds = %bb792
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2200.sroa.5.0.copyload, i64 noundef %_2200.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4259, !noalias !4264
  br label %bb443, !dbg !4267

bb793:                                            ; preds = %bb791
  %_2210 = load i64, ptr %93, align 8, !dbg !4268, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_548), !dbg !4241
  %446 = icmp eq i64 %_2200.sroa.0.0.copyload, 0, !dbg !4269
  br i1 %446, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit904", label %bb2.i.i.i.i902, !dbg !4269

bb2.i.i.i.i902:                                   ; preds = %bb793
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2200.sroa.5.0.copyload, i64 noundef %_2200.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4275, !noalias !4280
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit904", !dbg !4283

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit904": ; preds = %bb2.i.i.i.i902, %bb793
  call void @llvm.lifetime.start.p0(ptr nonnull %_558), !dbg !4284
  %_559 = load i64, ptr %35, align 8, !dbg !4286, !noundef !13
  %_3087 = icmp ult i64 %_559, 384307168202282326, !dbg !4288
  call void @llvm.assume(i1 %_3087), !dbg !4290
  call void @llvm.lifetime.start.p0(ptr nonnull %_560), !dbg !4291
  %_561 = icmp eq i64 %_2210, 0, !dbg !4292
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_560, i1 noundef zeroext %_561) #16, !dbg !4291
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_558, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_559, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_560) #16, !dbg !4284
  call void @llvm.lifetime.end.p0(ptr nonnull %_560), !dbg !4293
  %447 = load i64, ptr %_558, align 8, !dbg !4294, !range !1747, !noundef !13
  %.not350 = icmp eq i64 %447, -9223372036854775797, !dbg !4294
  br i1 %.not350, label %bb796, label %bb795, !dbg !4295

bb795:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit904"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_558, i64 24, i1 false), !dbg !4296
  call void @llvm.lifetime.end.p0(ptr nonnull %_558), !dbg !4297
  br label %bb443, !dbg !4298

bb796:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit904"
  call void @llvm.lifetime.end.p0(ptr nonnull %_558), !dbg !4297
  br label %bb394, !dbg !4300

bb797:                                            ; preds = %bb128
  store i64 %_2225.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4301
  %_2232.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4301
  store ptr %_2225.sroa.5.0.copyload, ptr %_2232.sroa.2.0._0.sroa_idx, align 8, !dbg !4301
  %_2232.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4301
  store i64 %_2225.sroa.6.0.copyload, ptr %_2232.sroa.3.0._0.sroa_idx, align 8, !dbg !4301
  call void @llvm.lifetime.end.p0(ptr nonnull %_564), !dbg !4307
  br label %bb443, !dbg !1706

bb798:                                            ; preds = %bb128
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_564, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2225.sroa.5.0.copyload, i64 noundef %_2225.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1945
  %448 = load i8, ptr %_564, align 8, !dbg !4308, !range !144, !noundef !13
  %449 = trunc nuw i8 %448 to i1, !dbg !4308
  br i1 %449, label %bb799, label %bb800, !dbg !4309

bb799:                                            ; preds = %bb798
  %450 = getelementptr inbounds nuw i8, ptr %_564, i64 1, !dbg !4310
  %451 = load i8, ptr %450, align 1, !dbg !4310, !range !144, !noundef !13
  %_2236 = trunc nuw i8 %451 to i1, !dbg !4310
  call void @llvm.lifetime.end.p0(ptr nonnull %_564), !dbg !4307
  call void @llvm.lifetime.start.p0(ptr nonnull %_2240), !dbg !4311
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2240, i1 noundef zeroext %_2236) #16, !dbg !4311
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2240, i64 24, i1 false), !dbg !4317
  call void @llvm.lifetime.end.p0(ptr nonnull %_2240), !dbg !4318
  %452 = icmp eq i64 %_2225.sroa.0.0.copyload, 0, !dbg !4319
  br i1 %452, label %bb443, label %bb2.i.i.i.i906, !dbg !4319

bb2.i.i.i.i906:                                   ; preds = %bb799
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2225.sroa.5.0.copyload, i64 noundef %_2225.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4325, !noalias !4330
  br label %bb443, !dbg !4333

bb800:                                            ; preds = %bb798
  %_2235 = load i64, ptr %91, align 8, !dbg !4334, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_564), !dbg !4307
  %453 = icmp eq i64 %_2225.sroa.0.0.copyload, 0, !dbg !4335
  br i1 %453, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit912", label %bb2.i.i.i.i910, !dbg !4335

bb2.i.i.i.i910:                                   ; preds = %bb800
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2225.sroa.5.0.copyload, i64 noundef %_2225.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4341, !noalias !4346
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit912", !dbg !4349

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit912": ; preds = %bb2.i.i.i.i910, %bb800
  call void @llvm.lifetime.start.p0(ptr nonnull %_574), !dbg !4350
  %_575 = load i64, ptr %35, align 8, !dbg !4352, !noundef !13
  %_3088 = icmp ult i64 %_575, 384307168202282326, !dbg !4354
  call void @llvm.assume(i1 %_3088), !dbg !4356
  call void @llvm.lifetime.start.p0(ptr nonnull %_576), !dbg !4357
  %_577 = icmp ne i64 %_2235, 0, !dbg !4358
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_576, i1 noundef zeroext %_577) #16, !dbg !4357
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_574, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_575, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_576) #16, !dbg !4350
  call void @llvm.lifetime.end.p0(ptr nonnull %_576), !dbg !4359
  %454 = load i64, ptr %_574, align 8, !dbg !4360, !range !1747, !noundef !13
  %.not349 = icmp eq i64 %454, -9223372036854775797, !dbg !4360
  br i1 %.not349, label %bb803, label %bb802, !dbg !4361

bb802:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit912"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_574, i64 24, i1 false), !dbg !4362
  call void @llvm.lifetime.end.p0(ptr nonnull %_574), !dbg !4363
  br label %bb443, !dbg !4364

bb803:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit912"
  call void @llvm.lifetime.end.p0(ptr nonnull %_574), !dbg !4363
  br label %bb394, !dbg !4366

bb804:                                            ; preds = %bb127
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_580, i64 24, i1 false), !dbg !4367
  call void @llvm.lifetime.end.p0(ptr nonnull %_580), !dbg !4368
  br label %bb443, !dbg !1706

bb805:                                            ; preds = %bb127
  call void @llvm.lifetime.end.p0(ptr nonnull %_580), !dbg !4368
  br label %bb394, !dbg !4368

bb806:                                            ; preds = %bb126
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_584, i64 24, i1 false), !dbg !4369
  call void @llvm.lifetime.end.p0(ptr nonnull %_584), !dbg !4370
  br label %bb443, !dbg !1706

bb807:                                            ; preds = %bb126
  call void @llvm.lifetime.end.p0(ptr nonnull %_584), !dbg !4370
  br label %bb394, !dbg !4370

bb808:                                            ; preds = %bb125
  store i64 %_2262.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4371
  %_2269.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4371
  store ptr %_2262.sroa.5.0.copyload, ptr %_2269.sroa.2.0._0.sroa_idx, align 8, !dbg !4371
  %_2269.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4371
  store i64 %_2262.sroa.6.0.copyload, ptr %_2269.sroa.3.0._0.sroa_idx, align 8, !dbg !4371
  call void @llvm.lifetime.end.p0(ptr nonnull %_588), !dbg !4377
  br label %bb443, !dbg !1706

bb809:                                            ; preds = %bb125
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_588, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2262.sroa.5.0.copyload, i64 noundef %_2262.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1967
  %455 = load i8, ptr %_588, align 8, !dbg !4378, !range !144, !noundef !13
  %456 = trunc nuw i8 %455 to i1, !dbg !4378
  br i1 %456, label %bb810, label %bb811, !dbg !4379

bb810:                                            ; preds = %bb809
  %457 = getelementptr inbounds nuw i8, ptr %_588, i64 1, !dbg !4380
  %458 = load i8, ptr %457, align 1, !dbg !4380, !range !144, !noundef !13
  %_2273 = trunc nuw i8 %458 to i1, !dbg !4380
  call void @llvm.lifetime.end.p0(ptr nonnull %_588), !dbg !4377
  call void @llvm.lifetime.start.p0(ptr nonnull %_2277), !dbg !4381
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2277, i1 noundef zeroext %_2273) #16, !dbg !4381
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2277, i64 24, i1 false), !dbg !4387
  call void @llvm.lifetime.end.p0(ptr nonnull %_2277), !dbg !4388
  %459 = icmp eq i64 %_2262.sroa.0.0.copyload, 0, !dbg !4389
  br i1 %459, label %bb443, label %bb2.i.i.i.i914, !dbg !4389

bb2.i.i.i.i914:                                   ; preds = %bb810
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2262.sroa.5.0.copyload, i64 noundef %_2262.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4395, !noalias !4400
  br label %bb443, !dbg !4403

bb811:                                            ; preds = %bb809
  %_2272 = load i64, ptr %87, align 8, !dbg !4404, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_588), !dbg !4377
  %460 = icmp eq i64 %_2262.sroa.0.0.copyload, 0, !dbg !4405
  br i1 %460, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit920", label %bb2.i.i.i.i918, !dbg !4405

bb2.i.i.i.i918:                                   ; preds = %bb811
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2262.sroa.5.0.copyload, i64 noundef %_2262.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4411, !noalias !4416
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit920", !dbg !4419

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit920": ; preds = %bb2.i.i.i.i918, %bb811
  call void @llvm.lifetime.start.p0(ptr nonnull %_598), !dbg !4420
  call void @llvm.lifetime.start.p0(ptr nonnull %_602), !dbg !4422
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_602, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !4422
  %_2279 = load i64, ptr %_602, align 8, !dbg !4423, !range !1765, !noundef !13
  %461 = trunc nuw i64 %_2279 to i1, !dbg !4424
  %_2281.sroa.0.0.copyload = load i64, ptr %88, align 8, !dbg !4425
  %_2281.sroa.5.0.copyload = load ptr, ptr %_2280.sroa.5.0..sroa_idx, align 8, !dbg !4425
  %_2281.sroa.6.0.copyload = load i64, ptr %_2280.sroa.6.0..sroa_idx, align 8, !dbg !4425
  call void @llvm.lifetime.end.p0(ptr nonnull %_602), !dbg !4426
  br i1 %461, label %bb813, label %bb814, !dbg !4424

bb813:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit920"
  store i64 %_2281.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4427
  %_2288.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4427
  store ptr %_2281.sroa.5.0.copyload, ptr %_2288.sroa.2.0._0.sroa_idx, align 8, !dbg !4427
  %_2288.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4427
  store i64 %_2281.sroa.6.0.copyload, ptr %_2288.sroa.3.0._0.sroa_idx, align 8, !dbg !4427
  call void @llvm.lifetime.end.p0(ptr nonnull %_598), !dbg !4433
  br label %bb443, !dbg !4434

bb814:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit920"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_598, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2281.sroa.5.0.copyload, i64 noundef %_2281.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !4420
  %462 = load i8, ptr %_598, align 8, !dbg !4436, !range !144, !noundef !13
  %463 = trunc nuw i8 %462 to i1, !dbg !4436
  br i1 %463, label %bb815, label %bb816, !dbg !4437

bb815:                                            ; preds = %bb814
  %464 = getelementptr inbounds nuw i8, ptr %_598, i64 1, !dbg !4438
  %465 = load i8, ptr %464, align 1, !dbg !4438, !range !144, !noundef !13
  %_2292 = trunc nuw i8 %465 to i1, !dbg !4438
  call void @llvm.lifetime.end.p0(ptr nonnull %_598), !dbg !4433
  call void @llvm.lifetime.start.p0(ptr nonnull %_2296), !dbg !4439
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2296, i1 noundef zeroext %_2292) #16, !dbg !4439
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2296, i64 24, i1 false), !dbg !4445
  call void @llvm.lifetime.end.p0(ptr nonnull %_2296), !dbg !4446
  %466 = icmp eq i64 %_2281.sroa.0.0.copyload, 0, !dbg !4447
  br i1 %466, label %bb443, label %bb2.i.i.i.i922, !dbg !4447

bb2.i.i.i.i922:                                   ; preds = %bb815
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2281.sroa.5.0.copyload, i64 noundef %_2281.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4453, !noalias !4458
  br label %bb443, !dbg !4461

bb816:                                            ; preds = %bb814
  %_2291 = load i64, ptr %89, align 8, !dbg !4462, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_598), !dbg !4433
  %467 = icmp eq i64 %_2281.sroa.0.0.copyload, 0, !dbg !4463
  br i1 %467, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit928", label %bb2.i.i.i.i926, !dbg !4463

bb2.i.i.i.i926:                                   ; preds = %bb816
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2281.sroa.5.0.copyload, i64 noundef %_2281.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4469, !noalias !4474
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit928", !dbg !4477

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit928": ; preds = %bb2.i.i.i.i926, %bb816
  call void @llvm.lifetime.start.p0(ptr nonnull %_608), !dbg !4478
  %_609 = load i64, ptr %35, align 8, !dbg !4480, !noundef !13
  %_3089 = icmp ult i64 %_609, 384307168202282326, !dbg !4482
  call void @llvm.assume(i1 %_3089), !dbg !4484
  call void @llvm.lifetime.start.p0(ptr nonnull %_610), !dbg !4485
  %468 = icmp ne i64 %_2291, 0, !dbg !4486
  %469 = icmp ne i64 %_2272, 0, !dbg !4486
  %_611.sroa.0.0 = and i1 %469, %468, !dbg !4486
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_610, i1 noundef zeroext %_611.sroa.0.0) #16, !dbg !4485
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_608, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_609, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_610) #16, !dbg !4478
  call void @llvm.lifetime.end.p0(ptr nonnull %_610), !dbg !4487
  %470 = load i64, ptr %_608, align 8, !dbg !4488, !range !1747, !noundef !13
  %.not346 = icmp eq i64 %470, -9223372036854775797, !dbg !4488
  br i1 %.not346, label %bb819, label %bb818, !dbg !4489

bb818:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit928"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_608, i64 24, i1 false), !dbg !4490
  call void @llvm.lifetime.end.p0(ptr nonnull %_608), !dbg !4491
  br label %bb443, !dbg !4492

bb819:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit928"
  call void @llvm.lifetime.end.p0(ptr nonnull %_608), !dbg !4491
  br label %bb394, !dbg !4494

bb820:                                            ; preds = %bb124
  store i64 %_2306.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4495
  %_2313.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4495
  store ptr %_2306.sroa.5.0.copyload, ptr %_2313.sroa.2.0._0.sroa_idx, align 8, !dbg !4495
  %_2313.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4495
  store i64 %_2306.sroa.6.0.copyload, ptr %_2313.sroa.3.0._0.sroa_idx, align 8, !dbg !4495
  call void @llvm.lifetime.end.p0(ptr nonnull %_614), !dbg !4501
  br label %bb443, !dbg !1706

bb821:                                            ; preds = %bb124
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_614, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2306.sroa.5.0.copyload, i64 noundef %_2306.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1973
  %471 = load i8, ptr %_614, align 8, !dbg !4502, !range !144, !noundef !13
  %472 = trunc nuw i8 %471 to i1, !dbg !4502
  br i1 %472, label %bb822, label %bb823, !dbg !4503

bb822:                                            ; preds = %bb821
  %473 = getelementptr inbounds nuw i8, ptr %_614, i64 1, !dbg !4504
  %474 = load i8, ptr %473, align 1, !dbg !4504, !range !144, !noundef !13
  %_2317 = trunc nuw i8 %474 to i1, !dbg !4504
  call void @llvm.lifetime.end.p0(ptr nonnull %_614), !dbg !4501
  call void @llvm.lifetime.start.p0(ptr nonnull %_2321), !dbg !4505
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2321, i1 noundef zeroext %_2317) #16, !dbg !4505
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2321, i64 24, i1 false), !dbg !4511
  call void @llvm.lifetime.end.p0(ptr nonnull %_2321), !dbg !4512
  %475 = icmp eq i64 %_2306.sroa.0.0.copyload, 0, !dbg !4513
  br i1 %475, label %bb443, label %bb2.i.i.i.i930, !dbg !4513

bb2.i.i.i.i930:                                   ; preds = %bb822
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2306.sroa.5.0.copyload, i64 noundef %_2306.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4519, !noalias !4524
  br label %bb443, !dbg !4527

bb823:                                            ; preds = %bb821
  %_2316 = load i64, ptr %83, align 8, !dbg !4528, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_614), !dbg !4501
  %476 = icmp eq i64 %_2306.sroa.0.0.copyload, 0, !dbg !4529
  br i1 %476, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit936", label %bb2.i.i.i.i934, !dbg !4529

bb2.i.i.i.i934:                                   ; preds = %bb823
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2306.sroa.5.0.copyload, i64 noundef %_2306.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4535, !noalias !4540
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit936", !dbg !4543

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit936": ; preds = %bb2.i.i.i.i934, %bb823
  call void @llvm.lifetime.start.p0(ptr nonnull %_624), !dbg !4544
  call void @llvm.lifetime.start.p0(ptr nonnull %_628), !dbg !4546
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_628, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !4546
  %_2323 = load i64, ptr %_628, align 8, !dbg !4547, !range !1765, !noundef !13
  %477 = trunc nuw i64 %_2323 to i1, !dbg !4548
  %_2325.sroa.0.0.copyload = load i64, ptr %84, align 8, !dbg !4549
  %_2325.sroa.5.0.copyload = load ptr, ptr %_2324.sroa.5.0..sroa_idx, align 8, !dbg !4549
  %_2325.sroa.6.0.copyload = load i64, ptr %_2324.sroa.6.0..sroa_idx, align 8, !dbg !4549
  call void @llvm.lifetime.end.p0(ptr nonnull %_628), !dbg !4550
  br i1 %477, label %bb825, label %bb826, !dbg !4548

bb825:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit936"
  store i64 %_2325.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4551
  %_2332.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4551
  store ptr %_2325.sroa.5.0.copyload, ptr %_2332.sroa.2.0._0.sroa_idx, align 8, !dbg !4551
  %_2332.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4551
  store i64 %_2325.sroa.6.0.copyload, ptr %_2332.sroa.3.0._0.sroa_idx, align 8, !dbg !4551
  call void @llvm.lifetime.end.p0(ptr nonnull %_624), !dbg !4557
  br label %bb443, !dbg !4558

bb826:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit936"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_624, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2325.sroa.5.0.copyload, i64 noundef %_2325.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !4544
  %478 = load i8, ptr %_624, align 8, !dbg !4560, !range !144, !noundef !13
  %479 = trunc nuw i8 %478 to i1, !dbg !4560
  br i1 %479, label %bb827, label %bb828, !dbg !4561

bb827:                                            ; preds = %bb826
  %480 = getelementptr inbounds nuw i8, ptr %_624, i64 1, !dbg !4562
  %481 = load i8, ptr %480, align 1, !dbg !4562, !range !144, !noundef !13
  %_2336 = trunc nuw i8 %481 to i1, !dbg !4562
  call void @llvm.lifetime.end.p0(ptr nonnull %_624), !dbg !4557
  call void @llvm.lifetime.start.p0(ptr nonnull %_2340), !dbg !4563
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2340, i1 noundef zeroext %_2336) #16, !dbg !4563
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2340, i64 24, i1 false), !dbg !4569
  call void @llvm.lifetime.end.p0(ptr nonnull %_2340), !dbg !4570
  %482 = icmp eq i64 %_2325.sroa.0.0.copyload, 0, !dbg !4571
  br i1 %482, label %bb443, label %bb2.i.i.i.i938, !dbg !4571

bb2.i.i.i.i938:                                   ; preds = %bb827
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2325.sroa.5.0.copyload, i64 noundef %_2325.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4577, !noalias !4582
  br label %bb443, !dbg !4585

bb828:                                            ; preds = %bb826
  %_2335 = load i64, ptr %85, align 8, !dbg !4586, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_624), !dbg !4557
  %483 = icmp eq i64 %_2325.sroa.0.0.copyload, 0, !dbg !4587
  br i1 %483, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit944", label %bb2.i.i.i.i942, !dbg !4587

bb2.i.i.i.i942:                                   ; preds = %bb828
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2325.sroa.5.0.copyload, i64 noundef %_2325.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4593, !noalias !4598
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit944", !dbg !4601

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit944": ; preds = %bb2.i.i.i.i942, %bb828
  call void @llvm.lifetime.start.p0(ptr nonnull %_634), !dbg !4602
  %_635 = load i64, ptr %35, align 8, !dbg !4604, !noundef !13
  %_3090 = icmp ult i64 %_635, 384307168202282326, !dbg !4606
  call void @llvm.assume(i1 %_3090), !dbg !4608
  call void @llvm.lifetime.start.p0(ptr nonnull %_636), !dbg !4609
  %484 = or i64 %_2335, %_2316, !dbg !4610
  %_637.sroa.0.0 = icmp ne i64 %484, 0, !dbg !4610
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_636, i1 noundef zeroext %_637.sroa.0.0) #16, !dbg !4609
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_634, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_635, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_636) #16, !dbg !4602
  call void @llvm.lifetime.end.p0(ptr nonnull %_636), !dbg !4611
  %485 = load i64, ptr %_634, align 8, !dbg !4612, !range !1747, !noundef !13
  %.not345 = icmp eq i64 %485, -9223372036854775797, !dbg !4612
  br i1 %.not345, label %bb831, label %bb830, !dbg !4613

bb830:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit944"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_634, i64 24, i1 false), !dbg !4614
  call void @llvm.lifetime.end.p0(ptr nonnull %_634), !dbg !4615
  br label %bb443, !dbg !4616

bb831:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit944"
  call void @llvm.lifetime.end.p0(ptr nonnull %_634), !dbg !4615
  br label %bb394, !dbg !4618

bb832:                                            ; preds = %bb123
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_640, i64 24, i1 false), !dbg !4619
  call void @llvm.lifetime.end.p0(ptr nonnull %_640), !dbg !4620
  br label %bb443, !dbg !1706

bb833:                                            ; preds = %bb123
  call void @llvm.lifetime.end.p0(ptr nonnull %_640), !dbg !4620
  br label %bb394, !dbg !4620

bb834:                                            ; preds = %bb122
  store i64 %_2356.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4621
  %_2363.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4621
  store ptr %_2356.sroa.5.0.copyload, ptr %_2363.sroa.2.0._0.sroa_idx, align 8, !dbg !4621
  %_2363.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4621
  store i64 %_2356.sroa.6.0.copyload, ptr %_2363.sroa.3.0._0.sroa_idx, align 8, !dbg !4621
  call void @llvm.lifetime.end.p0(ptr nonnull %_644), !dbg !4627
  br label %bb443, !dbg !1706

bb835:                                            ; preds = %bb122
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_644, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2356.sroa.5.0.copyload, i64 noundef %_2356.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !1987
  %486 = load i8, ptr %_644, align 8, !dbg !4628, !range !144, !noundef !13
  %487 = trunc nuw i8 %486 to i1, !dbg !4628
  br i1 %487, label %bb836, label %bb837, !dbg !4629

bb836:                                            ; preds = %bb835
  %488 = getelementptr inbounds nuw i8, ptr %_644, i64 1, !dbg !4630
  %489 = load i8, ptr %488, align 1, !dbg !4630, !range !144, !noundef !13
  %_2367 = trunc nuw i8 %489 to i1, !dbg !4630
  call void @llvm.lifetime.end.p0(ptr nonnull %_644), !dbg !4627
  call void @llvm.lifetime.start.p0(ptr nonnull %_2371), !dbg !4631
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2371, i1 noundef zeroext %_2367) #16, !dbg !4631
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2371, i64 24, i1 false), !dbg !4637
  call void @llvm.lifetime.end.p0(ptr nonnull %_2371), !dbg !4638
  %490 = icmp eq i64 %_2356.sroa.0.0.copyload, 0, !dbg !4639
  br i1 %490, label %bb443, label %bb2.i.i.i.i946, !dbg !4639

bb2.i.i.i.i946:                                   ; preds = %bb836
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2356.sroa.5.0.copyload, i64 noundef %_2356.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4645, !noalias !4650
  br label %bb443, !dbg !4653

bb837:                                            ; preds = %bb835
  %_2366 = load i64, ptr %79, align 8, !dbg !4654, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_644), !dbg !4627
  %491 = icmp eq i64 %_2356.sroa.0.0.copyload, 0, !dbg !4655
  br i1 %491, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit952", label %bb2.i.i.i.i950, !dbg !4655

bb2.i.i.i.i950:                                   ; preds = %bb837
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2356.sroa.5.0.copyload, i64 noundef %_2356.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4661, !noalias !4666
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit952", !dbg !4669

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit952": ; preds = %bb2.i.i.i.i950, %bb837
  call void @llvm.lifetime.start.p0(ptr nonnull %_654), !dbg !4670
  call void @llvm.lifetime.start.p0(ptr nonnull %_658), !dbg !4672
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_658, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !4672
  %_2373 = load i64, ptr %_658, align 8, !dbg !4673, !range !1765, !noundef !13
  %492 = trunc nuw i64 %_2373 to i1, !dbg !4674
  %_2375.sroa.0.0.copyload = load i64, ptr %80, align 8, !dbg !4675
  %_2375.sroa.5.0.copyload = load ptr, ptr %_2374.sroa.5.0..sroa_idx, align 8, !dbg !4675
  %_2375.sroa.6.0.copyload = load i64, ptr %_2374.sroa.6.0..sroa_idx, align 8, !dbg !4675
  call void @llvm.lifetime.end.p0(ptr nonnull %_658), !dbg !4676
  br i1 %492, label %bb839, label %bb840, !dbg !4674

bb839:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit952"
  store i64 %_2375.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4677
  %_2382.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4677
  store ptr %_2375.sroa.5.0.copyload, ptr %_2382.sroa.2.0._0.sroa_idx, align 8, !dbg !4677
  %_2382.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4677
  store i64 %_2375.sroa.6.0.copyload, ptr %_2382.sroa.3.0._0.sroa_idx, align 8, !dbg !4677
  call void @llvm.lifetime.end.p0(ptr nonnull %_654), !dbg !4683
  br label %bb443, !dbg !4684

bb840:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit952"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_654, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2375.sroa.5.0.copyload, i64 noundef %_2375.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !4670
  %493 = load i8, ptr %_654, align 8, !dbg !4686, !range !144, !noundef !13
  %494 = trunc nuw i8 %493 to i1, !dbg !4686
  br i1 %494, label %bb841, label %bb842, !dbg !4687

bb841:                                            ; preds = %bb840
  %495 = getelementptr inbounds nuw i8, ptr %_654, i64 1, !dbg !4688
  %496 = load i8, ptr %495, align 1, !dbg !4688, !range !144, !noundef !13
  %_2386 = trunc nuw i8 %496 to i1, !dbg !4688
  call void @llvm.lifetime.end.p0(ptr nonnull %_654), !dbg !4683
  call void @llvm.lifetime.start.p0(ptr nonnull %_2390), !dbg !4689
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2390, i1 noundef zeroext %_2386) #16, !dbg !4689
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2390, i64 24, i1 false), !dbg !4695
  call void @llvm.lifetime.end.p0(ptr nonnull %_2390), !dbg !4696
  %497 = icmp eq i64 %_2375.sroa.0.0.copyload, 0, !dbg !4697
  br i1 %497, label %bb443, label %bb2.i.i.i.i954, !dbg !4697

bb2.i.i.i.i954:                                   ; preds = %bb841
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2375.sroa.5.0.copyload, i64 noundef %_2375.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4703, !noalias !4708
  br label %bb443, !dbg !4711

bb842:                                            ; preds = %bb840
  %_2385 = load i64, ptr %81, align 8, !dbg !4712, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_654), !dbg !4683
  %498 = icmp eq i64 %_2375.sroa.0.0.copyload, 0, !dbg !4713
  br i1 %498, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit960", label %bb2.i.i.i.i958, !dbg !4713

bb2.i.i.i.i958:                                   ; preds = %bb842
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2375.sroa.5.0.copyload, i64 noundef %_2375.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4719, !noalias !4724
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit960", !dbg !4727

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit960": ; preds = %bb2.i.i.i.i958, %bb842
  %_663.not = icmp eq i64 %_2385, %_2366, !dbg !4728
  br i1 %_663.not, label %bb394, label %bb306, !dbg !4728

bb306:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit960"
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !4730, !noalias !4752
  %499 = call noundef dereferenceable_or_null(17) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 17, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4755, !noalias !4752
  %500 = icmp eq ptr %499, null, !dbg !4760
  br i1 %500, label %bb847, label %bb848, !dbg !4761

bb847:                                            ; preds = %bb306
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 17) #17, !dbg !4762
  unreachable, !dbg !4762

bb848:                                            ; preds = %bb306
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(17) %499, ptr noundef nonnull align 1 dereferenceable(17) @alloc_61f921f288c92b2b8cae67f33bec51d2, i64 17, i1 false), !dbg !4764
  store i64 17, ptr %_0, align 8, !dbg !4770
  %_664.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4770
  store ptr %499, ptr %_664.sroa.4.0._0.sroa_idx, align 8, !dbg !4770
  %_664.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4770
  store i64 17, ptr %_664.sroa.5.0._0.sroa_idx, align 8, !dbg !4770
  br label %bb443, !dbg !4771

bb849:                                            ; preds = %bb121
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_667, i64 24, i1 false), !dbg !4773
  call void @llvm.lifetime.end.p0(ptr nonnull %_667), !dbg !4774
  br label %bb443, !dbg !1706

bb850:                                            ; preds = %bb121
  call void @llvm.lifetime.end.p0(ptr nonnull %_667), !dbg !4774
  br label %bb394, !dbg !4774

bb851:                                            ; preds = %bb120
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_671, i64 24, i1 false), !dbg !4775
  call void @llvm.lifetime.end.p0(ptr nonnull %_671), !dbg !4776
  br label %bb443, !dbg !1706

bb852:                                            ; preds = %bb120
  call void @llvm.lifetime.end.p0(ptr nonnull %_671), !dbg !4776
  br label %bb394, !dbg !4776

bb853:                                            ; preds = %bb119
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_675, i64 24, i1 false), !dbg !4777
  call void @llvm.lifetime.end.p0(ptr nonnull %_675), !dbg !4778
  br label %bb443, !dbg !1706

bb854:                                            ; preds = %bb119
  call void @llvm.lifetime.end.p0(ptr nonnull %_675), !dbg !4778
  br label %bb394, !dbg !4778

bb855:                                            ; preds = %bb118
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_679, i64 24, i1 false), !dbg !4779
  call void @llvm.lifetime.end.p0(ptr nonnull %_679), !dbg !4780
  br label %bb443, !dbg !1706

bb856:                                            ; preds = %bb118
  call void @llvm.lifetime.end.p0(ptr nonnull %_679), !dbg !4780
  br label %bb394, !dbg !4780

bb857:                                            ; preds = %bb117
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_683, i64 24, i1 false), !dbg !4781
  call void @llvm.lifetime.end.p0(ptr nonnull %_683), !dbg !4782
  br label %bb443, !dbg !1706

bb858:                                            ; preds = %bb117
  call void @llvm.lifetime.end.p0(ptr nonnull %_683), !dbg !4782
  br label %bb394, !dbg !4782

bb859:                                            ; preds = %bb116
  store i64 %_2443.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4783
  %_2450.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4783
  store ptr %_2443.sroa.5.0.copyload, ptr %_2450.sroa.2.0._0.sroa_idx, align 8, !dbg !4783
  %_2450.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4783
  store i64 %_2443.sroa.6.0.copyload, ptr %_2450.sroa.3.0._0.sroa_idx, align 8, !dbg !4783
  call void @llvm.lifetime.end.p0(ptr nonnull %_687), !dbg !4789
  br label %bb443, !dbg !1706

bb860:                                            ; preds = %bb116
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_687, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2443.sroa.5.0.copyload, i64 noundef %_2443.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !2033
  %501 = load i8, ptr %_687, align 8, !dbg !4790, !range !144, !noundef !13
  %502 = trunc nuw i8 %501 to i1, !dbg !4790
  br i1 %502, label %bb861, label %bb862, !dbg !4791

bb861:                                            ; preds = %bb860
  %503 = getelementptr inbounds nuw i8, ptr %_687, i64 1, !dbg !4792
  %504 = load i8, ptr %503, align 1, !dbg !4792, !range !144, !noundef !13
  %_2454 = trunc nuw i8 %504 to i1, !dbg !4792
  call void @llvm.lifetime.end.p0(ptr nonnull %_687), !dbg !4789
  call void @llvm.lifetime.start.p0(ptr nonnull %_2458), !dbg !4793
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2458, i1 noundef zeroext %_2454) #16, !dbg !4793
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2458, i64 24, i1 false), !dbg !4799
  call void @llvm.lifetime.end.p0(ptr nonnull %_2458), !dbg !4800
  %505 = icmp eq i64 %_2443.sroa.0.0.copyload, 0, !dbg !4801
  br i1 %505, label %bb443, label %bb2.i.i.i.i970, !dbg !4801

bb2.i.i.i.i970:                                   ; preds = %bb861
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2443.sroa.5.0.copyload, i64 noundef %_2443.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4807, !noalias !4812
  br label %bb443, !dbg !4815

bb862:                                            ; preds = %bb860
  %_2453 = load i64, ptr %75, align 8, !dbg !4816, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_687), !dbg !4789
  %506 = icmp eq i64 %_2443.sroa.0.0.copyload, 0, !dbg !4817
  br i1 %506, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit976", label %bb2.i.i.i.i974, !dbg !4817

bb2.i.i.i.i974:                                   ; preds = %bb862
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2443.sroa.5.0.copyload, i64 noundef %_2443.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4823, !noalias !4828
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit976", !dbg !4831

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit976": ; preds = %bb2.i.i.i.i974, %bb862
  call void @llvm.lifetime.start.p0(ptr nonnull %_697), !dbg !4832
  call void @llvm.lifetime.start.p0(ptr nonnull %_701), !dbg !4834
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_701, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !4834
  %_2460 = load i64, ptr %_701, align 8, !dbg !4835, !range !1765, !noundef !13
  %507 = trunc nuw i64 %_2460 to i1, !dbg !4836
  %_2462.sroa.0.0.copyload = load i64, ptr %76, align 8, !dbg !4837
  %_2462.sroa.5.0.copyload = load ptr, ptr %_2461.sroa.5.0..sroa_idx, align 8, !dbg !4837
  %_2462.sroa.6.0.copyload = load i64, ptr %_2461.sroa.6.0..sroa_idx, align 8, !dbg !4837
  call void @llvm.lifetime.end.p0(ptr nonnull %_701), !dbg !4838
  br i1 %507, label %bb864, label %bb865, !dbg !4836

bb864:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit976"
  store i64 %_2462.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4839
  %_2469.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4839
  store ptr %_2462.sroa.5.0.copyload, ptr %_2469.sroa.2.0._0.sroa_idx, align 8, !dbg !4839
  %_2469.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4839
  store i64 %_2462.sroa.6.0.copyload, ptr %_2469.sroa.3.0._0.sroa_idx, align 8, !dbg !4839
  call void @llvm.lifetime.end.p0(ptr nonnull %_697), !dbg !4845
  br label %bb443, !dbg !4846

bb865:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit976"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_697, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2462.sroa.5.0.copyload, i64 noundef %_2462.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !4832
  %508 = load i8, ptr %_697, align 8, !dbg !4848, !range !144, !noundef !13
  %509 = trunc nuw i8 %508 to i1, !dbg !4848
  br i1 %509, label %bb866, label %bb867, !dbg !4849

bb866:                                            ; preds = %bb865
  %510 = getelementptr inbounds nuw i8, ptr %_697, i64 1, !dbg !4850
  %511 = load i8, ptr %510, align 1, !dbg !4850, !range !144, !noundef !13
  %_2473 = trunc nuw i8 %511 to i1, !dbg !4850
  call void @llvm.lifetime.end.p0(ptr nonnull %_697), !dbg !4845
  call void @llvm.lifetime.start.p0(ptr nonnull %_2477), !dbg !4851
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2477, i1 noundef zeroext %_2473) #16, !dbg !4851
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2477, i64 24, i1 false), !dbg !4857
  call void @llvm.lifetime.end.p0(ptr nonnull %_2477), !dbg !4858
  %512 = icmp eq i64 %_2462.sroa.0.0.copyload, 0, !dbg !4859
  br i1 %512, label %bb443, label %bb2.i.i.i.i978, !dbg !4859

bb2.i.i.i.i978:                                   ; preds = %bb866
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2462.sroa.5.0.copyload, i64 noundef %_2462.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4865, !noalias !4870
  br label %bb443, !dbg !4873

bb867:                                            ; preds = %bb865
  %_2472 = load i64, ptr %77, align 8, !dbg !4874, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_697), !dbg !4845
  %513 = icmp eq i64 %_2462.sroa.0.0.copyload, 0, !dbg !4875
  br i1 %513, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit984", label %bb2.i.i.i.i982, !dbg !4875

bb2.i.i.i.i982:                                   ; preds = %bb867
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2462.sroa.5.0.copyload, i64 noundef %_2462.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4881, !noalias !4886
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit984", !dbg !4889

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit984": ; preds = %bb2.i.i.i.i982, %bb867
  call void @llvm.lifetime.start.p0(ptr nonnull %_707), !dbg !4890
  %_708 = load i64, ptr %35, align 8, !dbg !4892, !noundef !13
  %_3091 = icmp ult i64 %_708, 384307168202282326, !dbg !4894
  call void @llvm.assume(i1 %_3091), !dbg !4896
  call void @llvm.lifetime.start.p0(ptr nonnull %_709), !dbg !4897
  %..i = call noundef i64 @llvm.smin.i64(i64 %_2453, i64 %_2472), !dbg !4898
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_709, i64 noundef %..i) #16, !dbg !4897
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_707, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_708, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_709) #16, !dbg !4890
  call void @llvm.lifetime.end.p0(ptr nonnull %_709), !dbg !4902
  %514 = load i64, ptr %_707, align 8, !dbg !4903, !range !1747, !noundef !13
  %.not338 = icmp eq i64 %514, -9223372036854775797, !dbg !4903
  br i1 %.not338, label %bb870, label %bb869, !dbg !4904

bb869:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit984"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_707, i64 24, i1 false), !dbg !4905
  call void @llvm.lifetime.end.p0(ptr nonnull %_707), !dbg !4906
  br label %bb443, !dbg !4907

bb870:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit984"
  call void @llvm.lifetime.end.p0(ptr nonnull %_707), !dbg !4906
  br label %bb394, !dbg !4909

bb871:                                            ; preds = %bb115
  store i64 %_2487.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4910
  %_2494.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4910
  store ptr %_2487.sroa.5.0.copyload, ptr %_2494.sroa.2.0._0.sroa_idx, align 8, !dbg !4910
  %_2494.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4910
  store i64 %_2487.sroa.6.0.copyload, ptr %_2494.sroa.3.0._0.sroa_idx, align 8, !dbg !4910
  call void @llvm.lifetime.end.p0(ptr nonnull %_713), !dbg !4916
  br label %bb443, !dbg !1706

bb872:                                            ; preds = %bb115
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_713, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2487.sroa.5.0.copyload, i64 noundef %_2487.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !2039
  %515 = load i8, ptr %_713, align 8, !dbg !4917, !range !144, !noundef !13
  %516 = trunc nuw i8 %515 to i1, !dbg !4917
  br i1 %516, label %bb873, label %bb874, !dbg !4918

bb873:                                            ; preds = %bb872
  %517 = getelementptr inbounds nuw i8, ptr %_713, i64 1, !dbg !4919
  %518 = load i8, ptr %517, align 1, !dbg !4919, !range !144, !noundef !13
  %_2498 = trunc nuw i8 %518 to i1, !dbg !4919
  call void @llvm.lifetime.end.p0(ptr nonnull %_713), !dbg !4916
  call void @llvm.lifetime.start.p0(ptr nonnull %_2502), !dbg !4920
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2502, i1 noundef zeroext %_2498) #16, !dbg !4920
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2502, i64 24, i1 false), !dbg !4926
  call void @llvm.lifetime.end.p0(ptr nonnull %_2502), !dbg !4927
  %519 = icmp eq i64 %_2487.sroa.0.0.copyload, 0, !dbg !4928
  br i1 %519, label %bb443, label %bb2.i.i.i.i986, !dbg !4928

bb2.i.i.i.i986:                                   ; preds = %bb873
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2487.sroa.5.0.copyload, i64 noundef %_2487.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4934, !noalias !4939
  br label %bb443, !dbg !4942

bb874:                                            ; preds = %bb872
  %_2497 = load i64, ptr %71, align 8, !dbg !4943, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_713), !dbg !4916
  %520 = icmp eq i64 %_2487.sroa.0.0.copyload, 0, !dbg !4944
  br i1 %520, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit992", label %bb2.i.i.i.i990, !dbg !4944

bb2.i.i.i.i990:                                   ; preds = %bb874
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2487.sroa.5.0.copyload, i64 noundef %_2487.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4950, !noalias !4955
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit992", !dbg !4958

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit992": ; preds = %bb2.i.i.i.i990, %bb874
  call void @llvm.lifetime.start.p0(ptr nonnull %_723), !dbg !4959
  call void @llvm.lifetime.start.p0(ptr nonnull %_727), !dbg !4961
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_727, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !4961
  %_2504 = load i64, ptr %_727, align 8, !dbg !4962, !range !1765, !noundef !13
  %521 = trunc nuw i64 %_2504 to i1, !dbg !4963
  %_2506.sroa.0.0.copyload = load i64, ptr %72, align 8, !dbg !4964
  %_2506.sroa.5.0.copyload = load ptr, ptr %_2505.sroa.5.0..sroa_idx, align 8, !dbg !4964
  %_2506.sroa.6.0.copyload = load i64, ptr %_2505.sroa.6.0..sroa_idx, align 8, !dbg !4964
  call void @llvm.lifetime.end.p0(ptr nonnull %_727), !dbg !4965
  br i1 %521, label %bb876, label %bb877, !dbg !4963

bb876:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit992"
  store i64 %_2506.sroa.0.0.copyload, ptr %_0, align 8, !dbg !4966
  %_2513.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !4966
  store ptr %_2506.sroa.5.0.copyload, ptr %_2513.sroa.2.0._0.sroa_idx, align 8, !dbg !4966
  %_2513.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !4966
  store i64 %_2506.sroa.6.0.copyload, ptr %_2513.sroa.3.0._0.sroa_idx, align 8, !dbg !4966
  call void @llvm.lifetime.end.p0(ptr nonnull %_723), !dbg !4972
  br label %bb443, !dbg !4973

bb877:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit992"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_723, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2506.sroa.5.0.copyload, i64 noundef %_2506.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !4959
  %522 = load i8, ptr %_723, align 8, !dbg !4975, !range !144, !noundef !13
  %523 = trunc nuw i8 %522 to i1, !dbg !4975
  br i1 %523, label %bb878, label %bb879, !dbg !4976

bb878:                                            ; preds = %bb877
  %524 = getelementptr inbounds nuw i8, ptr %_723, i64 1, !dbg !4977
  %525 = load i8, ptr %524, align 1, !dbg !4977, !range !144, !noundef !13
  %_2517 = trunc nuw i8 %525 to i1, !dbg !4977
  call void @llvm.lifetime.end.p0(ptr nonnull %_723), !dbg !4972
  call void @llvm.lifetime.start.p0(ptr nonnull %_2521), !dbg !4978
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2521, i1 noundef zeroext %_2517) #16, !dbg !4978
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2521, i64 24, i1 false), !dbg !4984
  call void @llvm.lifetime.end.p0(ptr nonnull %_2521), !dbg !4985
  %526 = icmp eq i64 %_2506.sroa.0.0.copyload, 0, !dbg !4986
  br i1 %526, label %bb443, label %bb2.i.i.i.i994, !dbg !4986

bb2.i.i.i.i994:                                   ; preds = %bb878
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2506.sroa.5.0.copyload, i64 noundef %_2506.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !4992, !noalias !4997
  br label %bb443, !dbg !5000

bb879:                                            ; preds = %bb877
  %_2516 = load i64, ptr %73, align 8, !dbg !5001, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_723), !dbg !4972
  %527 = icmp eq i64 %_2506.sroa.0.0.copyload, 0, !dbg !5002
  br i1 %527, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1000", label %bb2.i.i.i.i998, !dbg !5002

bb2.i.i.i.i998:                                   ; preds = %bb879
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2506.sroa.5.0.copyload, i64 noundef %_2506.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5008, !noalias !5013
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1000", !dbg !5016

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1000": ; preds = %bb2.i.i.i.i998, %bb879
  call void @llvm.lifetime.start.p0(ptr nonnull %_733), !dbg !5017
  %_734 = load i64, ptr %35, align 8, !dbg !5019, !noundef !13
  %_3092 = icmp ult i64 %_734, 384307168202282326, !dbg !5021
  call void @llvm.assume(i1 %_3092), !dbg !5023
  call void @llvm.lifetime.start.p0(ptr nonnull %_735), !dbg !5024
  %..i1001 = call noundef i64 @llvm.smax.i64(i64 %_2497, i64 %_2516), !dbg !5025
  call void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_735, i64 noundef %..i1001) #16, !dbg !5024
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_733, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_734, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_735) #16, !dbg !5017
  call void @llvm.lifetime.end.p0(ptr nonnull %_735), !dbg !5028
  %528 = load i64, ptr %_733, align 8, !dbg !5029, !range !1747, !noundef !13
  %.not337 = icmp eq i64 %528, -9223372036854775797, !dbg !5029
  br i1 %.not337, label %bb882, label %bb881, !dbg !5030

bb881:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1000"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_733, i64 24, i1 false), !dbg !5031
  call void @llvm.lifetime.end.p0(ptr nonnull %_733), !dbg !5032
  br label %bb443, !dbg !5033

bb882:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1000"
  call void @llvm.lifetime.end.p0(ptr nonnull %_733), !dbg !5032
  br label %bb394, !dbg !5035

bb883:                                            ; preds = %bb114
  store i64 %_2531.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5036
  %_2538.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5036
  store ptr %_2531.sroa.5.0.copyload, ptr %_2538.sroa.2.0._0.sroa_idx, align 8, !dbg !5036
  %_2538.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5036
  store i64 %_2531.sroa.6.0.copyload, ptr %_2538.sroa.3.0._0.sroa_idx, align 8, !dbg !5036
  call void @llvm.lifetime.end.p0(ptr nonnull %_739), !dbg !5042
  br label %bb443, !dbg !1706

bb884:                                            ; preds = %bb114
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_739, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2531.sroa.5.0.copyload, i64 noundef %_2531.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !2045
  %529 = load i8, ptr %_739, align 8, !dbg !5043, !range !144, !noundef !13
  %530 = trunc nuw i8 %529 to i1, !dbg !5043
  br i1 %530, label %bb885, label %bb886, !dbg !5044

bb885:                                            ; preds = %bb884
  %531 = getelementptr inbounds nuw i8, ptr %_739, i64 1, !dbg !5045
  %532 = load i8, ptr %531, align 1, !dbg !5045, !range !144, !noundef !13
  %_2542 = trunc nuw i8 %532 to i1, !dbg !5045
  call void @llvm.lifetime.end.p0(ptr nonnull %_739), !dbg !5042
  call void @llvm.lifetime.start.p0(ptr nonnull %_2546), !dbg !5046
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2546, i1 noundef zeroext %_2542) #16, !dbg !5046
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2546, i64 24, i1 false), !dbg !5052
  call void @llvm.lifetime.end.p0(ptr nonnull %_2546), !dbg !5053
  %533 = icmp eq i64 %_2531.sroa.0.0.copyload, 0, !dbg !5054
  br i1 %533, label %bb443, label %bb2.i.i.i.i1003, !dbg !5054

bb2.i.i.i.i1003:                                  ; preds = %bb885
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2531.sroa.5.0.copyload, i64 noundef %_2531.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5060, !noalias !5065
  br label %bb443, !dbg !5068

bb886:                                            ; preds = %bb884
  %_2541 = load i64, ptr %65, align 8, !dbg !5069, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_739), !dbg !5042
  %534 = icmp eq i64 %_2531.sroa.0.0.copyload, 0, !dbg !5070
  br i1 %534, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1009", label %bb2.i.i.i.i1007, !dbg !5070

bb2.i.i.i.i1007:                                  ; preds = %bb886
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2531.sroa.5.0.copyload, i64 noundef %_2531.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5076, !noalias !5081
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1009", !dbg !5084

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1009": ; preds = %bb2.i.i.i.i1007, %bb886
  call void @llvm.lifetime.start.p0(ptr nonnull %_749), !dbg !5085
  call void @llvm.lifetime.start.p0(ptr nonnull %_753), !dbg !5087
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_753, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !5087
  %_2548 = load i64, ptr %_753, align 8, !dbg !5088, !range !1765, !noundef !13
  %535 = trunc nuw i64 %_2548 to i1, !dbg !5089
  %_2550.sroa.0.0.copyload = load i64, ptr %66, align 8, !dbg !5090
  %_2550.sroa.5.0.copyload = load ptr, ptr %_2549.sroa.5.0..sroa_idx, align 8, !dbg !5090
  %_2550.sroa.6.0.copyload = load i64, ptr %_2549.sroa.6.0..sroa_idx, align 8, !dbg !5090
  call void @llvm.lifetime.end.p0(ptr nonnull %_753), !dbg !5091
  br i1 %535, label %bb888, label %bb889, !dbg !5089

bb888:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1009"
  store i64 %_2550.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5092
  %_2557.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5092
  store ptr %_2550.sroa.5.0.copyload, ptr %_2557.sroa.2.0._0.sroa_idx, align 8, !dbg !5092
  %_2557.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5092
  store i64 %_2550.sroa.6.0.copyload, ptr %_2557.sroa.3.0._0.sroa_idx, align 8, !dbg !5092
  call void @llvm.lifetime.end.p0(ptr nonnull %_749), !dbg !5098
  br label %bb443, !dbg !5099

bb889:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1009"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_749, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2550.sroa.5.0.copyload, i64 noundef %_2550.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !5085
  %536 = load i8, ptr %_749, align 8, !dbg !5101, !range !144, !noundef !13
  %537 = trunc nuw i8 %536 to i1, !dbg !5101
  br i1 %537, label %bb890, label %bb891, !dbg !5102

bb890:                                            ; preds = %bb889
  %538 = getelementptr inbounds nuw i8, ptr %_749, i64 1, !dbg !5103
  %539 = load i8, ptr %538, align 1, !dbg !5103, !range !144, !noundef !13
  %_2561 = trunc nuw i8 %539 to i1, !dbg !5103
  call void @llvm.lifetime.end.p0(ptr nonnull %_749), !dbg !5098
  call void @llvm.lifetime.start.p0(ptr nonnull %_2565), !dbg !5104
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2565, i1 noundef zeroext %_2561) #16, !dbg !5104
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2565, i64 24, i1 false), !dbg !5110
  call void @llvm.lifetime.end.p0(ptr nonnull %_2565), !dbg !5111
  %540 = icmp eq i64 %_2550.sroa.0.0.copyload, 0, !dbg !5112
  br i1 %540, label %bb443, label %bb2.i.i.i.i1011, !dbg !5112

bb2.i.i.i.i1011:                                  ; preds = %bb890
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2550.sroa.5.0.copyload, i64 noundef %_2550.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5118, !noalias !5123
  br label %bb443, !dbg !5126

bb891:                                            ; preds = %bb889
  %_2560 = load i64, ptr %67, align 8, !dbg !5127, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_749), !dbg !5098
  %541 = icmp eq i64 %_2550.sroa.0.0.copyload, 0, !dbg !5128
  br i1 %541, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1017", label %bb2.i.i.i.i1015, !dbg !5128

bb2.i.i.i.i1015:                                  ; preds = %bb891
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2550.sroa.5.0.copyload, i64 noundef %_2550.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5134, !noalias !5139
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1017", !dbg !5142

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1017": ; preds = %bb2.i.i.i.i1015, %bb891
  call void @llvm.lifetime.start.p0(ptr nonnull %_759), !dbg !5143
  call void @llvm.lifetime.start.p0(ptr nonnull %_763), !dbg !5145
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr noalias noundef align 8 captures(none) dereferenceable(32) %_763, ptr noalias noundef align 8 dereferenceable(24) %stack) #16, !dbg !5145
  %_2567 = load i64, ptr %_763, align 8, !dbg !5146, !range !1765, !noundef !13
  %542 = trunc nuw i64 %_2567 to i1, !dbg !5147
  %_2569.sroa.0.0.copyload = load i64, ptr %68, align 8, !dbg !5148
  %_2569.sroa.5.0.copyload = load ptr, ptr %_2568.sroa.5.0..sroa_idx, align 8, !dbg !5148
  %_2569.sroa.6.0.copyload = load i64, ptr %_2568.sroa.6.0..sroa_idx, align 8, !dbg !5148
  call void @llvm.lifetime.end.p0(ptr nonnull %_763), !dbg !5149
  br i1 %542, label %bb893, label %bb894, !dbg !5147

bb893:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1017"
  store i64 %_2569.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5150
  %_2576.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5150
  store ptr %_2569.sroa.5.0.copyload, ptr %_2576.sroa.2.0._0.sroa_idx, align 8, !dbg !5150
  %_2576.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5150
  store i64 %_2569.sroa.6.0.copyload, ptr %_2576.sroa.3.0._0.sroa_idx, align 8, !dbg !5150
  call void @llvm.lifetime.end.p0(ptr nonnull %_759), !dbg !5156
  br label %bb443, !dbg !5157

bb894:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1017"
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter10decode_i6417hae25098d53c6d99dE(ptr noalias noundef align 8 captures(none) dereferenceable(16) %_759, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2569.sroa.5.0.copyload, i64 noundef %_2569.sroa.6.0.copyload, i1 noundef zeroext %rm) #16, !dbg !5143
  %543 = load i8, ptr %_759, align 8, !dbg !5159, !range !144, !noundef !13
  %544 = trunc nuw i8 %543 to i1, !dbg !5159
  br i1 %544, label %bb895, label %bb896, !dbg !5160

bb895:                                            ; preds = %bb894
  %545 = getelementptr inbounds nuw i8, ptr %_759, i64 1, !dbg !5161
  %546 = load i8, ptr %545, align 1, !dbg !5161, !range !144, !noundef !13
  %_2580 = trunc nuw i8 %546 to i1, !dbg !5161
  call void @llvm.lifetime.end.p0(ptr nonnull %_759), !dbg !5156
  call void @llvm.lifetime.start.p0(ptr nonnull %_2584), !dbg !5162
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2584, i1 noundef zeroext %_2580) #16, !dbg !5162
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2584, i64 24, i1 false), !dbg !5168
  call void @llvm.lifetime.end.p0(ptr nonnull %_2584), !dbg !5169
  %547 = icmp eq i64 %_2569.sroa.0.0.copyload, 0, !dbg !5170
  br i1 %547, label %bb443, label %bb2.i.i.i.i1019, !dbg !5170

bb2.i.i.i.i1019:                                  ; preds = %bb895
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2569.sroa.5.0.copyload, i64 noundef %_2569.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5176, !noalias !5181
  br label %bb443, !dbg !5184

bb896:                                            ; preds = %bb894
  %_2579 = load i64, ptr %69, align 8, !dbg !5185, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_759), !dbg !5156
  %548 = icmp eq i64 %_2569.sroa.0.0.copyload, 0, !dbg !5186
  br i1 %548, label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1025", label %bb2.i.i.i.i1023, !dbg !5186

bb2.i.i.i.i1023:                                  ; preds = %bb896
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2569.sroa.5.0.copyload, i64 noundef %_2569.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5192, !noalias !5197
  br label %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1025", !dbg !5200

"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1025": ; preds = %bb2.i.i.i.i1023, %bb896
  call void @llvm.lifetime.start.p0(ptr nonnull %_769), !dbg !5201
  %_770 = load i64, ptr %35, align 8, !dbg !5203, !noundef !13
  %_3093 = icmp ult i64 %_770, 384307168202282326, !dbg !5205
  call void @llvm.assume(i1 %_3093), !dbg !5207
  call void @llvm.lifetime.start.p0(ptr nonnull %_771), !dbg !5208
  %_773.not = icmp sge i64 %_2579, %_2560, !dbg !5209
  %549 = icmp slt i64 %_2579, %_2541, !dbg !5209
  %_772.sroa.0.0 = and i1 %_773.not, %549, !dbg !5209
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter11bool_encode17h6cf3d3beab52c352E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_771, i1 noundef zeroext %_772.sroa.0.0) #16, !dbg !5208
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_769, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_770, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_771) #16, !dbg !5201
  call void @llvm.lifetime.end.p0(ptr nonnull %_771), !dbg !5210
  %550 = load i64, ptr %_769, align 8, !dbg !5211, !range !1747, !noundef !13
  %.not336 = icmp eq i64 %550, -9223372036854775797, !dbg !5211
  br i1 %.not336, label %bb899, label %bb898, !dbg !5212

bb898:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1025"
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_769, i64 24, i1 false), !dbg !5213
  call void @llvm.lifetime.end.p0(ptr nonnull %_769), !dbg !5214
  br label %bb443, !dbg !5215

bb899:                                            ; preds = %"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E.exit1025"
  call void @llvm.lifetime.end.p0(ptr nonnull %_769), !dbg !5214
  br label %bb394, !dbg !5217

bb900:                                            ; preds = %bb113
  store i64 %_2594.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5218
  %_2601.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5218
  store ptr %_2594.sroa.5.0.copyload, ptr %_2601.sroa.2.0._0.sroa_idx, align 8, !dbg !5218
  %_2601.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5218
  store i64 %_2594.sroa.6.0.copyload, ptr %_2601.sroa.3.0._0.sroa_idx, align 8, !dbg !5218
  br label %bb443, !dbg !1706

bb901:                                            ; preds = %bb113
  call void @llvm.lifetime.start.p0(ptr nonnull %digest), !dbg !5224
  call fastcc void @_ZN14bitcoin_hashes4Hash4hash17h0c6cd049fe8a3fa5E(ptr noalias noundef align 1 captures(address) dereferenceable(20) %digest, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2594.sroa.5.0.copyload, i64 noundef %_2594.sroa.6.0.copyload) #16, !dbg !5226
  call void @llvm.lifetime.start.p0(ptr nonnull %_784), !dbg !5227
  %_785 = load i64, ptr %35, align 8, !dbg !5229, !noundef !13
  %_2603 = icmp ult i64 %_785, 384307168202282326, !dbg !5231
  call void @llvm.assume(i1 %_2603), !dbg !5233
  call void @llvm.lifetime.start.p0(ptr nonnull %_786), !dbg !5234
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5235, !noalias !5249
  %551 = call noundef dereferenceable_or_null(20) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 20, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5252, !noalias !5249
  %552 = icmp eq ptr %551, null, !dbg !5257
  br i1 %552, label %bb903, label %bb904, !dbg !5258

bb903:                                            ; preds = %bb901
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 20) #17, !dbg !5259
  unreachable, !dbg !5259

bb904:                                            ; preds = %bb901
  store i64 20, ptr %_786, align 8, !dbg !5261
  store ptr %551, ptr %62, align 8, !dbg !5261
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(20) %551, ptr noundef nonnull align 1 dereferenceable(20) %digest, i64 20, i1 false), !dbg !5262
  store i64 20, ptr %63, align 8, !dbg !5268
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_784, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_785, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_786) #16, !dbg !5227
  call void @llvm.lifetime.end.p0(ptr nonnull %_786), !dbg !5271
  %553 = load i64, ptr %_784, align 8, !dbg !5272, !range !1747, !noundef !13
  %.not335 = icmp eq i64 %553, -9223372036854775797, !dbg !5272
  br i1 %.not335, label %bb906, label %bb905, !dbg !5273

bb905:                                            ; preds = %bb904
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_784, i64 24, i1 false), !dbg !5274
  call void @llvm.lifetime.end.p0(ptr nonnull %_784), !dbg !5275
  call void @llvm.lifetime.end.p0(ptr nonnull %digest), !dbg !5276
  %554 = icmp eq i64 %_2594.sroa.0.0.copyload, 0, !dbg !5277
  br i1 %554, label %bb443, label %bb2.i.i.i.i1035, !dbg !5277

bb2.i.i.i.i1035:                                  ; preds = %bb905
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2594.sroa.5.0.copyload, i64 noundef %_2594.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5283, !noalias !5288
  br label %bb443, !dbg !5291

bb906:                                            ; preds = %bb904
  call void @llvm.lifetime.end.p0(ptr nonnull %_784), !dbg !5275
  call void @llvm.lifetime.end.p0(ptr nonnull %digest), !dbg !5276
  %555 = icmp eq i64 %_2594.sroa.0.0.copyload, 0, !dbg !5292
  br i1 %555, label %bb394, label %bb2.i.i.i.i1039, !dbg !5292

bb2.i.i.i.i1039:                                  ; preds = %bb906
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2594.sroa.5.0.copyload, i64 noundef %_2594.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5298, !noalias !5303
  br label %bb394, !dbg !5306

bb907:                                            ; preds = %bb112
  store i64 %_2627.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5307
  %_2631.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5307
  store ptr %_2627.sroa.5.0.copyload, ptr %_2631.sroa.2.0._0.sroa_idx, align 8, !dbg !5307
  %_2631.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5307
  store i64 %_2627.sroa.6.0.copyload, ptr %_2631.sroa.3.0._0.sroa_idx, align 8, !dbg !5307
  br label %bb443, !dbg !1706

bb908:                                            ; preds = %bb112
  call void @llvm.lifetime.start.p0(ptr nonnull %_796), !dbg !5313
  %_797 = load i64, ptr %35, align 8, !dbg !5315, !noundef !13
  %_2629 = icmp ult i64 %_797, 384307168202282326, !dbg !5317
  call void @llvm.assume(i1 %_2629), !dbg !5319
  call void @llvm.lifetime.start.p0(ptr nonnull %_798), !dbg !5320
  call void @llvm.lifetime.start.p0(ptr nonnull %_801), !dbg !5320
  call fastcc void @_ZN18rbitcoin_consensus6script6crypto4sha117h43ec7d90f07f0c1cE(ptr noalias noundef align 1 captures(none) dereferenceable(20) %_801, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2627.sroa.5.0.copyload, i64 noundef %_2627.sroa.6.0.copyload) #16, !dbg !5320
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5321, !noalias !5335
  %556 = call noundef dereferenceable_or_null(20) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 20, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5338, !noalias !5335
  %557 = icmp eq ptr %556, null, !dbg !5343
  br i1 %557, label %bb910, label %bb911, !dbg !5344

bb910:                                            ; preds = %bb908
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 20) #17, !dbg !5345
  unreachable, !dbg !5345

bb911:                                            ; preds = %bb908
  store i64 20, ptr %_798, align 8, !dbg !5347
  store ptr %556, ptr %59, align 8, !dbg !5347
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(20) %556, ptr noundef nonnull align 1 dereferenceable(20) %_801, i64 20, i1 false), !dbg !5348
  store i64 20, ptr %60, align 8, !dbg !5354
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_796, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_797, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_798) #16, !dbg !5313
  call void @llvm.lifetime.end.p0(ptr nonnull %_798), !dbg !5356
  %558 = load i64, ptr %_796, align 8, !dbg !5357, !range !1747, !noundef !13
  %.not334 = icmp eq i64 %558, -9223372036854775797, !dbg !5357
  br i1 %.not334, label %bb913, label %bb912, !dbg !5358

bb912:                                            ; preds = %bb911
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_796, i64 24, i1 false), !dbg !5359
  call void @llvm.lifetime.end.p0(ptr nonnull %_796), !dbg !5360
  call void @llvm.lifetime.end.p0(ptr nonnull %_801), !dbg !5361
  %559 = icmp eq i64 %_2627.sroa.0.0.copyload, 0, !dbg !5362
  br i1 %559, label %bb443, label %bb2.i.i.i.i1051, !dbg !5362

bb2.i.i.i.i1051:                                  ; preds = %bb912
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2627.sroa.5.0.copyload, i64 noundef %_2627.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5368, !noalias !5373
  br label %bb443, !dbg !5376

bb913:                                            ; preds = %bb911
  call void @llvm.lifetime.end.p0(ptr nonnull %_796), !dbg !5360
  call void @llvm.lifetime.end.p0(ptr nonnull %_801), !dbg !5361
  %560 = icmp eq i64 %_2627.sroa.0.0.copyload, 0, !dbg !5377
  br i1 %560, label %bb394, label %bb2.i.i.i.i1055, !dbg !5377

bb2.i.i.i.i1055:                                  ; preds = %bb913
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2627.sroa.5.0.copyload, i64 noundef %_2627.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5383, !noalias !5388
  br label %bb394, !dbg !5391

bb914:                                            ; preds = %bb111
  store i64 %_2660.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5392
  %_2664.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5392
  store ptr %_2660.sroa.5.0.copyload, ptr %_2664.sroa.2.0._0.sroa_idx, align 8, !dbg !5392
  %_2664.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5392
  store i64 %_2660.sroa.6.0.copyload, ptr %_2664.sroa.3.0._0.sroa_idx, align 8, !dbg !5392
  br label %bb443, !dbg !1706

bb915:                                            ; preds = %bb111
  call void @llvm.lifetime.start.p0(ptr nonnull %_810), !dbg !5398
  %_811 = load i64, ptr %35, align 8, !dbg !5400, !noundef !13
  %_2662 = icmp ult i64 %_811, 384307168202282326, !dbg !5402
  call void @llvm.assume(i1 %_2662), !dbg !5404
  call void @llvm.lifetime.start.p0(ptr nonnull %_812), !dbg !5405
  call void @llvm.lifetime.start.p0(ptr nonnull %_815), !dbg !5405
  call fastcc void @_ZN18rbitcoin_consensus6script6crypto6sha25617h5457b5a3ce962158E(ptr noalias noundef align 1 captures(none) dereferenceable(32) %_815, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2660.sroa.5.0.copyload, i64 noundef %_2660.sroa.6.0.copyload) #16, !dbg !5405
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5406, !noalias !5420
  %561 = call noundef dereferenceable_or_null(32) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 32, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5423, !noalias !5420
  %562 = icmp eq ptr %561, null, !dbg !5428
  br i1 %562, label %bb917, label %bb918, !dbg !5429

bb917:                                            ; preds = %bb915
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 32) #17, !dbg !5430
  unreachable, !dbg !5430

bb918:                                            ; preds = %bb915
  store i64 32, ptr %_812, align 8, !dbg !5432
  store ptr %561, ptr %56, align 8, !dbg !5432
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %561, ptr noundef nonnull align 1 dereferenceable(32) %_815, i64 32, i1 false), !dbg !5433
  store i64 32, ptr %57, align 8, !dbg !5439
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_810, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_811, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_812) #16, !dbg !5398
  call void @llvm.lifetime.end.p0(ptr nonnull %_812), !dbg !5441
  %563 = load i64, ptr %_810, align 8, !dbg !5442, !range !1747, !noundef !13
  %.not333 = icmp eq i64 %563, -9223372036854775797, !dbg !5442
  br i1 %.not333, label %bb920, label %bb919, !dbg !5443

bb919:                                            ; preds = %bb918
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_810, i64 24, i1 false), !dbg !5444
  call void @llvm.lifetime.end.p0(ptr nonnull %_810), !dbg !5445
  call void @llvm.lifetime.end.p0(ptr nonnull %_815), !dbg !5446
  %564 = icmp eq i64 %_2660.sroa.0.0.copyload, 0, !dbg !5447
  br i1 %564, label %bb443, label %bb2.i.i.i.i1067, !dbg !5447

bb2.i.i.i.i1067:                                  ; preds = %bb919
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2660.sroa.5.0.copyload, i64 noundef %_2660.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5453, !noalias !5458
  br label %bb443, !dbg !5461

bb920:                                            ; preds = %bb918
  call void @llvm.lifetime.end.p0(ptr nonnull %_810), !dbg !5445
  call void @llvm.lifetime.end.p0(ptr nonnull %_815), !dbg !5446
  %565 = icmp eq i64 %_2660.sroa.0.0.copyload, 0, !dbg !5462
  br i1 %565, label %bb394, label %bb2.i.i.i.i1071, !dbg !5462

bb2.i.i.i.i1071:                                  ; preds = %bb920
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2660.sroa.5.0.copyload, i64 noundef %_2660.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5468, !noalias !5473
  br label %bb394, !dbg !5476

bb921:                                            ; preds = %bb110
  store i64 %_2693.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5477
  %_2697.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5477
  store ptr %_2693.sroa.5.0.copyload, ptr %_2697.sroa.2.0._0.sroa_idx, align 8, !dbg !5477
  %_2697.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5477
  store i64 %_2693.sroa.6.0.copyload, ptr %_2697.sroa.3.0._0.sroa_idx, align 8, !dbg !5477
  br label %bb443, !dbg !1706

bb922:                                            ; preds = %bb110
  call void @llvm.lifetime.start.p0(ptr nonnull %_824), !dbg !5483
  %_825 = load i64, ptr %35, align 8, !dbg !5485, !noundef !13
  %_2695 = icmp ult i64 %_825, 384307168202282326, !dbg !5487
  call void @llvm.assume(i1 %_2695), !dbg !5489
  call void @llvm.lifetime.start.p0(ptr nonnull %_826), !dbg !5490
  call void @llvm.lifetime.start.p0(ptr nonnull %_829), !dbg !5490
  call fastcc void @_ZN18rbitcoin_consensus6script6crypto7hash16017hd4348c3b7381f5ddE(ptr noalias noundef align 1 captures(none) dereferenceable(20) %_829, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2693.sroa.5.0.copyload, i64 noundef %_2693.sroa.6.0.copyload) #16, !dbg !5490
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5491, !noalias !5505
  %566 = call noundef dereferenceable_or_null(20) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 20, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5508, !noalias !5505
  %567 = icmp eq ptr %566, null, !dbg !5513
  br i1 %567, label %bb924, label %bb925, !dbg !5514

bb924:                                            ; preds = %bb922
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 20) #17, !dbg !5515
  unreachable, !dbg !5515

bb925:                                            ; preds = %bb922
  store i64 20, ptr %_826, align 8, !dbg !5517
  store ptr %566, ptr %53, align 8, !dbg !5517
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(20) %566, ptr noundef nonnull align 1 dereferenceable(20) %_829, i64 20, i1 false), !dbg !5518
  store i64 20, ptr %54, align 8, !dbg !5524
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_824, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_825, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_826) #16, !dbg !5483
  call void @llvm.lifetime.end.p0(ptr nonnull %_826), !dbg !5526
  %568 = load i64, ptr %_824, align 8, !dbg !5527, !range !1747, !noundef !13
  %.not332 = icmp eq i64 %568, -9223372036854775797, !dbg !5527
  br i1 %.not332, label %bb927, label %bb926, !dbg !5528

bb926:                                            ; preds = %bb925
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_824, i64 24, i1 false), !dbg !5529
  call void @llvm.lifetime.end.p0(ptr nonnull %_824), !dbg !5530
  call void @llvm.lifetime.end.p0(ptr nonnull %_829), !dbg !5531
  %569 = icmp eq i64 %_2693.sroa.0.0.copyload, 0, !dbg !5532
  br i1 %569, label %bb443, label %bb2.i.i.i.i1083, !dbg !5532

bb2.i.i.i.i1083:                                  ; preds = %bb926
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2693.sroa.5.0.copyload, i64 noundef %_2693.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5538, !noalias !5543
  br label %bb443, !dbg !5546

bb927:                                            ; preds = %bb925
  call void @llvm.lifetime.end.p0(ptr nonnull %_824), !dbg !5530
  call void @llvm.lifetime.end.p0(ptr nonnull %_829), !dbg !5531
  %570 = icmp eq i64 %_2693.sroa.0.0.copyload, 0, !dbg !5547
  br i1 %570, label %bb394, label %bb2.i.i.i.i1087, !dbg !5547

bb2.i.i.i.i1087:                                  ; preds = %bb927
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2693.sroa.5.0.copyload, i64 noundef %_2693.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5553, !noalias !5558
  br label %bb394, !dbg !5561

bb928:                                            ; preds = %bb109
  store i64 %_2726.sroa.0.0.copyload, ptr %_0, align 8, !dbg !5562
  %_2733.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5562
  store ptr %_2726.sroa.5.0.copyload, ptr %_2733.sroa.2.0._0.sroa_idx, align 8, !dbg !5562
  %_2733.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5562
  store i64 %_2726.sroa.6.0.copyload, ptr %_2733.sroa.3.0._0.sroa_idx, align 8, !dbg !5562
  br label %bb443, !dbg !1706

bb929:                                            ; preds = %bb109
  call void @llvm.lifetime.start.p0(ptr nonnull %digest160), !dbg !5568
  call fastcc void @_ZN14bitcoin_hashes4Hash4hash17ha1931f230c6e1e50E(ptr noalias noundef align 1 captures(address) dereferenceable(32) %digest160, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2726.sroa.5.0.copyload, i64 noundef %_2726.sroa.6.0.copyload) #16, !dbg !5570
  call void @llvm.lifetime.start.p0(ptr nonnull %_841), !dbg !5571
  %_842 = load i64, ptr %35, align 8, !dbg !5573, !noundef !13
  %_2735 = icmp ult i64 %_842, 384307168202282326, !dbg !5575
  call void @llvm.assume(i1 %_2735), !dbg !5577
  call void @llvm.lifetime.start.p0(ptr nonnull %_843), !dbg !5578
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5579, !noalias !5593
  %571 = call noundef dereferenceable_or_null(32) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 32, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5596, !noalias !5593
  %572 = icmp eq ptr %571, null, !dbg !5601
  br i1 %572, label %bb931, label %bb932, !dbg !5602

bb931:                                            ; preds = %bb929
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 32) #17, !dbg !5603
  unreachable, !dbg !5603

bb932:                                            ; preds = %bb929
  store i64 32, ptr %_843, align 8, !dbg !5605
  store ptr %571, ptr %50, align 8, !dbg !5605
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(32) %571, ptr noundef nonnull align 1 dereferenceable(32) %digest160, i64 32, i1 false), !dbg !5606
  store i64 32, ptr %51, align 8, !dbg !5612
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_841, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_842, ptr noalias noundef align 8 captures(address) dereferenceable(24) %_843) #16, !dbg !5571
  call void @llvm.lifetime.end.p0(ptr nonnull %_843), !dbg !5614
  %573 = load i64, ptr %_841, align 8, !dbg !5615, !range !1747, !noundef !13
  %.not331 = icmp eq i64 %573, -9223372036854775797, !dbg !5615
  br i1 %.not331, label %bb934, label %bb933, !dbg !5616

bb933:                                            ; preds = %bb932
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_841, i64 24, i1 false), !dbg !5617
  call void @llvm.lifetime.end.p0(ptr nonnull %_841), !dbg !5618
  call void @llvm.lifetime.end.p0(ptr nonnull %digest160), !dbg !5619
  %574 = icmp eq i64 %_2726.sroa.0.0.copyload, 0, !dbg !5620
  br i1 %574, label %bb443, label %bb2.i.i.i.i1099, !dbg !5620

bb2.i.i.i.i1099:                                  ; preds = %bb933
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2726.sroa.5.0.copyload, i64 noundef %_2726.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5626, !noalias !5631
  br label %bb443, !dbg !5634

bb934:                                            ; preds = %bb932
  call void @llvm.lifetime.end.p0(ptr nonnull %_841), !dbg !5618
  call void @llvm.lifetime.end.p0(ptr nonnull %digest160), !dbg !5619
  %575 = icmp eq i64 %_2726.sroa.0.0.copyload, 0, !dbg !5635
  br i1 %575, label %bb394, label %bb2.i.i.i.i1103, !dbg !5635

bb2.i.i.i.i1103:                                  ; preds = %bb934
  call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_2726.sroa.5.0.copyload, i64 noundef %_2726.sroa.0.0.copyload, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5641, !noalias !5646
  br label %bb394, !dbg !5649

bb936:                                            ; preds = %bb107
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_850, i64 24, i1 false), !dbg !5650
  call void @llvm.lifetime.end.p0(ptr nonnull %_850), !dbg !5651
  br label %bb443, !dbg !1706

bb937:                                            ; preds = %bb107
  call void @llvm.lifetime.end.p0(ptr nonnull %_850), !dbg !5651
  br label %bb394, !dbg !5651

bb938:                                            ; preds = %bb106
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_854, i64 24, i1 false), !dbg !5652
  call void @llvm.lifetime.end.p0(ptr nonnull %_854), !dbg !5653
  br label %bb443, !dbg !1706

bb939:                                            ; preds = %bb106
  call void @llvm.lifetime.end.p0(ptr nonnull %_854), !dbg !5653
  br label %bb394, !dbg !5653

bb361:                                            ; preds = %bb105
  call void @llvm.lifetime.start.p0(ptr nonnull %_862), !dbg !5654
  %_863 = load i64, ptr %35, align 8, !dbg !5655, !noundef !13
  %_2790 = icmp ult i64 %_863, 384307168202282326, !dbg !5657
  call void @llvm.assume(i1 %_2790), !dbg !5659
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter14op_checksigadd17h58d983ce716c8d23E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_862, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_863, ptr noundef nonnull align 8 %ctx) #16, !dbg !5654
  %576 = load i64, ptr %_862, align 8, !dbg !5660, !range !1747, !noundef !13
  %.not328 = icmp eq i64 %576, -9223372036854775797, !dbg !5660
  br i1 %.not328, label %bb946, label %bb945, !dbg !5661

bb360:                                            ; preds = %bb105
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5662, !noalias !5684
  %577 = call noundef dereferenceable_or_null(19) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 19, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5687, !noalias !5684
  %578 = icmp eq ptr %577, null, !dbg !5692
  br i1 %578, label %bb943, label %bb944, !dbg !5693

bb945:                                            ; preds = %bb361
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_862, i64 24, i1 false), !dbg !5694
  call void @llvm.lifetime.end.p0(ptr nonnull %_862), !dbg !5695
  br label %bb443, !dbg !1706

bb946:                                            ; preds = %bb361
  call void @llvm.lifetime.end.p0(ptr nonnull %_862), !dbg !5695
  br label %bb394, !dbg !5696

bb943:                                            ; preds = %bb360
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 19) #17, !dbg !5697
  unreachable, !dbg !5697

bb944:                                            ; preds = %bb360
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(19) %577, ptr noundef nonnull align 1 dereferenceable(19) @alloc_b5950a714e85e2d9a1cbf7e97b2f2592, i64 19, i1 false), !dbg !5699
  store i64 19, ptr %_0, align 8, !dbg !5705
  %_859.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5705
  store ptr %577, ptr %_859.sroa.4.0._0.sroa_idx, align 8, !dbg !5705
  %_859.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5705
  store i64 19, ptr %_859.sroa.5.0._0.sroa_idx, align 8, !dbg !5705
  br label %bb443, !dbg !1706

bb364:                                            ; preds = %bb104
  %pre = trunc nuw i8 %_6.val392 to i1, !dbg !5706
  call void @llvm.lifetime.start.p0(ptr nonnull %_872), !dbg !5707
  %_873 = load i64, ptr %35, align 8, !dbg !5709, !noundef !13
  %_2797 = icmp ult i64 %_873, 384307168202282326, !dbg !5711
  call void @llvm.assume(i1 %_2797), !dbg !5713
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter16op_checkmultisig17h93c6fdf44d13f186E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_872, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_873, ptr noundef nonnull align 8 %ctx, i1 noundef zeroext false, ptr noalias noundef align 8 dereferenceable(8) %op_count, i1 noundef zeroext %pre) #16, !dbg !5707
  %579 = load i64, ptr %_872, align 8, !dbg !5714, !range !1747, !noundef !13
  %.not327 = icmp eq i64 %579, -9223372036854775797, !dbg !5714
  br i1 %.not327, label %bb953, label %bb952, !dbg !5715

bb365:                                            ; preds = %bb104
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5716, !noalias !5738
  %580 = call noundef dereferenceable_or_null(35) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 35, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5741, !noalias !5738
  %581 = icmp eq ptr %580, null, !dbg !5746
  br i1 %581, label %bb950, label %bb951, !dbg !5747

bb952:                                            ; preds = %bb364
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_872, i64 24, i1 false), !dbg !5748
  call void @llvm.lifetime.end.p0(ptr nonnull %_872), !dbg !5749
  br label %bb443, !dbg !1706

bb953:                                            ; preds = %bb364
  call void @llvm.lifetime.end.p0(ptr nonnull %_872), !dbg !5749
  br label %bb394, !dbg !5750

bb950:                                            ; preds = %bb365
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 35) #17, !dbg !5751
  unreachable, !dbg !5751

bb951:                                            ; preds = %bb365
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(35) %580, ptr noundef nonnull align 1 dereferenceable(35) @alloc_76451f304efea00a147201872a6c61d1, i64 35, i1 false), !dbg !5753
  store i64 35, ptr %_0, align 8, !dbg !5759
  %_865.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5759
  store ptr %580, ptr %_865.sroa.4.0._0.sroa_idx, align 8, !dbg !5759
  %_865.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5759
  store i64 35, ptr %_865.sroa.5.0._0.sroa_idx, align 8, !dbg !5759
  br label %bb443, !dbg !1706

bb368:                                            ; preds = %bb103
  %pre242 = trunc nuw i8 %_6.val392 to i1, !dbg !5760
  call void @llvm.lifetime.start.p0(ptr nonnull %_883), !dbg !5761
  %_884 = load i64, ptr %35, align 8, !dbg !5763, !noundef !13
  %_2823 = icmp ult i64 %_884, 384307168202282326, !dbg !5765
  call void @llvm.assume(i1 %_2823), !dbg !5767
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter16op_checkmultisig17h93c6fdf44d13f186E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_883, ptr noalias noundef align 8 dereferenceable(24) %stack, i64 noundef %_884, ptr noundef nonnull align 8 %ctx, i1 noundef zeroext true, ptr noalias noundef align 8 dereferenceable(8) %op_count, i1 noundef zeroext %pre242) #16, !dbg !5761
  %582 = load i64, ptr %_883, align 8, !dbg !5768, !range !1747, !noundef !13
  %.not325 = icmp eq i64 %582, -9223372036854775797, !dbg !5768
  br i1 %.not325, label %bb960, label %bb959, !dbg !5769

bb369:                                            ; preds = %bb103
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5770, !noalias !5792
  %583 = call noundef dereferenceable_or_null(41) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 41, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5795, !noalias !5792
  %584 = icmp eq ptr %583, null, !dbg !5800
  br i1 %584, label %bb957, label %bb958, !dbg !5801

bb959:                                            ; preds = %bb368
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_883, i64 24, i1 false), !dbg !5802
  call void @llvm.lifetime.end.p0(ptr nonnull %_883), !dbg !5803
  br label %bb443, !dbg !1706

bb960:                                            ; preds = %bb368
  call void @llvm.lifetime.end.p0(ptr nonnull %_883), !dbg !5803
  br label %bb394, !dbg !5804

bb957:                                            ; preds = %bb369
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 41) #17, !dbg !5805
  unreachable, !dbg !5805

bb958:                                            ; preds = %bb369
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(41) %583, ptr noundef nonnull align 1 dereferenceable(41) @alloc_420b47dc024432f6dbc618fef11b0af8, i64 41, i1 false), !dbg !5807
  store i64 41, ptr %_0, align 8, !dbg !5813
  %_876.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !5813
  store ptr %583, ptr %_876.sroa.4.0._0.sroa_idx, align 8, !dbg !5813
  %_876.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !5813
  store i64 41, ptr %_876.sroa.5.0._0.sroa_idx, align 8, !dbg !5813
  br label %bb443, !dbg !1706

bb371:                                            ; preds = %bb102
  call void @llvm.lifetime.start.p0(ptr nonnull %_889), !dbg !5814
  %_2851 = load i64, ptr %39, align 8, !dbg !5815, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_889, i64 noundef %_2851, i64 noundef 1) #16, !dbg !5814
  %585 = load i64, ptr %_889, align 8, !dbg !5819, !range !1747, !noundef !13
  %.not323 = icmp eq i64 %585, -9223372036854775797, !dbg !5819
  br i1 %.not323, label %bb962, label %bb961, !dbg !5820

bb961:                                            ; preds = %bb371
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_889, i64 24, i1 false), !dbg !5821
  call void @llvm.lifetime.end.p0(ptr nonnull %_889), !dbg !5822
  br label %bb443, !dbg !1706

bb962:                                            ; preds = %bb371
  call void @llvm.lifetime.end.p0(ptr nonnull %_889), !dbg !5822
  call void @llvm.lifetime.start.p0(ptr nonnull %_893), !dbg !5823
  %_2858 = load i64, ptr %39, align 8, !dbg !5824, !noundef !13
  %_2863.not = icmp eq i64 %_2858, 0, !dbg !5828
  br i1 %_2863.not, label %bb964, label %bb963, !dbg !5828, !prof !1627

bb964:                                            ; preds = %bb962
  call void @_RNvNtCsgEmfK2I1SDS_4core6option13unwrap_failed(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_92e8cfa91beedd87ed07014a34c9e885) #15, !dbg !5831
  unreachable, !dbg !5831

bb963:                                            ; preds = %bb962
  %_2859 = load ptr, ptr %40, align 8, !dbg !5833, !nonnull !13, !noundef !13
  %586 = getelementptr %"alloc::vec::Vec<u8>", ptr %_2859, i64 %_2858, !dbg !5842
  %587 = getelementptr i8, ptr %586, i64 -16, !dbg !5843
  %_2869 = load ptr, ptr %587, align 8, !dbg !5843, !nonnull !13, !noundef !13
  %588 = getelementptr i8, ptr %586, i64 -8, !dbg !5855
  %_2868 = load i64, ptr %588, align 8, !dbg !5855, !noundef !13
  call void @_ZN19rbitcoin_primitives9scriptnum22scriptnum_decode_width17h06c01f6519d03db8E(ptr noalias noundef nonnull sret([16 x i8]) align 8 captures(none) dereferenceable(16) %_893, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2869, i64 noundef %_2868, i64 noundef 5, i1 noundef zeroext %rm) #16, !dbg !5823
  %589 = load i8, ptr %_893, align 8, !dbg !5856, !range !144, !noundef !13
  %590 = trunc nuw i8 %589 to i1, !dbg !5856
  br i1 %590, label %bb965, label %bb966, !dbg !5857

bb965:                                            ; preds = %bb963
  %591 = getelementptr inbounds nuw i8, ptr %_893, i64 1, !dbg !5858
  %592 = load i8, ptr %591, align 1, !dbg !5858, !range !144, !noundef !13
  %_2872 = trunc nuw i8 %592 to i1, !dbg !5858
  call void @llvm.lifetime.end.p0(ptr nonnull %_893), !dbg !5859
  call void @llvm.lifetime.start.p0(ptr nonnull %_2876), !dbg !5860
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2876, i1 noundef zeroext %_2872) #16, !dbg !5860
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2876, i64 24, i1 false), !dbg !5866
  call void @llvm.lifetime.end.p0(ptr nonnull %_2876), !dbg !5867
  br label %bb443, !dbg !1706

bb966:                                            ; preds = %bb963
  %_2871 = load i64, ptr %47, align 8, !dbg !5868, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_893), !dbg !5859
  %_899 = icmp slt i64 %_2871, 0, !dbg !5869
  br i1 %_899, label %bb374, label %bb375, !dbg !5869

bb375:                                            ; preds = %bb966
  %_956 = load ptr, ptr %44, align 8, !dbg !5871, !nonnull !13, !align !5872, !noundef !13
  %593 = getelementptr inbounds nuw i8, ptr %_956, i64 52, !dbg !5871
  %594 = load i32, ptr %593, align 4, !dbg !5871, !noundef !13
  %lock_is_time = icmp samesign ugt i64 %_2871, 499999999, !dbg !5873
  %tx_is_time = icmp ugt i32 %594, 499999999, !dbg !5875
  %_907 = xor i1 %lock_is_time, %tx_is_time, !dbg !5877
  br i1 %_907, label %bb376, label %bb377, !dbg !5877

bb374:                                            ; preds = %bb966
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5879, !noalias !5901
  %595 = call noundef dereferenceable_or_null(13) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 13, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5904, !noalias !5901
  %596 = icmp eq ptr %595, null, !dbg !5909
  br i1 %596, label %bb971, label %bb972, !dbg !5910

bb377:                                            ; preds = %bb375
  %tx_lock = zext i32 %594 to i64, !dbg !5871
  %_910 = icmp samesign ugt i64 %_2871, %tx_lock, !dbg !5911
  br i1 %_910, label %bb378, label %bb379, !dbg !5911

bb376:                                            ; preds = %bb375
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5912, !noalias !5934
  %597 = call noundef dereferenceable_or_null(9) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 9, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5937, !noalias !5934
  %598 = icmp eq ptr %597, null, !dbg !5942
  br i1 %598, label %bb979, label %bb980, !dbg !5943

bb379:                                            ; preds = %bb377
  %_914 = load i64, ptr %45, align 8, !dbg !5944, !noundef !13
  %599 = getelementptr inbounds nuw i8, ptr %_956, i64 16, !dbg !5945
  %_2938 = load i64, ptr %599, align 8, !dbg !5945, !noundef !13
  %_2940 = icmp ult i64 %_914, %_2938, !dbg !5954
  br i1 %_2940, label %bb986, label %panic243, !dbg !5954

bb378:                                            ; preds = %bb377
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !5960, !noalias !5982
  %600 = call noundef dereferenceable_or_null(4) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 4, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !5985, !noalias !5982
  %601 = icmp eq ptr %600, null, !dbg !5990
  br i1 %601, label %bb984, label %bb985, !dbg !5991

bb986:                                            ; preds = %bb379
  %602 = getelementptr inbounds nuw i8, ptr %_956, i64 8, !dbg !5992
  %_2939 = load ptr, ptr %602, align 8, !dbg !5992, !nonnull !13, !noundef !13
  %_913 = getelementptr inbounds nuw %"bitcoin::blockdata::transaction::TxIn", ptr %_2939, i64 %_914, !dbg !6005
  %603 = getelementptr inbounds nuw i8, ptr %_913, i64 100, !dbg !6006
  %_2941 = load i32, ptr %603, align 4, !dbg !6006, !noundef !13
  %604 = icmp eq i32 %_2941, -1, !dbg !6020
  br i1 %604, label %bb380, label %bb394, !dbg !6020

panic243:                                         ; preds = %bb379
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_914, i64 noundef %_2938, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_19d013f3a919f93ece092868f0eff1de) #15, !dbg !5954
  unreachable, !dbg !5954

bb380:                                            ; preds = %bb986
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !6021, !noalias !6043
  %605 = call noundef dereferenceable_or_null(19) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 19, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !6046, !noalias !6043
  %606 = icmp eq ptr %605, null, !dbg !6051
  br i1 %606, label %bb990, label %bb991, !dbg !6052

bb990:                                            ; preds = %bb380
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 19) #17, !dbg !6053
  unreachable, !dbg !6053

bb991:                                            ; preds = %bb380
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(19) %605, ptr noundef nonnull align 1 dereferenceable(19) @alloc_a562a5f2e4413e2438e7655a709b4d07, i64 19, i1 false), !dbg !6055
  store i64 19, ptr %_0, align 8, !dbg !6061
  %_915.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6061
  store ptr %605, ptr %_915.sroa.4.0._0.sroa_idx, align 8, !dbg !6061
  %_915.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6061
  store i64 19, ptr %_915.sroa.5.0._0.sroa_idx, align 8, !dbg !6061
  br label %bb443, !dbg !6062

bb984:                                            ; preds = %bb378
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 4) #17, !dbg !6064
  unreachable, !dbg !6064

bb985:                                            ; preds = %bb378
  store i32 1448365123, ptr %600, align 1, !dbg !6066
  store i64 4, ptr %_0, align 8, !dbg !6072
  %_911.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6072
  store ptr %600, ptr %_911.sroa.4.0._0.sroa_idx, align 8, !dbg !6072
  %_911.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6072
  store i64 4, ptr %_911.sroa.5.0._0.sroa_idx, align 8, !dbg !6072
  br label %bb443, !dbg !6062

bb979:                                            ; preds = %bb376
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 9) #17, !dbg !6073
  unreachable, !dbg !6073

bb980:                                            ; preds = %bb376
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(9) %597, ptr noundef nonnull align 1 dereferenceable(9) @alloc_fc99526dd087ba82588f50a651d3cd28, i64 9, i1 false), !dbg !6075
  store i64 9, ptr %_0, align 8, !dbg !6081
  %_908.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6081
  store ptr %597, ptr %_908.sroa.4.0._0.sroa_idx, align 8, !dbg !6081
  %_908.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6081
  store i64 9, ptr %_908.sroa.5.0._0.sroa_idx, align 8, !dbg !6081
  br label %bb443, !dbg !6062

bb971:                                            ; preds = %bb374
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 13) #17, !dbg !6082
  unreachable, !dbg !6082

bb972:                                            ; preds = %bb374
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(13) %595, ptr noundef nonnull align 1 dereferenceable(13) @alloc_bbfddc5812f83af444aa1059f17430fb, i64 13, i1 false), !dbg !6084
  store i64 13, ptr %_0, align 8, !dbg !6090
  %_900.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6090
  store ptr %595, ptr %_900.sroa.4.0._0.sroa_idx, align 8, !dbg !6090
  %_900.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6090
  store i64 13, ptr %_900.sroa.5.0._0.sroa_idx, align 8, !dbg !6090
  br label %bb443, !dbg !6091

bb382:                                            ; preds = %bb101
  call void @llvm.lifetime.start.p0(ptr nonnull %_919), !dbg !6093
  %_2963 = load i64, ptr %39, align 8, !dbg !6094, !noundef !13
  call fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr noalias noundef align 8 captures(none) dereferenceable(24) %_919, i64 noundef %_2963, i64 noundef 1) #16, !dbg !6093
  %607 = load i64, ptr %_919, align 8, !dbg !6098, !range !1747, !noundef !13
  %.not322 = icmp eq i64 %607, -9223372036854775797, !dbg !6098
  br i1 %.not322, label %bb993, label %bb992, !dbg !6099

bb992:                                            ; preds = %bb382
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_919, i64 24, i1 false), !dbg !6100
  call void @llvm.lifetime.end.p0(ptr nonnull %_919), !dbg !6101
  br label %bb443, !dbg !1706

bb993:                                            ; preds = %bb382
  call void @llvm.lifetime.end.p0(ptr nonnull %_919), !dbg !6101
  call void @llvm.lifetime.start.p0(ptr nonnull %_923), !dbg !6102
  %_2970 = load i64, ptr %39, align 8, !dbg !6103, !noundef !13
  %_2975.not = icmp eq i64 %_2970, 0, !dbg !6107
  br i1 %_2975.not, label %bb995, label %bb994, !dbg !6107, !prof !1627

bb995:                                            ; preds = %bb993
  call void @_RNvNtCsgEmfK2I1SDS_4core6option13unwrap_failed(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_cc4a58c6e661e532d59f57cfe6103566) #15, !dbg !6110
  unreachable, !dbg !6110

bb994:                                            ; preds = %bb993
  %_2971 = load ptr, ptr %40, align 8, !dbg !6112, !nonnull !13, !noundef !13
  %608 = getelementptr %"alloc::vec::Vec<u8>", ptr %_2971, i64 %_2970, !dbg !6121
  %609 = getelementptr i8, ptr %608, i64 -16, !dbg !6122
  %_2981 = load ptr, ptr %609, align 8, !dbg !6122, !nonnull !13, !noundef !13
  %610 = getelementptr i8, ptr %608, i64 -8, !dbg !6134
  %_2980 = load i64, ptr %610, align 8, !dbg !6134, !noundef !13
  call void @_ZN19rbitcoin_primitives9scriptnum22scriptnum_decode_width17h06c01f6519d03db8E(ptr noalias noundef nonnull sret([16 x i8]) align 8 captures(none) dereferenceable(16) %_923, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) %_2981, i64 noundef %_2980, i64 noundef 5, i1 noundef zeroext %rm) #16, !dbg !6102
  %611 = load i8, ptr %_923, align 8, !dbg !6135, !range !144, !noundef !13
  %612 = trunc nuw i8 %611 to i1, !dbg !6135
  br i1 %612, label %bb996, label %bb997, !dbg !6136

bb996:                                            ; preds = %bb994
  %613 = getelementptr inbounds nuw i8, ptr %_923, i64 1, !dbg !6137
  %614 = load i8, ptr %613, align 1, !dbg !6137, !range !144, !noundef !13
  %_2984 = trunc nuw i8 %614 to i1, !dbg !6137
  call void @llvm.lifetime.end.p0(ptr nonnull %_923), !dbg !6138
  call void @llvm.lifetime.start.p0(ptr nonnull %_2988), !dbg !6139
  call void @"_ZN135_$LT$rbitcoin_consensus..error..ConsensusError$u20$as$u20$core..convert..From$LT$rbitcoin_primitives..scriptnum..ScriptNumError$GT$$GT$4from17h560bc9a4e4f929f2E"(ptr noalias noundef nonnull sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_2988, i1 noundef zeroext %_2984) #16, !dbg !6139
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_2988, i64 24, i1 false), !dbg !6145
  call void @llvm.lifetime.end.p0(ptr nonnull %_2988), !dbg !6146
  br label %bb443, !dbg !1706

bb997:                                            ; preds = %bb994
  %_2983 = load i64, ptr %43, align 8, !dbg !6147, !noundef !13
  call void @llvm.lifetime.end.p0(ptr nonnull %_923), !dbg !6138
  %_929 = icmp slt i64 %_2983, 0, !dbg !6148
  br i1 %_929, label %bb385, label %bb386, !dbg !6148

bb386:                                            ; preds = %bb997
  %_933 = trunc i64 %_2983 to i32, !dbg !6150
  %615 = icmp sgt i32 %_933, -1, !dbg !6150
  br i1 %615, label %bb388, label %bb398, !dbg !6150

bb385:                                            ; preds = %bb997
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !6151, !noalias !6173
  %616 = call noundef dereferenceable_or_null(12) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 12, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !6176, !noalias !6173
  %617 = icmp eq ptr %616, null, !dbg !6181
  br i1 %617, label %bb1002, label %bb1003, !dbg !6182

bb388:                                            ; preds = %bb386
  %_958 = load ptr, ptr %44, align 8, !dbg !6183, !nonnull !13, !align !5872, !noundef !13
  %618 = getelementptr inbounds nuw i8, ptr %_958, i64 56, !dbg !6183
  %_936 = load i32, ptr %618, align 8, !dbg !6183, !noundef !13
  %_934 = icmp ult i32 %_936, 2, !dbg !6184
  br i1 %_934, label %bb389, label %bb390, !dbg !6184

bb390:                                            ; preds = %bb388
  %_941 = load i64, ptr %45, align 8, !dbg !6185, !noundef !13
  %619 = getelementptr inbounds nuw i8, ptr %_958, i64 16, !dbg !6186
  %_3030 = load i64, ptr %619, align 8, !dbg !6186, !noundef !13
  %_3032 = icmp ult i64 %_941, %_3030, !dbg !6192
  br i1 %_3032, label %bb1009, label %panic245, !dbg !6192

bb389:                                            ; preds = %bb388
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !6196, !noalias !6218
  %620 = call noundef dereferenceable_or_null(11) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 11, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !6221, !noalias !6218
  %621 = icmp eq ptr %620, null, !dbg !6226
  br i1 %621, label %bb1007, label %bb1008, !dbg !6227

bb1009:                                           ; preds = %bb390
  %622 = getelementptr inbounds nuw i8, ptr %_958, i64 8, !dbg !6228
  %_3031 = load ptr, ptr %622, align 8, !dbg !6228, !nonnull !13, !noundef !13
  %_940 = getelementptr inbounds nuw %"bitcoin::blockdata::transaction::TxIn", ptr %_3031, i64 %_941, !dbg !6237
  %623 = getelementptr inbounds nuw i8, ptr %_940, i64 100, !dbg !6238
  %seq = load i32, ptr %623, align 4, !dbg !6238, !noundef !13
  %624 = icmp sgt i32 %seq, -1, !dbg !6239
  br i1 %624, label %bb2.i1180, label %bb393, !dbg !6239

bb2.i1180:                                        ; preds = %bb1009
  %_7.i1181 = xor i32 %seq, %_933, !dbg !6244
  %_6.i1182 = and i32 %_7.i1181, 4194304, !dbg !6244
  %625 = icmp eq i32 %_6.i1182, 0, !dbg !6244
  br i1 %625, label %_ZN18rbitcoin_consensus6script11interpreter15sequence_csv_ok17h5764dc0d818dfb98E.exit, label %bb393, !dbg !6244

_ZN18rbitcoin_consensus6script11interpreter15sequence_csv_ok17h5764dc0d818dfb98E.exit: ; preds = %bb2.i1180
  %_8.i1184 = and i32 %_933, 65535, !dbg !6250
  %_9.i1185 = and i32 %seq, 65535, !dbg !6251
  %.not1725 = icmp samesign ugt i32 %_8.i1184, %_9.i1185, !dbg !6250
  br i1 %.not1725, label %bb393, label %bb394, !dbg !6252

panic245:                                         ; preds = %bb390
  call void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef %_941, i64 noundef %_3030, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_67582fafe2d63da76bfb1f7a3c421bad) #15, !dbg !6192
  unreachable, !dbg !6192

bb393:                                            ; preds = %_ZN18rbitcoin_consensus6script11interpreter15sequence_csv_ok17h5764dc0d818dfb98E.exit, %bb2.i1180, %bb1009
  call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #16, !dbg !6253, !noalias !6275
  %626 = call noundef dereferenceable_or_null(3) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef 3, i64 noundef range(i64 1, -9223372036854775807) 1) #16, !dbg !6278, !noalias !6275
  %627 = icmp eq ptr %626, null, !dbg !6283
  br i1 %627, label %bb1013, label %bb1014, !dbg !6284

bb1013:                                           ; preds = %bb393
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 3) #17, !dbg !6285
  unreachable, !dbg !6285

bb1014:                                           ; preds = %bb393
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(3) %626, ptr noundef nonnull align 1 dereferenceable(3) @alloc_925914e8e9780efb09322acfc270e443, i64 3, i1 false), !dbg !6287
  store i64 3, ptr %_0, align 8, !dbg !6293
  %_943.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6293
  store ptr %626, ptr %_943.sroa.4.0._0.sroa_idx, align 8, !dbg !6293
  %_943.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6293
  store i64 3, ptr %_943.sroa.5.0._0.sroa_idx, align 8, !dbg !6293
  br label %bb443, !dbg !6294

bb1007:                                           ; preds = %bb389
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 11) #17, !dbg !6296
  unreachable, !dbg !6296

bb1008:                                           ; preds = %bb389
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(11) %620, ptr noundef nonnull align 1 dereferenceable(11) @alloc_6476b7d94dcf327b4611985ef2e36bf8, i64 11, i1 false), !dbg !6298
  store i64 11, ptr %_0, align 8, !dbg !6304
  %_937.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6304
  store ptr %620, ptr %_937.sroa.4.0._0.sroa_idx, align 8, !dbg !6304
  %_937.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6304
  store i64 11, ptr %_937.sroa.5.0._0.sroa_idx, align 8, !dbg !6304
  br label %bb443, !dbg !6294

bb1002:                                           ; preds = %bb385
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 12) #17, !dbg !6305
  unreachable, !dbg !6305

bb1003:                                           ; preds = %bb385
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(12) %616, ptr noundef nonnull align 1 dereferenceable(12) @alloc_532002b94befc8a9d927779d10100e7e, i64 12, i1 false), !dbg !6307
  store i64 12, ptr %_0, align 8, !dbg !6313
  %_930.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6313
  store ptr %616, ptr %_930.sroa.4.0._0.sroa_idx, align 8, !dbg !6313
  %_930.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6313
  store i64 12, ptr %_930.sroa.5.0._0.sroa_idx, align 8, !dbg !6313
  br label %bb443, !dbg !6294

bb587:                                            ; preds = %bb160
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %_144, i64 24, i1 false), !dbg !6314
  call void @llvm.lifetime.end.p0(ptr nonnull %_144), !dbg !6315
  br label %bb443, !dbg !1706

bb588:                                            ; preds = %bb160
  call void @llvm.lifetime.end.p0(ptr nonnull %_144), !dbg !6315
  br label %bb394, !dbg !6316

bb538:                                            ; preds = %bb49
  call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 8) #17, !dbg !6317
  unreachable, !dbg !6317

bb539:                                            ; preds = %bb49
  store i64 8389772277102702703, ptr %161, align 1, !dbg !6319
  store i64 8, ptr %_0, align 8, !dbg !6325
  %_74.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6325
  store ptr %161, ptr %_74.sroa.4.0._0.sroa_idx, align 8, !dbg !6325
  %_74.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6325
  store i64 8, ptr %_74.sroa.5.0._0.sroa_idx, align 8, !dbg !6325
  br label %bb443, !dbg !1013

bb445:                                            ; preds = %bb443, %bb519, %bb533, %bb527, %"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17h0dacae20f2481f43E.exit"
  call void @llvm.lifetime.end.p0(ptr nonnull %_40), !dbg !378
  call void @llvm.lifetime.end.p0(ptr nonnull %iter1), !dbg !379
  br label %bb446, !dbg !501

bb508:                                            ; preds = %bb18
  tail call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 16) #17, !dbg !6326
  unreachable, !dbg !6326

bb509:                                            ; preds = %bb18
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(16) %33, ptr noundef nonnull align 1 dereferenceable(16) @alloc_dcc8064e61d6be54ea73841fdb88c03e, i64 16, i1 false), !dbg !6328
  store i64 16, ptr %_0, align 8, !dbg !6334
  %_25.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6334
  store ptr %33, ptr %_25.sroa.4.0._0.sroa_idx, align 8, !dbg !6334
  %_25.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6334
  store i64 16, ptr %_25.sroa.5.0._0.sroa_idx, align 8, !dbg !6334
  br label %bb449, !dbg !119

bb495:                                            ; preds = %bb9
  tail call void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef 1, i64 10) #17, !dbg !6335
  unreachable, !dbg !6335

bb496:                                            ; preds = %bb9
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 1 dereferenceable(10) %26, ptr noundef nonnull align 1 dereferenceable(10) @alloc_369ee17d61227813032237a0166bc7fe, i64 10, i1 false), !dbg !6337
  store i64 10, ptr %_0, align 8, !dbg !6341
  %_12.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8, !dbg !6341
  store ptr %26, ptr %_12.sroa.4.0._0.sroa_idx, align 8, !dbg !6341
  %_12.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16, !dbg !6341
  store i64 10, ptr %_12.sroa.5.0._0.sroa_idx, align 8, !dbg !6341
  br label %bb449, !dbg !119
}

; Function Attrs: inlinehint nounwind nonlazybind uwtable
declare hidden fastcc void @"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17heb075e8674a2226aE"(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24)) unnamed_addr #0

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter11op_checksig17h9fc43a5a76d407e8E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), ptr noundef nonnull align 8, i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter14op_checksigadd17h58d983ce716c8d23E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), ptr noundef nonnull align 8 captures(none)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter16op_checkmultisig17h93c6fdf44d13f186E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), ptr noundef nonnull align 8, i1 noundef zeroext, ptr noalias noundef nonnull align 8 captures(none) dereferenceable(8), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(32), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), ptr dead_on_return noalias noundef nonnull readonly align 8 captures(none) dereferenceable(24)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h2f973f8e0b9535c3E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h4011a77626a82398E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h553f7ce6705c6daaE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17h90c71f3b60f04393E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17ha2aa4046e5746b0aE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter7bin_cmp17hf6aeffa5975d17bcE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter9bin_arith17h413fa78bc0791c0dE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter9bin_arith17hd7711d4ba5bd900eE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script11interpreter9require_n17hbcc66569d6d3f2a9E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), i64 noundef range(i64 0, 384307168202282326), i64 noundef range(i64 1, 7)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script6crypto4sha117h43ec7d90f07f0c1cE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 1 captures(none) dereferenceable(20), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script6crypto6sha25617h5457b5a3ce962158E(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 1 captures(none) dereferenceable(32), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @_ZN18rbitcoin_consensus6script6crypto7hash16017hd4348c3b7381f5ddE(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 1 captures(none) dereferenceable(20), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @"_ZN5alloc3vec16Vec$LT$T$C$A$GT$6remove17h5557be3c5b5ee181E"(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr noalias noundef nonnull align 8 captures(none) dereferenceable(24), i64 noundef range(i64 -384307168202282324, 384307168202282325)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare hidden fastcc void @"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17hb1b34ee757dcdfc4E"(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24), ptr readonly captures(address_is_null), i64) unnamed_addr #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #4

; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr allocptr noundef captures(address), i64 noundef, i64 noundef range(i64 1, -9223372036854775807)) unnamed_addr #5

; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #1

; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #6

; Function Attrs: nounwind nonlazybind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #1

; Function Attrs: cold minsize noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCslNYArtu3iFV_5alloc5alloc18handle_alloc_error(i64 noundef range(i64 1, -9223372036854775807), i64 noundef) unnamed_addr #7

; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCsgEmfK2I1SDS_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #8

; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXse_NtNtCsgEmfK2I1SDS_4core3fmt3numhNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 1 captures(address, read_provenance) dereferenceable(1), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.uadd.sat.i64(i64, i64) #9

; Function Attrs: cold minsize noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCslNYArtu3iFV_5alloc7raw_vec12handle_error(i64 noundef range(i64 0, -9223372036854775807), i64) unnamed_addr #7

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.uadd.sat.i32(i32, i32) #9

; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCsgEmfK2I1SDS_4core6option13unwrap_failed(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; Function Attrs: nounwind nonlazybind uwtable
declare void @"_ZN118_$LT$bitcoin..blockdata..script..instruction..InstructionIndices$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17h6d281e0b32b4cb98E"(ptr dead_on_unwind noalias noundef writable sret([40 x i8]) align 8 captures(address) dereferenceable(40), ptr noalias noundef align 8 dereferenceable(32)) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @_ZN19rbitcoin_primitives9scriptnum16scriptnum_encode17hcba9f699fc6b955fE(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24), i64 noundef) unnamed_addr #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.sadd.sat.i64(i64, i64) #9

; Function Attrs: nounwind nonlazybind uwtable
declare void @_ZN19rbitcoin_primitives9scriptnum22scriptnum_decode_width17h06c01f6519d03db8E(ptr dead_on_unwind noalias noundef writable sret([16 x i8]) align 8 captures(none) dereferenceable(16), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef range(i64 0, -9223372036854775808), i64 noundef, i1 noundef zeroext) unnamed_addr #1

; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvNvNtCslNYArtu3iFV_5alloc3fmt6format12format_inner(ptr dead_on_unwind noalias noundef writable sret([24 x i8]) align 8 captures(none) dereferenceable(24), ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #1

; Function Attrs: noinline nounwind nonlazybind uwtable
declare void @_RNvMs3_NtCslNYArtu3iFV_5alloc7raw_vecINtB5_6RawVecINtNtB7_3vec3VechEE8grow_oneCsjrHSEGnQ3l9_3std(ptr noalias noundef align 8 dereferenceable(16)) unnamed_addr #11

; Function Attrs: nocallback nofree nounwind nonlazybind willreturn memory(argmem: read)
declare i32 @bcmp(ptr captures(none), ptr captures(none), i64) local_unnamed_addr #12

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #13

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smin.i64(i64, i64) #9

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.smax.i64(i64, i64) #9

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.abs.i64(i64, i1 immarg) #14

attributes #0 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #1 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #6 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #7 = { cold minsize noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #8 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #9 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #10 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #11 = { noinline nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="x86-64" }
attributes #12 = { nocallback nofree nounwind nonlazybind willreturn memory(argmem: read) }
attributes #13 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #14 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #15 = { noinline noreturn nounwind }
attributes #16 = { nounwind }
attributes #17 = { noreturn nounwind }
attributes #18 = { noinline nounwind }
attributes #19 = { inlinehint nounwind }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}
!llvm.dbg.cu = !{!5}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 2, !"RtLibUseGOT", i32 1}
!2 = !{i32 7, !"Dwarf Version", i32 4}
!3 = !{i32 2, !"Debug Info Version", i32 3}
!4 = !{!"rustc version 1.95.0 (59807616e 2026-04-14)"}
!5 = distinct !DICompileUnit(language: DW_LANG_Rust, file: !6, producer: "clang LLVM (rustc version 1.95.0 (59807616e 2026-04-14))", isOptimized: true, runtimeVersion: 0, emissionKind: FullDebug, splitDebugInlining: false, nameTableKind: None)
!6 = !DIFile(filename: "crates/rbitcoin-consensus/src/lib.rs/@/rbitcoin_consensus.feaf38542b4ff5dd-cgu.0", directory: "/tmp/opencode/equiv-work/rbitcoin")
!7 = distinct !DISubprogram(name: "eval_script", linkageName: "_ZN18rbitcoin_consensus6script11interpreter11eval_script17h9bf99c7ab3467ea9E", scope: !9, file: !8, line: 453, type: !12, scopeLine: 453, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!8 = !DIFile(filename: "crates/rbitcoin-consensus/src/script/interpreter.rs", directory: "/tmp/opencode/equiv-work/rbitcoin", checksumkind: CSK_MD5, checksum: "43ff25281d01a03a992b7854e2465ace")
!9 = !DINamespace(name: "interpreter", scope: !10)
!10 = !DINamespace(name: "script", scope: !11)
!11 = !DINamespace(name: "rbitcoin_consensus", scope: null)
!12 = !DISubroutineType(types: !13)
!13 = !{}
!14 = !DILocation(line: 461, column: 8, scope: !15)
!15 = distinct !DILexicalBlock(scope: !7, file: !8, line: 458, column: 5)
!16 = !{i8 0, i8 3}
!17 = !DILocation(line: 43, column: 30, scope: !18, inlinedAt: !22)
!18 = distinct !DILexicalBlock(scope: !19, file: !8, line: 43, column: 30)
!19 = distinct !DILexicalBlock(scope: !20, file: !8, line: 43, column: 30)
!20 = distinct !DISubprogram(name: "eq", linkageName: "_ZN92_$LT$rbitcoin_consensus..script..interpreter..SigVersion$u20$as$u20$core..cmp..PartialEq$GT$2eq17h941d57d5d9dbbbeeE", scope: !21, file: !8, line: 43, type: !12, scopeLine: 43, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!21 = !DINamespace(name: "{impl#8}", scope: !9)
!22 = distinct !DILocation(line: 461, column: 8, scope: !15)
!23 = !{!24}
!24 = distinct !{!24, !25, !"_ZN18rbitcoin_consensus6script11interpreter24tapscript_has_op_success17h907064c9111a2352E: %script.0"}
!25 = distinct !{!25, !"_ZN18rbitcoin_consensus6script11interpreter24tapscript_has_op_success17h907064c9111a2352E"}
!26 = !DILocation(line: 461, column: 52, scope: !15)
!27 = !DILocation(line: 120, column: 11, scope: !28, inlinedAt: !31)
!28 = distinct !DILexicalBlock(scope: !29, file: !8, line: 119, column: 5)
!29 = distinct !DILexicalBlock(scope: !30, file: !8, line: 118, column: 5)
!30 = distinct !DISubprogram(name: "tapscript_has_op_success", linkageName: "_ZN18rbitcoin_consensus6script11interpreter24tapscript_has_op_success17h907064c9111a2352E", scope: !9, file: !8, line: 117, type: !12, scopeLine: 117, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!31 = distinct !DILocation(line: 461, column: 52, scope: !15)
!32 = !DILocation(line: 121, column: 18, scope: !28, inlinedAt: !31)
!33 = !DILocation(line: 1918, column: 50, scope: !34, inlinedAt: !40)
!34 = distinct !DISubprogram(name: "le", linkageName: "_RNvXsW_NtNtCsgEmfK2I1SDS_4core3cmp5implshNtB7_10PartialOrd2le", scope: !36, file: !35, line: 1918, type: !12, scopeLine: 1918, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!35 = !DIFile(filename: "library/core/src/cmp.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "9b875f3ee90b4abbf50efdba3db39504")
!36 = !DINamespace(name: "{impl#60}", scope: !37)
!37 = !DINamespace(name: "impls", scope: !38)
!38 = !DINamespace(name: "cmp", scope: !39)
!39 = !DINamespace(name: "core", scope: null)
!40 = distinct !DILocation(line: 2146, column: 13, scope: !41, inlinedAt: !43)
!41 = distinct !DISubprogram(name: "le<u8, u8>", linkageName: "_ZN4core3cmp5impls70_$LT$impl$u20$core..cmp..PartialOrd$LT$$RF$B$GT$$u20$for$u20$$RF$A$GT$2le17h71ba750b7164a7caE", scope: !42, file: !35, line: 2145, type: !12, scopeLine: 2145, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!42 = !DINamespace(name: "{impl#10}", scope: !37)
!43 = distinct !DILocation(line: 874, column: 32, scope: !44, inlinedAt: !50)
!44 = distinct !DILexicalBlock(scope: !46, file: !45, line: 874, column: 13)
!45 = !DIFile(filename: "library/core/src/ops/range.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "aa9e58e587ecf6fc84aabc8815f8ac79")
!46 = distinct !DISubprogram(name: "contains<core::ops::range::RangeInclusive<u8>, u8, u8>", linkageName: "_ZN4core3ops5range11RangeBounds8contains17h01e927bf53f01bd6E", scope: !47, file: !45, line: 868, type: !12, scopeLine: 868, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!47 = !DINamespace(name: "RangeBounds", scope: !48)
!48 = !DINamespace(name: "range", scope: !49)
!49 = !DINamespace(name: "ops", scope: !39)
!50 = distinct !DILocation(line: 527, column: 9, scope: !51, inlinedAt: !53)
!51 = distinct !DISubprogram(name: "contains<u8, u8>", linkageName: "_ZN4core3ops5range25RangeInclusive$LT$Idx$GT$8contains17h19b0330085d584e4E", scope: !52, file: !45, line: 522, type: !12, scopeLine: 522, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!52 = !DINamespace(name: "RangeInclusive", scope: !48)
!53 = distinct !DILocation(line: 122, column: 21, scope: !54, inlinedAt: !31)
!54 = distinct !DILexicalBlock(scope: !28, file: !8, line: 121, column: 9)
!55 = !DILocation(line: 873, column: 9, scope: !46, inlinedAt: !50)
!56 = !DILocation(line: 1918, column: 50, scope: !34, inlinedAt: !57)
!57 = distinct !DILocation(line: 2146, column: 13, scope: !41, inlinedAt: !58)
!58 = distinct !DILocation(line: 878, column: 30, scope: !59, inlinedAt: !50)
!59 = distinct !DILexicalBlock(scope: !46, file: !45, line: 878, column: 13)
!60 = !DILocation(line: 122, column: 12, scope: !54, inlinedAt: !31)
!61 = !DILocation(line: 127, column: 9, scope: !54, inlinedAt: !31)
!62 = !DILocation(line: 123, column: 21, scope: !54, inlinedAt: !31)
!63 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !68)
!64 = distinct !DISubprogram(name: "saturating_add", linkageName: "_RNvMs9_NtCsgEmfK2I1SDS_4core3numj14saturating_add", scope: !66, file: !65, line: 2300, type: !12, scopeLine: 2300, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!65 = !DIFile(filename: "library/core/src/num/uint_macros.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "de2f29a3485fc28d710ba6c3062e6efa")
!66 = !DINamespace(name: "{impl#11}", scope: !67)
!67 = !DINamespace(name: "num", scope: !39)
!68 = distinct !DILocation(line: 124, column: 19, scope: !69, inlinedAt: !31)
!69 = distinct !DILexicalBlock(scope: !54, file: !8, line: 123, column: 13)
!70 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !71)
!71 = distinct !DILocation(line: 124, column: 37, scope: !69, inlinedAt: !31)
!72 = !DILocation(line: 0, scope: !73, inlinedAt: !31)
!73 = !DILexicalBlockFile(scope: !28, file: !74, discriminator: 0)
!74 = !DIFile(filename: "crates/rbitcoin-consensus/src/lib.rs", directory: "/tmp/opencode/equiv-work/rbitcoin", checksumkind: CSK_MD5, checksum: "62d5cb2f6f256a2657e8cca45e92f410")
!75 = !DILocation(line: 873, column: 9, scope: !46, inlinedAt: !76)
!76 = distinct !DILocation(line: 527, column: 9, scope: !77, inlinedAt: !78)
!77 = distinct !DISubprogram(name: "contains<u8, u8>", linkageName: "_ZN4core3ops5range25RangeInclusive$LT$Idx$GT$8contains17h19b0330085d584e4E", scope: !52, file: !45, line: 522, type: !12, scopeLine: 522, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!78 = distinct !DILocation(line: 113, column: 22, scope: !79, inlinedAt: !80)
!79 = distinct !DISubprogram(name: "is_op_success", linkageName: "_ZN18rbitcoin_consensus6script11interpreter13is_op_success17h5c7f8cd81ac30a2eE", scope: !9, file: !8, line: 92, type: !12, scopeLine: 92, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!80 = distinct !DILocation(line: 151, column: 20, scope: !54, inlinedAt: !31)
!81 = !DILocation(line: 151, column: 20, scope: !54, inlinedAt: !31)
!82 = !DILocation(line: 129, column: 20, scope: !54, inlinedAt: !31)
!83 = !DILocation(line: 136, column: 20, scope: !54, inlinedAt: !31)
!84 = !DILocation(line: 143, column: 20, scope: !54, inlinedAt: !31)
!85 = !DILocation(line: 132, column: 25, scope: !54, inlinedAt: !31)
!86 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !87)
!87 = distinct !DILocation(line: 133, column: 23, scope: !88, inlinedAt: !31)
!88 = distinct !DILexicalBlock(scope: !54, file: !8, line: 132, column: 17)
!89 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !90)
!90 = distinct !DILocation(line: 133, column: 41, scope: !88, inlinedAt: !31)
!91 = !DILocation(line: 134, column: 13, scope: !54, inlinedAt: !31)
!92 = !DILocation(line: 139, column: 51, scope: !54, inlinedAt: !31)
!93 = !DILocation(line: 139, column: 45, scope: !54, inlinedAt: !31)
!94 = !DILocation(line: 139, column: 59, scope: !54, inlinedAt: !31)
!95 = !DILocation(line: 139, column: 72, scope: !54, inlinedAt: !31)
!96 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !97)
!97 = distinct !DILocation(line: 140, column: 23, scope: !98, inlinedAt: !31)
!98 = distinct !DILexicalBlock(scope: !54, file: !8, line: 139, column: 17)
!99 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !100)
!100 = distinct !DILocation(line: 140, column: 41, scope: !98, inlinedAt: !31)
!101 = !DILocation(line: 141, column: 13, scope: !54, inlinedAt: !31)
!102 = !DILocation(line: 146, column: 51, scope: !54, inlinedAt: !31)
!103 = !DILocation(line: 146, column: 45, scope: !54, inlinedAt: !31)
!104 = !DILocation(line: 146, column: 65, scope: !54, inlinedAt: !31)
!105 = !DILocation(line: 146, column: 59, scope: !54, inlinedAt: !31)
!106 = !DILocation(line: 146, column: 79, scope: !54, inlinedAt: !31)
!107 = !DILocation(line: 146, column: 73, scope: !54, inlinedAt: !31)
!108 = !DILocation(line: 146, column: 87, scope: !54, inlinedAt: !31)
!109 = !DILocation(line: 146, column: 100, scope: !54, inlinedAt: !31)
!110 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !111)
!111 = distinct !DILocation(line: 148, column: 23, scope: !112, inlinedAt: !31)
!112 = distinct !DILexicalBlock(scope: !54, file: !8, line: 146, column: 17)
!113 = !DILocation(line: 2301, column: 13, scope: !64, inlinedAt: !114)
!114 = distinct !DILocation(line: 148, column: 41, scope: !112, inlinedAt: !31)
!115 = !DILocation(line: 149, column: 13, scope: !54, inlinedAt: !31)
!116 = !DILocation(line: 154, column: 17, scope: !54, inlinedAt: !31)
!117 = !DILocation(line: 150, column: 18, scope: !54, inlinedAt: !31)
!118 = !DILocation(line: 462, column: 16, scope: !15)
!119 = !DILocation(line: 0, scope: !120)
!120 = !DILexicalBlockFile(scope: !15, file: !74, discriminator: 0)
!121 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !127)
!122 = distinct !DISubprogram(name: "len<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$3len17he380850a57f8bd03E", scope: !124, file: !123, line: 2996, type: !12, scopeLine: 2996, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!123 = !DIFile(filename: "library/alloc/src/vec/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "561105229399139e451a3aa6309b761e")
!124 = !DINamespace(name: "Vec", scope: !125)
!125 = !DINamespace(name: "vec", scope: !126)
!126 = !DINamespace(name: "alloc", scope: null)
!127 = !DILocation(line: 465, column: 18, scope: !15)
!128 = !DILocation(line: 3002, column: 37, scope: !129, inlinedAt: !127)
!129 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!130 = !DILocation(line: 3002, column: 18, scope: !129, inlinedAt: !127)
!131 = !DILocation(line: 465, column: 12, scope: !15)
!132 = !DILocation(line: 475, column: 8, scope: !15)
!133 = !DILocation(line: 479, column: 9, scope: !15)
!134 = !DILocation(line: 464, column: 9, scope: !135, inlinedAt: !136)
!135 = distinct !DISubprogram(name: "new<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc3vec12Vec$LT$T$GT$3new17h7c25b1a51dd3f560E", scope: !124, file: !123, line: 463, type: !12, scopeLine: 463, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!136 = !DILocation(line: 479, column: 38, scope: !15)
!137 = !DILocation(line: 481, column: 9, scope: !138)
!138 = distinct !DILexicalBlock(scope: !139, file: !8, line: 480, column: 5)
!139 = distinct !DILexicalBlock(scope: !15, file: !8, line: 479, column: 5)
!140 = !DILocation(line: 481, column: 24, scope: !138)
!141 = !DILocation(line: 486, column: 13, scope: !142)
!142 = distinct !DILexicalBlock(scope: !143, file: !8, line: 482, column: 5)
!143 = distinct !DILexicalBlock(scope: !138, file: !8, line: 481, column: 5)
!144 = !{i8 0, i8 2}
!145 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !150)
!146 = distinct !DISubprogram(name: "non_null<alloc::alloc::Global, alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8non_null17h48f19a6fe835f1a8E", scope: !148, file: !147, line: 611, type: !12, scopeLine: 611, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!147 = !DIFile(filename: "library/alloc/src/raw_vec/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "78584250230dfe0aae92794a07566ae7")
!148 = !DINamespace(name: "RawVecInner", scope: !149)
!149 = !DINamespace(name: "raw_vec", scope: !126)
!150 = !DILocation(line: 607, column: 14, scope: !151, inlinedAt: !153)
!151 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 2)
!152 = distinct !DISubprogram(name: "ptr<alloc::alloc::Global, alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$3ptr17h14a549210941dc8aE", scope: !148, file: !147, line: 606, type: !12, scopeLine: 606, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!153 = !DILocation(line: 295, column: 20, scope: !154, inlinedAt: !157)
!154 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 2)
!155 = distinct !DISubprogram(name: "ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$3ptr17he48fe43939ce2533E", scope: !156, file: !147, line: 294, type: !12, scopeLine: 294, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!156 = !DINamespace(name: "RawVec", scope: !149)
!157 = !DILocation(line: 1916, column: 18, scope: !158, inlinedAt: !159)
!158 = distinct !DISubprogram(name: "as_ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$6as_ptr17he724f02ec7635c63E", scope: !124, file: !123, line: 1913, type: !12, scopeLine: 1913, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!159 = !DILocation(line: 1815, column: 76, scope: !160, inlinedAt: !161)
!160 = distinct !DISubprogram(name: "as_slice<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$8as_slice17he765cff926ff8ccbE", scope: !124, file: !123, line: 1798, type: !12, scopeLine: 1798, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!161 = !DILocation(line: 3729, column: 14, scope: !162, inlinedAt: !164)
!162 = distinct !DISubprogram(name: "deref<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN72_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..deref..Deref$GT$5deref17h21e567f10d6d1aceE", scope: !163, file: !123, line: 3728, type: !12, scopeLine: 3728, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!163 = !DINamespace(name: "{impl#9}", scope: !125)
!164 = !DILocation(line: 468, column: 21, scope: !15)
!165 = !DILocation(line: 961, column: 18, scope: !166, inlinedAt: !171)
!166 = distinct !DISubprogram(name: "add<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr7mut_ptr31_$LT$impl$u20$$BP$mut$u20$T$GT$3add17h23b68dca67d1e391E", scope: !168, file: !167, line: 927, type: !12, scopeLine: 927, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!167 = !DIFile(filename: "library/core/src/ptr/mut_ptr.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "7c03c8e0ae695174f7f10881dc49d2cb")
!168 = !DINamespace(name: "{impl#0}", scope: !169)
!169 = !DINamespace(name: "mut_ptr", scope: !170)
!170 = !DINamespace(name: "ptr", scope: !39)
!171 = !DILocation(line: 102, column: 78, scope: !172, inlinedAt: !179)
!172 = distinct !DILexicalBlock(scope: !174, file: !173, line: 98, column: 9)
!173 = !DIFile(filename: "library/core/src/slice/iter.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "f33ab2e22fe09095bf73c41c52bd166c")
!174 = distinct !DILexicalBlock(scope: !175, file: !173, line: 97, column: 9)
!175 = distinct !DISubprogram(name: "new<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core5slice4iter13Iter$LT$T$GT$3new17h9aa6c5f507b44a71E", scope: !176, file: !173, line: 96, type: !12, scopeLine: 96, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!176 = !DINamespace(name: "Iter", scope: !177)
!177 = !DINamespace(name: "iter", scope: !178)
!178 = !DINamespace(name: "slice", scope: !39)
!179 = !DILocation(line: 1041, column: 9, scope: !180, inlinedAt: !183)
!180 = distinct !DISubprogram(name: "iter<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$4iter17h5f3772b8780c0451E", scope: !182, file: !181, line: 1040, type: !12, scopeLine: 1040, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!181 = !DIFile(filename: "library/core/src/slice/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "b606e5d97bff599edd0dcbc6067a14f1")
!182 = !DINamespace(name: "{impl#0}", scope: !178)
!183 = !DILocation(line: 468, column: 27, scope: !15)
!184 = !DILocation(line: 1720, column: 9, scope: !185, inlinedAt: !189)
!185 = distinct !DISubprogram(name: "eq<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN78_$LT$core..ptr..non_null..NonNull$LT$T$GT$$u20$as$u20$core..cmp..PartialEq$GT$2eq17h16de4cc2c882f30eE", scope: !187, file: !186, line: 1719, type: !12, scopeLine: 1719, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!186 = !DIFile(filename: "library/core/src/ptr/non_null.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "e5222a5160165ba1cd09076ad7a11733")
!187 = !DINamespace(name: "{impl#16}", scope: !188)
!188 = !DINamespace(name: "non_null", scope: !170)
!189 = !DILocation(line: 180, column: 28, scope: !190, inlinedAt: !195)
!190 = distinct !DILexicalBlock(scope: !192, file: !191, line: 162, column: 17)
!191 = !DIFile(filename: "library/core/src/slice/iter/macros.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "87d1f0c2746f51593d75ddf4c9271f14")
!192 = distinct !DILexicalBlock(scope: !193, file: !191, line: 161, column: 17)
!193 = distinct !DISubprogram(name: "next<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17ha30c321a9b130631E", scope: !194, file: !191, line: 157, type: !12, scopeLine: 157, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!194 = !DINamespace(name: "{impl#171}", scope: !177)
!195 = !DILocation(line: 468, column: 21, scope: !196)
!196 = !DILexicalBlockFile(scope: !197, file: !8, discriminator: 4)
!197 = distinct !DILexicalBlock(scope: !15, file: !8, line: 468, column: 9)
!198 = !DILocation(line: 0, scope: !199, inlinedAt: !201)
!199 = distinct !DILexicalBlock(scope: !200, file: !147, line: 453, column: 9)
!200 = distinct !DISubprogram(name: "try_allocate_in<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E", scope: !148, file: !147, line: 445, type: !12, scopeLine: 445, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!201 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !203)
!202 = distinct !DISubprogram(name: "with_capacity_in<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17h4b7c5b0a570540dbE", scope: !148, file: !147, line: 432, type: !12, scopeLine: 432, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!203 = !DILocation(line: 177, column: 20, scope: !204, inlinedAt: !205)
!204 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$16with_capacity_in17h0bdfdcf1695b87b8E", scope: !156, file: !147, line: 175, type: !12, scopeLine: 175, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!205 = !DILocation(line: 965, column: 20, scope: !206, inlinedAt: !207)
!206 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$16with_capacity_in17h7bbe374ec8ebd6e6E", scope: !124, file: !123, line: 964, type: !12, scopeLine: 964, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!207 = !DILocation(line: 448, column: 29, scope: !208, inlinedAt: !215)
!208 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!209 = !DIFile(filename: "library/alloc/src/slice.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "c354101fc648df7ae7a06556360deeb9")
!210 = distinct !DISubprogram(name: "to_vec<u8, alloc::alloc::Global>", linkageName: "_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h40185a762448c357E", scope: !211, file: !209, line: 446, type: !12, scopeLine: 446, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!211 = !DINamespace(name: "{impl#1}", scope: !212)
!212 = !DINamespace(name: "to_vec_in", scope: !213)
!213 = !DINamespace(name: "{impl#0}", scope: !214)
!214 = !DINamespace(name: "slice", scope: !126)
!215 = !DILocation(line: 400, column: 16, scope: !216, inlinedAt: !217)
!216 = distinct !DISubprogram(name: "to_vec_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$9to_vec_in17ha67aa4274a1d15f1E", scope: !213, file: !209, line: 396, type: !12, scopeLine: 396, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!217 = !DILocation(line: 376, column: 14, scope: !218, inlinedAt: !219)
!218 = distinct !DISubprogram(name: "to_vec<u8>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$6to_vec17ha9badac3c2b4dfd0E", scope: !213, file: !209, line: 372, type: !12, scopeLine: 372, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!219 = !DILocation(line: 842, column: 14, scope: !220, inlinedAt: !222)
!220 = distinct !DISubprogram(name: "to_owned<u8>", linkageName: "_ZN5alloc5slice64_$LT$impl$u20$alloc..borrow..ToOwned$u20$for$u20$$u5b$T$u5d$$GT$8to_owned17hf38001dd71254299E", scope: !221, file: !209, line: 841, type: !12, scopeLine: 841, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!221 = !DINamespace(name: "{impl#9}", scope: !214)
!222 = !DILocation(line: 211, column: 62, scope: !223, inlinedAt: !227)
!223 = distinct !DISubprogram(name: "to_owned", linkageName: "_RNvXs2_NtCslNYArtu3iFV_5alloc3streNtNtB7_6borrow7ToOwned8to_owned", scope: !225, file: !224, line: 210, type: !12, scopeLine: 210, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!224 = !DIFile(filename: "library/alloc/src/str.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "df2687b23b15ff9362a5ffa3e0f54f56")
!225 = !DINamespace(name: "{impl#4}", scope: !226)
!226 = !DINamespace(name: "str", scope: !126)
!227 = !DILocation(line: 3114, column: 11, scope: !228, inlinedAt: !232)
!228 = distinct !DISubprogram(name: "from", linkageName: "_RNvXsK_NtCslNYArtu3iFV_5alloc6stringNtB5_6StringINtNtCsgEmfK2I1SDS_4core7convert4FromReE4from", scope: !230, file: !229, line: 3113, type: !12, scopeLine: 3113, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!229 = !DIFile(filename: "library/alloc/src/string.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "d83aa07ff14615d36cf46a54ac461721")
!230 = !DINamespace(name: "{impl#48}", scope: !231)
!231 = !DINamespace(name: "string", scope: !126)
!232 = !DILocation(line: 778, column: 9, scope: !233, inlinedAt: !237)
!233 = distinct !DISubprogram(name: "into<&str, alloc::string::String>", linkageName: "_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17hb6f00133dedb813aE", scope: !235, file: !234, line: 777, type: !12, scopeLine: 777, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!234 = !DIFile(filename: "library/core/src/convert/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "895b07ad419949eb0829369911de237b")
!235 = !DINamespace(name: "{impl#3}", scope: !236)
!236 = !DINamespace(name: "convert", scope: !39)
!237 = !DILocation(line: 466, column: 60, scope: !15)
!238 = !{!239}
!239 = distinct !{!239, !240, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!240 = distinct !{!240, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!241 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !245)
!242 = distinct !DISubprogram(name: "alloc", linkageName: "_RNvNtCslNYArtu3iFV_5alloc5alloc5alloc", scope: !244, file: !243, line: 89, type: !12, scopeLine: 89, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!243 = !DIFile(filename: "library/alloc/src/alloc.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "57066d22da38e4b1f3bfd29f3d5ff5ae")
!244 = !DINamespace(name: "alloc", scope: !126)
!245 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !249)
!246 = distinct !DILexicalBlock(scope: !247, file: !243, line: 189, column: 13)
!247 = distinct !DISubprogram(name: "alloc_impl_runtime", linkageName: "_RNvMNtCslNYArtu3iFV_5alloc5allocNtB2_6Global18alloc_impl_runtime", scope: !248, file: !243, line: 185, type: !12, scopeLine: 185, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!248 = !DINamespace(name: "Global", scope: !244)
!249 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !251)
!250 = distinct !DISubprogram(name: "alloc_impl", linkageName: "_RNvMNtCslNYArtu3iFV_5alloc5allocNtB2_6Global10alloc_impl", scope: !248, file: !243, line: 311, type: !12, scopeLine: 311, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!251 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !254)
!252 = distinct !DISubprogram(name: "allocate", linkageName: "_RNvXs_NtCslNYArtu3iFV_5alloc5allocNtB4_6GlobalNtNtCsgEmfK2I1SDS_4core5alloc9Allocator8allocate", scope: !253, file: !243, line: 428, type: !12, scopeLine: 428, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!253 = !DINamespace(name: "{impl#1}", scope: !244)
!254 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !201)
!255 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !201)
!256 = distinct !DILexicalBlock(scope: !199, file: !147, line: 463, column: 9)
!257 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !201)
!258 = !DILocation(line: 659, column: 28, scope: !259, inlinedAt: !261)
!259 = distinct !DISubprogram(name: "add<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr8non_null16NonNull$LT$T$GT$3add17h0537cb7c9af2adaaE", scope: !260, file: !186, line: 651, type: !12, scopeLine: 651, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!260 = !DINamespace(name: "NonNull", scope: !188)
!261 = !DILocation(line: 185, column: 40, scope: !190, inlinedAt: !195)
!262 = !DILocation(line: 2997, column: 19, scope: !263, inlinedAt: !264)
!263 = distinct !DISubprogram(name: "len<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$3len17h6dd8e00f79c9c186E", scope: !124, file: !123, line: 2996, type: !12, scopeLine: 2996, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!264 = !DILocation(line: 469, column: 21, scope: !265)
!265 = distinct !DILexicalBlock(scope: !197, file: !8, line: 468, column: 9)
!266 = !DILocation(line: 3002, column: 37, scope: !267, inlinedAt: !264)
!267 = distinct !DILexicalBlock(scope: !263, file: !123, line: 2997, column: 9)
!268 = !DILocation(line: 3002, column: 18, scope: !267, inlinedAt: !264)
!269 = !DILocation(line: 469, column: 16, scope: !265)
!270 = !DILocation(line: 0, scope: !199, inlinedAt: !271)
!271 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !272)
!272 = !DILocation(line: 177, column: 20, scope: !273, inlinedAt: !274)
!273 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 2)
!274 = !DILocation(line: 965, column: 20, scope: !275, inlinedAt: !276)
!275 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 2)
!276 = !DILocation(line: 448, column: 29, scope: !277, inlinedAt: !279)
!277 = !DILexicalBlockFile(scope: !278, file: !209, discriminator: 2)
!278 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!279 = !DILocation(line: 400, column: 16, scope: !280, inlinedAt: !281)
!280 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 2)
!281 = !DILocation(line: 376, column: 14, scope: !282, inlinedAt: !283)
!282 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 2)
!283 = !DILocation(line: 842, column: 14, scope: !284, inlinedAt: !285)
!284 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 2)
!285 = !DILocation(line: 211, column: 62, scope: !286, inlinedAt: !287)
!286 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 2)
!287 = !DILocation(line: 3114, column: 11, scope: !288, inlinedAt: !289)
!288 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 2)
!289 = !DILocation(line: 778, column: 9, scope: !290, inlinedAt: !291)
!290 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 2)
!291 = !DILocation(line: 470, column: 63, scope: !265)
!292 = !{!293}
!293 = distinct !{!293, !294, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!294 = distinct !{!294, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!295 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !296)
!296 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !297)
!297 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !298)
!298 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !299)
!299 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !271)
!300 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !271)
!301 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !271)
!302 = !DILocation(line: 441, column: 25, scope: !303, inlinedAt: !272)
!303 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!304 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !307)
!305 = distinct !DISubprogram(name: "copy_nonoverlapping<u8>", linkageName: "_ZN4core3ptr19copy_nonoverlapping17heb33bba51c9dc77cE", scope: !170, file: !306, line: 526, type: !12, scopeLine: 526, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!306 = !DIFile(filename: "library/core/src/ptr/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "8f706ae0a0620120e6e931983ef127f1")
!307 = !DILocation(line: 1252, column: 18, scope: !308, inlinedAt: !313)
!308 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 2)
!309 = !DIFile(filename: "library/core/src/ptr/const_ptr.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "48638a38fe414ca30cde797e4a40b3a9")
!310 = distinct !DISubprogram(name: "copy_to_nonoverlapping<u8>", linkageName: "_ZN4core3ptr9const_ptr33_$LT$impl$u20$$BP$const$u20$T$GT$22copy_to_nonoverlapping17h9f85b7ce45773255E", scope: !311, file: !309, line: 1247, type: !12, scopeLine: 1247, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!311 = !DINamespace(name: "{impl#0}", scope: !312)
!312 = !DINamespace(name: "const_ptr", scope: !170)
!313 = !DILocation(line: 454, column: 36, scope: !314, inlinedAt: !279)
!314 = !DILexicalBlockFile(scope: !315, file: !209, discriminator: 2)
!315 = distinct !DILexicalBlock(scope: !278, file: !209, line: 448, column: 17)
!316 = !DILocation(line: 470, column: 24, scope: !265)
!317 = !DILocation(line: 485, column: 22, scope: !142)
!318 = !DILocation(line: 0, scope: !199, inlinedAt: !319)
!319 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !320)
!320 = !DILocation(line: 177, column: 20, scope: !321, inlinedAt: !322)
!321 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 4)
!322 = !DILocation(line: 965, column: 20, scope: !323, inlinedAt: !324)
!323 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 4)
!324 = !DILocation(line: 448, column: 29, scope: !325, inlinedAt: !327)
!325 = !DILexicalBlockFile(scope: !326, file: !209, discriminator: 4)
!326 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!327 = !DILocation(line: 400, column: 16, scope: !328, inlinedAt: !329)
!328 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 4)
!329 = !DILocation(line: 376, column: 14, scope: !330, inlinedAt: !331)
!330 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 4)
!331 = !DILocation(line: 842, column: 14, scope: !332, inlinedAt: !333)
!332 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 4)
!333 = !DILocation(line: 211, column: 62, scope: !334, inlinedAt: !335)
!334 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 4)
!335 = !DILocation(line: 3114, column: 11, scope: !336, inlinedAt: !337)
!336 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 4)
!337 = !DILocation(line: 778, column: 9, scope: !338, inlinedAt: !339)
!338 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 4)
!339 = !DILocation(line: 476, column: 62, scope: !15)
!340 = !{!341}
!341 = distinct !{!341, !342, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!342 = distinct !{!342, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!343 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !344)
!344 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !345)
!345 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !346)
!346 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !347)
!347 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !319)
!348 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !319)
!349 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !319)
!350 = !DILocation(line: 0, scope: !142)
!351 = !DILocation(line: 961, column: 18, scope: !352, inlinedAt: !353)
!352 = distinct !DISubprogram(name: "add<u8>", linkageName: "_ZN4core3ptr7mut_ptr31_$LT$impl$u20$$BP$mut$u20$T$GT$3add17hbd4287e08d321749E", scope: !168, file: !167, line: 927, type: !12, scopeLine: 927, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!353 = !DILocation(line: 102, column: 78, scope: !354, inlinedAt: !358)
!354 = !DILexicalBlockFile(scope: !355, file: !173, discriminator: 2)
!355 = distinct !DILexicalBlock(scope: !356, file: !173, line: 98, column: 9)
!356 = distinct !DILexicalBlock(scope: !357, file: !173, line: 97, column: 9)
!357 = distinct !DISubprogram(name: "new<u8>", linkageName: "_ZN4core5slice4iter13Iter$LT$T$GT$3new17hb5a4526e1e8e77ddE", scope: !176, file: !173, line: 96, type: !12, scopeLine: 96, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!358 = !DILocation(line: 1041, column: 9, scope: !359, inlinedAt: !361)
!359 = !DILexicalBlockFile(scope: !360, file: !181, discriminator: 2)
!360 = distinct !DISubprogram(name: "iter<u8>", linkageName: "_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$4iter17h705c610fea66e56eE", scope: !182, file: !181, line: 1040, type: !12, scopeLine: 1040, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!361 = !DILocation(line: 551, column: 37, scope: !362, inlinedAt: !369)
!362 = distinct !DISubprogram(name: "instructions", linkageName: "_ZN7bitcoin9blockdata6script8borrowed6Script12instructions17h152d5ac5a4adcff3E", scope: !364, file: !363, line: 550, type: !12, scopeLine: 550, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!363 = !DIFile(filename: "src/blockdata/script/borrowed.rs", directory: "/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bitcoin-0.32.102", checksumkind: CSK_MD5, checksum: "6b454f554fd4c4087208ce56a34530e3")
!364 = !DINamespace(name: "Script", scope: !365)
!365 = !DINamespace(name: "borrowed", scope: !366)
!366 = !DINamespace(name: "script", scope: !367)
!367 = !DINamespace(name: "blockdata", scope: !368)
!368 = !DINamespace(name: "bitcoin", scope: null)
!369 = !DILocation(line: 572, column: 52, scope: !370, inlinedAt: !371)
!370 = distinct !DISubprogram(name: "instruction_indices", linkageName: "_ZN7bitcoin9blockdata6script8borrowed6Script19instruction_indices17h34391419ccb85513E", scope: !364, file: !363, line: 571, type: !12, scopeLine: 571, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!371 = !DILocation(line: 491, column: 24, scope: !372)
!372 = distinct !DILexicalBlock(scope: !373, file: !8, line: 488, column: 5)
!373 = distinct !DILexicalBlock(scope: !142, file: !8, line: 485, column: 5)
!374 = !DILocation(line: 491, column: 17, scope: !372)
!375 = !DILocation(line: 491, column: 17, scope: !376)
!376 = distinct !DILexicalBlock(scope: !372, file: !8, line: 491, column: 5)
!377 = !{i32 0, i32 7}
!378 = !DILocation(line: 926, column: 5, scope: !376)
!379 = !DILocation(line: 926, column: 5, scope: !372)
!380 = !DILocation(line: 928, column: 9, scope: !372)
!381 = !DILocation(line: 491, column: 9, scope: !376)
!382 = !DILocation(line: 966, column: 15, scope: !383, inlinedAt: !387)
!383 = distinct !DISubprogram(name: "map_err<(usize, bitcoin::blockdata::script::instruction::Instruction), bitcoin::blockdata::script::Error, rbitcoin_consensus::error::ConsensusError, rbitcoin_consensus::script::interpreter::eval_script::{closure_env#0}>", linkageName: "_ZN4core6result19Result$LT$T$C$E$GT$7map_err17haa70ce6deb53ebf2E", scope: !385, file: !384, line: 962, type: !12, scopeLine: 962, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!384 = !DIFile(filename: "library/core/src/result.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "7ebc974a4b69a504d7e902d792c422dd")
!385 = !DINamespace(name: "Result", scope: !386)
!386 = !DINamespace(name: "result", scope: !39)
!387 = !DILocation(line: 492, column: 38, scope: !388)
!388 = distinct !DILexicalBlock(scope: !376, file: !8, line: 491, column: 5)
!389 = !DILocation(line: 966, column: 9, scope: !383, inlinedAt: !387)
!390 = !DILocation(line: 418, column: 9, scope: !391, inlinedAt: !393)
!391 = distinct !DISubprogram(name: "is_empty", linkageName: "_ZN18rbitcoin_consensus6script11interpreter14ConditionStack8is_empty17h65a8c2cc352686d6E", scope: !392, file: !8, line: 417, type: !12, scopeLine: 417, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!392 = !DINamespace(name: "ConditionStack", scope: !9)
!393 = distinct !DILocation(line: 928, column: 20, scope: !372)
!394 = !DILocation(line: 0, scope: !199, inlinedAt: !395)
!395 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !396)
!396 = !DILocation(line: 177, column: 20, scope: !397, inlinedAt: !398)
!397 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 194)
!398 = !DILocation(line: 965, column: 20, scope: !399, inlinedAt: !400)
!399 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 194)
!400 = !DILocation(line: 448, column: 29, scope: !401, inlinedAt: !403)
!401 = !DILexicalBlockFile(scope: !402, file: !209, discriminator: 194)
!402 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!403 = !DILocation(line: 400, column: 16, scope: !404, inlinedAt: !405)
!404 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 194)
!405 = !DILocation(line: 376, column: 14, scope: !406, inlinedAt: !407)
!406 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 194)
!407 = !DILocation(line: 842, column: 14, scope: !408, inlinedAt: !409)
!408 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 54)
!409 = !DILocation(line: 211, column: 62, scope: !410, inlinedAt: !411)
!410 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 54)
!411 = !DILocation(line: 3114, column: 11, scope: !412, inlinedAt: !413)
!412 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 54)
!413 = !DILocation(line: 778, column: 9, scope: !414, inlinedAt: !415)
!414 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 54)
!415 = !DILocation(line: 929, column: 59, scope: !372)
!416 = !{!417}
!417 = distinct !{!417, !418, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!418 = distinct !{!418, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!419 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !420)
!420 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !421)
!421 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !422)
!422 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !423)
!423 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !395)
!424 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !395)
!425 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !395)
!426 = !DILocation(line: 931, column: 5, scope: !372)
!427 = !DILocation(line: 932, column: 1, scope: !138)
!428 = !{!429}
!429 = distinct !{!429, !430, !"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE: %_1"}
!430 = distinct !{!430, !"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE"}
!431 = !DILocation(line: 932, column: 1, scope: !15)
!432 = !DILocation(line: 805, column: 1, scope: !433, inlinedAt: !434)
!433 = distinct !DISubprogram(name: "drop_in_place<alloc::vec::Vec<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE", scope: !170, file: !306, line: 805, type: !12, scopeLine: 805, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!434 = distinct !DILocation(line: 932, column: 1, scope: !15)
!435 = !{!436}
!436 = distinct !{!436, !437, !"_ZN4core3ptr56drop_in_place$LT$$u5b$alloc..vec..Vec$LT$u8$GT$$u5d$$GT$17he49993fd321d5c98E: %_1.0"}
!437 = distinct !{!437, !"_ZN4core3ptr56drop_in_place$LT$$u5b$alloc..vec..Vec$LT$u8$GT$$u5d$$GT$17he49993fd321d5c98E"}
!438 = !DILocation(line: 4224, column: 13, scope: !439, inlinedAt: !441)
!439 = distinct !DISubprogram(name: "drop<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN70_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17hee5509643b7e31c2E", scope: !440, file: !123, line: 4219, type: !12, scopeLine: 4219, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!440 = !DINamespace(name: "{impl#26}", scope: !125)
!441 = distinct !DILocation(line: 805, column: 1, scope: !433, inlinedAt: !434)
!442 = !DILocation(line: 805, column: 1, scope: !443, inlinedAt: !444)
!443 = distinct !DISubprogram(name: "drop_in_place<[alloc::vec::Vec<u8, alloc::alloc::Global>]>", linkageName: "_ZN4core3ptr56drop_in_place$LT$$u5b$alloc..vec..Vec$LT$u8$GT$$u5d$$GT$17he49993fd321d5c98E", scope: !170, file: !306, line: 805, type: !12, scopeLine: 805, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!444 = distinct !DILocation(line: 4224, column: 13, scope: !439, inlinedAt: !441)
!445 = !{!446}
!446 = distinct !{!446, !447, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!447 = distinct !{!447, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!448 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !450)
!449 = distinct !DISubprogram(name: "drop_in_place<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E", scope: !170, file: !306, line: 805, type: !12, scopeLine: 805, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!450 = distinct !DILocation(line: 805, column: 1, scope: !443, inlinedAt: !444)
!451 = !{i64 0, i64 -9223372036854775808}
!452 = !{!446, !436}
!453 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !455)
!454 = distinct !DISubprogram(name: "current_memory<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$14current_memory17h288afaee937bcc02E", scope: !148, file: !147, line: 631, type: !12, scopeLine: 631, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!455 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !458)
!456 = distinct !DILexicalBlock(scope: !457, file: !147, line: 872, column: 82)
!457 = distinct !DISubprogram(name: "deallocate<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$10deallocate17h169db54ecf1c5236E", scope: !148, file: !147, line: 870, type: !12, scopeLine: 870, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!458 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !461)
!459 = distinct !DISubprogram(name: "drop<u8, alloc::alloc::Global>", linkageName: "_ZN77_$LT$alloc..raw_vec..RawVec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17h217b7970593b4626E", scope: !460, file: !147, line: 421, type: !12, scopeLine: 421, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!460 = !DINamespace(name: "{impl#3}", scope: !149)
!461 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !463)
!462 = distinct !DISubprogram(name: "drop_in_place<alloc::raw_vec::RawVec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr53drop_in_place$LT$alloc..raw_vec..RawVec$LT$u8$GT$$GT$17h4e9cb26778302473E", scope: !170, file: !306, line: 805, type: !12, scopeLine: 805, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!463 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !450)
!464 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !466)
!465 = distinct !DISubprogram(name: "dealloc", linkageName: "_RNvNtCslNYArtu3iFV_5alloc5alloc7dealloc", scope: !244, file: !243, line: 114, type: !12, scopeLine: 114, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!466 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !468)
!467 = distinct !DISubprogram(name: "deallocate_impl_runtime", linkageName: "_RNvMNtCslNYArtu3iFV_5alloc5allocNtB2_6Global23deallocate_impl_runtime", scope: !248, file: !243, line: 199, type: !12, scopeLine: 199, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!468 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !470)
!469 = distinct !DISubprogram(name: "deallocate_impl", linkageName: "_RNvMNtCslNYArtu3iFV_5alloc5allocNtB2_6Global15deallocate_impl", scope: !248, file: !243, line: 323, type: !12, scopeLine: 323, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!470 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !472)
!471 = distinct !DISubprogram(name: "deallocate", linkageName: "_RNvXs_NtCslNYArtu3iFV_5alloc5allocNtB4_6GlobalNtNtCsgEmfK2I1SDS_4core5alloc9Allocator10deallocate", scope: !253, file: !243, line: 440, type: !12, scopeLine: 440, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!472 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !458)
!473 = !{!446, !436, !429}
!474 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !468)
!475 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !476)
!476 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !477)
!477 = distinct !DILocation(line: 423, column: 29, scope: !478, inlinedAt: !479)
!478 = distinct !DISubprogram(name: "drop<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN77_$LT$alloc..raw_vec..RawVec$LT$T$C$A$GT$$u20$as$u20$core..ops..drop..Drop$GT$4drop17h2438dd766861e63fE", scope: !460, file: !147, line: 421, type: !12, scopeLine: 421, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!479 = distinct !DILocation(line: 805, column: 1, scope: !480, inlinedAt: !481)
!480 = distinct !DISubprogram(name: "drop_in_place<alloc::raw_vec::RawVec<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr76drop_in_place$LT$alloc..raw_vec..RawVec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h6f6367928f4a8916E", scope: !170, file: !306, line: 805, type: !12, scopeLine: 805, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!481 = distinct !DILocation(line: 805, column: 1, scope: !433, inlinedAt: !434)
!482 = !DILocation(line: 1232, column: 17, scope: !483, inlinedAt: !484)
!483 = distinct !DISubprogram(name: "unchecked_mul", linkageName: "_RNvMs9_NtCsgEmfK2I1SDS_4core3numj13unchecked_mul", scope: !66, file: !65, line: 1220, type: !12, scopeLine: 1220, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!484 = distinct !DILocation(line: 640, column: 53, scope: !454, inlinedAt: !476)
!485 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !486)
!486 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !487)
!487 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !488)
!488 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !489)
!489 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !477)
!490 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !487)
!491 = !DILocation(line: 932, column: 2, scope: !7)
!492 = !DILocation(line: 441, column: 25, scope: !493, inlinedAt: !396)
!493 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!494 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !495)
!495 = !DILocation(line: 1252, column: 18, scope: !496, inlinedAt: !497)
!496 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 194)
!497 = !DILocation(line: 454, column: 36, scope: !498, inlinedAt: !403)
!498 = !DILexicalBlockFile(scope: !499, file: !209, discriminator: 194)
!499 = distinct !DILexicalBlock(scope: !402, file: !209, line: 448, column: 17)
!500 = !DILocation(line: 929, column: 16, scope: !372)
!501 = !DILocation(line: 0, scope: !502)
!502 = !DILexicalBlockFile(scope: !372, file: !74, discriminator: 0)
!503 = !{!504}
!504 = distinct !{!504, !505, !"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE: %_1"}
!505 = distinct !{!505, !"_ZN4core3ptr69drop_in_place$LT$alloc..vec..Vec$LT$alloc..vec..Vec$LT$u8$GT$$GT$$GT$17h7b48a73008bf9d8aE"}
!506 = !DILocation(line: 805, column: 1, scope: !433, inlinedAt: !507)
!507 = distinct !DILocation(line: 932, column: 1, scope: !15)
!508 = !{!509}
!509 = distinct !{!509, !510, !"_ZN4core3ptr56drop_in_place$LT$$u5b$alloc..vec..Vec$LT$u8$GT$$u5d$$GT$17he49993fd321d5c98E: %_1.0"}
!510 = distinct !{!510, !"_ZN4core3ptr56drop_in_place$LT$$u5b$alloc..vec..Vec$LT$u8$GT$$u5d$$GT$17he49993fd321d5c98E"}
!511 = !DILocation(line: 4224, column: 13, scope: !439, inlinedAt: !512)
!512 = distinct !DILocation(line: 805, column: 1, scope: !433, inlinedAt: !507)
!513 = !DILocation(line: 805, column: 1, scope: !443, inlinedAt: !514)
!514 = distinct !DILocation(line: 4224, column: 13, scope: !439, inlinedAt: !512)
!515 = !{!516}
!516 = distinct !{!516, !517, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!517 = distinct !{!517, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!518 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !519)
!519 = distinct !DILocation(line: 805, column: 1, scope: !443, inlinedAt: !514)
!520 = !{!516, !509}
!521 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !522)
!522 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !523)
!523 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !524)
!524 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !525)
!525 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !519)
!526 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !527)
!527 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !528)
!528 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !529)
!529 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !530)
!530 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !523)
!531 = !{!516, !509, !504}
!532 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !528)
!533 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !534)
!534 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !535)
!535 = distinct !DILocation(line: 423, column: 29, scope: !478, inlinedAt: !536)
!536 = distinct !DILocation(line: 805, column: 1, scope: !480, inlinedAt: !537)
!537 = distinct !DILocation(line: 805, column: 1, scope: !433, inlinedAt: !507)
!538 = !DILocation(line: 1232, column: 17, scope: !483, inlinedAt: !539)
!539 = distinct !DILocation(line: 640, column: 53, scope: !454, inlinedAt: !534)
!540 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !541)
!541 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !542)
!542 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !543)
!543 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !544)
!544 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !535)
!545 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !542)
!546 = !DILocation(line: 0, scope: !199, inlinedAt: !547)
!547 = distinct !DILocation(line: 433, column: 15, scope: !548, inlinedAt: !549)
!548 = distinct !DISubprogram(name: "with_capacity_in<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17h4b7c5b0a570540dbE", scope: !148, file: !147, line: 432, type: !12, scopeLine: 432, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!549 = distinct !DILocation(line: 177, column: 20, scope: !550, inlinedAt: !551)
!550 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$16with_capacity_in17h0bdfdcf1695b87b8E", scope: !156, file: !147, line: 175, type: !12, scopeLine: 175, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!551 = distinct !DILocation(line: 965, column: 20, scope: !552, inlinedAt: !553)
!552 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$16with_capacity_in17h7bbe374ec8ebd6e6E", scope: !124, file: !123, line: 964, type: !12, scopeLine: 964, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!553 = distinct !DILocation(line: 448, column: 29, scope: !554, inlinedAt: !556)
!554 = distinct !DILexicalBlock(scope: !555, file: !209, line: 447, column: 17)
!555 = distinct !DISubprogram(name: "to_vec<u8, alloc::alloc::Global>", linkageName: "_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h40185a762448c357E", scope: !211, file: !209, line: 446, type: !12, scopeLine: 446, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!556 = distinct !DILocation(line: 400, column: 16, scope: !557, inlinedAt: !558)
!557 = distinct !DISubprogram(name: "to_vec_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$9to_vec_in17ha67aa4274a1d15f1E", scope: !213, file: !209, line: 396, type: !12, scopeLine: 396, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!558 = distinct !DILocation(line: 376, column: 14, scope: !559, inlinedAt: !560)
!559 = distinct !DISubprogram(name: "to_vec<u8>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$6to_vec17ha9badac3c2b4dfd0E", scope: !213, file: !209, line: 372, type: !12, scopeLine: 372, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!560 = distinct !DILocation(line: 842, column: 14, scope: !561, inlinedAt: !562)
!561 = distinct !DISubprogram(name: "to_owned<u8>", linkageName: "_ZN5alloc5slice64_$LT$impl$u20$alloc..borrow..ToOwned$u20$for$u20$$u5b$T$u5d$$GT$8to_owned17hf38001dd71254299E", scope: !221, file: !209, line: 841, type: !12, scopeLine: 841, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!562 = distinct !DILocation(line: 211, column: 62, scope: !563, inlinedAt: !564)
!563 = distinct !DISubprogram(name: "to_owned", linkageName: "_RNvXs2_NtCslNYArtu3iFV_5alloc3streNtNtB7_6borrow7ToOwned8to_owned", scope: !225, file: !224, line: 210, type: !12, scopeLine: 210, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!564 = distinct !DILocation(line: 3114, column: 11, scope: !565, inlinedAt: !566)
!565 = distinct !DISubprogram(name: "from", linkageName: "_RNvXsK_NtCslNYArtu3iFV_5alloc6stringNtB5_6StringINtNtCsgEmfK2I1SDS_4core7convert4FromReE4from", scope: !230, file: !229, line: 3113, type: !12, scopeLine: 3113, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!566 = distinct !DILocation(line: 778, column: 9, scope: !567, inlinedAt: !568)
!567 = distinct !DISubprogram(name: "into<&str, alloc::string::String>", linkageName: "_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17hb6f00133dedb813aE", scope: !235, file: !234, line: 777, type: !12, scopeLine: 777, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!568 = distinct !DILocation(line: 492, column: 88, scope: !569, inlinedAt: !571)
!569 = distinct !DISubprogram(name: "{closure#0}", linkageName: "_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17h0dacae20f2481f43E", scope: !570, file: !8, line: 492, type: !12, scopeLine: 492, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!570 = !DINamespace(name: "eval_script", scope: !9)
!571 = distinct !DILocation(line: 968, column: 27, scope: !572, inlinedAt: !387)
!572 = distinct !DILexicalBlock(scope: !383, file: !384, line: 968, column: 13)
!573 = !{!574, !576}
!574 = distinct !{!574, !575, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!575 = distinct !{!575, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!576 = distinct !{!576, !577, !"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17h0dacae20f2481f43E: %_0"}
!577 = distinct !{!577, !"_ZN18rbitcoin_consensus6script11interpreter11eval_script28_$u7b$$u7b$closure$u7d$$u7d$17h0dacae20f2481f43E"}
!578 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !579)
!579 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !580)
!580 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !581)
!581 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !582)
!582 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !547)
!583 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !547)
!584 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !547)
!585 = !DILocation(line: 441, column: 25, scope: !586, inlinedAt: !549)
!586 = distinct !DILexicalBlock(scope: !548, file: !147, line: 441, column: 13)
!587 = !{!576}
!588 = !DILocation(line: 547, column: 14, scope: !589, inlinedAt: !590)
!589 = distinct !DISubprogram(name: "copy_nonoverlapping<u8>", linkageName: "_ZN4core3ptr19copy_nonoverlapping17heb33bba51c9dc77cE", scope: !170, file: !306, line: 526, type: !12, scopeLine: 526, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!590 = distinct !DILocation(line: 1252, column: 18, scope: !591, inlinedAt: !592)
!591 = distinct !DISubprogram(name: "copy_to_nonoverlapping<u8>", linkageName: "_ZN4core3ptr9const_ptr33_$LT$impl$u20$$BP$const$u20$T$GT$22copy_to_nonoverlapping17h9f85b7ce45773255E", scope: !311, file: !309, line: 1247, type: !12, scopeLine: 1247, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!592 = distinct !DILocation(line: 454, column: 36, scope: !593, inlinedAt: !556)
!593 = distinct !DILexicalBlock(scope: !554, file: !209, line: 448, column: 17)
!594 = !DILocation(line: 2189, column: 23, scope: !595, inlinedAt: !598)
!595 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!596 = distinct !DISubprogram(name: "from_residual<bool, rbitcoin_consensus::error::ConsensusError, rbitcoin_consensus::error::ConsensusError>", linkageName: "_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h2456fd96106395c5E", scope: !597, file: !384, line: 2187, type: !12, scopeLine: 2187, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!597 = !DINamespace(name: "{impl#28}", scope: !386)
!598 = !DILocation(line: 492, column: 33, scope: !599)
!599 = !DILexicalBlockFile(scope: !600, file: !8, discriminator: 2)
!600 = distinct !DILexicalBlock(scope: !601, file: !8, line: 492, column: 96)
!601 = distinct !DILexicalBlock(scope: !388, file: !8, line: 492, column: 96)
!602 = !DILocation(line: 0, scope: !603)
!603 = !DILexicalBlockFile(scope: !388, file: !74, discriminator: 0)
!604 = !DILocation(line: 2301, column: 13, scope: !605, inlinedAt: !607)
!605 = distinct !DISubprogram(name: "saturating_add", linkageName: "_RNvMs6_NtCsgEmfK2I1SDS_4core3numm14saturating_add", scope: !606, file: !65, line: 2300, type: !12, scopeLine: 2300, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!606 = !DINamespace(name: "{impl#8}", scope: !67)
!607 = !DILocation(line: 494, column: 33, scope: !608)
!608 = distinct !DILexicalBlock(scope: !609, file: !8, line: 493, column: 9)
!609 = distinct !DILexicalBlock(scope: !388, file: !8, line: 492, column: 9)
!610 = !DILocation(line: 497, column: 15, scope: !611)
!611 = distinct !DILexicalBlock(scope: !608, file: !8, line: 495, column: 9)
!612 = !DILocation(line: 497, column: 9, scope: !611)
!613 = !DILocation(line: 516, column: 29, scope: !611)
!614 = !DILocation(line: 517, column: 21, scope: !615)
!615 = distinct !DILexicalBlock(scope: !611, file: !8, line: 516, column: 13)
!616 = !DILocation(line: 418, column: 38, scope: !617, inlinedAt: !621)
!617 = distinct !DISubprogram(name: "to_u8", linkageName: "_ZN7bitcoin9blockdata7opcodes6Opcode5to_u817h073cd08c831abbedE", scope: !619, file: !618, line: 418, type: !12, scopeLine: 418, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!618 = !DIFile(filename: "src/blockdata/opcodes.rs", directory: "/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bitcoin-0.32.102", checksumkind: CSK_MD5, checksum: "df36c1bb948b270292c2411252f89a81")
!619 = !DINamespace(name: "Opcode", scope: !620)
!620 = !DINamespace(name: "opcodes", scope: !367)
!621 = !DILocation(line: 517, column: 31, scope: !615)
!622 = !DILocation(line: 521, column: 20, scope: !623)
!623 = distinct !DILexicalBlock(scope: !615, file: !8, line: 517, column: 17)
!624 = !DILocation(line: 501, column: 20, scope: !625)
!625 = distinct !DILexicalBlock(scope: !626, file: !8, line: 500, column: 17)
!626 = distinct !DILexicalBlock(scope: !611, file: !8, line: 498, column: 13)
!627 = !DILocation(line: 506, column: 20, scope: !625)
!628 = !DILocation(line: 0, scope: !199, inlinedAt: !629)
!629 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !630)
!630 = !DILocation(line: 177, column: 20, scope: !631, inlinedAt: !632)
!631 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 6)
!632 = !DILocation(line: 965, column: 20, scope: !633, inlinedAt: !634)
!633 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 6)
!634 = !DILocation(line: 448, column: 29, scope: !635, inlinedAt: !637)
!635 = !DILexicalBlockFile(scope: !636, file: !209, discriminator: 6)
!636 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!637 = !DILocation(line: 400, column: 16, scope: !638, inlinedAt: !639)
!638 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 6)
!639 = !DILocation(line: 376, column: 14, scope: !640, inlinedAt: !641)
!640 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 6)
!641 = !DILocation(line: 842, column: 14, scope: !642, inlinedAt: !643)
!642 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 6)
!643 = !DILocation(line: 211, column: 62, scope: !644, inlinedAt: !645)
!644 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 6)
!645 = !DILocation(line: 3114, column: 11, scope: !646, inlinedAt: !647)
!646 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 6)
!647 = !DILocation(line: 778, column: 9, scope: !648, inlinedAt: !649)
!648 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 6)
!649 = !DILocation(line: 502, column: 72, scope: !625)
!650 = !{!651}
!651 = distinct !{!651, !652, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!652 = distinct !{!652, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!653 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !654)
!654 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !655)
!655 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !656)
!656 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !657)
!657 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !629)
!658 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !629)
!659 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !629)
!660 = !DILocation(line: 507, column: 24, scope: !625)
!661 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !662)
!662 = !DILocation(line: 513, column: 42, scope: !625)
!663 = !DILocation(line: 3002, column: 37, scope: !664, inlinedAt: !662)
!664 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!665 = !DILocation(line: 3002, column: 18, scope: !664, inlinedAt: !662)
!666 = !DILocation(line: 459, column: 12, scope: !199, inlinedAt: !667)
!667 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !668)
!668 = !DILocation(line: 177, column: 20, scope: !669, inlinedAt: !670)
!669 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 10)
!670 = !DILocation(line: 965, column: 20, scope: !671, inlinedAt: !672)
!671 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 10)
!672 = !DILocation(line: 448, column: 29, scope: !673, inlinedAt: !675)
!673 = !DILexicalBlockFile(scope: !674, file: !209, discriminator: 10)
!674 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!675 = !DILocation(line: 400, column: 16, scope: !676, inlinedAt: !677)
!676 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 10)
!677 = !DILocation(line: 376, column: 14, scope: !678, inlinedAt: !679)
!678 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 10)
!679 = !DILocation(line: 513, column: 54, scope: !625)
!680 = !DILocation(line: 0, scope: !199, inlinedAt: !667)
!681 = !{!682}
!682 = distinct !{!682, !683, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!683 = distinct !{!683, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!684 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !685)
!685 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !686)
!686 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !687)
!687 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !688)
!688 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !667)
!689 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !667)
!690 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !667)
!691 = !DILocation(line: 219, column: 12, scope: !692, inlinedAt: !696)
!692 = distinct !DISubprogram(name: "get<u8>", linkageName: "_ZN75_$LT$usize$u20$as$u20$core..slice..index..SliceIndex$LT$$u5b$T$u5d$$GT$$GT$3get17ha8c87334b6b342f2E", scope: !694, file: !693, line: 218, type: !12, scopeLine: 218, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!693 = !DIFile(filename: "library/core/src/slice/index.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "35f1d9855ef780cd44773269ad8900cd")
!694 = !DINamespace(name: "{impl#2}", scope: !695)
!695 = !DINamespace(name: "index", scope: !178)
!696 = !DILocation(line: 576, column: 15, scope: !697, inlinedAt: !698)
!697 = distinct !DISubprogram(name: "get<u8, usize>", linkageName: "_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$3get17h7c2fd3ff33807367E", scope: !182, file: !181, line: 572, type: !12, scopeLine: 572, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!698 = !DILocation(line: 508, column: 44, scope: !625)
!699 = !DILocation(line: 221, column: 27, scope: !692, inlinedAt: !696)
!700 = !DILocation(line: 2126, column: 19, scope: !701, inlinedAt: !705)
!701 = distinct !DISubprogram(name: "copied<u8>", linkageName: "_ZN4core6option19Option$LT$$RF$T$GT$6copied17h207a9c2bfff5e946E", scope: !703, file: !702, line: 2119, type: !12, scopeLine: 2119, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!702 = !DIFile(filename: "library/core/src/option.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "3f12dd837a95e960b90752f70f5ddc0e")
!703 = !DINamespace(name: "Option", scope: !704)
!704 = !DINamespace(name: "option", scope: !39)
!705 = !DILocation(line: 508, column: 60, scope: !625)
!706 = !DILocation(line: 1046, column: 5, scope: !707, inlinedAt: !708)
!707 = distinct !DISubprogram(name: "unwrap_or<u8>", linkageName: "_ZN4core6option15Option$LT$T$GT$9unwrap_or17hd552fa0ef8d0b1a1E", scope: !703, file: !702, line: 1038, type: !12, scopeLine: 1038, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!708 = !DILocation(line: 508, column: 69, scope: !625)
!709 = !DILocation(line: 0, scope: !707, inlinedAt: !708)
!710 = !DILocation(line: 1527, column: 8, scope: !711, inlinedAt: !712)
!711 = distinct !DISubprogram(name: "check_minimal_push", linkageName: "_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E", scope: !9, file: !8, line: 1526, type: !12, scopeLine: 1526, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!712 = distinct !DILocation(line: 509, column: 29, scope: !713)
!713 = distinct !DILexicalBlock(scope: !625, file: !8, line: 508, column: 25)
!714 = !DILocation(line: 1528, column: 16, scope: !711, inlinedAt: !712)
!715 = !DILocation(line: 509, column: 29, scope: !713)
!716 = !DILocation(line: 1530, column: 27, scope: !711, inlinedAt: !712)
!717 = !{!718}
!718 = distinct !{!718, !719, !"_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E: %data.0"}
!719 = distinct !{!719, !"_ZN18rbitcoin_consensus6script11interpreter18check_minimal_push17h9bf7ac260dbb6c20E"}
!720 = !DILocation(line: 1531, column: 26, scope: !711, inlinedAt: !712)
!721 = !DILocation(line: 1531, column: 16, scope: !711, inlinedAt: !712)
!722 = !DILocation(line: 1533, column: 27, scope: !711, inlinedAt: !712)
!723 = !DILocation(line: 1534, column: 16, scope: !711, inlinedAt: !712)
!724 = !DILocation(line: 1536, column: 8, scope: !711, inlinedAt: !712)
!725 = !DILocation(line: 1539, column: 8, scope: !711, inlinedAt: !712)
!726 = !DILocation(line: 1537, column: 16, scope: !711, inlinedAt: !712)
!727 = !DILocation(line: 1543, column: 16, scope: !711, inlinedAt: !712)
!728 = !DILocation(line: 1540, column: 16, scope: !711, inlinedAt: !712)
!729 = !DILocation(line: 0, scope: !199, inlinedAt: !730)
!730 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !731)
!731 = !DILocation(line: 177, column: 20, scope: !732, inlinedAt: !733)
!732 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 8)
!733 = !DILocation(line: 965, column: 20, scope: !734, inlinedAt: !735)
!734 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 8)
!735 = !DILocation(line: 448, column: 29, scope: !736, inlinedAt: !738)
!736 = !DILexicalBlockFile(scope: !737, file: !209, discriminator: 8)
!737 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!738 = !DILocation(line: 400, column: 16, scope: !739, inlinedAt: !740)
!739 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 8)
!740 = !DILocation(line: 376, column: 14, scope: !741, inlinedAt: !742)
!741 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 8)
!742 = !DILocation(line: 842, column: 14, scope: !743, inlinedAt: !744)
!743 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 8)
!744 = !DILocation(line: 211, column: 62, scope: !745, inlinedAt: !746)
!745 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 8)
!746 = !DILocation(line: 3114, column: 11, scope: !747, inlinedAt: !748)
!747 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 8)
!748 = !DILocation(line: 778, column: 9, scope: !749, inlinedAt: !750)
!749 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 8)
!750 = !DILocation(line: 510, column: 77, scope: !713)
!751 = !{!752}
!752 = distinct !{!752, !753, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!753 = distinct !{!753, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!754 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !755)
!755 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !756)
!756 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !757)
!757 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !758)
!758 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !730)
!759 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !730)
!760 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !730)
!761 = !DILocation(line: 441, column: 25, scope: !762, inlinedAt: !731)
!762 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!763 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !764)
!764 = !DILocation(line: 1252, column: 18, scope: !765, inlinedAt: !766)
!765 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 8)
!766 = !DILocation(line: 454, column: 36, scope: !767, inlinedAt: !738)
!767 = !DILexicalBlockFile(scope: !768, file: !209, discriminator: 8)
!768 = distinct !DILexicalBlock(scope: !737, file: !209, line: 448, column: 17)
!769 = !DILocation(line: 510, column: 36, scope: !713)
!770 = !DILocation(line: 0, scope: !771)
!771 = !DILexicalBlockFile(scope: !625, file: !74, discriminator: 0)
!772 = !DILocation(line: 441, column: 25, scope: !773, inlinedAt: !668)
!773 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!774 = !{!775}
!775 = distinct !{!775, !776, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE: %stack"}
!776 = distinct !{!776, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE"}
!777 = !DILocation(line: 513, column: 21, scope: !625)
!778 = !DILocation(line: 2997, column: 19, scope: !779, inlinedAt: !780)
!779 = distinct !DISubprogram(name: "len<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$3len17he380850a57f8bd03E", scope: !124, file: !123, line: 2996, type: !12, scopeLine: 2996, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!780 = distinct !DILocation(line: 1479, column: 14, scope: !781, inlinedAt: !782)
!781 = distinct !DISubprogram(name: "push", linkageName: "_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE", scope: !9, file: !8, line: 1478, type: !12, scopeLine: 1478, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!782 = distinct !DILocation(line: 513, column: 21, scope: !625)
!783 = !{!784, !785}
!784 = distinct !{!784, !776, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE: %_0"}
!785 = distinct !{!785, !776, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE: %v"}
!786 = !DILocation(line: 3002, column: 37, scope: !787, inlinedAt: !780)
!787 = distinct !DILexicalBlock(scope: !779, file: !123, line: 2997, column: 9)
!788 = !DILocation(line: 3002, column: 18, scope: !787, inlinedAt: !780)
!789 = !DILocation(line: 2301, column: 13, scope: !790, inlinedAt: !791)
!790 = distinct !DISubprogram(name: "saturating_add", linkageName: "_RNvMs9_NtCsgEmfK2I1SDS_4core3numj14saturating_add", scope: !66, file: !65, line: 2300, type: !12, scopeLine: 2300, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!791 = distinct !DILocation(line: 1479, column: 20, scope: !781, inlinedAt: !782)
!792 = !DILocation(line: 1479, column: 8, scope: !781, inlinedAt: !782)
!793 = !DILocation(line: 617, column: 49, scope: !794, inlinedAt: !795)
!794 = distinct !DISubprogram(name: "capacity<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8capacity17he27ac60cd2f1eca6E", scope: !148, file: !147, line: 616, type: !12, scopeLine: 616, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!795 = distinct !DILocation(line: 308, column: 20, scope: !796, inlinedAt: !797)
!796 = distinct !DISubprogram(name: "capacity<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8capacity17h92f042a2a1219c16E", scope: !156, file: !147, line: 307, type: !12, scopeLine: 307, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!797 = distinct !DILocation(line: 1028, column: 28, scope: !798, inlinedAt: !800)
!798 = distinct !DILexicalBlock(scope: !799, file: !123, line: 1025, column: 9)
!799 = distinct !DISubprogram(name: "push_mut<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E", scope: !124, file: !123, line: 1023, type: !12, scopeLine: 1023, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!800 = distinct !DILocation(line: 992, column: 22, scope: !801, inlinedAt: !802)
!801 = distinct !DISubprogram(name: "push<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$4push17h02e46a499ef19dd5E", scope: !124, file: !123, line: 991, type: !12, scopeLine: 991, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!802 = distinct !DILocation(line: 1482, column: 11, scope: !781, inlinedAt: !782)
!803 = !{!804, !775}
!804 = distinct !{!804, !805, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E: %self"}
!805 = distinct !{!805, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E"}
!806 = !{!807, !784, !785}
!807 = distinct !{!807, !805, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E: %value"}
!808 = !DILocation(line: 1028, column: 12, scope: !798, inlinedAt: !800)
!809 = !DILocation(line: 1029, column: 22, scope: !798, inlinedAt: !800)
!810 = !DILocation(line: 1028, column: 9, scope: !798, inlinedAt: !800)
!811 = !DILocation(line: 0, scope: !199, inlinedAt: !812)
!812 = distinct !DILocation(line: 433, column: 15, scope: !813, inlinedAt: !814)
!813 = distinct !DISubprogram(name: "with_capacity_in<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17h4b7c5b0a570540dbE", scope: !148, file: !147, line: 432, type: !12, scopeLine: 432, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!814 = distinct !DILocation(line: 177, column: 20, scope: !815, inlinedAt: !816)
!815 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$16with_capacity_in17h0bdfdcf1695b87b8E", scope: !156, file: !147, line: 175, type: !12, scopeLine: 175, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!816 = distinct !DILocation(line: 965, column: 20, scope: !817, inlinedAt: !818)
!817 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$16with_capacity_in17h7bbe374ec8ebd6e6E", scope: !124, file: !123, line: 964, type: !12, scopeLine: 964, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!818 = distinct !DILocation(line: 448, column: 29, scope: !819, inlinedAt: !821)
!819 = distinct !DILexicalBlock(scope: !820, file: !209, line: 447, column: 17)
!820 = distinct !DISubprogram(name: "to_vec<u8, alloc::alloc::Global>", linkageName: "_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h40185a762448c357E", scope: !211, file: !209, line: 446, type: !12, scopeLine: 446, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!821 = distinct !DILocation(line: 400, column: 16, scope: !822, inlinedAt: !823)
!822 = distinct !DISubprogram(name: "to_vec_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$9to_vec_in17ha67aa4274a1d15f1E", scope: !213, file: !209, line: 396, type: !12, scopeLine: 396, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!823 = distinct !DILocation(line: 376, column: 14, scope: !824, inlinedAt: !825)
!824 = distinct !DISubprogram(name: "to_vec<u8>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$6to_vec17ha9badac3c2b4dfd0E", scope: !213, file: !209, line: 372, type: !12, scopeLine: 372, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!825 = distinct !DILocation(line: 842, column: 14, scope: !826, inlinedAt: !827)
!826 = distinct !DISubprogram(name: "to_owned<u8>", linkageName: "_ZN5alloc5slice64_$LT$impl$u20$alloc..borrow..ToOwned$u20$for$u20$$u5b$T$u5d$$GT$8to_owned17hf38001dd71254299E", scope: !221, file: !209, line: 841, type: !12, scopeLine: 841, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!827 = distinct !DILocation(line: 211, column: 62, scope: !828, inlinedAt: !829)
!828 = distinct !DISubprogram(name: "to_owned", linkageName: "_RNvXs2_NtCslNYArtu3iFV_5alloc3streNtNtB7_6borrow7ToOwned8to_owned", scope: !225, file: !224, line: 210, type: !12, scopeLine: 210, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!829 = distinct !DILocation(line: 3114, column: 11, scope: !830, inlinedAt: !831)
!830 = distinct !DISubprogram(name: "from", linkageName: "_RNvXsK_NtCslNYArtu3iFV_5alloc6stringNtB5_6StringINtNtCsgEmfK2I1SDS_4core7convert4FromReE4from", scope: !230, file: !229, line: 3113, type: !12, scopeLine: 3113, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!831 = distinct !DILocation(line: 778, column: 9, scope: !832, inlinedAt: !833)
!832 = distinct !DISubprogram(name: "into<&str, alloc::string::String>", linkageName: "_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17hb6f00133dedb813aE", scope: !235, file: !234, line: 777, type: !12, scopeLine: 777, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!833 = distinct !DILocation(line: 1480, column: 56, scope: !781, inlinedAt: !782)
!834 = !{!835, !784, !775, !785}
!835 = distinct !{!835, !836, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!836 = distinct !{!836, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!837 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !838)
!838 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !839)
!839 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !840)
!840 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !841)
!841 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !812)
!842 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !812)
!843 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !812)
!844 = !DILocation(line: 441, column: 25, scope: !845, inlinedAt: !814)
!845 = distinct !DILexicalBlock(scope: !813, file: !147, line: 441, column: 13)
!846 = !{!784, !775, !785}
!847 = !DILocation(line: 547, column: 14, scope: !848, inlinedAt: !849)
!848 = distinct !DISubprogram(name: "copy_nonoverlapping<u8>", linkageName: "_ZN4core3ptr19copy_nonoverlapping17heb33bba51c9dc77cE", scope: !170, file: !306, line: 526, type: !12, scopeLine: 526, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!849 = distinct !DILocation(line: 1252, column: 18, scope: !850, inlinedAt: !851)
!850 = distinct !DISubprogram(name: "copy_to_nonoverlapping<u8>", linkageName: "_ZN4core3ptr9const_ptr33_$LT$impl$u20$$BP$const$u20$T$GT$22copy_to_nonoverlapping17h9f85b7ce45773255E", scope: !311, file: !309, line: 1247, type: !12, scopeLine: 1247, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!851 = distinct !DILocation(line: 454, column: 36, scope: !852, inlinedAt: !821)
!852 = distinct !DILexicalBlock(scope: !819, file: !209, line: 448, column: 17)
!853 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !854)
!854 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !855)
!855 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !856)
!856 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !857)
!857 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !858)
!858 = distinct !DILocation(line: 1484, column: 1, scope: !781, inlinedAt: !782)
!859 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !860)
!860 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !861)
!861 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !862)
!862 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !863)
!863 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !855)
!864 = !{!865, !784, !775, !785}
!865 = distinct !{!865, !866, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!866 = distinct !{!866, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!867 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !861)
!868 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !869)
!869 = !DILocation(line: 1252, column: 18, scope: !870, inlinedAt: !871)
!870 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 10)
!871 = !DILocation(line: 454, column: 36, scope: !872, inlinedAt: !675)
!872 = !DILexicalBlockFile(scope: !873, file: !209, discriminator: 10)
!873 = distinct !DILexicalBlock(scope: !674, file: !209, line: 448, column: 17)
!874 = !DILocation(line: 452, column: 17, scope: !873, inlinedAt: !675)
!875 = !DILocation(line: 2189, column: 23, scope: !876, inlinedAt: !877)
!876 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!877 = !DILocation(line: 513, column: 21, scope: !878)
!878 = !DILexicalBlockFile(scope: !879, file: !8, discriminator: 2)
!879 = distinct !DILexicalBlock(scope: !880, file: !8, line: 513, column: 63)
!880 = distinct !DILexicalBlock(scope: !625, file: !8, line: 513, column: 63)
!881 = !DILocation(line: 612, column: 9, scope: !882, inlinedAt: !883)
!882 = distinct !DISubprogram(name: "non_null<alloc::alloc::Global, alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8non_null17h48f19a6fe835f1a8E", scope: !148, file: !147, line: 611, type: !12, scopeLine: 611, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!883 = distinct !DILocation(line: 607, column: 14, scope: !884, inlinedAt: !885)
!884 = distinct !DISubprogram(name: "ptr<alloc::alloc::Global, alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$3ptr17h14a549210941dc8aE", scope: !148, file: !147, line: 606, type: !12, scopeLine: 606, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!885 = distinct !DILocation(line: 295, column: 20, scope: !886, inlinedAt: !887)
!886 = distinct !DISubprogram(name: "ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$3ptr17he48fe43939ce2533E", scope: !156, file: !147, line: 294, type: !12, scopeLine: 294, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!887 = distinct !DILocation(line: 2000, column: 18, scope: !888, inlinedAt: !889)
!888 = distinct !DISubprogram(name: "as_mut_ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$10as_mut_ptr17h5fd5b382b129a816E", scope: !124, file: !123, line: 1997, type: !12, scopeLine: 1997, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!889 = distinct !DILocation(line: 1032, column: 28, scope: !798, inlinedAt: !800)
!890 = !DILocation(line: 961, column: 18, scope: !891, inlinedAt: !892)
!891 = distinct !DISubprogram(name: "add<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr7mut_ptr31_$LT$impl$u20$$BP$mut$u20$T$GT$3add17h23b68dca67d1e391E", scope: !168, file: !167, line: 927, type: !12, scopeLine: 927, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!892 = distinct !DILocation(line: 1032, column: 41, scope: !798, inlinedAt: !800)
!893 = !DILocation(line: 1917, column: 41, scope: !894, inlinedAt: !895)
!894 = distinct !DISubprogram(name: "write<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr5write17hd83bed101a89aa2dE", scope: !170, file: !306, line: 1894, type: !12, scopeLine: 1894, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!895 = distinct !DILocation(line: 1033, column: 13, scope: !896, inlinedAt: !800)
!896 = distinct !DILexicalBlock(scope: !798, file: !123, line: 1032, column: 13)
!897 = !{!784}
!898 = !DILocation(line: 1034, column: 13, scope: !896, inlinedAt: !800)
!899 = !DILocation(line: 506, column: 17, scope: !625)
!900 = !DILocation(line: 441, column: 25, scope: !901, inlinedAt: !630)
!901 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!902 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !903)
!903 = !DILocation(line: 1252, column: 18, scope: !904, inlinedAt: !905)
!904 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 6)
!905 = !DILocation(line: 454, column: 36, scope: !906, inlinedAt: !637)
!906 = !DILexicalBlockFile(scope: !907, file: !209, discriminator: 6)
!907 = distinct !DILexicalBlock(scope: !636, file: !209, line: 448, column: 17)
!908 = !DILocation(line: 502, column: 28, scope: !625)
!909 = !DILocation(line: 529, column: 17, scope: !623)
!910 = !DILocation(line: 522, column: 21, scope: !623)
!911 = !DILocation(line: 523, column: 24, scope: !623)
!912 = !DILocation(line: 0, scope: !199, inlinedAt: !913)
!913 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !914)
!914 = !DILocation(line: 177, column: 20, scope: !915, inlinedAt: !916)
!915 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 12)
!916 = !DILocation(line: 965, column: 20, scope: !917, inlinedAt: !918)
!917 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 12)
!918 = !DILocation(line: 448, column: 29, scope: !919, inlinedAt: !921)
!919 = !DILexicalBlockFile(scope: !920, file: !209, discriminator: 12)
!920 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!921 = !DILocation(line: 400, column: 16, scope: !922, inlinedAt: !923)
!922 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 12)
!923 = !DILocation(line: 376, column: 14, scope: !924, inlinedAt: !925)
!924 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 12)
!925 = !DILocation(line: 842, column: 14, scope: !926, inlinedAt: !927)
!926 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 10)
!927 = !DILocation(line: 211, column: 62, scope: !928, inlinedAt: !929)
!928 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 10)
!929 = !DILocation(line: 3114, column: 11, scope: !930, inlinedAt: !931)
!930 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 10)
!931 = !DILocation(line: 778, column: 9, scope: !932, inlinedAt: !933)
!932 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 10)
!933 = !DILocation(line: 524, column: 70, scope: !623)
!934 = !{!935}
!935 = distinct !{!935, !936, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!936 = distinct !{!936, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!937 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !938)
!938 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !939)
!939 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !940)
!940 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !941)
!941 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !913)
!942 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !913)
!943 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !913)
!944 = !DILocation(line: 532, column: 28, scope: !945)
!945 = distinct !DILexicalBlock(scope: !623, file: !8, line: 531, column: 25)
!946 = !DILocation(line: 544, column: 28, scope: !947)
!947 = distinct !DILexicalBlock(scope: !623, file: !8, line: 543, column: 25)
!948 = !DILocation(line: 418, column: 9, scope: !391, inlinedAt: !949)
!949 = distinct !DILocation(line: 555, column: 39, scope: !623)
!950 = !DILocation(line: 555, column: 28, scope: !623)
!951 = !DILocation(line: 418, column: 9, scope: !391, inlinedAt: !952)
!952 = distinct !DILocation(line: 562, column: 39, scope: !623)
!953 = !DILocation(line: 562, column: 28, scope: !623)
!954 = !{!955}
!955 = distinct !{!955, !956, !"_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E: %stack"}
!956 = distinct !{!956, !"_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E"}
!957 = !DILocation(line: 533, column: 37, scope: !945)
!958 = !DILocation(line: 2791, column: 12, scope: !959, inlinedAt: !960)
!959 = distinct !DISubprogram(name: "pop<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$3pop17hb17e0537e1ff823eE", scope: !124, file: !123, line: 2790, type: !12, scopeLine: 2790, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!960 = distinct !DILocation(line: 1488, column: 10, scope: !961, inlinedAt: !962)
!961 = distinct !DISubprogram(name: "pop", linkageName: "_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E", scope: !9, file: !8, line: 1486, type: !12, scopeLine: 1486, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!962 = distinct !DILocation(line: 533, column: 37, scope: !945)
!963 = !{!964}
!964 = distinct !{!964, !956, !"_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E: %_0"}
!965 = !DILocation(line: 0, scope: !199, inlinedAt: !966)
!966 = distinct !DILocation(line: 433, column: 15, scope: !967, inlinedAt: !968)
!967 = distinct !DISubprogram(name: "with_capacity_in<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17h4b7c5b0a570540dbE", scope: !148, file: !147, line: 432, type: !12, scopeLine: 432, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!968 = distinct !DILocation(line: 177, column: 20, scope: !969, inlinedAt: !970)
!969 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$16with_capacity_in17h0bdfdcf1695b87b8E", scope: !156, file: !147, line: 175, type: !12, scopeLine: 175, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!970 = distinct !DILocation(line: 965, column: 20, scope: !971, inlinedAt: !972)
!971 = distinct !DISubprogram(name: "with_capacity_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$16with_capacity_in17h7bbe374ec8ebd6e6E", scope: !124, file: !123, line: 964, type: !12, scopeLine: 964, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!972 = distinct !DILocation(line: 448, column: 29, scope: !973, inlinedAt: !975)
!973 = distinct !DILexicalBlock(scope: !974, file: !209, line: 447, column: 17)
!974 = distinct !DISubprogram(name: "to_vec<u8, alloc::alloc::Global>", linkageName: "_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h40185a762448c357E", scope: !211, file: !209, line: 446, type: !12, scopeLine: 446, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!975 = distinct !DILocation(line: 400, column: 16, scope: !976, inlinedAt: !977)
!976 = distinct !DISubprogram(name: "to_vec_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$9to_vec_in17ha67aa4274a1d15f1E", scope: !213, file: !209, line: 396, type: !12, scopeLine: 396, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!977 = distinct !DILocation(line: 376, column: 14, scope: !978, inlinedAt: !979)
!978 = distinct !DISubprogram(name: "to_vec<u8>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$6to_vec17ha9badac3c2b4dfd0E", scope: !213, file: !209, line: 372, type: !12, scopeLine: 372, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!979 = distinct !DILocation(line: 842, column: 14, scope: !980, inlinedAt: !981)
!980 = distinct !DISubprogram(name: "to_owned<u8>", linkageName: "_ZN5alloc5slice64_$LT$impl$u20$alloc..borrow..ToOwned$u20$for$u20$$u5b$T$u5d$$GT$8to_owned17hf38001dd71254299E", scope: !221, file: !209, line: 841, type: !12, scopeLine: 841, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!981 = distinct !DILocation(line: 211, column: 62, scope: !982, inlinedAt: !983)
!982 = distinct !DISubprogram(name: "to_owned", linkageName: "_RNvXs2_NtCslNYArtu3iFV_5alloc3streNtNtB7_6borrow7ToOwned8to_owned", scope: !225, file: !224, line: 210, type: !12, scopeLine: 210, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!983 = distinct !DILocation(line: 3114, column: 11, scope: !984, inlinedAt: !985)
!984 = distinct !DISubprogram(name: "from", linkageName: "_RNvXsK_NtCslNYArtu3iFV_5alloc6stringNtB5_6StringINtNtCsgEmfK2I1SDS_4core7convert4FromReE4from", scope: !230, file: !229, line: 3113, type: !12, scopeLine: 3113, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!985 = distinct !DILocation(line: 778, column: 9, scope: !986, inlinedAt: !987)
!986 = distinct !DISubprogram(name: "into<&str, alloc::string::String>", linkageName: "_ZN50_$LT$T$u20$as$u20$core..convert..Into$LT$U$GT$$GT$4into17hb6f00133dedb813aE", scope: !235, file: !234, line: 777, type: !12, scopeLine: 777, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!987 = distinct !DILocation(line: 1489, column: 61, scope: !988, inlinedAt: !990)
!988 = distinct !DISubprogram(name: "{closure#0}", linkageName: "_ZN18rbitcoin_consensus6script11interpreter3pop28_$u7b$$u7b$closure$u7d$$u7d$17h314c249baa1729b1E", scope: !989, file: !8, line: 1489, type: !12, scopeLine: 1489, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!989 = !DINamespace(name: "pop", scope: !9)
!990 = distinct !DILocation(line: 1369, column: 25, scope: !991, inlinedAt: !992)
!991 = distinct !DISubprogram(name: "ok_or_else<alloc::vec::Vec<u8, alloc::alloc::Global>, rbitcoin_consensus::error::ConsensusError, rbitcoin_consensus::script::interpreter::pop::{closure_env#0}>", linkageName: "_ZN4core6option15Option$LT$T$GT$10ok_or_else17hc704090b6cfd01ebE", scope: !703, file: !702, line: 1363, type: !12, scopeLine: 1363, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!992 = distinct !DILocation(line: 1489, column: 10, scope: !961, inlinedAt: !962)
!993 = !{!994, !996, !964, !955}
!994 = distinct !{!994, !995, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!995 = distinct !{!995, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!996 = distinct !{!996, !997, !"_ZN18rbitcoin_consensus6script11interpreter3pop28_$u7b$$u7b$closure$u7d$$u7d$17h314c249baa1729b1E: %_0"}
!997 = distinct !{!997, !"_ZN18rbitcoin_consensus6script11interpreter3pop28_$u7b$$u7b$closure$u7d$$u7d$17h314c249baa1729b1E"}
!998 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !999)
!999 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1000)
!1000 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1001)
!1001 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1002)
!1002 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !966)
!1003 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !966)
!1004 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !966)
!1005 = !DILocation(line: 441, column: 25, scope: !1006, inlinedAt: !968)
!1006 = distinct !DILexicalBlock(scope: !967, file: !147, line: 441, column: 13)
!1007 = !{!996, !964, !955}
!1008 = !DILocation(line: 426, column: 12, scope: !1009, inlinedAt: !1010)
!1009 = distinct !DISubprogram(name: "push", linkageName: "_ZN18rbitcoin_consensus6script11interpreter14ConditionStack4push17h2aa362c30ab8fd5bE", scope: !392, file: !8, line: 425, type: !12, scopeLine: 425, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1010 = distinct !DILocation(line: 539, column: 36, scope: !945)
!1011 = !DILocation(line: 0, scope: !139)
!1012 = !DILocation(line: 429, column: 9, scope: !1009, inlinedAt: !1010)
!1013 = !DILocation(line: 0, scope: !1014)
!1014 = !DILexicalBlockFile(scope: !623, file: !74, discriminator: 0)
!1015 = !DILocation(line: 547, column: 14, scope: !1016, inlinedAt: !1017)
!1016 = distinct !DISubprogram(name: "copy_nonoverlapping<u8>", linkageName: "_ZN4core3ptr19copy_nonoverlapping17heb33bba51c9dc77cE", scope: !170, file: !306, line: 526, type: !12, scopeLine: 526, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1017 = distinct !DILocation(line: 1252, column: 18, scope: !1018, inlinedAt: !1019)
!1018 = distinct !DISubprogram(name: "copy_to_nonoverlapping<u8>", linkageName: "_ZN4core3ptr9const_ptr33_$LT$impl$u20$$BP$const$u20$T$GT$22copy_to_nonoverlapping17h9f85b7ce45773255E", scope: !311, file: !309, line: 1247, type: !12, scopeLine: 1247, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1019 = distinct !DILocation(line: 454, column: 36, scope: !1020, inlinedAt: !975)
!1020 = distinct !DILexicalBlock(scope: !973, file: !209, line: 448, column: 17)
!1021 = !DILocation(line: 2189, column: 23, scope: !1022, inlinedAt: !1023)
!1022 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!1023 = !DILocation(line: 533, column: 37, scope: !1024)
!1024 = !DILexicalBlockFile(scope: !1025, file: !8, discriminator: 2)
!1025 = distinct !DILexicalBlock(scope: !1026, file: !8, line: 533, column: 47)
!1026 = distinct !DILexicalBlock(scope: !945, file: !8, line: 533, column: 47)
!1027 = !DILocation(line: 0, scope: !1028)
!1028 = !DILexicalBlockFile(scope: !945, file: !74, discriminator: 0)
!1029 = !DILocation(line: 2795, column: 17, scope: !959, inlinedAt: !960)
!1030 = !DILocation(line: 617, column: 49, scope: !1031, inlinedAt: !1032)
!1031 = distinct !DISubprogram(name: "capacity<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8capacity17he27ac60cd2f1eca6E", scope: !148, file: !147, line: 616, type: !12, scopeLine: 616, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1032 = distinct !DILocation(line: 308, column: 20, scope: !1033, inlinedAt: !1034)
!1033 = distinct !DISubprogram(name: "capacity<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8capacity17h92f042a2a1219c16E", scope: !156, file: !147, line: 307, type: !12, scopeLine: 307, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1034 = distinct !DILocation(line: 1422, column: 18, scope: !1035, inlinedAt: !1036)
!1035 = distinct !DISubprogram(name: "capacity<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$8capacity17h808049f3502df27eE", scope: !124, file: !123, line: 1421, type: !12, scopeLine: 1421, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1036 = distinct !DILocation(line: 2796, column: 62, scope: !959, inlinedAt: !960)
!1037 = !DILocation(line: 2796, column: 46, scope: !959, inlinedAt: !960)
!1038 = !DILocation(line: 210, column: 9, scope: !1039, inlinedAt: !1042)
!1039 = distinct !DISubprogram(name: "assert_unchecked", linkageName: "_RNvNtCsgEmfK2I1SDS_4core4hint16assert_unchecked", scope: !1041, file: !1040, line: 202, type: !12, scopeLine: 202, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1040 = !DIFile(filename: "library/core/src/hint.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "2a901a283eb5f69871d8be07d256ca78")
!1041 = !DINamespace(name: "hint", scope: !39)
!1042 = distinct !DILocation(line: 2796, column: 17, scope: !959, inlinedAt: !960)
!1043 = !DILocation(line: 612, column: 9, scope: !1044, inlinedAt: !1045)
!1044 = distinct !DISubprogram(name: "non_null<alloc::alloc::Global, alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8non_null17h48f19a6fe835f1a8E", scope: !148, file: !147, line: 611, type: !12, scopeLine: 611, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1045 = distinct !DILocation(line: 607, column: 14, scope: !1046, inlinedAt: !1047)
!1046 = distinct !DISubprogram(name: "ptr<alloc::alloc::Global, alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$3ptr17h14a549210941dc8aE", scope: !148, file: !147, line: 606, type: !12, scopeLine: 606, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1047 = distinct !DILocation(line: 295, column: 20, scope: !1048, inlinedAt: !1049)
!1048 = distinct !DISubprogram(name: "ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$3ptr17he48fe43939ce2533E", scope: !156, file: !147, line: 294, type: !12, scopeLine: 294, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1049 = distinct !DILocation(line: 1916, column: 18, scope: !1050, inlinedAt: !1051)
!1050 = distinct !DISubprogram(name: "as_ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$6as_ptr17he724f02ec7635c63E", scope: !124, file: !123, line: 1913, type: !12, scopeLine: 1913, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1051 = distinct !DILocation(line: 2797, column: 37, scope: !959, inlinedAt: !960)
!1052 = !DILocation(line: 3002, column: 37, scope: !1053, inlinedAt: !1055)
!1053 = distinct !DILexicalBlock(scope: !1054, file: !123, line: 2997, column: 9)
!1054 = distinct !DISubprogram(name: "len<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$3len17he380850a57f8bd03E", scope: !124, file: !123, line: 2996, type: !12, scopeLine: 2996, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1055 = distinct !DILocation(line: 2797, column: 55, scope: !959, inlinedAt: !960)
!1056 = !DILocation(line: 3002, column: 18, scope: !1053, inlinedAt: !1055)
!1057 = !DILocation(line: 863, column: 18, scope: !1058, inlinedAt: !1059)
!1058 = distinct !DISubprogram(name: "add<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr9const_ptr33_$LT$impl$u20$$BP$const$u20$T$GT$3add17h0e4bcabc1f5ba454E", scope: !311, file: !309, line: 829, type: !12, scopeLine: 829, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1059 = distinct !DILocation(line: 2797, column: 46, scope: !959, inlinedAt: !960)
!1060 = !DILocation(line: 1717, column: 9, scope: !1061, inlinedAt: !1062)
!1061 = distinct !DISubprogram(name: "read<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr4read17h53fcd9cbaf9f5787E", scope: !170, file: !306, line: 1678, type: !12, scopeLine: 1678, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1062 = distinct !DILocation(line: 2797, column: 22, scope: !959, inlinedAt: !960)
!1063 = !DILocation(line: 534, column: 32, scope: !1064)
!1064 = distinct !DILexicalBlock(scope: !945, file: !8, line: 533, column: 29)
!1065 = !DILocation(line: 241, column: 16, scope: !1066, inlinedAt: !1068)
!1066 = distinct !DILexicalBlock(scope: !1067, file: !181, line: 241, column: 41)
!1067 = distinct !DISubprogram(name: "split_last<u8>", linkageName: "_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$10split_last17hbee03a8bbf8e1418E", scope: !182, file: !181, line: 240, type: !12, scopeLine: 240, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1068 = distinct !DILocation(line: 235, column: 13, scope: !1069, inlinedAt: !1071)
!1069 = distinct !DISubprogram(name: "read_scriptbool", linkageName: "_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE", scope: !366, file: !1070, line: 234, type: !12, scopeLine: 234, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1070 = !DIFile(filename: "src/blockdata/script/mod.rs", directory: "/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bitcoin-0.32.102", checksumkind: CSK_MD5, checksum: "2f86ec94a15e46a76ddf03cf552eb755")
!1071 = distinct !DILocation(line: 537, column: 36, scope: !1064)
!1072 = !DILocation(line: 241, column: 28, scope: !1066, inlinedAt: !1068)
!1073 = !DILocation(line: 28, column: 31, scope: !1074, inlinedAt: !1078)
!1074 = distinct !DISubprogram(name: "bitand", linkageName: "_RNvXsI_NtNtCsgEmfK2I1SDS_4core3ops3bitRhINtB5_6BitAndhE6bitand", scope: !1076, file: !1075, line: 27, type: !12, scopeLine: 27, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1075 = !DIFile(filename: "library/core/src/internal_macros.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "9ec673d06a3eb53c47178443a566ec32")
!1076 = !DINamespace(name: "{impl#46}", scope: !1077)
!1077 = !DINamespace(name: "bit", scope: !49)
!1078 = distinct !DILocation(line: 236, column: 34, scope: !1079, inlinedAt: !1071)
!1079 = distinct !DILexicalBlock(scope: !1069, file: !1070, line: 236, column: 9)
!1080 = !{!1081}
!1081 = distinct !{!1081, !1082, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE: %v.0"}
!1082 = distinct !{!1082, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE"}
!1083 = !DILocation(line: 178, column: 46, scope: !1084, inlinedAt: !1087)
!1084 = distinct !DISubprogram(name: "bitand", linkageName: "_RNvXsr_NtNtCsgEmfK2I1SDS_4core3ops3bithNtB5_6BitAnd6bitand", scope: !1086, file: !1085, line: 178, type: !12, scopeLine: 178, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1085 = !DIFile(filename: "library/core/src/ops/bit.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "a9cd3c7a17fc40edd73dac2b4ffebad6")
!1086 = !DINamespace(name: "{impl#29}", scope: !1077)
!1087 = distinct !DILocation(line: 28, column: 17, scope: !1074, inlinedAt: !1078)
!1088 = !DILocation(line: 236, column: 33, scope: !1079, inlinedAt: !1071)
!1089 = !DILocation(line: 1720, column: 9, scope: !1090, inlinedAt: !1091)
!1090 = distinct !DISubprogram(name: "eq<u8>", linkageName: "_ZN78_$LT$core..ptr..non_null..NonNull$LT$T$GT$$u20$as$u20$core..cmp..PartialEq$GT$2eq17h6b2d7bb2da6138d4E", scope: !187, file: !186, line: 1719, type: !12, scopeLine: 1719, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1091 = distinct !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !1095)
!1092 = distinct !DILexicalBlock(scope: !1093, file: !191, line: 162, column: 17)
!1093 = distinct !DILexicalBlock(scope: !1094, file: !191, line: 161, column: 17)
!1094 = distinct !DISubprogram(name: "next<u8>", linkageName: "_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hae2c5a92cc6c89cdE", scope: !194, file: !191, line: 157, type: !12, scopeLine: 157, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1095 = distinct !DILocation(line: 314, column: 42, scope: !1096, inlinedAt: !1098)
!1096 = distinct !DILexicalBlock(scope: !1097, file: !191, line: 314, column: 49)
!1097 = distinct !DISubprogram(name: "all<u8, bitcoin::blockdata::script::read_scriptbool::{closure_env#0}>", linkageName: "_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E", scope: !194, file: !191, line: 309, type: !12, scopeLine: 309, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1098 = distinct !DILocation(line: 236, column: 71, scope: !1079, inlinedAt: !1071)
!1099 = !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !1095)
!1100 = !DILocation(line: 659, column: 28, scope: !1101, inlinedAt: !1102)
!1101 = distinct !DISubprogram(name: "add<u8>", linkageName: "_ZN4core3ptr8non_null16NonNull$LT$T$GT$3add17h74245517aec77e19E", scope: !260, file: !186, line: 651, type: !12, scopeLine: 651, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1102 = distinct !DILocation(line: 185, column: 40, scope: !1092, inlinedAt: !1095)
!1103 = !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !1098)
!1104 = !{!1105}
!1105 = distinct !{!1105, !1106, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E: %self"}
!1106 = distinct !{!1106, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E"}
!1107 = !DILocation(line: 236, column: 80, scope: !1108, inlinedAt: !1111)
!1108 = distinct !DILexicalBlock(scope: !1109, file: !1070, line: 236, column: 80)
!1109 = distinct !DISubprogram(name: "{closure#0}", linkageName: "_ZN7bitcoin9blockdata6script15read_scriptbool28_$u7b$$u7b$closure$u7d$$u7d$17h64cea24b2857c87fE", scope: !1110, file: !1070, line: 236, type: !12, scopeLine: 236, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1110 = !DINamespace(name: "read_scriptbool", scope: !366)
!1111 = distinct !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !1098)
!1112 = !DILocation(line: 0, scope: !1069, inlinedAt: !1071)
!1113 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !1114)
!1114 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !1115)
!1115 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !1116)
!1116 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !1117)
!1117 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !1118)
!1118 = distinct !DILocation(line: 538, column: 25, scope: !945)
!1119 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !1120)
!1120 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !1121)
!1121 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !1122)
!1122 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !1123)
!1123 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !1115)
!1124 = !{!1125}
!1125 = distinct !{!1125, !1126, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!1126 = distinct !{!1126, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!1127 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !1121)
!1128 = !DILocation(line: 1514, column: 5, scope: !1129, inlinedAt: !1130)
!1129 = distinct !DISubprogram(name: "is_minimal_if_arg", linkageName: "_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE", scope: !9, file: !8, line: 1513, type: !12, scopeLine: 1513, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1130 = distinct !DILocation(line: 534, column: 47, scope: !1064)
!1131 = !DILocation(line: 157, column: 18, scope: !1132, inlinedAt: !1137)
!1132 = distinct !DISubprogram(name: "spec_eq<u8, u8, 1>", linkageName: "_ZN69_$LT$T$u20$as$u20$core..array..equality..SpecArrayEq$LT$U$C$_$GT$$GT$7spec_eq17hf148ce6c667e7237E", scope: !1134, file: !1133, line: 153, type: !12, scopeLine: 153, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1133 = !DIFile(filename: "library/core/src/array/equality.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "1a0823a6c30a4b75bb7112adc588a407")
!1134 = !DINamespace(name: "{impl#9}", scope: !1135)
!1135 = !DINamespace(name: "equality", scope: !1136)
!1136 = !DINamespace(name: "array", scope: !39)
!1137 = distinct !DILocation(line: 11, column: 9, scope: !1138, inlinedAt: !1140)
!1138 = distinct !DISubprogram(name: "eq<u8, u8, 1>", linkageName: "_ZN4core5array8equality103_$LT$impl$u20$core..cmp..PartialEq$LT$$u5b$U$u3b$$u20$N$u5d$$GT$$u20$for$u20$$u5b$T$u3b$$u20$N$u5d$$GT$2eq17h92374644d98573d4E", scope: !1139, file: !1133, line: 10, type: !12, scopeLine: 10, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1139 = !DINamespace(name: "{impl#0}", scope: !1135)
!1140 = distinct !DILocation(line: 50, column: 24, scope: !1141, inlinedAt: !1144)
!1141 = distinct !DILexicalBlock(scope: !1142, file: !1133, line: 50, column: 13)
!1142 = distinct !DISubprogram(name: "eq<u8, u8, 1>", linkageName: "_ZN4core5array8equality92_$LT$impl$u20$core..cmp..PartialEq$LT$$u5b$U$u3b$$u20$N$u5d$$GT$$u20$for$u20$$u5b$T$u5d$$GT$2eq17h996e807d6d497fd6E", scope: !1143, file: !1133, line: 48, type: !12, scopeLine: 48, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1143 = !DINamespace(name: "{impl#2}", scope: !1135)
!1144 = distinct !DILocation(line: 87, column: 9, scope: !1145, inlinedAt: !1147)
!1145 = distinct !DISubprogram(name: "eq<u8, u8, 1>", linkageName: "_ZN4core5array8equality96_$LT$impl$u20$core..cmp..PartialEq$LT$$u5b$U$u3b$$u20$N$u5d$$GT$$u20$for$u20$$RF$$u5b$T$u5d$$GT$2eq17hca337768928355f1E", scope: !1146, file: !1133, line: 86, type: !12, scopeLine: 86, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1146 = !DINamespace(name: "{impl#4}", scope: !1135)
!1147 = distinct !DILocation(line: 1514, column: 21, scope: !1129, inlinedAt: !1130)
!1148 = !{!1149}
!1149 = distinct !{!1149, !1150, !"_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE: %v.0"}
!1150 = distinct !{!1150, !"_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE"}
!1151 = !DILocation(line: 534, column: 47, scope: !1064)
!1152 = !DILocation(line: 0, scope: !199, inlinedAt: !1153)
!1153 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !1154)
!1154 = !DILocation(line: 177, column: 20, scope: !1155, inlinedAt: !1156)
!1155 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 14)
!1156 = !DILocation(line: 965, column: 20, scope: !1157, inlinedAt: !1158)
!1157 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 14)
!1158 = !DILocation(line: 448, column: 29, scope: !1159, inlinedAt: !1161)
!1159 = !DILexicalBlockFile(scope: !1160, file: !209, discriminator: 14)
!1160 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!1161 = !DILocation(line: 400, column: 16, scope: !1162, inlinedAt: !1163)
!1162 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 14)
!1163 = !DILocation(line: 376, column: 14, scope: !1164, inlinedAt: !1165)
!1164 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 14)
!1165 = !DILocation(line: 842, column: 14, scope: !1166, inlinedAt: !1167)
!1166 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 12)
!1167 = !DILocation(line: 211, column: 62, scope: !1168, inlinedAt: !1169)
!1168 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 12)
!1169 = !DILocation(line: 3114, column: 11, scope: !1170, inlinedAt: !1171)
!1170 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 12)
!1171 = !DILocation(line: 778, column: 9, scope: !1172, inlinedAt: !1173)
!1172 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 12)
!1173 = !DILocation(line: 535, column: 79, scope: !1064)
!1174 = !{!1175}
!1175 = distinct !{!1175, !1176, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1176 = distinct !{!1176, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1177 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1178)
!1178 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1179)
!1179 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1180)
!1180 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1181)
!1181 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1153)
!1182 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1153)
!1183 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1153)
!1184 = !DILocation(line: 441, column: 25, scope: !1185, inlinedAt: !1154)
!1185 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!1186 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !1187)
!1187 = !DILocation(line: 1252, column: 18, scope: !1188, inlinedAt: !1189)
!1188 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 14)
!1189 = !DILocation(line: 454, column: 36, scope: !1190, inlinedAt: !1161)
!1190 = !DILexicalBlockFile(scope: !1191, file: !209, discriminator: 14)
!1191 = distinct !DILexicalBlock(scope: !1160, file: !209, line: 448, column: 17)
!1192 = !DILocation(line: 535, column: 40, scope: !1064)
!1193 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !1194)
!1194 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !1195)
!1195 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !1196)
!1196 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !1197)
!1197 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !1198)
!1198 = distinct !DILocation(line: 538, column: 25, scope: !945)
!1199 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !1200)
!1200 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !1201)
!1201 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !1202)
!1202 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !1203)
!1203 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !1195)
!1204 = !{!1205}
!1205 = distinct !{!1205, !1206, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!1206 = distinct !{!1206, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!1207 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !1201)
!1208 = !DILocation(line: 924, column: 13, scope: !615)
!1209 = !DILocation(line: 0, scope: !1210)
!1210 = !DILexicalBlockFile(scope: !611, file: !74, discriminator: 0)
!1211 = !{!1212}
!1212 = distinct !{!1212, !1213, !"_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E: %stack"}
!1213 = distinct !{!1213, !"_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E"}
!1214 = !DILocation(line: 545, column: 37, scope: !947)
!1215 = !DILocation(line: 2791, column: 12, scope: !959, inlinedAt: !1216)
!1216 = distinct !DILocation(line: 1488, column: 10, scope: !961, inlinedAt: !1217)
!1217 = distinct !DILocation(line: 545, column: 37, scope: !947)
!1218 = !{!1219}
!1219 = distinct !{!1219, !1213, !"_ZN18rbitcoin_consensus6script11interpreter3pop17hd57423e0432511c0E: %_0"}
!1220 = !DILocation(line: 0, scope: !199, inlinedAt: !1221)
!1221 = distinct !DILocation(line: 433, column: 15, scope: !967, inlinedAt: !1222)
!1222 = distinct !DILocation(line: 177, column: 20, scope: !969, inlinedAt: !1223)
!1223 = distinct !DILocation(line: 965, column: 20, scope: !971, inlinedAt: !1224)
!1224 = distinct !DILocation(line: 448, column: 29, scope: !973, inlinedAt: !1225)
!1225 = distinct !DILocation(line: 400, column: 16, scope: !976, inlinedAt: !1226)
!1226 = distinct !DILocation(line: 376, column: 14, scope: !978, inlinedAt: !1227)
!1227 = distinct !DILocation(line: 842, column: 14, scope: !980, inlinedAt: !1228)
!1228 = distinct !DILocation(line: 211, column: 62, scope: !982, inlinedAt: !1229)
!1229 = distinct !DILocation(line: 3114, column: 11, scope: !984, inlinedAt: !1230)
!1230 = distinct !DILocation(line: 778, column: 9, scope: !986, inlinedAt: !1231)
!1231 = distinct !DILocation(line: 1489, column: 61, scope: !988, inlinedAt: !1232)
!1232 = distinct !DILocation(line: 1369, column: 25, scope: !991, inlinedAt: !1233)
!1233 = distinct !DILocation(line: 1489, column: 10, scope: !961, inlinedAt: !1217)
!1234 = !{!1235, !1237, !1219, !1212}
!1235 = distinct !{!1235, !1236, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1236 = distinct !{!1236, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1237 = distinct !{!1237, !1238, !"_ZN18rbitcoin_consensus6script11interpreter3pop28_$u7b$$u7b$closure$u7d$$u7d$17h314c249baa1729b1E: %_0"}
!1238 = distinct !{!1238, !"_ZN18rbitcoin_consensus6script11interpreter3pop28_$u7b$$u7b$closure$u7d$$u7d$17h314c249baa1729b1E"}
!1239 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1240)
!1240 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1241)
!1241 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1242)
!1242 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1243)
!1243 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1221)
!1244 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1221)
!1245 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1221)
!1246 = !DILocation(line: 441, column: 25, scope: !1006, inlinedAt: !1222)
!1247 = !{!1237, !1219, !1212}
!1248 = !DILocation(line: 426, column: 12, scope: !1009, inlinedAt: !1249)
!1249 = distinct !DILocation(line: 551, column: 36, scope: !947)
!1250 = !DILocation(line: 429, column: 9, scope: !1009, inlinedAt: !1249)
!1251 = !DILocation(line: 547, column: 14, scope: !1016, inlinedAt: !1252)
!1252 = distinct !DILocation(line: 1252, column: 18, scope: !1018, inlinedAt: !1253)
!1253 = distinct !DILocation(line: 454, column: 36, scope: !1020, inlinedAt: !1225)
!1254 = !DILocation(line: 2189, column: 23, scope: !1255, inlinedAt: !1256)
!1255 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!1256 = !DILocation(line: 545, column: 37, scope: !1257)
!1257 = !DILexicalBlockFile(scope: !1258, file: !8, discriminator: 2)
!1258 = distinct !DILexicalBlock(scope: !1259, file: !8, line: 545, column: 47)
!1259 = distinct !DILexicalBlock(scope: !947, file: !8, line: 545, column: 47)
!1260 = !DILocation(line: 0, scope: !1261)
!1261 = !DILexicalBlockFile(scope: !947, file: !74, discriminator: 0)
!1262 = !DILocation(line: 2795, column: 17, scope: !959, inlinedAt: !1216)
!1263 = !DILocation(line: 617, column: 49, scope: !1031, inlinedAt: !1264)
!1264 = distinct !DILocation(line: 308, column: 20, scope: !1033, inlinedAt: !1265)
!1265 = distinct !DILocation(line: 1422, column: 18, scope: !1035, inlinedAt: !1266)
!1266 = distinct !DILocation(line: 2796, column: 62, scope: !959, inlinedAt: !1216)
!1267 = !DILocation(line: 2796, column: 46, scope: !959, inlinedAt: !1216)
!1268 = !DILocation(line: 210, column: 9, scope: !1039, inlinedAt: !1269)
!1269 = distinct !DILocation(line: 2796, column: 17, scope: !959, inlinedAt: !1216)
!1270 = !DILocation(line: 612, column: 9, scope: !1044, inlinedAt: !1271)
!1271 = distinct !DILocation(line: 607, column: 14, scope: !1046, inlinedAt: !1272)
!1272 = distinct !DILocation(line: 295, column: 20, scope: !1048, inlinedAt: !1273)
!1273 = distinct !DILocation(line: 1916, column: 18, scope: !1050, inlinedAt: !1274)
!1274 = distinct !DILocation(line: 2797, column: 37, scope: !959, inlinedAt: !1216)
!1275 = !DILocation(line: 3002, column: 37, scope: !1053, inlinedAt: !1276)
!1276 = distinct !DILocation(line: 2797, column: 55, scope: !959, inlinedAt: !1216)
!1277 = !DILocation(line: 3002, column: 18, scope: !1053, inlinedAt: !1276)
!1278 = !DILocation(line: 863, column: 18, scope: !1058, inlinedAt: !1279)
!1279 = distinct !DILocation(line: 2797, column: 46, scope: !959, inlinedAt: !1216)
!1280 = !DILocation(line: 1717, column: 9, scope: !1061, inlinedAt: !1281)
!1281 = distinct !DILocation(line: 2797, column: 22, scope: !959, inlinedAt: !1216)
!1282 = !DILocation(line: 546, column: 32, scope: !1283)
!1283 = distinct !DILexicalBlock(scope: !947, file: !8, line: 545, column: 29)
!1284 = !DILocation(line: 241, column: 16, scope: !1066, inlinedAt: !1285)
!1285 = distinct !DILocation(line: 235, column: 13, scope: !1069, inlinedAt: !1286)
!1286 = distinct !DILocation(line: 549, column: 37, scope: !1283)
!1287 = !DILocation(line: 241, column: 28, scope: !1066, inlinedAt: !1285)
!1288 = !DILocation(line: 28, column: 31, scope: !1074, inlinedAt: !1289)
!1289 = distinct !DILocation(line: 236, column: 34, scope: !1079, inlinedAt: !1286)
!1290 = !{!1291}
!1291 = distinct !{!1291, !1292, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE: %v.0"}
!1292 = distinct !{!1292, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE"}
!1293 = !DILocation(line: 178, column: 46, scope: !1084, inlinedAt: !1294)
!1294 = distinct !DILocation(line: 28, column: 17, scope: !1074, inlinedAt: !1289)
!1295 = !DILocation(line: 236, column: 33, scope: !1079, inlinedAt: !1286)
!1296 = !DILocation(line: 1720, column: 9, scope: !1090, inlinedAt: !1297)
!1297 = distinct !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !1298)
!1298 = distinct !DILocation(line: 314, column: 42, scope: !1096, inlinedAt: !1299)
!1299 = distinct !DILocation(line: 236, column: 71, scope: !1079, inlinedAt: !1286)
!1300 = !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !1298)
!1301 = !DILocation(line: 659, column: 28, scope: !1101, inlinedAt: !1302)
!1302 = distinct !DILocation(line: 185, column: 40, scope: !1092, inlinedAt: !1298)
!1303 = !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !1299)
!1304 = !{!1305}
!1305 = distinct !{!1305, !1306, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E: %self"}
!1306 = distinct !{!1306, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E"}
!1307 = !DILocation(line: 236, column: 80, scope: !1108, inlinedAt: !1308)
!1308 = distinct !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !1299)
!1309 = !DILocation(line: 0, scope: !1069, inlinedAt: !1286)
!1310 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !1311)
!1311 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !1312)
!1312 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !1313)
!1313 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !1314)
!1314 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !1315)
!1315 = distinct !DILocation(line: 550, column: 25, scope: !947)
!1316 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !1317)
!1317 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !1318)
!1318 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !1319)
!1319 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !1320)
!1320 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !1312)
!1321 = !{!1322}
!1322 = distinct !{!1322, !1323, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!1323 = distinct !{!1323, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!1324 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !1318)
!1325 = !DILocation(line: 1514, column: 5, scope: !1129, inlinedAt: !1326)
!1326 = distinct !DILocation(line: 546, column: 47, scope: !1283)
!1327 = !DILocation(line: 157, column: 18, scope: !1132, inlinedAt: !1328)
!1328 = distinct !DILocation(line: 11, column: 9, scope: !1138, inlinedAt: !1329)
!1329 = distinct !DILocation(line: 50, column: 24, scope: !1141, inlinedAt: !1330)
!1330 = distinct !DILocation(line: 87, column: 9, scope: !1145, inlinedAt: !1331)
!1331 = distinct !DILocation(line: 1514, column: 21, scope: !1129, inlinedAt: !1326)
!1332 = !{!1333}
!1333 = distinct !{!1333, !1334, !"_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE: %v.0"}
!1334 = distinct !{!1334, !"_ZN18rbitcoin_consensus6script11interpreter17is_minimal_if_arg17h10ee9ea5760b59baE"}
!1335 = !DILocation(line: 546, column: 47, scope: !1283)
!1336 = !DILocation(line: 0, scope: !199, inlinedAt: !1337)
!1337 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !1338)
!1338 = !DILocation(line: 177, column: 20, scope: !1339, inlinedAt: !1340)
!1339 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 16)
!1340 = !DILocation(line: 965, column: 20, scope: !1341, inlinedAt: !1342)
!1341 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 16)
!1342 = !DILocation(line: 448, column: 29, scope: !1343, inlinedAt: !1345)
!1343 = !DILexicalBlockFile(scope: !1344, file: !209, discriminator: 16)
!1344 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!1345 = !DILocation(line: 400, column: 16, scope: !1346, inlinedAt: !1347)
!1346 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 16)
!1347 = !DILocation(line: 376, column: 14, scope: !1348, inlinedAt: !1349)
!1348 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 16)
!1349 = !DILocation(line: 842, column: 14, scope: !1350, inlinedAt: !1351)
!1350 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 14)
!1351 = !DILocation(line: 211, column: 62, scope: !1352, inlinedAt: !1353)
!1352 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 14)
!1353 = !DILocation(line: 3114, column: 11, scope: !1354, inlinedAt: !1355)
!1354 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 14)
!1355 = !DILocation(line: 778, column: 9, scope: !1356, inlinedAt: !1357)
!1356 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 14)
!1357 = !DILocation(line: 547, column: 79, scope: !1283)
!1358 = !{!1359}
!1359 = distinct !{!1359, !1360, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1360 = distinct !{!1360, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1361 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1362)
!1362 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1363)
!1363 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1364)
!1364 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1365)
!1365 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1337)
!1366 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1337)
!1367 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1337)
!1368 = !DILocation(line: 441, column: 25, scope: !1369, inlinedAt: !1338)
!1369 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!1370 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !1371)
!1371 = !DILocation(line: 1252, column: 18, scope: !1372, inlinedAt: !1373)
!1372 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 16)
!1373 = !DILocation(line: 454, column: 36, scope: !1374, inlinedAt: !1345)
!1374 = !DILexicalBlockFile(scope: !1375, file: !209, discriminator: 16)
!1375 = distinct !DILexicalBlock(scope: !1344, file: !209, line: 448, column: 17)
!1376 = !DILocation(line: 547, column: 40, scope: !1283)
!1377 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !1378)
!1378 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !1379)
!1379 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !1380)
!1380 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !1381)
!1381 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !1382)
!1382 = distinct !DILocation(line: 550, column: 25, scope: !947)
!1383 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !1384)
!1384 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !1385)
!1385 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !1386)
!1386 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !1387)
!1387 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !1379)
!1388 = !{!1389}
!1389 = distinct !{!1389, !1390, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!1390 = distinct !{!1390, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!1391 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !1385)
!1392 = !DILocation(line: 442, column: 19, scope: !1393, inlinedAt: !1394)
!1393 = distinct !DISubprogram(name: "toggle_top", linkageName: "_ZN18rbitcoin_consensus6script11interpreter14ConditionStack10toggle_top17h35b9d55dee90f6a7E", scope: !392, file: !8, line: 441, type: !12, scopeLine: 441, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1394 = distinct !DILocation(line: 558, column: 36, scope: !623)
!1395 = !DILocation(line: 443, column: 9, scope: !1396, inlinedAt: !1394)
!1396 = distinct !DILexicalBlock(scope: !1393, file: !8, line: 442, column: 9)
!1397 = !DILocation(line: 445, column: 26, scope: !1396, inlinedAt: !1394)
!1398 = !DILocation(line: 0, scope: !199, inlinedAt: !1399)
!1399 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !1400)
!1400 = !DILocation(line: 177, column: 20, scope: !1401, inlinedAt: !1402)
!1401 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 18)
!1402 = !DILocation(line: 965, column: 20, scope: !1403, inlinedAt: !1404)
!1403 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 18)
!1404 = !DILocation(line: 448, column: 29, scope: !1405, inlinedAt: !1407)
!1405 = !DILexicalBlockFile(scope: !1406, file: !209, discriminator: 18)
!1406 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!1407 = !DILocation(line: 400, column: 16, scope: !1408, inlinedAt: !1409)
!1408 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 18)
!1409 = !DILocation(line: 376, column: 14, scope: !1410, inlinedAt: !1411)
!1410 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 18)
!1411 = !DILocation(line: 842, column: 14, scope: !1412, inlinedAt: !1413)
!1412 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 16)
!1413 = !DILocation(line: 211, column: 62, scope: !1414, inlinedAt: !1415)
!1414 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 16)
!1415 = !DILocation(line: 3114, column: 11, scope: !1416, inlinedAt: !1417)
!1416 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 16)
!1417 = !DILocation(line: 778, column: 9, scope: !1418, inlinedAt: !1419)
!1418 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 16)
!1419 = !DILocation(line: 556, column: 73, scope: !623)
!1420 = !{!1421}
!1421 = distinct !{!1421, !1422, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1422 = distinct !{!1422, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1423 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1424)
!1424 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1425)
!1425 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1426)
!1426 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1427)
!1427 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1399)
!1428 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1399)
!1429 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1399)
!1430 = !DILocation(line: 441, column: 25, scope: !1431, inlinedAt: !1400)
!1431 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!1432 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !1433)
!1433 = !DILocation(line: 1252, column: 18, scope: !1434, inlinedAt: !1435)
!1434 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 18)
!1435 = !DILocation(line: 454, column: 36, scope: !1436, inlinedAt: !1407)
!1436 = !DILexicalBlockFile(scope: !1437, file: !209, discriminator: 18)
!1437 = distinct !DILexicalBlock(scope: !1406, file: !209, line: 448, column: 17)
!1438 = !DILocation(line: 556, column: 36, scope: !623)
!1439 = !DILocation(line: 434, column: 9, scope: !1440, inlinedAt: !1441)
!1440 = distinct !DISubprogram(name: "pop", linkageName: "_ZN18rbitcoin_consensus6script11interpreter14ConditionStack3pop17h95a81502ba887774E", scope: !392, file: !8, line: 433, type: !12, scopeLine: 433, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1441 = distinct !DILocation(line: 565, column: 36, scope: !623)
!1442 = !DILocation(line: 2427, column: 9, scope: !1443, inlinedAt: !1445)
!1443 = distinct !DISubprogram(name: "eq<usize>", linkageName: "_ZN70_$LT$core..option..Option$LT$T$GT$$u20$as$u20$core..cmp..PartialEq$GT$2eq17haf051b1282fd60c5E", scope: !1444, file: !702, line: 2424, type: !12, scopeLine: 2424, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1444 = !DINamespace(name: "{impl#17}", scope: !704)
!1445 = distinct !DILocation(line: 435, column: 12, scope: !1440, inlinedAt: !1441)
!1446 = !DILocation(line: 0, scope: !199, inlinedAt: !1447)
!1447 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !1448)
!1448 = !DILocation(line: 177, column: 20, scope: !1449, inlinedAt: !1450)
!1449 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 20)
!1450 = !DILocation(line: 965, column: 20, scope: !1451, inlinedAt: !1452)
!1451 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 20)
!1452 = !DILocation(line: 448, column: 29, scope: !1453, inlinedAt: !1455)
!1453 = !DILexicalBlockFile(scope: !1454, file: !209, discriminator: 20)
!1454 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!1455 = !DILocation(line: 400, column: 16, scope: !1456, inlinedAt: !1457)
!1456 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 20)
!1457 = !DILocation(line: 376, column: 14, scope: !1458, inlinedAt: !1459)
!1458 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 20)
!1459 = !DILocation(line: 842, column: 14, scope: !1460, inlinedAt: !1461)
!1460 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 18)
!1461 = !DILocation(line: 211, column: 62, scope: !1462, inlinedAt: !1463)
!1462 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 18)
!1463 = !DILocation(line: 3114, column: 11, scope: !1464, inlinedAt: !1465)
!1464 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 18)
!1465 = !DILocation(line: 778, column: 9, scope: !1466, inlinedAt: !1467)
!1466 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 18)
!1467 = !DILocation(line: 563, column: 74, scope: !623)
!1468 = !{!1469}
!1469 = distinct !{!1469, !1470, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1470 = distinct !{!1470, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1471 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1472)
!1472 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1473)
!1473 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1474)
!1474 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1475)
!1475 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1447)
!1476 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1447)
!1477 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1447)
!1478 = !DILocation(line: 441, column: 25, scope: !1479, inlinedAt: !1448)
!1479 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!1480 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !1481)
!1481 = !DILocation(line: 1252, column: 18, scope: !1482, inlinedAt: !1483)
!1482 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 20)
!1483 = !DILocation(line: 454, column: 36, scope: !1484, inlinedAt: !1455)
!1484 = !DILexicalBlockFile(scope: !1485, file: !209, discriminator: 20)
!1485 = distinct !DILexicalBlock(scope: !1454, file: !209, line: 448, column: 17)
!1486 = !DILocation(line: 563, column: 36, scope: !623)
!1487 = !DILocation(line: 0, scope: !199, inlinedAt: !1488)
!1488 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !1489)
!1489 = !DILocation(line: 177, column: 20, scope: !1490, inlinedAt: !1491)
!1490 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 22)
!1491 = !DILocation(line: 965, column: 20, scope: !1492, inlinedAt: !1493)
!1492 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 22)
!1493 = !DILocation(line: 448, column: 29, scope: !1494, inlinedAt: !1496)
!1494 = !DILexicalBlockFile(scope: !1495, file: !209, discriminator: 22)
!1495 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!1496 = !DILocation(line: 400, column: 16, scope: !1497, inlinedAt: !1498)
!1497 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 22)
!1498 = !DILocation(line: 376, column: 14, scope: !1499, inlinedAt: !1500)
!1499 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 22)
!1500 = !DILocation(line: 842, column: 14, scope: !1501, inlinedAt: !1502)
!1501 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 20)
!1502 = !DILocation(line: 211, column: 62, scope: !1503, inlinedAt: !1504)
!1503 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 20)
!1504 = !DILocation(line: 3114, column: 11, scope: !1505, inlinedAt: !1506)
!1505 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 20)
!1506 = !DILocation(line: 778, column: 9, scope: !1507, inlinedAt: !1508)
!1507 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 20)
!1508 = !DILocation(line: 573, column: 66, scope: !623)
!1509 = !{!1510}
!1510 = distinct !{!1510, !1511, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1511 = distinct !{!1511, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1512 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1513)
!1513 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1514)
!1514 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1515)
!1515 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1516)
!1516 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1488)
!1517 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1488)
!1518 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1488)
!1519 = !DILocation(line: 265, column: 15, scope: !1520, inlinedAt: !1522)
!1520 = distinct !DISubprogram(name: "ne<rbitcoin_consensus::script::interpreter::SigVersion, rbitcoin_consensus::script::interpreter::SigVersion>", linkageName: "_ZN4core3cmp9PartialEq2ne17h95e81f89f27d49beE", scope: !1521, file: !35, line: 264, type: !12, scopeLine: 264, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1521 = !DINamespace(name: "PartialEq", scope: !38)
!1522 = !DILocation(line: 576, column: 20, scope: !623)
!1523 = !DILocation(line: 43, column: 30, scope: !18, inlinedAt: !1524)
!1524 = distinct !DILocation(line: 265, column: 15, scope: !1520, inlinedAt: !1522)
!1525 = !DILocation(line: 441, column: 25, scope: !1526, inlinedAt: !1489)
!1526 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!1527 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !1528)
!1528 = !DILocation(line: 1252, column: 18, scope: !1529, inlinedAt: !1530)
!1529 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 22)
!1530 = !DILocation(line: 454, column: 36, scope: !1531, inlinedAt: !1496)
!1531 = !DILexicalBlockFile(scope: !1532, file: !209, discriminator: 22)
!1532 = distinct !DILexicalBlock(scope: !1495, file: !209, line: 448, column: 17)
!1533 = !DILocation(line: 573, column: 28, scope: !623)
!1534 = !DILocation(line: 73, column: 5, scope: !1535, inlinedAt: !1539)
!1535 = !DILexicalBlockFile(scope: !1536, file: !8, discriminator: 0)
!1536 = distinct !DILexicalBlock(scope: !1538, file: !1537, line: 433, column: 9)
!1537 = !DIFile(filename: "library/core/src/macros/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "51376b65c07e3acab5731a6bddd7c4b3")
!1538 = distinct !DISubprogram(name: "is_disabled_legacy", linkageName: "_ZN18rbitcoin_consensus6script11interpreter18is_disabled_legacy17hdcdcb5d2a43211a3E", scope: !9, file: !8, line: 72, type: !12, scopeLine: 72, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1539 = distinct !DILocation(line: 576, column: 64, scope: !623)
!1540 = !DILocation(line: 577, column: 32, scope: !623)
!1541 = !DILocation(line: 577, column: 55, scope: !1542)
!1542 = !DILexicalBlockFile(scope: !1543, file: !8, discriminator: 0)
!1543 = distinct !DILexicalBlock(scope: !623, file: !1544, line: 114, column: 33)
!1544 = !DIFile(filename: "library/alloc/src/macros.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "c06fded2c893c2cc0e8ea200156f1086")
!1545 = !DILocation(line: 659, column: 34, scope: !1546, inlinedAt: !1550)
!1546 = distinct !DISubprogram(name: "{closure#0}", linkageName: "_ZN5alloc3fmt6format28_$u7b$$u7b$closure$u7d$$u7d$17hf59d76194c811b04E", scope: !1548, file: !1547, line: 659, type: !12, scopeLine: 659, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1547 = !DIFile(filename: "library/alloc/src/fmt.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "ff238ed6a2e10a790bec34161252a63b")
!1548 = !DINamespace(name: "format", scope: !1549)
!1549 = !DINamespace(name: "fmt", scope: !126)
!1550 = distinct !DILocation(line: 1278, column: 21, scope: !1551, inlinedAt: !1552)
!1551 = distinct !DISubprogram(name: "map_or_else<&str, alloc::string::String, alloc::fmt::format::{closure_env#0}, fn(&str) -> alloc::string::String>", linkageName: "_ZN4core6option15Option$LT$T$GT$11map_or_else17h6f1f113538ade8f7E", scope: !703, file: !702, line: 1271, type: !12, scopeLine: 1271, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1552 = distinct !DILocation(line: 659, column: 19, scope: !1553, inlinedAt: !1554)
!1553 = distinct !DISubprogram(name: "format", linkageName: "_RNvNtCslNYArtu3iFV_5alloc3fmt6format", scope: !1549, file: !1547, line: 649, type: !12, scopeLine: 649, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1554 = !DILocation(line: 577, column: 55, scope: !1555)
!1555 = !DILexicalBlockFile(scope: !623, file: !8, discriminator: 4)
!1556 = !DILocation(line: 577, column: 55, scope: !623)
!1557 = !DILocation(line: 577, column: 28, scope: !623)
!1558 = !DILocation(line: 579, column: 23, scope: !623)
!1559 = !DILocation(line: 582, column: 36, scope: !623)
!1560 = !DILocation(line: 586, column: 21, scope: !623)
!1561 = !DILocation(line: 0, scope: !199, inlinedAt: !1562)
!1562 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !1563)
!1563 = !DILocation(line: 177, column: 20, scope: !1564, inlinedAt: !1565)
!1564 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 24)
!1565 = !DILocation(line: 965, column: 20, scope: !1566, inlinedAt: !1567)
!1566 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 24)
!1567 = !DILocation(line: 448, column: 29, scope: !1568, inlinedAt: !1570)
!1568 = !DILexicalBlockFile(scope: !1569, file: !209, discriminator: 24)
!1569 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!1570 = !DILocation(line: 400, column: 16, scope: !1571, inlinedAt: !1572)
!1571 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 24)
!1572 = !DILocation(line: 376, column: 14, scope: !1573, inlinedAt: !1574)
!1573 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 24)
!1574 = !DILocation(line: 842, column: 14, scope: !1575, inlinedAt: !1576)
!1575 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 22)
!1576 = !DILocation(line: 211, column: 62, scope: !1577, inlinedAt: !1578)
!1577 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 22)
!1578 = !DILocation(line: 3114, column: 11, scope: !1579, inlinedAt: !1580)
!1579 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 22)
!1580 = !DILocation(line: 778, column: 9, scope: !1581, inlinedAt: !1582)
!1581 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 22)
!1582 = !DILocation(line: 583, column: 74, scope: !623)
!1583 = !{!1584}
!1584 = distinct !{!1584, !1585, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1585 = distinct !{!1585, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1586 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1587)
!1587 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1588)
!1588 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1589)
!1589 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1590)
!1590 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1562)
!1591 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1562)
!1592 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1562)
!1593 = !DILocation(line: 441, column: 25, scope: !1594, inlinedAt: !1563)
!1594 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!1595 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !1596)
!1596 = !DILocation(line: 1252, column: 18, scope: !1597, inlinedAt: !1598)
!1597 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 24)
!1598 = !DILocation(line: 454, column: 36, scope: !1599, inlinedAt: !1570)
!1599 = !DILexicalBlockFile(scope: !1600, file: !209, discriminator: 24)
!1600 = distinct !DILexicalBlock(scope: !1569, file: !209, line: 448, column: 17)
!1601 = !DILocation(line: 583, column: 28, scope: !623)
!1602 = !DILocation(line: 590, column: 26, scope: !623)
!1603 = !DILocation(line: 595, column: 17, scope: !1604)
!1604 = distinct !DILexicalBlock(scope: !623, file: !8, line: 590, column: 17)
!1605 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1606)
!1606 = !DILocation(line: 599, column: 50, scope: !1604)
!1607 = !DILocation(line: 3002, column: 37, scope: !1608, inlinedAt: !1606)
!1608 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1609 = !DILocation(line: 3002, column: 18, scope: !1608, inlinedAt: !1606)
!1610 = !DILocation(line: 190, scope: !246, inlinedAt: !1611)
!1611 = distinct !DILocation(line: 312, column: 9, scope: !1612, inlinedAt: !1613)
!1612 = distinct !DISubprogram(name: "alloc_impl", linkageName: "_RNvMNtCslNYArtu3iFV_5alloc5allocNtB2_6Global10alloc_impl", scope: !248, file: !243, line: 311, type: !12, scopeLine: 311, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1613 = distinct !DILocation(line: 429, column: 14, scope: !1614, inlinedAt: !1615)
!1614 = distinct !DISubprogram(name: "allocate", linkageName: "_RNvXs_NtCslNYArtu3iFV_5alloc5allocNtB4_6GlobalNtNtCsgEmfK2I1SDS_4core5alloc9Allocator8allocate", scope: !253, file: !243, line: 428, type: !12, scopeLine: 428, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1615 = distinct !DILocation(line: 248, column: 18, scope: !1616, inlinedAt: !1619)
!1616 = distinct !DISubprogram(name: "box_new_uninit", linkageName: "_RNvNtCslNYArtu3iFV_5alloc5boxed14box_new_uninit", scope: !1618, file: !1617, line: 247, type: !12, scopeLine: 247, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1617 = !DIFile(filename: "library/alloc/src/boxed.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "c2c961396e00891ae9e97f5dc112a35a")
!1618 = !DINamespace(name: "boxed", scope: !126)
!1619 = distinct !DILocation(line: 317, column: 33, scope: !1620, inlinedAt: !1622)
!1620 = distinct !DISubprogram(name: "new_uninit<[u8; 1]>", linkageName: "_ZN5alloc5boxed12Box$LT$T$GT$10new_uninit17h1456ea71b3054522E", scope: !1621, file: !1617, line: 311, type: !12, scopeLine: 311, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1621 = !DINamespace(name: "{impl#0}", scope: !1618)
!1622 = !DILocation(line: 599, column: 57, scope: !1604)
!1623 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1624)
!1624 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1611)
!1625 = !DILocation(line: 248, column: 11, scope: !1616, inlinedAt: !1619)
!1626 = !DILocation(line: 248, column: 5, scope: !1616, inlinedAt: !1619)
!1627 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!1628 = !DILocation(line: 250, column: 19, scope: !1616, inlinedAt: !1619)
!1629 = !{!1630}
!1630 = distinct !{!1630, !1631, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE: %stack"}
!1631 = distinct !{!1631, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE"}
!1632 = !DILocation(line: 599, column: 29, scope: !1604)
!1633 = !DILocation(line: 2997, column: 19, scope: !779, inlinedAt: !1634)
!1634 = distinct !DILocation(line: 1479, column: 14, scope: !781, inlinedAt: !1635)
!1635 = distinct !DILocation(line: 599, column: 29, scope: !1604)
!1636 = !{!1637, !1638}
!1637 = distinct !{!1637, !1631, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE: %_0"}
!1638 = distinct !{!1638, !1631, !"_ZN18rbitcoin_consensus6script11interpreter4push17h9901103c7688f27aE: %v"}
!1639 = !DILocation(line: 3002, column: 37, scope: !787, inlinedAt: !1634)
!1640 = !DILocation(line: 3002, column: 18, scope: !787, inlinedAt: !1634)
!1641 = !DILocation(line: 2301, column: 13, scope: !790, inlinedAt: !1642)
!1642 = distinct !DILocation(line: 1479, column: 20, scope: !781, inlinedAt: !1635)
!1643 = !DILocation(line: 1479, column: 8, scope: !781, inlinedAt: !1635)
!1644 = !DILocation(line: 617, column: 49, scope: !794, inlinedAt: !1645)
!1645 = distinct !DILocation(line: 308, column: 20, scope: !796, inlinedAt: !1646)
!1646 = distinct !DILocation(line: 1028, column: 28, scope: !798, inlinedAt: !1647)
!1647 = distinct !DILocation(line: 992, column: 22, scope: !801, inlinedAt: !1648)
!1648 = distinct !DILocation(line: 1482, column: 11, scope: !781, inlinedAt: !1635)
!1649 = !{!1650, !1630}
!1650 = distinct !{!1650, !1651, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E: %self"}
!1651 = distinct !{!1651, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E"}
!1652 = !{!1653, !1637, !1638}
!1653 = distinct !{!1653, !1651, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E: %value"}
!1654 = !DILocation(line: 1028, column: 12, scope: !798, inlinedAt: !1647)
!1655 = !DILocation(line: 1029, column: 22, scope: !798, inlinedAt: !1647)
!1656 = !DILocation(line: 1028, column: 9, scope: !798, inlinedAt: !1647)
!1657 = !DILocation(line: 0, scope: !199, inlinedAt: !1658)
!1658 = distinct !DILocation(line: 433, column: 15, scope: !813, inlinedAt: !1659)
!1659 = distinct !DILocation(line: 177, column: 20, scope: !815, inlinedAt: !1660)
!1660 = distinct !DILocation(line: 965, column: 20, scope: !817, inlinedAt: !1661)
!1661 = distinct !DILocation(line: 448, column: 29, scope: !819, inlinedAt: !1662)
!1662 = distinct !DILocation(line: 400, column: 16, scope: !822, inlinedAt: !1663)
!1663 = distinct !DILocation(line: 376, column: 14, scope: !824, inlinedAt: !1664)
!1664 = distinct !DILocation(line: 842, column: 14, scope: !826, inlinedAt: !1665)
!1665 = distinct !DILocation(line: 211, column: 62, scope: !828, inlinedAt: !1666)
!1666 = distinct !DILocation(line: 3114, column: 11, scope: !830, inlinedAt: !1667)
!1667 = distinct !DILocation(line: 778, column: 9, scope: !832, inlinedAt: !1668)
!1668 = distinct !DILocation(line: 1480, column: 56, scope: !781, inlinedAt: !1635)
!1669 = !{!1670, !1637, !1630, !1638}
!1670 = distinct !{!1670, !1671, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!1671 = distinct !{!1671, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!1672 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !1673)
!1673 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !1674)
!1674 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !1675)
!1675 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !1676)
!1676 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !1658)
!1677 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !1658)
!1678 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !1658)
!1679 = !DILocation(line: 441, column: 25, scope: !845, inlinedAt: !1659)
!1680 = !{!1637, !1630, !1638}
!1681 = !DILocation(line: 873, column: 9, scope: !46, inlinedAt: !1682)
!1682 = distinct !DILocation(line: 527, column: 9, scope: !1683, inlinedAt: !1684)
!1683 = distinct !DISubprogram(name: "contains<u8, u8>", linkageName: "_ZN4core3ops5range25RangeInclusive$LT$Idx$GT$8contains17h19b0330085d584e4E", scope: !52, file: !45, line: 522, type: !12, scopeLine: 522, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1684 = !DILocation(line: 600, column: 40, scope: !1604)
!1685 = !DILocation(line: 547, column: 14, scope: !848, inlinedAt: !1686)
!1686 = distinct !DILocation(line: 1252, column: 18, scope: !850, inlinedAt: !1687)
!1687 = distinct !DILocation(line: 454, column: 36, scope: !852, inlinedAt: !1662)
!1688 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !1689)
!1689 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !1690)
!1690 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !1691)
!1691 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !1692)
!1692 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !1693)
!1693 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !1694)
!1694 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !1695)
!1695 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !1696)
!1696 = distinct !DILocation(line: 1484, column: 1, scope: !781, inlinedAt: !1635)
!1697 = !{!1698, !1637, !1630, !1638}
!1698 = distinct !{!1698, !1699, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!1699 = distinct !{!1699, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!1700 = !DILocation(line: 2189, column: 23, scope: !1701, inlinedAt: !1702)
!1701 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!1702 = !DILocation(line: 599, column: 29, scope: !1703)
!1703 = !DILexicalBlockFile(scope: !1704, file: !8, discriminator: 2)
!1704 = distinct !DILexicalBlock(scope: !1705, file: !8, line: 599, column: 68)
!1705 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 599, column: 68)
!1706 = !DILocation(line: 0, scope: !1707)
!1707 = !DILexicalBlockFile(scope: !1604, file: !74, discriminator: 0)
!1708 = !DILocation(line: 612, column: 9, scope: !882, inlinedAt: !1709)
!1709 = distinct !DILocation(line: 607, column: 14, scope: !884, inlinedAt: !1710)
!1710 = distinct !DILocation(line: 295, column: 20, scope: !886, inlinedAt: !1711)
!1711 = distinct !DILocation(line: 2000, column: 18, scope: !888, inlinedAt: !1712)
!1712 = distinct !DILocation(line: 1032, column: 28, scope: !798, inlinedAt: !1647)
!1713 = !DILocation(line: 961, column: 18, scope: !891, inlinedAt: !1714)
!1714 = distinct !DILocation(line: 1032, column: 41, scope: !798, inlinedAt: !1647)
!1715 = !DILocation(line: 1917, column: 41, scope: !894, inlinedAt: !1716)
!1716 = distinct !DILocation(line: 1033, column: 13, scope: !896, inlinedAt: !1647)
!1717 = !{!1637}
!1718 = !DILocation(line: 1034, column: 13, scope: !896, inlinedAt: !1647)
!1719 = !DILocation(line: 599, column: 68, scope: !1604)
!1720 = !DILocation(line: 924, column: 13, scope: !611)
!1721 = !DILocation(line: 600, column: 56, scope: !1722)
!1722 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 600, column: 21)
!1723 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1724)
!1724 = !DILocation(line: 600, column: 77, scope: !1722)
!1725 = !DILocation(line: 3002, column: 37, scope: !1726, inlinedAt: !1724)
!1726 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1727 = !DILocation(line: 3002, column: 18, scope: !1726, inlinedAt: !1724)
!1728 = !DILocation(line: 600, column: 84, scope: !1722)
!1729 = !DILocation(line: 317, column: 33, scope: !1620, inlinedAt: !1728)
!1730 = !DILocation(line: 600, column: 89, scope: !1722)
!1731 = !DILocation(line: 1187, column: 18, scope: !1732, inlinedAt: !1733)
!1732 = distinct !DISubprogram(name: "from_raw_parts_in<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$17from_raw_parts_in17h4654d935d4c51502E", scope: !124, file: !123, line: 1181, type: !12, scopeLine: 1181, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1733 = !DILocation(line: 484, column: 13, scope: !1734, inlinedAt: !1738)
!1734 = !DILexicalBlockFile(scope: !1735, file: !209, discriminator: 2)
!1735 = distinct !DILexicalBlock(scope: !1736, file: !209, line: 483, column: 13)
!1736 = distinct !DILexicalBlock(scope: !1737, file: !209, line: 482, column: 13)
!1737 = distinct !DISubprogram(name: "into_vec<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$8into_vec17h37889597dac96b96E", scope: !213, file: !209, line: 480, type: !12, scopeLine: 480, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1738 = !DILocation(line: 265, column: 44, scope: !1739, inlinedAt: !1741)
!1739 = !DILexicalBlockFile(scope: !1740, file: !1617, discriminator: 2)
!1740 = distinct !DISubprogram(name: "box_assume_init_into_vec_unsafe<u8, 1>", linkageName: "_ZN5alloc5boxed31box_assume_init_into_vec_unsafe17h5c4b6777dd1c4a23E", scope: !1618, file: !1617, line: 262, type: !12, scopeLine: 262, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1741 = !DILocation(line: 600, column: 84, scope: !1742)
!1742 = !DILexicalBlockFile(scope: !1722, file: !8, discriminator: 2)
!1743 = !DILocation(line: 600, column: 98, scope: !1722)
!1744 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1721)
!1745 = distinct !DISubprogram(name: "branch<(), rbitcoin_consensus::error::ConsensusError>", linkageName: "_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17hfdb033ce369be045E", scope: !1746, file: !384, line: 2172, type: !12, scopeLine: 2172, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1746 = !DINamespace(name: "{impl#27}", scope: !386)
!1747 = !{i64 0, i64 -9223372036854775796}
!1748 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1721)
!1749 = !DILocation(line: 919, column: 36, scope: !1604)
!1750 = !DILocation(line: 919, column: 59, scope: !1751)
!1751 = !DILexicalBlockFile(scope: !1752, file: !8, discriminator: 0)
!1752 = distinct !DILexicalBlock(scope: !1604, file: !1544, line: 114, column: 33)
!1753 = !DILocation(line: 659, column: 34, scope: !1546, inlinedAt: !1754)
!1754 = distinct !DILocation(line: 1278, column: 21, scope: !1551, inlinedAt: !1755)
!1755 = distinct !DILocation(line: 659, column: 19, scope: !1553, inlinedAt: !1756)
!1756 = !DILocation(line: 919, column: 59, scope: !1757)
!1757 = !DILexicalBlockFile(scope: !1604, file: !8, discriminator: 4)
!1758 = !DILocation(line: 919, column: 59, scope: !1604)
!1759 = !DILocation(line: 919, column: 32, scope: !1604)
!1760 = !DILocation(line: 921, column: 27, scope: !1604)
!1761 = !DILocation(line: 919, column: 25, scope: !1604)
!1762 = !DILocation(line: 603, column: 33, scope: !1604)
!1763 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1762)
!1764 = distinct !DISubprogram(name: "branch<alloc::vec::Vec<u8, alloc::alloc::Global>, rbitcoin_consensus::error::ConsensusError>", linkageName: "_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h1400be75f1b26d28E", scope: !1746, file: !384, line: 2172, type: !12, scopeLine: 2172, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1765 = !{i64 0, i64 2}
!1766 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1762)
!1767 = !DILocation(line: 0, scope: !1764, inlinedAt: !1762)
!1768 = !DILocation(line: 603, column: 43, scope: !1604)
!1769 = !DILocation(line: 610, column: 33, scope: !1604)
!1770 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1769)
!1771 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1769)
!1772 = !DILocation(line: 0, scope: !1764, inlinedAt: !1769)
!1773 = !DILocation(line: 610, column: 43, scope: !1604)
!1774 = !DILocation(line: 614, column: 33, scope: !1604)
!1775 = !DILocation(line: 2791, column: 12, scope: !1776, inlinedAt: !1777)
!1776 = distinct !DISubprogram(name: "pop<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$3pop17hb17e0537e1ff823eE", scope: !124, file: !123, line: 2790, type: !12, scopeLine: 2790, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!1777 = !DILocation(line: 615, column: 30, scope: !1604)
!1778 = !DILocation(line: 620, column: 25, scope: !1604)
!1779 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1778)
!1780 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1778)
!1781 = !DILocation(line: 0, scope: !1764, inlinedAt: !1778)
!1782 = !DILocation(line: 624, column: 25, scope: !1604)
!1783 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1784)
!1784 = !DILocation(line: 3729, column: 14, scope: !1785, inlinedAt: !1786)
!1785 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 34)
!1786 = !DILocation(line: 624, column: 35, scope: !1604)
!1787 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1782)
!1788 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1782)
!1789 = !DILocation(line: 631, column: 25, scope: !1604)
!1790 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1791)
!1791 = !DILocation(line: 3729, column: 14, scope: !1792, inlinedAt: !1793)
!1792 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 32)
!1793 = !DILocation(line: 631, column: 35, scope: !1604)
!1794 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1789)
!1795 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1789)
!1796 = !DILocation(line: 640, column: 25, scope: !1604)
!1797 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1798)
!1798 = !DILocation(line: 3729, column: 14, scope: !1799, inlinedAt: !1800)
!1799 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 30)
!1800 = !DILocation(line: 640, column: 35, scope: !1604)
!1801 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1796)
!1802 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1796)
!1803 = !DILocation(line: 647, column: 25, scope: !1604)
!1804 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1805)
!1805 = !DILocation(line: 3729, column: 14, scope: !1806, inlinedAt: !1807)
!1806 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 28)
!1807 = !DILocation(line: 647, column: 35, scope: !1604)
!1808 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1803)
!1809 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1803)
!1810 = !DILocation(line: 658, column: 25, scope: !1604)
!1811 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1812)
!1812 = !DILocation(line: 3729, column: 14, scope: !1813, inlinedAt: !1814)
!1813 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 26)
!1814 = !DILocation(line: 658, column: 35, scope: !1604)
!1815 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1810)
!1816 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1810)
!1817 = !DILocation(line: 664, column: 25, scope: !1604)
!1818 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1819)
!1819 = !DILocation(line: 3729, column: 14, scope: !1820, inlinedAt: !1821)
!1820 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 24)
!1821 = !DILocation(line: 664, column: 35, scope: !1604)
!1822 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1817)
!1823 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1817)
!1824 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1825)
!1825 = !DILocation(line: 671, column: 39, scope: !1604)
!1826 = !DILocation(line: 3002, column: 37, scope: !1827, inlinedAt: !1825)
!1827 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1828 = !DILocation(line: 3002, column: 18, scope: !1827, inlinedAt: !1825)
!1829 = !DILocation(line: 672, column: 25, scope: !1830)
!1830 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 671, column: 25)
!1831 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1832)
!1832 = !DILocation(line: 672, column: 46, scope: !1830)
!1833 = !DILocation(line: 3002, column: 37, scope: !1834, inlinedAt: !1832)
!1834 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1835 = !DILocation(line: 3002, column: 18, scope: !1834, inlinedAt: !1832)
!1836 = !DILocation(line: 672, column: 53, scope: !1830)
!1837 = !DILocation(line: 672, column: 72, scope: !1830)
!1838 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1829)
!1839 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1829)
!1840 = !DILocation(line: 675, column: 25, scope: !1604)
!1841 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1840)
!1842 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1840)
!1843 = !DILocation(line: 0, scope: !1764, inlinedAt: !1840)
!1844 = !DILocation(line: 678, column: 25, scope: !1604)
!1845 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1846)
!1846 = !DILocation(line: 3729, column: 14, scope: !1847, inlinedAt: !1848)
!1847 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 22)
!1848 = !DILocation(line: 678, column: 35, scope: !1604)
!1849 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1844)
!1850 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1844)
!1851 = !DILocation(line: 683, column: 25, scope: !1604)
!1852 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1853)
!1853 = !DILocation(line: 3729, column: 14, scope: !1854, inlinedAt: !1855)
!1854 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 20)
!1855 = !DILocation(line: 683, column: 35, scope: !1604)
!1856 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1851)
!1857 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1851)
!1858 = !DILocation(line: 689, column: 25, scope: !1604)
!1859 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1860)
!1860 = !DILocation(line: 3729, column: 14, scope: !1861, inlinedAt: !1862)
!1861 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 18)
!1862 = !DILocation(line: 689, column: 35, scope: !1604)
!1863 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1858)
!1864 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1858)
!1865 = !DILocation(line: 694, column: 33, scope: !1604)
!1866 = !DILocation(line: 694, column: 45, scope: !1604)
!1867 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1866)
!1868 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1866)
!1869 = !DILocation(line: 0, scope: !1764, inlinedAt: !1866)
!1870 = !DILocation(line: 694, column: 55, scope: !1604)
!1871 = !DILocation(line: 702, column: 33, scope: !1604)
!1872 = !DILocation(line: 702, column: 45, scope: !1604)
!1873 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1872)
!1874 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1872)
!1875 = !DILocation(line: 0, scope: !1764, inlinedAt: !1872)
!1876 = !DILocation(line: 702, column: 55, scope: !1604)
!1877 = !DILocation(line: 711, column: 25, scope: !1604)
!1878 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1879)
!1879 = !DILocation(line: 3729, column: 14, scope: !1880, inlinedAt: !1881)
!1880 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 16)
!1881 = !DILocation(line: 711, column: 35, scope: !1604)
!1882 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1877)
!1883 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1877)
!1884 = !DILocation(line: 717, column: 25, scope: !1604)
!1885 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1886)
!1886 = !DILocation(line: 3729, column: 14, scope: !1887, inlinedAt: !1888)
!1887 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 14)
!1888 = !DILocation(line: 717, column: 35, scope: !1604)
!1889 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1884)
!1890 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1884)
!1891 = !DILocation(line: 722, column: 25, scope: !1604)
!1892 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1893)
!1893 = !DILocation(line: 3729, column: 14, scope: !1894, inlinedAt: !1895)
!1894 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 12)
!1895 = !DILocation(line: 722, column: 35, scope: !1604)
!1896 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1891)
!1897 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1891)
!1898 = !DILocation(line: 729, column: 25, scope: !1604)
!1899 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !1900)
!1900 = !DILocation(line: 3729, column: 14, scope: !1901, inlinedAt: !1902)
!1901 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 10)
!1902 = !DILocation(line: 729, column: 35, scope: !1604)
!1903 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1898)
!1904 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1898)
!1905 = !DILocation(line: 734, column: 33, scope: !1604)
!1906 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1905)
!1907 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1905)
!1908 = !DILocation(line: 0, scope: !1764, inlinedAt: !1905)
!1909 = !DILocation(line: 734, column: 43, scope: !1604)
!1910 = !DILocation(line: 739, column: 33, scope: !1604)
!1911 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1910)
!1912 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1910)
!1913 = !DILocation(line: 0, scope: !1764, inlinedAt: !1910)
!1914 = !DILocation(line: 739, column: 43, scope: !1604)
!1915 = !DILocation(line: 746, column: 33, scope: !1604)
!1916 = !DILocation(line: 746, column: 45, scope: !1604)
!1917 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1916)
!1918 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1916)
!1919 = !DILocation(line: 0, scope: !1764, inlinedAt: !1916)
!1920 = !DILocation(line: 746, column: 55, scope: !1604)
!1921 = !DILocation(line: 750, column: 33, scope: !1604)
!1922 = !DILocation(line: 750, column: 45, scope: !1604)
!1923 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1922)
!1924 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1922)
!1925 = !DILocation(line: 0, scope: !1764, inlinedAt: !1922)
!1926 = !DILocation(line: 750, column: 55, scope: !1604)
!1927 = !DILocation(line: 754, column: 33, scope: !1604)
!1928 = !DILocation(line: 754, column: 45, scope: !1604)
!1929 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1928)
!1930 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1928)
!1931 = !DILocation(line: 0, scope: !1764, inlinedAt: !1928)
!1932 = !DILocation(line: 754, column: 55, scope: !1604)
!1933 = !DILocation(line: 758, column: 33, scope: !1604)
!1934 = !DILocation(line: 758, column: 45, scope: !1604)
!1935 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1934)
!1936 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1934)
!1937 = !DILocation(line: 0, scope: !1764, inlinedAt: !1934)
!1938 = !DILocation(line: 758, column: 55, scope: !1604)
!1939 = !DILocation(line: 762, column: 33, scope: !1604)
!1940 = !DILocation(line: 762, column: 45, scope: !1604)
!1941 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1940)
!1942 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1940)
!1943 = !DILocation(line: 0, scope: !1764, inlinedAt: !1940)
!1944 = !DILocation(line: 762, column: 55, scope: !1604)
!1945 = !DILocation(line: 766, column: 33, scope: !1604)
!1946 = !DILocation(line: 766, column: 45, scope: !1604)
!1947 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1946)
!1948 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1946)
!1949 = !DILocation(line: 0, scope: !1764, inlinedAt: !1946)
!1950 = !DILocation(line: 766, column: 55, scope: !1604)
!1951 = !DILocation(line: 769, column: 29, scope: !1604)
!1952 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1953)
!1953 = !DILocation(line: 769, column: 55, scope: !1604)
!1954 = !DILocation(line: 3002, column: 37, scope: !1955, inlinedAt: !1953)
!1955 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1956 = !DILocation(line: 3002, column: 18, scope: !1955, inlinedAt: !1953)
!1957 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1951)
!1958 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1951)
!1959 = !DILocation(line: 770, column: 29, scope: !1604)
!1960 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1961)
!1961 = !DILocation(line: 770, column: 55, scope: !1604)
!1962 = !DILocation(line: 3002, column: 37, scope: !1963, inlinedAt: !1961)
!1963 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1964 = !DILocation(line: 3002, column: 18, scope: !1963, inlinedAt: !1961)
!1965 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1959)
!1966 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1959)
!1967 = !DILocation(line: 772, column: 33, scope: !1604)
!1968 = !DILocation(line: 772, column: 45, scope: !1604)
!1969 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1968)
!1970 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1968)
!1971 = !DILocation(line: 0, scope: !1764, inlinedAt: !1968)
!1972 = !DILocation(line: 772, column: 55, scope: !1604)
!1973 = !DILocation(line: 777, column: 33, scope: !1604)
!1974 = !DILocation(line: 777, column: 45, scope: !1604)
!1975 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1974)
!1976 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1974)
!1977 = !DILocation(line: 0, scope: !1764, inlinedAt: !1974)
!1978 = !DILocation(line: 777, column: 55, scope: !1604)
!1979 = !DILocation(line: 781, column: 29, scope: !1604)
!1980 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1981)
!1981 = !DILocation(line: 781, column: 53, scope: !1604)
!1982 = !DILocation(line: 3002, column: 37, scope: !1983, inlinedAt: !1981)
!1983 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1984 = !DILocation(line: 3002, column: 18, scope: !1983, inlinedAt: !1981)
!1985 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1979)
!1986 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1979)
!1987 = !DILocation(line: 783, column: 33, scope: !1604)
!1988 = !DILocation(line: 783, column: 45, scope: !1604)
!1989 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !1988)
!1990 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !1988)
!1991 = !DILocation(line: 0, scope: !1764, inlinedAt: !1988)
!1992 = !DILocation(line: 783, column: 55, scope: !1604)
!1993 = !DILocation(line: 789, column: 29, scope: !1604)
!1994 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !1995)
!1995 = !DILocation(line: 789, column: 53, scope: !1604)
!1996 = !DILocation(line: 3002, column: 37, scope: !1997, inlinedAt: !1995)
!1997 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!1998 = !DILocation(line: 3002, column: 18, scope: !1997, inlinedAt: !1995)
!1999 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !1993)
!2000 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !1993)
!2001 = !DILocation(line: 790, column: 29, scope: !1604)
!2002 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2003)
!2003 = !DILocation(line: 790, column: 53, scope: !1604)
!2004 = !DILocation(line: 3002, column: 37, scope: !2005, inlinedAt: !2003)
!2005 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2006 = !DILocation(line: 3002, column: 18, scope: !2005, inlinedAt: !2003)
!2007 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2001)
!2008 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2001)
!2009 = !DILocation(line: 791, column: 29, scope: !1604)
!2010 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2011)
!2011 = !DILocation(line: 791, column: 53, scope: !1604)
!2012 = !DILocation(line: 3002, column: 37, scope: !2013, inlinedAt: !2011)
!2013 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2014 = !DILocation(line: 3002, column: 18, scope: !2013, inlinedAt: !2011)
!2015 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2009)
!2016 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2009)
!2017 = !DILocation(line: 792, column: 29, scope: !1604)
!2018 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2019)
!2019 = !DILocation(line: 792, column: 53, scope: !1604)
!2020 = !DILocation(line: 3002, column: 37, scope: !2021, inlinedAt: !2019)
!2021 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2022 = !DILocation(line: 3002, column: 18, scope: !2021, inlinedAt: !2019)
!2023 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2017)
!2024 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2017)
!2025 = !DILocation(line: 793, column: 29, scope: !1604)
!2026 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2027)
!2027 = !DILocation(line: 793, column: 53, scope: !1604)
!2028 = !DILocation(line: 3002, column: 37, scope: !2029, inlinedAt: !2027)
!2029 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2030 = !DILocation(line: 3002, column: 18, scope: !2029, inlinedAt: !2027)
!2031 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2025)
!2032 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2025)
!2033 = !DILocation(line: 795, column: 33, scope: !1604)
!2034 = !DILocation(line: 795, column: 45, scope: !1604)
!2035 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2034)
!2036 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2034)
!2037 = !DILocation(line: 0, scope: !1764, inlinedAt: !2034)
!2038 = !DILocation(line: 795, column: 55, scope: !1604)
!2039 = !DILocation(line: 800, column: 33, scope: !1604)
!2040 = !DILocation(line: 800, column: 45, scope: !1604)
!2041 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2040)
!2042 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2040)
!2043 = !DILocation(line: 0, scope: !1764, inlinedAt: !2040)
!2044 = !DILocation(line: 800, column: 55, scope: !1604)
!2045 = !DILocation(line: 805, column: 35, scope: !1604)
!2046 = !DILocation(line: 805, column: 47, scope: !1604)
!2047 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2046)
!2048 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2046)
!2049 = !DILocation(line: 0, scope: !1764, inlinedAt: !2046)
!2050 = !DILocation(line: 805, column: 57, scope: !1604)
!2051 = !DILocation(line: 811, column: 33, scope: !1604)
!2052 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2051)
!2053 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2051)
!2054 = !DILocation(line: 0, scope: !1764, inlinedAt: !2051)
!2055 = !DILocation(line: 811, column: 43, scope: !1604)
!2056 = !DILocation(line: 818, column: 33, scope: !1604)
!2057 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2056)
!2058 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2056)
!2059 = !DILocation(line: 0, scope: !1764, inlinedAt: !2056)
!2060 = !DILocation(line: 818, column: 43, scope: !1604)
!2061 = !DILocation(line: 822, column: 33, scope: !1604)
!2062 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2061)
!2063 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2061)
!2064 = !DILocation(line: 0, scope: !1764, inlinedAt: !2061)
!2065 = !DILocation(line: 822, column: 43, scope: !1604)
!2066 = !DILocation(line: 826, column: 33, scope: !1604)
!2067 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2066)
!2068 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2066)
!2069 = !DILocation(line: 0, scope: !1764, inlinedAt: !2066)
!2070 = !DILocation(line: 826, column: 43, scope: !1604)
!2071 = !DILocation(line: 830, column: 33, scope: !1604)
!2072 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2071)
!2073 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2071)
!2074 = !DILocation(line: 0, scope: !1764, inlinedAt: !2071)
!2075 = !DILocation(line: 830, column: 43, scope: !1604)
!2076 = !DILocation(line: 902, column: 49, scope: !2077, inlinedAt: !2081)
!2077 = distinct !DILexicalBlock(scope: !2079, file: !2078, line: 901, column: 9)
!2078 = !DIFile(filename: "library/core/src/mem/mod.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "6bca88b164013e73def192dcdbc80502")
!2079 = distinct !DISubprogram(name: "replace<u32>", linkageName: "_ZN4core3mem7replace17h8e2003382b7ea477E", scope: !2080, file: !2078, line: 887, type: !12, scopeLine: 887, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2080 = !DINamespace(name: "mem", scope: !39)
!2081 = !DILocation(line: 513, column: 9, scope: !2082, inlinedAt: !2086)
!2082 = distinct !DISubprogram(name: "replace<u32>", linkageName: "_ZN4core4cell13Cell$LT$T$GT$7replace17hb778deaa7480fed3E", scope: !2084, file: !2083, line: 510, type: !12, scopeLine: 510, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2083 = !DIFile(filename: "library/core/src/cell.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "96404e804c6faf0fea9fa631bcb8d1d2")
!2084 = !DINamespace(name: "Cell", scope: !2085)
!2085 = !DINamespace(name: "cell", scope: !39)
!2086 = !DILocation(line: 437, column: 14, scope: !2087, inlinedAt: !2088)
!2087 = distinct !DISubprogram(name: "set<u32>", linkageName: "_ZN4core4cell13Cell$LT$T$GT$3set17h23fe394eb5b818adE", scope: !2084, file: !2083, line: 433, type: !12, scopeLine: 433, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2088 = !DILocation(line: 838, column: 47, scope: !1604)
!2089 = !DILocation(line: 2301, column: 13, scope: !2090, inlinedAt: !2091)
!2090 = distinct !DISubprogram(name: "saturating_add", linkageName: "_RNvMs9_NtCsgEmfK2I1SDS_4core3numj14saturating_add", scope: !66, file: !65, line: 2300, type: !12, scopeLine: 2300, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2091 = !DILocation(line: 840, column: 50, scope: !1604)
!2092 = !DILocation(line: 902, column: 49, scope: !2093, inlinedAt: !2095)
!2093 = distinct !DILexicalBlock(scope: !2094, file: !2078, line: 901, column: 9)
!2094 = distinct !DISubprogram(name: "replace<core::option::Option<usize>>", linkageName: "_ZN4core3mem7replace17h370439711cb47e1dE", scope: !2080, file: !2078, line: 887, type: !12, scopeLine: 887, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2095 = !DILocation(line: 513, column: 9, scope: !2096, inlinedAt: !2098)
!2096 = !DILexicalBlockFile(scope: !2097, file: !2083, discriminator: 2)
!2097 = distinct !DISubprogram(name: "replace<core::option::Option<usize>>", linkageName: "_ZN4core4cell13Cell$LT$T$GT$7replace17hcc5351638ecdac36E", scope: !2084, file: !2083, line: 510, type: !12, scopeLine: 510, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2098 = !DILocation(line: 437, column: 14, scope: !2099, inlinedAt: !2101)
!2099 = !DILexicalBlockFile(scope: !2100, file: !2083, discriminator: 2)
!2100 = distinct !DISubprogram(name: "set<core::option::Option<usize>>", linkageName: "_ZN4core4cell13Cell$LT$T$GT$3set17h276b7384453eeecbE", scope: !2084, file: !2083, line: 433, type: !12, scopeLine: 433, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2101 = !DILocation(line: 840, column: 30, scope: !1604)
!2102 = !DILocation(line: 835, column: 29, scope: !1604)
!2103 = !DILocation(line: 842, column: 29, scope: !1604)
!2104 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2105)
!2105 = !DILocation(line: 842, column: 57, scope: !1604)
!2106 = !DILocation(line: 3002, column: 37, scope: !2107, inlinedAt: !2105)
!2107 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2108 = !DILocation(line: 3002, column: 18, scope: !2107, inlinedAt: !2105)
!2109 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2103)
!2110 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2103)
!2111 = !DILocation(line: 843, column: 29, scope: !1604)
!2112 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2113)
!2113 = !DILocation(line: 843, column: 57, scope: !1604)
!2114 = !DILocation(line: 3002, column: 37, scope: !2115, inlinedAt: !2113)
!2115 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2116 = !DILocation(line: 3002, column: 18, scope: !2115, inlinedAt: !2113)
!2117 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2111)
!2118 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2111)
!2119 = !DILocation(line: 845, column: 28, scope: !1604)
!2120 = !DILocation(line: 852, column: 29, scope: !1604)
!2121 = !DILocation(line: 860, column: 29, scope: !1604)
!2122 = !DILocation(line: 869, column: 29, scope: !1604)
!2123 = !DILocation(line: 894, column: 29, scope: !1604)
!2124 = !DILocation(line: 2189, column: 23, scope: !2125, inlinedAt: !2126)
!2125 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!2126 = !DILocation(line: 603, column: 33, scope: !2127)
!2127 = !DILexicalBlockFile(scope: !2128, file: !8, discriminator: 2)
!2128 = distinct !DILexicalBlock(scope: !2129, file: !8, line: 603, column: 43)
!2129 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 603, column: 43)
!2130 = !DILocation(line: 241, column: 16, scope: !1066, inlinedAt: !2131)
!2131 = distinct !DILocation(line: 235, column: 13, scope: !1069, inlinedAt: !2132)
!2132 = distinct !DILocation(line: 604, column: 29, scope: !2133)
!2133 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 603, column: 25)
!2134 = !DILocation(line: 241, column: 28, scope: !1066, inlinedAt: !2131)
!2135 = !DILocation(line: 28, column: 31, scope: !1074, inlinedAt: !2136)
!2136 = distinct !DILocation(line: 236, column: 34, scope: !1079, inlinedAt: !2132)
!2137 = !{!2138}
!2138 = distinct !{!2138, !2139, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE: %v.0"}
!2139 = distinct !{!2139, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE"}
!2140 = !DILocation(line: 178, column: 46, scope: !1084, inlinedAt: !2141)
!2141 = distinct !DILocation(line: 28, column: 17, scope: !1074, inlinedAt: !2136)
!2142 = !DILocation(line: 236, column: 33, scope: !1079, inlinedAt: !2132)
!2143 = !DILocation(line: 1720, column: 9, scope: !1090, inlinedAt: !2144)
!2144 = distinct !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !2145)
!2145 = distinct !DILocation(line: 314, column: 42, scope: !1096, inlinedAt: !2146)
!2146 = distinct !DILocation(line: 236, column: 71, scope: !1079, inlinedAt: !2132)
!2147 = !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !2145)
!2148 = !DILocation(line: 659, column: 28, scope: !1101, inlinedAt: !2149)
!2149 = distinct !DILocation(line: 185, column: 40, scope: !1092, inlinedAt: !2145)
!2150 = !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !2146)
!2151 = !{!2152}
!2152 = distinct !{!2152, !2153, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E: %self"}
!2153 = distinct !{!2153, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E"}
!2154 = !DILocation(line: 236, column: 80, scope: !1108, inlinedAt: !2155)
!2155 = distinct !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !2146)
!2156 = !DILocation(line: 0, scope: !199, inlinedAt: !2157)
!2157 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !2158)
!2158 = !DILocation(line: 177, column: 20, scope: !2159, inlinedAt: !2160)
!2159 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 26)
!2160 = !DILocation(line: 965, column: 20, scope: !2161, inlinedAt: !2162)
!2161 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 26)
!2162 = !DILocation(line: 448, column: 29, scope: !2163, inlinedAt: !2165)
!2163 = !DILexicalBlockFile(scope: !2164, file: !209, discriminator: 26)
!2164 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!2165 = !DILocation(line: 400, column: 16, scope: !2166, inlinedAt: !2167)
!2166 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 26)
!2167 = !DILocation(line: 376, column: 14, scope: !2168, inlinedAt: !2169)
!2168 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 26)
!2169 = !DILocation(line: 842, column: 14, scope: !2170, inlinedAt: !2171)
!2170 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 24)
!2171 = !DILocation(line: 211, column: 62, scope: !2172, inlinedAt: !2173)
!2172 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 24)
!2173 = !DILocation(line: 3114, column: 11, scope: !2174, inlinedAt: !2175)
!2174 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 24)
!2175 = !DILocation(line: 778, column: 9, scope: !2176, inlinedAt: !2177)
!2176 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 24)
!2177 = !DILocation(line: 605, column: 75, scope: !2133)
!2178 = !{!2179}
!2179 = distinct !{!2179, !2180, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!2180 = distinct !{!2180, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!2181 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !2182)
!2182 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !2183)
!2183 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !2184)
!2184 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !2185)
!2185 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !2157)
!2186 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !2157)
!2187 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !2157)
!2188 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2189)
!2189 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2190)
!2190 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2191)
!2191 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2192)
!2192 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2193)
!2193 = distinct !DILocation(line: 607, column: 21, scope: !1604)
!2194 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2195)
!2195 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2196)
!2196 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2197)
!2197 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2198)
!2198 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2190)
!2199 = !{!2200}
!2200 = distinct !{!2200, !2201, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2201 = distinct !{!2201, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2202 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2196)
!2203 = !DILocation(line: 441, column: 25, scope: !2204, inlinedAt: !2158)
!2204 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!2205 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !2206)
!2206 = !DILocation(line: 1252, column: 18, scope: !2207, inlinedAt: !2208)
!2207 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 26)
!2208 = !DILocation(line: 454, column: 36, scope: !2209, inlinedAt: !2165)
!2209 = !DILexicalBlockFile(scope: !2210, file: !209, discriminator: 26)
!2210 = distinct !DILexicalBlock(scope: !2164, file: !209, line: 448, column: 17)
!2211 = !DILocation(line: 605, column: 36, scope: !2133)
!2212 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2213)
!2213 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2214)
!2214 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2215)
!2215 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2216)
!2216 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2217)
!2217 = distinct !DILocation(line: 607, column: 21, scope: !1604)
!2218 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2219)
!2219 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2220)
!2220 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2221)
!2221 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2222)
!2222 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2214)
!2223 = !{!2224}
!2224 = distinct !{!2224, !2225, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2225 = distinct !{!2225, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2226 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2220)
!2227 = !DILocation(line: 610, column: 44, scope: !1604)
!2228 = !DILocation(line: 1025, column: 19, scope: !799, inlinedAt: !2229)
!2229 = distinct !DILocation(line: 992, column: 22, scope: !2230, inlinedAt: !2231)
!2230 = distinct !DISubprogram(name: "push<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$4push17h02e46a499ef19dd5E", scope: !124, file: !123, line: 991, type: !12, scopeLine: 991, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2231 = !DILocation(line: 611, column: 34, scope: !2232)
!2232 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 610, column: 25)
!2233 = !{!2234}
!2234 = distinct !{!2234, !2235, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E: %self"}
!2235 = distinct !{!2235, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E"}
!2236 = !{!2237}
!2237 = distinct !{!2237, !2235, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$8push_mut17h62f7f7b245b27b57E: %value"}
!2238 = !DILocation(line: 617, column: 49, scope: !794, inlinedAt: !2239)
!2239 = distinct !DILocation(line: 308, column: 20, scope: !796, inlinedAt: !2240)
!2240 = distinct !DILocation(line: 1028, column: 28, scope: !798, inlinedAt: !2229)
!2241 = !DILocation(line: 1028, column: 12, scope: !798, inlinedAt: !2229)
!2242 = !DILocation(line: 1029, column: 22, scope: !798, inlinedAt: !2229)
!2243 = !DILocation(line: 1028, column: 9, scope: !798, inlinedAt: !2229)
!2244 = !DILocation(line: 612, column: 9, scope: !882, inlinedAt: !2245)
!2245 = distinct !DILocation(line: 607, column: 14, scope: !884, inlinedAt: !2246)
!2246 = distinct !DILocation(line: 295, column: 20, scope: !886, inlinedAt: !2247)
!2247 = distinct !DILocation(line: 2000, column: 18, scope: !888, inlinedAt: !2248)
!2248 = distinct !DILocation(line: 1032, column: 28, scope: !798, inlinedAt: !2229)
!2249 = !DILocation(line: 961, column: 18, scope: !891, inlinedAt: !2250)
!2250 = distinct !DILocation(line: 1032, column: 41, scope: !798, inlinedAt: !2229)
!2251 = !DILocation(line: 1917, column: 41, scope: !894, inlinedAt: !2252)
!2252 = distinct !DILocation(line: 1033, column: 13, scope: !896, inlinedAt: !2229)
!2253 = !DILocation(line: 1034, column: 13, scope: !896, inlinedAt: !2229)
!2254 = !DILocation(line: 612, column: 21, scope: !1604)
!2255 = !DILocation(line: 1369, column: 25, scope: !2256, inlinedAt: !2257)
!2256 = distinct !DISubprogram(name: "ok_or_else<alloc::vec::Vec<u8, alloc::alloc::Global>, rbitcoin_consensus::error::ConsensusError, rbitcoin_consensus::script::interpreter::eval_script::{closure_env#1}>", linkageName: "_ZN4core6option15Option$LT$T$GT$10ok_or_else17h4e89fe3b3ca1549dE", scope: !703, file: !702, line: 1363, type: !12, scopeLine: 1363, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2257 = !DILocation(line: 616, column: 30, scope: !1604)
!2258 = !DILocation(line: 2175, column: 17, scope: !1764, inlinedAt: !1774)
!2259 = !DILocation(line: 616, column: 92, scope: !1604)
!2260 = !DILocation(line: 616, column: 93, scope: !1604)
!2261 = !DILocation(line: 2795, column: 17, scope: !1776, inlinedAt: !1777)
!2262 = !DILocation(line: 617, column: 49, scope: !2263, inlinedAt: !2264)
!2263 = distinct !DISubprogram(name: "capacity<alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8capacity17he27ac60cd2f1eca6E", scope: !148, file: !147, line: 616, type: !12, scopeLine: 616, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2264 = !DILocation(line: 308, column: 20, scope: !2265, inlinedAt: !2267)
!2265 = !DILexicalBlockFile(scope: !2266, file: !147, discriminator: 26)
!2266 = distinct !DISubprogram(name: "capacity<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8capacity17h92f042a2a1219c16E", scope: !156, file: !147, line: 307, type: !12, scopeLine: 307, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2267 = !DILocation(line: 1422, column: 18, scope: !2268, inlinedAt: !2270)
!2268 = !DILexicalBlockFile(scope: !2269, file: !123, discriminator: 26)
!2269 = distinct !DISubprogram(name: "capacity<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$8capacity17h808049f3502df27eE", scope: !124, file: !123, line: 1421, type: !12, scopeLine: 1421, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2270 = !DILocation(line: 2796, column: 62, scope: !1776, inlinedAt: !1777)
!2271 = !DILocation(line: 2796, column: 46, scope: !1776, inlinedAt: !1777)
!2272 = !DILocation(line: 210, column: 9, scope: !2273, inlinedAt: !2274)
!2273 = distinct !DISubprogram(name: "assert_unchecked", linkageName: "_RNvNtCsgEmfK2I1SDS_4core4hint16assert_unchecked", scope: !1041, file: !1040, line: 202, type: !12, scopeLine: 202, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2274 = !DILocation(line: 2796, column: 17, scope: !1776, inlinedAt: !1777)
!2275 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2276)
!2276 = !DILocation(line: 607, column: 14, scope: !2277, inlinedAt: !2278)
!2277 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 62)
!2278 = !DILocation(line: 295, column: 20, scope: !2279, inlinedAt: !2280)
!2279 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 62)
!2280 = !DILocation(line: 1916, column: 18, scope: !2281, inlinedAt: !2282)
!2281 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 36)
!2282 = !DILocation(line: 2797, column: 37, scope: !1776, inlinedAt: !1777)
!2283 = !DILocation(line: 3002, column: 37, scope: !2284, inlinedAt: !2285)
!2284 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2285 = !DILocation(line: 2797, column: 55, scope: !1776, inlinedAt: !1777)
!2286 = !DILocation(line: 3002, column: 18, scope: !2284, inlinedAt: !2285)
!2287 = !DILocation(line: 863, column: 18, scope: !2288, inlinedAt: !2289)
!2288 = distinct !DISubprogram(name: "add<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr9const_ptr33_$LT$impl$u20$$BP$const$u20$T$GT$3add17h0e4bcabc1f5ba454E", scope: !311, file: !309, line: 829, type: !12, scopeLine: 829, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2289 = !DILocation(line: 2797, column: 46, scope: !1776, inlinedAt: !1777)
!2290 = !DILocation(line: 617, column: 25, scope: !2291)
!2291 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 614, column: 25)
!2292 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2290)
!2293 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2290)
!2294 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2290)
!2295 = !DILocation(line: 617, column: 55, scope: !2291)
!2296 = !DILocation(line: 618, column: 21, scope: !1604)
!2297 = !DILocation(line: 2175, column: 17, scope: !1764, inlinedAt: !1778)
!2298 = !DILocation(line: 620, column: 35, scope: !1604)
!2299 = !DILocation(line: 2189, column: 23, scope: !2300, inlinedAt: !2301)
!2300 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!2301 = !DILocation(line: 620, column: 25, scope: !2302)
!2302 = !DILexicalBlockFile(scope: !2303, file: !8, discriminator: 2)
!2303 = distinct !DILexicalBlock(scope: !2304, file: !8, line: 620, column: 35)
!2304 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 620, column: 35)
!2305 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2306)
!2306 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2307)
!2307 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2308)
!2308 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2309)
!2309 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2310)
!2310 = distinct !DILocation(line: 620, column: 36, scope: !1604)
!2311 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2312)
!2312 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2313)
!2313 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2314)
!2314 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2315)
!2315 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2307)
!2316 = !{!2317}
!2317 = distinct !{!2317, !2318, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2318 = distinct !{!2318, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2319 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2313)
!2320 = !DILocation(line: 621, column: 25, scope: !1604)
!2321 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !2320)
!2322 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !2320)
!2323 = !DILocation(line: 0, scope: !1764, inlinedAt: !2320)
!2324 = !DILocation(line: 2175, column: 17, scope: !1764, inlinedAt: !2320)
!2325 = !DILocation(line: 621, column: 35, scope: !1604)
!2326 = !DILocation(line: 2189, column: 23, scope: !2327, inlinedAt: !2328)
!2327 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!2328 = !DILocation(line: 621, column: 25, scope: !2329)
!2329 = !DILexicalBlockFile(scope: !2330, file: !8, discriminator: 2)
!2330 = distinct !DILexicalBlock(scope: !2331, file: !8, line: 621, column: 35)
!2331 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 621, column: 35)
!2332 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2333)
!2333 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2334)
!2334 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2335)
!2335 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2336)
!2336 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2337)
!2337 = distinct !DILocation(line: 621, column: 36, scope: !1604)
!2338 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2339)
!2339 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2340)
!2340 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2341)
!2341 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2342)
!2342 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2334)
!2343 = !{!2344}
!2344 = distinct !{!2344, !2345, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2345 = distinct !{!2345, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2346 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2340)
!2347 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1782)
!2348 = !DILocation(line: 624, column: 44, scope: !1604)
!2349 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2350)
!2350 = !DILocation(line: 625, column: 45, scope: !1604)
!2351 = !DILocation(line: 3002, column: 37, scope: !2352, inlinedAt: !2350)
!2352 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2353 = !DILocation(line: 3002, column: 18, scope: !2352, inlinedAt: !2350)
!2354 = !DILocation(line: 625, column: 39, scope: !1604)
!2355 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2357)
!2356 = distinct !DISubprogram(name: "index<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN75_$LT$usize$u20$as$u20$core..slice..index..SliceIndex$LT$$u5b$T$u5d$$GT$$GT$5index17hff0355192ef13632E", scope: !694, file: !693, line: 270, type: !12, scopeLine: 270, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2357 = !DILocation(line: 19, column: 15, scope: !2358, inlinedAt: !2360)
!2358 = distinct !DISubprogram(name: "index<alloc::vec::Vec<u8, alloc::alloc::Global>, usize>", linkageName: "_ZN4core5slice5index74_$LT$impl$u20$core..ops..index..Index$LT$I$GT$$u20$for$u20$$u5b$T$u5d$$GT$5index17h60b01956909286efE", scope: !2359, file: !693, line: 18, type: !12, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2359 = !DINamespace(name: "{impl#0}", scope: !695)
!2360 = !DILocation(line: 3804, column: 9, scope: !2361, inlinedAt: !2363)
!2361 = distinct !DISubprogram(name: "index<alloc::vec::Vec<u8, alloc::alloc::Global>, usize, alloc::alloc::Global>", linkageName: "_ZN81_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..index..Index$LT$I$GT$$GT$5index17hf1bf797f8eabec82E", scope: !2362, file: !123, line: 3803, type: !12, scopeLine: 3803, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2362 = !DINamespace(name: "{impl#14}", scope: !125)
!2363 = !DILocation(line: 625, column: 38, scope: !1604)
!2364 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2365)
!2365 = !DILocation(line: 607, column: 14, scope: !2366, inlinedAt: !2367)
!2366 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 196)
!2367 = !DILocation(line: 295, column: 20, scope: !2368, inlinedAt: !2369)
!2368 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 196)
!2369 = !DILocation(line: 1916, column: 18, scope: !2370, inlinedAt: !2371)
!2370 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 40)
!2371 = !DILocation(line: 1815, column: 76, scope: !2372, inlinedAt: !2373)
!2372 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 38)
!2373 = !DILocation(line: 3729, column: 14, scope: !2374, inlinedAt: !2375)
!2374 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 38)
!2375 = !DILocation(line: 3804, column: 23, scope: !2361, inlinedAt: !2363)
!2376 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2357)
!2377 = !DILocation(line: 625, column: 56, scope: !1604)
!2378 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2379)
!2379 = !DILocation(line: 626, column: 45, scope: !2380)
!2380 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 625, column: 25)
!2381 = !DILocation(line: 3002, column: 37, scope: !2382, inlinedAt: !2379)
!2382 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2383 = !DILocation(line: 3002, column: 18, scope: !2382, inlinedAt: !2379)
!2384 = !DILocation(line: 626, column: 39, scope: !2380)
!2385 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2386)
!2386 = !DILocation(line: 19, column: 15, scope: !2387, inlinedAt: !2388)
!2387 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 2)
!2388 = !DILocation(line: 3804, column: 9, scope: !2389, inlinedAt: !2390)
!2389 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 2)
!2390 = !DILocation(line: 626, column: 38, scope: !2380)
!2391 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2392)
!2392 = !DILocation(line: 607, column: 14, scope: !2393, inlinedAt: !2394)
!2393 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 198)
!2394 = !DILocation(line: 295, column: 20, scope: !2395, inlinedAt: !2396)
!2395 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 198)
!2396 = !DILocation(line: 1916, column: 18, scope: !2397, inlinedAt: !2398)
!2397 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 42)
!2398 = !DILocation(line: 1815, column: 76, scope: !2399, inlinedAt: !2400)
!2399 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 40)
!2400 = !DILocation(line: 3729, column: 14, scope: !2401, inlinedAt: !2402)
!2401 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 40)
!2402 = !DILocation(line: 3804, column: 23, scope: !2389, inlinedAt: !2390)
!2403 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2386)
!2404 = !DILocation(line: 626, column: 56, scope: !2380)
!2405 = !DILocation(line: 627, column: 25, scope: !2406)
!2406 = distinct !DILexicalBlock(scope: !2380, file: !8, line: 626, column: 25)
!2407 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2408)
!2408 = !DILocation(line: 627, column: 46, scope: !2406)
!2409 = !DILocation(line: 3002, column: 37, scope: !2410, inlinedAt: !2408)
!2410 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2411 = !DILocation(line: 3002, column: 18, scope: !2410, inlinedAt: !2408)
!2412 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2405)
!2413 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2405)
!2414 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2405)
!2415 = !DILocation(line: 627, column: 55, scope: !2406)
!2416 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2417)
!2417 = distinct !DILocation(line: 629, column: 21, scope: !2380)
!2418 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2419)
!2419 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2420)
!2420 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2421)
!2421 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2422)
!2422 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2417)
!2423 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2424)
!2424 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2425)
!2425 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2426)
!2426 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2427)
!2427 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2420)
!2428 = !{!2429}
!2429 = distinct !{!2429, !2430, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2430 = distinct !{!2430, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2431 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2425)
!2432 = !DILocation(line: 628, column: 25, scope: !2406)
!2433 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2434)
!2434 = !DILocation(line: 628, column: 46, scope: !2406)
!2435 = !DILocation(line: 3002, column: 37, scope: !2436, inlinedAt: !2434)
!2436 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2437 = !DILocation(line: 3002, column: 18, scope: !2436, inlinedAt: !2434)
!2438 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2432)
!2439 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2432)
!2440 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2432)
!2441 = !DILocation(line: 628, column: 55, scope: !2406)
!2442 = !DILocation(line: 0, scope: !2443)
!2443 = !DILexicalBlockFile(scope: !2406, file: !74, discriminator: 0)
!2444 = !DILocation(line: 629, column: 21, scope: !1604)
!2445 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1789)
!2446 = !DILocation(line: 631, column: 44, scope: !1604)
!2447 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2448)
!2448 = !DILocation(line: 632, column: 45, scope: !1604)
!2449 = !DILocation(line: 3002, column: 37, scope: !2450, inlinedAt: !2448)
!2450 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2451 = !DILocation(line: 3002, column: 18, scope: !2450, inlinedAt: !2448)
!2452 = !DILocation(line: 632, column: 39, scope: !1604)
!2453 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2454)
!2454 = !DILocation(line: 19, column: 15, scope: !2455, inlinedAt: !2456)
!2455 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 4)
!2456 = !DILocation(line: 3804, column: 9, scope: !2457, inlinedAt: !2458)
!2457 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 4)
!2458 = !DILocation(line: 632, column: 38, scope: !1604)
!2459 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2460)
!2460 = !DILocation(line: 607, column: 14, scope: !2461, inlinedAt: !2462)
!2461 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 200)
!2462 = !DILocation(line: 295, column: 20, scope: !2463, inlinedAt: !2464)
!2463 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 200)
!2464 = !DILocation(line: 1916, column: 18, scope: !2465, inlinedAt: !2466)
!2465 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 44)
!2466 = !DILocation(line: 1815, column: 76, scope: !2467, inlinedAt: !2468)
!2467 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 42)
!2468 = !DILocation(line: 3729, column: 14, scope: !2469, inlinedAt: !2470)
!2469 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 42)
!2470 = !DILocation(line: 3804, column: 23, scope: !2457, inlinedAt: !2458)
!2471 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2454)
!2472 = !DILocation(line: 632, column: 56, scope: !1604)
!2473 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2474)
!2474 = !DILocation(line: 633, column: 45, scope: !2475)
!2475 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 632, column: 25)
!2476 = !DILocation(line: 3002, column: 37, scope: !2477, inlinedAt: !2474)
!2477 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2478 = !DILocation(line: 3002, column: 18, scope: !2477, inlinedAt: !2474)
!2479 = !DILocation(line: 633, column: 39, scope: !2475)
!2480 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2481)
!2481 = !DILocation(line: 19, column: 15, scope: !2482, inlinedAt: !2483)
!2482 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 6)
!2483 = !DILocation(line: 3804, column: 9, scope: !2484, inlinedAt: !2485)
!2484 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 6)
!2485 = !DILocation(line: 633, column: 38, scope: !2475)
!2486 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2487)
!2487 = !DILocation(line: 607, column: 14, scope: !2488, inlinedAt: !2489)
!2488 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 202)
!2489 = !DILocation(line: 295, column: 20, scope: !2490, inlinedAt: !2491)
!2490 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 202)
!2491 = !DILocation(line: 1916, column: 18, scope: !2492, inlinedAt: !2493)
!2492 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 46)
!2493 = !DILocation(line: 1815, column: 76, scope: !2494, inlinedAt: !2495)
!2494 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 44)
!2495 = !DILocation(line: 3729, column: 14, scope: !2496, inlinedAt: !2497)
!2496 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 44)
!2497 = !DILocation(line: 3804, column: 23, scope: !2484, inlinedAt: !2485)
!2498 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2481)
!2499 = !DILocation(line: 633, column: 56, scope: !2475)
!2500 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2501)
!2501 = !DILocation(line: 634, column: 45, scope: !2502)
!2502 = distinct !DILexicalBlock(scope: !2475, file: !8, line: 633, column: 25)
!2503 = !DILocation(line: 3002, column: 37, scope: !2504, inlinedAt: !2501)
!2504 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2505 = !DILocation(line: 3002, column: 18, scope: !2504, inlinedAt: !2501)
!2506 = !DILocation(line: 634, column: 39, scope: !2502)
!2507 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2508)
!2508 = !DILocation(line: 19, column: 15, scope: !2509, inlinedAt: !2510)
!2509 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 8)
!2510 = !DILocation(line: 3804, column: 9, scope: !2511, inlinedAt: !2512)
!2511 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 8)
!2512 = !DILocation(line: 634, column: 38, scope: !2502)
!2513 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2514)
!2514 = !DILocation(line: 607, column: 14, scope: !2515, inlinedAt: !2516)
!2515 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 204)
!2516 = !DILocation(line: 295, column: 20, scope: !2517, inlinedAt: !2518)
!2517 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 204)
!2518 = !DILocation(line: 1916, column: 18, scope: !2519, inlinedAt: !2520)
!2519 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 48)
!2520 = !DILocation(line: 1815, column: 76, scope: !2521, inlinedAt: !2522)
!2521 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 46)
!2522 = !DILocation(line: 3729, column: 14, scope: !2523, inlinedAt: !2524)
!2523 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 46)
!2524 = !DILocation(line: 3804, column: 23, scope: !2511, inlinedAt: !2512)
!2525 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2508)
!2526 = !DILocation(line: 634, column: 56, scope: !2502)
!2527 = !DILocation(line: 635, column: 25, scope: !2528)
!2528 = distinct !DILexicalBlock(scope: !2502, file: !8, line: 634, column: 25)
!2529 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2530)
!2530 = !DILocation(line: 635, column: 46, scope: !2528)
!2531 = !DILocation(line: 3002, column: 37, scope: !2532, inlinedAt: !2530)
!2532 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2533 = !DILocation(line: 3002, column: 18, scope: !2532, inlinedAt: !2530)
!2534 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2527)
!2535 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2527)
!2536 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2527)
!2537 = !DILocation(line: 635, column: 55, scope: !2528)
!2538 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2539)
!2539 = distinct !DILocation(line: 638, column: 21, scope: !2502)
!2540 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2541)
!2541 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2542)
!2542 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2543)
!2543 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2544)
!2544 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2539)
!2545 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2546)
!2546 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2547)
!2547 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2548)
!2548 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2549)
!2549 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2542)
!2550 = !{!2551}
!2551 = distinct !{!2551, !2552, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2552 = distinct !{!2552, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2553 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2547)
!2554 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2555)
!2555 = distinct !DILocation(line: 638, column: 21, scope: !2475)
!2556 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2557)
!2557 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2558)
!2558 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2559)
!2559 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2560)
!2560 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2555)
!2561 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2562)
!2562 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2563)
!2563 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2564)
!2564 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2565)
!2565 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2558)
!2566 = !{!2567}
!2567 = distinct !{!2567, !2568, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2568 = distinct !{!2568, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2569 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2563)
!2570 = !DILocation(line: 636, column: 25, scope: !2528)
!2571 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2572)
!2572 = !DILocation(line: 636, column: 46, scope: !2528)
!2573 = !DILocation(line: 3002, column: 37, scope: !2574, inlinedAt: !2572)
!2574 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2575 = !DILocation(line: 3002, column: 18, scope: !2574, inlinedAt: !2572)
!2576 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2570)
!2577 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2570)
!2578 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2570)
!2579 = !DILocation(line: 636, column: 55, scope: !2528)
!2580 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2581)
!2581 = distinct !DILocation(line: 638, column: 21, scope: !2502)
!2582 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2583)
!2583 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2584)
!2584 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2585)
!2585 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2586)
!2586 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2581)
!2587 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2588)
!2588 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2589)
!2589 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2590)
!2590 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2591)
!2591 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2584)
!2592 = !{!2593}
!2593 = distinct !{!2593, !2594, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2594 = distinct !{!2594, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2595 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2589)
!2596 = !DILocation(line: 637, column: 25, scope: !2528)
!2597 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2598)
!2598 = !DILocation(line: 637, column: 46, scope: !2528)
!2599 = !DILocation(line: 3002, column: 37, scope: !2600, inlinedAt: !2598)
!2600 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2601 = !DILocation(line: 3002, column: 18, scope: !2600, inlinedAt: !2598)
!2602 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2596)
!2603 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2596)
!2604 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2596)
!2605 = !DILocation(line: 637, column: 55, scope: !2528)
!2606 = !DILocation(line: 0, scope: !2607)
!2607 = !DILexicalBlockFile(scope: !2528, file: !74, discriminator: 0)
!2608 = !DILocation(line: 638, column: 21, scope: !1604)
!2609 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1796)
!2610 = !DILocation(line: 640, column: 44, scope: !1604)
!2611 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2612)
!2612 = !DILocation(line: 641, column: 45, scope: !1604)
!2613 = !DILocation(line: 3002, column: 37, scope: !2614, inlinedAt: !2612)
!2614 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2615 = !DILocation(line: 3002, column: 18, scope: !2614, inlinedAt: !2612)
!2616 = !DILocation(line: 641, column: 39, scope: !1604)
!2617 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2618)
!2618 = !DILocation(line: 19, column: 15, scope: !2619, inlinedAt: !2620)
!2619 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 10)
!2620 = !DILocation(line: 3804, column: 9, scope: !2621, inlinedAt: !2622)
!2621 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 10)
!2622 = !DILocation(line: 641, column: 38, scope: !1604)
!2623 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2624)
!2624 = !DILocation(line: 607, column: 14, scope: !2625, inlinedAt: !2626)
!2625 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 206)
!2626 = !DILocation(line: 295, column: 20, scope: !2627, inlinedAt: !2628)
!2627 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 206)
!2628 = !DILocation(line: 1916, column: 18, scope: !2629, inlinedAt: !2630)
!2629 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 50)
!2630 = !DILocation(line: 1815, column: 76, scope: !2631, inlinedAt: !2632)
!2631 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 48)
!2632 = !DILocation(line: 3729, column: 14, scope: !2633, inlinedAt: !2634)
!2633 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 48)
!2634 = !DILocation(line: 3804, column: 23, scope: !2621, inlinedAt: !2622)
!2635 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2618)
!2636 = !DILocation(line: 641, column: 56, scope: !1604)
!2637 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2638)
!2638 = !DILocation(line: 642, column: 45, scope: !2639)
!2639 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 641, column: 25)
!2640 = !DILocation(line: 3002, column: 37, scope: !2641, inlinedAt: !2638)
!2641 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2642 = !DILocation(line: 3002, column: 18, scope: !2641, inlinedAt: !2638)
!2643 = !DILocation(line: 642, column: 39, scope: !2639)
!2644 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2645)
!2645 = !DILocation(line: 19, column: 15, scope: !2646, inlinedAt: !2647)
!2646 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 12)
!2647 = !DILocation(line: 3804, column: 9, scope: !2648, inlinedAt: !2649)
!2648 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 12)
!2649 = !DILocation(line: 642, column: 38, scope: !2639)
!2650 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2651)
!2651 = !DILocation(line: 607, column: 14, scope: !2652, inlinedAt: !2653)
!2652 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 208)
!2653 = !DILocation(line: 295, column: 20, scope: !2654, inlinedAt: !2655)
!2654 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 208)
!2655 = !DILocation(line: 1916, column: 18, scope: !2656, inlinedAt: !2657)
!2656 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 52)
!2657 = !DILocation(line: 1815, column: 76, scope: !2658, inlinedAt: !2659)
!2658 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 50)
!2659 = !DILocation(line: 3729, column: 14, scope: !2660, inlinedAt: !2661)
!2660 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 50)
!2661 = !DILocation(line: 3804, column: 23, scope: !2648, inlinedAt: !2649)
!2662 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2645)
!2663 = !DILocation(line: 642, column: 56, scope: !2639)
!2664 = !DILocation(line: 643, column: 25, scope: !2665)
!2665 = distinct !DILexicalBlock(scope: !2639, file: !8, line: 642, column: 25)
!2666 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2667)
!2667 = !DILocation(line: 643, column: 46, scope: !2665)
!2668 = !DILocation(line: 3002, column: 37, scope: !2669, inlinedAt: !2667)
!2669 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2670 = !DILocation(line: 3002, column: 18, scope: !2669, inlinedAt: !2667)
!2671 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2664)
!2672 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2664)
!2673 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2664)
!2674 = !DILocation(line: 643, column: 55, scope: !2665)
!2675 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2676)
!2676 = distinct !DILocation(line: 645, column: 21, scope: !2639)
!2677 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2678)
!2678 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2679)
!2679 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2680)
!2680 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2681)
!2681 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2676)
!2682 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2683)
!2683 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2684)
!2684 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2685)
!2685 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2686)
!2686 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2679)
!2687 = !{!2688}
!2688 = distinct !{!2688, !2689, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2689 = distinct !{!2689, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2690 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2684)
!2691 = !DILocation(line: 644, column: 25, scope: !2665)
!2692 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2693)
!2693 = !DILocation(line: 644, column: 46, scope: !2665)
!2694 = !DILocation(line: 3002, column: 37, scope: !2695, inlinedAt: !2693)
!2695 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2696 = !DILocation(line: 3002, column: 18, scope: !2695, inlinedAt: !2693)
!2697 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !2691)
!2698 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !2691)
!2699 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2691)
!2700 = !DILocation(line: 644, column: 55, scope: !2665)
!2701 = !DILocation(line: 0, scope: !2702)
!2702 = !DILexicalBlockFile(scope: !2665, file: !74, discriminator: 0)
!2703 = !DILocation(line: 645, column: 21, scope: !1604)
!2704 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1803)
!2705 = !DILocation(line: 647, column: 44, scope: !1604)
!2706 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2707)
!2707 = !DILocation(line: 648, column: 39, scope: !1604)
!2708 = !DILocation(line: 3002, column: 37, scope: !2709, inlinedAt: !2707)
!2709 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2710 = !DILocation(line: 3002, column: 18, scope: !2709, inlinedAt: !2707)
!2711 = !DILocation(line: 649, column: 40, scope: !2712)
!2712 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 648, column: 25)
!2713 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2714)
!2714 = !DILocation(line: 19, column: 15, scope: !2715, inlinedAt: !2716)
!2715 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 14)
!2716 = !DILocation(line: 3804, column: 9, scope: !2717, inlinedAt: !2718)
!2717 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 14)
!2718 = !DILocation(line: 649, column: 39, scope: !2712)
!2719 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2720)
!2720 = !DILocation(line: 607, column: 14, scope: !2721, inlinedAt: !2722)
!2721 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 210)
!2722 = !DILocation(line: 295, column: 20, scope: !2723, inlinedAt: !2724)
!2723 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 210)
!2724 = !DILocation(line: 1916, column: 18, scope: !2725, inlinedAt: !2726)
!2725 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 54)
!2726 = !DILocation(line: 1815, column: 76, scope: !2727, inlinedAt: !2728)
!2727 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 52)
!2728 = !DILocation(line: 3729, column: 14, scope: !2729, inlinedAt: !2730)
!2729 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 52)
!2730 = !DILocation(line: 3804, column: 23, scope: !2717, inlinedAt: !2718)
!2731 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2714)
!2732 = !DILocation(line: 649, column: 47, scope: !2712)
!2733 = !DILocation(line: 650, column: 40, scope: !2734)
!2734 = distinct !DILexicalBlock(scope: !2712, file: !8, line: 649, column: 25)
!2735 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !2736)
!2736 = !DILocation(line: 3729, column: 14, scope: !2737, inlinedAt: !2738)
!2737 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 54)
!2738 = !DILocation(line: 3804, column: 23, scope: !2739, inlinedAt: !2740)
!2739 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 16)
!2740 = !DILocation(line: 650, column: 39, scope: !2734)
!2741 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2742)
!2742 = !DILocation(line: 19, column: 15, scope: !2743, inlinedAt: !2744)
!2743 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 16)
!2744 = !DILocation(line: 3804, column: 9, scope: !2739, inlinedAt: !2740)
!2745 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2746)
!2746 = !DILocation(line: 607, column: 14, scope: !2747, inlinedAt: !2748)
!2747 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 212)
!2748 = !DILocation(line: 295, column: 20, scope: !2749, inlinedAt: !2750)
!2749 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 212)
!2750 = !DILocation(line: 1916, column: 18, scope: !2751, inlinedAt: !2752)
!2751 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 56)
!2752 = !DILocation(line: 1815, column: 76, scope: !2753, inlinedAt: !2736)
!2753 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 54)
!2754 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2742)
!2755 = !DILocation(line: 650, column: 47, scope: !2734)
!2756 = !DILocation(line: 652, column: 48, scope: !2757)
!2757 = distinct !DILexicalBlock(scope: !2758, file: !8, line: 651, column: 25)
!2758 = distinct !DILexicalBlock(scope: !2759, file: !8, line: 651, column: 25)
!2759 = distinct !DILexicalBlock(scope: !2734, file: !8, line: 650, column: 25)
!2760 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !2761)
!2761 = !DILocation(line: 3729, column: 14, scope: !2762, inlinedAt: !2763)
!2762 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 56)
!2763 = !DILocation(line: 3804, column: 23, scope: !2764, inlinedAt: !2765)
!2764 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 18)
!2765 = !DILocation(line: 652, column: 53, scope: !2757)
!2766 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !2767)
!2767 = !DILocation(line: 19, column: 15, scope: !2768, inlinedAt: !2769)
!2768 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 18)
!2769 = !DILocation(line: 3804, column: 9, scope: !2764, inlinedAt: !2765)
!2770 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2771)
!2771 = !DILocation(line: 607, column: 14, scope: !2772, inlinedAt: !2773)
!2772 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 216)
!2773 = !DILocation(line: 295, column: 20, scope: !2774, inlinedAt: !2775)
!2774 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 216)
!2775 = !DILocation(line: 2000, column: 18, scope: !2776, inlinedAt: !2778)
!2776 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 28)
!2777 = distinct !DISubprogram(name: "as_mut_ptr<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$10as_mut_ptr17h5fd5b382b129a816E", scope: !124, file: !123, line: 1997, type: !12, scopeLine: 1997, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2778 = !DILocation(line: 1851, column: 78, scope: !2779, inlinedAt: !2780)
!2779 = distinct !DISubprogram(name: "as_mut_slice<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$12as_mut_slice17h56f588ad9880b15aE", scope: !124, file: !123, line: 1834, type: !12, scopeLine: 1834, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2780 = !DILocation(line: 3737, column: 14, scope: !2781, inlinedAt: !2783)
!2781 = distinct !DISubprogram(name: "deref_mut<alloc::vec::Vec<u8, alloc::alloc::Global>, alloc::alloc::Global>", linkageName: "_ZN75_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..deref..DerefMut$GT$9deref_mut17h4ffb3e36ed5260e9E", scope: !2782, file: !123, line: 3736, type: !12, scopeLine: 3736, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2782 = !DINamespace(name: "{impl#10}", scope: !125)
!2783 = !DILocation(line: 3812, column: 34, scope: !2784, inlinedAt: !2786)
!2784 = distinct !DISubprogram(name: "index_mut<alloc::vec::Vec<u8, alloc::alloc::Global>, usize, alloc::alloc::Global>", linkageName: "_ZN84_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..index..IndexMut$LT$I$GT$$GT$9index_mut17he73784ebcb98d031E", scope: !2785, file: !123, line: 3811, type: !12, scopeLine: 3811, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2785 = !DINamespace(name: "{impl#15}", scope: !125)
!2786 = !DILocation(line: 654, column: 30, scope: !2759)
!2787 = !DILocation(line: 278, column: 9, scope: !2788, inlinedAt: !2789)
!2788 = distinct !DISubprogram(name: "index_mut<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN75_$LT$usize$u20$as$u20$core..slice..index..SliceIndex$LT$$u5b$T$u5d$$GT$$GT$9index_mut17hf6ca4ec0db674eb6E", scope: !694, file: !693, line: 276, type: !12, scopeLine: 276, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2789 = !DILocation(line: 31, column: 15, scope: !2790, inlinedAt: !2792)
!2790 = distinct !DISubprogram(name: "index_mut<alloc::vec::Vec<u8, alloc::alloc::Global>, usize>", linkageName: "_ZN4core5slice5index77_$LT$impl$u20$core..ops..index..IndexMut$LT$I$GT$$u20$for$u20$$u5b$T$u5d$$GT$9index_mut17hd20a8366a72b6be8E", scope: !2791, file: !693, line: 30, type: !12, scopeLine: 30, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2791 = !DINamespace(name: "{impl#1}", scope: !695)
!2792 = !DILocation(line: 3812, column: 9, scope: !2784, inlinedAt: !2786)
!2793 = !{!2794}
!2794 = distinct !{!2794, !2795, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2795 = distinct !{!2795, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2796 = !DILocation(line: 654, column: 25, scope: !2759)
!2797 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2798)
!2798 = distinct !DILocation(line: 654, column: 25, scope: !2759)
!2799 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2800)
!2800 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2801)
!2801 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2802)
!2802 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2803)
!2803 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2798)
!2804 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2805)
!2805 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2806)
!2806 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2807)
!2807 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2808)
!2808 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2801)
!2809 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2806)
!2810 = !DILocation(line: 1851, column: 92, scope: !2779, inlinedAt: !2811)
!2811 = !DILocation(line: 3737, column: 14, scope: !2812, inlinedAt: !2813)
!2812 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 4)
!2813 = !DILocation(line: 3812, column: 34, scope: !2814, inlinedAt: !2815)
!2814 = !DILexicalBlockFile(scope: !2784, file: !123, discriminator: 4)
!2815 = !DILocation(line: 655, column: 30, scope: !2759)
!2816 = !DILocation(line: 278, column: 14, scope: !2788, inlinedAt: !2817)
!2817 = !DILocation(line: 31, column: 15, scope: !2818, inlinedAt: !2819)
!2818 = !DILexicalBlockFile(scope: !2790, file: !693, discriminator: 4)
!2819 = !DILocation(line: 3812, column: 9, scope: !2814, inlinedAt: !2815)
!2820 = !DILocation(line: 278, column: 14, scope: !2788, inlinedAt: !2789)
!2821 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2822)
!2822 = !DILocation(line: 607, column: 14, scope: !2823, inlinedAt: !2824)
!2823 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 220)
!2824 = !DILocation(line: 295, column: 20, scope: !2825, inlinedAt: !2826)
!2825 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 220)
!2826 = !DILocation(line: 2000, column: 18, scope: !2827, inlinedAt: !2828)
!2827 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 32)
!2828 = !DILocation(line: 1851, column: 78, scope: !2829, inlinedAt: !2811)
!2829 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 4)
!2830 = !DILocation(line: 278, column: 9, scope: !2788, inlinedAt: !2817)
!2831 = !{!2832}
!2832 = distinct !{!2832, !2833, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2833 = distinct !{!2833, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2834 = !DILocation(line: 655, column: 25, scope: !2759)
!2835 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2836)
!2836 = distinct !DILocation(line: 655, column: 25, scope: !2759)
!2837 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2838)
!2838 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2839)
!2839 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2840)
!2840 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2841)
!2841 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2836)
!2842 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2843)
!2843 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2844)
!2844 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2845)
!2845 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2846)
!2846 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2839)
!2847 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2844)
!2848 = !DILocation(line: 656, column: 21, scope: !1604)
!2849 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2850)
!2850 = !DILocation(line: 607, column: 14, scope: !2851, inlinedAt: !2852)
!2851 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 214)
!2852 = !DILocation(line: 295, column: 20, scope: !2853, inlinedAt: !2854)
!2853 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 214)
!2854 = !DILocation(line: 1916, column: 18, scope: !2855, inlinedAt: !2856)
!2855 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 58)
!2856 = !DILocation(line: 1815, column: 76, scope: !2857, inlinedAt: !2761)
!2857 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 56)
!2858 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !2767)
!2859 = !DILocation(line: 652, column: 65, scope: !2757)
!2860 = !DILocation(line: 1851, column: 92, scope: !2779, inlinedAt: !2861)
!2861 = !DILocation(line: 3737, column: 14, scope: !2862, inlinedAt: !2863)
!2862 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 2)
!2863 = !DILocation(line: 3812, column: 34, scope: !2864, inlinedAt: !2865)
!2864 = !DILexicalBlockFile(scope: !2784, file: !123, discriminator: 2)
!2865 = !DILocation(line: 652, column: 34, scope: !2757)
!2866 = !DILocation(line: 278, column: 14, scope: !2788, inlinedAt: !2867)
!2867 = !DILocation(line: 31, column: 15, scope: !2868, inlinedAt: !2869)
!2868 = !DILexicalBlockFile(scope: !2790, file: !693, discriminator: 2)
!2869 = !DILocation(line: 3812, column: 9, scope: !2864, inlinedAt: !2865)
!2870 = !DILocation(line: 652, column: 54, scope: !2757)
!2871 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2872)
!2872 = !DILocation(line: 607, column: 14, scope: !2873, inlinedAt: !2874)
!2873 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 218)
!2874 = !DILocation(line: 295, column: 20, scope: !2875, inlinedAt: !2876)
!2875 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 218)
!2876 = !DILocation(line: 2000, column: 18, scope: !2877, inlinedAt: !2878)
!2877 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 30)
!2878 = !DILocation(line: 1851, column: 78, scope: !2879, inlinedAt: !2861)
!2879 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 2)
!2880 = !DILocation(line: 278, column: 9, scope: !2788, inlinedAt: !2867)
!2881 = !{!2882}
!2882 = distinct !{!2882, !2883, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!2883 = distinct !{!2883, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!2884 = !DILocation(line: 652, column: 29, scope: !2757)
!2885 = !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2886)
!2886 = distinct !DILocation(line: 652, column: 29, scope: !2757)
!2887 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !2888)
!2888 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !2889)
!2889 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !2890)
!2890 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !2891)
!2891 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !2886)
!2892 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !2893)
!2893 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !2894)
!2894 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !2895)
!2895 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !2896)
!2896 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !2889)
!2897 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !2894)
!2898 = !DILocation(line: 652, column: 71, scope: !2757)
!2899 = !DILocation(line: 652, column: 35, scope: !2757)
!2900 = !{!2901}
!2901 = distinct !{!2901, !2883, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1:It1"}
!2902 = !{!2903}
!2903 = distinct !{!2903, !2883, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1:It2"}
!2904 = !{!2905}
!2905 = distinct !{!2905, !2883, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1:It3"}
!2906 = !DILocation(line: 1851, column: 92, scope: !2779, inlinedAt: !2780)
!2907 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1810)
!2908 = !DILocation(line: 658, column: 44, scope: !1604)
!2909 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !2910)
!2910 = !DILocation(line: 659, column: 39, scope: !1604)
!2911 = !DILocation(line: 3002, column: 37, scope: !2912, inlinedAt: !2910)
!2912 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!2913 = !DILocation(line: 3002, column: 18, scope: !2912, inlinedAt: !2910)
!2914 = !DILocation(line: 660, column: 36, scope: !2915)
!2915 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 659, column: 25)
!2916 = !DILocation(line: 908, column: 27, scope: !2917, inlinedAt: !2918)
!2917 = distinct !DISubprogram(name: "swap<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$4swap17h0dfabbd242d634bcE", scope: !182, file: !181, line: 905, type: !12, scopeLine: 905, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2918 = !DILocation(line: 660, column: 31, scope: !2915)
!2919 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2920)
!2920 = !DILocation(line: 607, column: 14, scope: !2921, inlinedAt: !2922)
!2921 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 222)
!2922 = !DILocation(line: 295, column: 20, scope: !2923, inlinedAt: !2924)
!2923 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 222)
!2924 = !DILocation(line: 2000, column: 18, scope: !2925, inlinedAt: !2926)
!2925 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 34)
!2926 = !DILocation(line: 1851, column: 78, scope: !2927, inlinedAt: !2928)
!2927 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 6)
!2928 = !DILocation(line: 3737, column: 14, scope: !2929, inlinedAt: !2930)
!2929 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 6)
!2930 = !DILocation(line: 660, column: 25, scope: !2915)
!2931 = !DILocation(line: 908, column: 18, scope: !2917, inlinedAt: !2918)
!2932 = !DILocation(line: 909, column: 18, scope: !2933, inlinedAt: !2918)
!2933 = distinct !DILexicalBlock(scope: !2917, file: !181, line: 908, column: 9)
!2934 = !DILocation(line: 1302, column: 9, scope: !2935, inlinedAt: !2936)
!2935 = distinct !DISubprogram(name: "swap<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr4swap17h8472f2c915d563d2E", scope: !170, file: !306, line: 1299, type: !12, scopeLine: 1299, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2936 = !DILocation(line: 915, column: 13, scope: !2937, inlinedAt: !2918)
!2937 = distinct !DILexicalBlock(scope: !2933, file: !181, line: 909, column: 9)
!2938 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !2940)
!2939 = distinct !DISubprogram(name: "copy_nonoverlapping<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr19copy_nonoverlapping17h648bda55887e2123E", scope: !170, file: !306, line: 526, type: !12, scopeLine: 526, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2940 = !DILocation(line: 1310, column: 9, scope: !2941, inlinedAt: !2936)
!2941 = distinct !DILexicalBlock(scope: !2935, file: !306, line: 1302, column: 5)
!2942 = !DILocation(line: 638, column: 9, scope: !2943, inlinedAt: !2944)
!2943 = distinct !DISubprogram(name: "copy<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core3ptr4copy17hfc9af9fff227a039E", scope: !170, file: !306, line: 623, type: !12, scopeLine: 623, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2944 = !DILocation(line: 1311, column: 9, scope: !2941, inlinedAt: !2936)
!2945 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !2946)
!2946 = !DILocation(line: 1312, column: 9, scope: !2941, inlinedAt: !2936)
!2947 = !DILocation(line: 1314, column: 1, scope: !2935, inlinedAt: !2936)
!2948 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2949)
!2949 = !DILocation(line: 607, column: 14, scope: !2950, inlinedAt: !2951)
!2950 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 224)
!2951 = !DILocation(line: 295, column: 20, scope: !2952, inlinedAt: !2953)
!2952 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 224)
!2953 = !DILocation(line: 2000, column: 18, scope: !2954, inlinedAt: !2955)
!2954 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 36)
!2955 = !DILocation(line: 1851, column: 78, scope: !2956, inlinedAt: !2957)
!2956 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 8)
!2957 = !DILocation(line: 3737, column: 14, scope: !2958, inlinedAt: !2959)
!2958 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 8)
!2959 = !DILocation(line: 661, column: 25, scope: !2915)
!2960 = !DILocation(line: 1851, column: 92, scope: !2779, inlinedAt: !2957)
!2961 = !DILocation(line: 661, column: 36, scope: !2915)
!2962 = !DILocation(line: 661, column: 43, scope: !2915)
!2963 = !DILocation(line: 908, column: 27, scope: !2917, inlinedAt: !2964)
!2964 = !DILocation(line: 661, column: 31, scope: !2915)
!2965 = !DILocation(line: 909, column: 27, scope: !2966, inlinedAt: !2964)
!2966 = distinct !DILexicalBlock(scope: !2917, file: !181, line: 908, column: 9)
!2967 = !DILocation(line: 908, column: 18, scope: !2917, inlinedAt: !2964)
!2968 = !DILocation(line: 909, column: 18, scope: !2966, inlinedAt: !2964)
!2969 = !DILocation(line: 1302, column: 9, scope: !2935, inlinedAt: !2970)
!2970 = !DILocation(line: 915, column: 13, scope: !2971, inlinedAt: !2964)
!2971 = !DILexicalBlockFile(scope: !2972, file: !181, discriminator: 2)
!2972 = distinct !DILexicalBlock(scope: !2966, file: !181, line: 909, column: 9)
!2973 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !2974)
!2974 = !DILocation(line: 1310, column: 9, scope: !2975, inlinedAt: !2970)
!2975 = !DILexicalBlockFile(scope: !2976, file: !306, discriminator: 2)
!2976 = distinct !DILexicalBlock(scope: !2935, file: !306, line: 1302, column: 5)
!2977 = !DILocation(line: 638, column: 9, scope: !2943, inlinedAt: !2978)
!2978 = !DILocation(line: 1311, column: 9, scope: !2975, inlinedAt: !2970)
!2979 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !2980)
!2980 = !DILocation(line: 1312, column: 9, scope: !2975, inlinedAt: !2970)
!2981 = !DILocation(line: 1314, column: 1, scope: !2935, inlinedAt: !2970)
!2982 = !DILocation(line: 662, column: 21, scope: !1604)
!2983 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1817)
!2984 = !DILocation(line: 664, column: 44, scope: !1604)
!2985 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !2986)
!2986 = !DILocation(line: 3729, column: 14, scope: !2987, inlinedAt: !2988)
!2987 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 58)
!2988 = !DILocation(line: 665, column: 61, scope: !1604)
!2989 = !DILocation(line: 282, column: 16, scope: !2990, inlinedAt: !2992)
!2990 = distinct !DILexicalBlock(scope: !2991, file: !181, line: 282, column: 34)
!2991 = distinct !DISubprogram(name: "last<alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$4last17h08e1f0ae1c7e0ac3E", scope: !182, file: !181, line: 281, type: !12, scopeLine: 281, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2992 = !DILocation(line: 665, column: 67, scope: !1604)
!2993 = !DILocation(line: 1016, column: 21, scope: !2994, inlinedAt: !2995)
!2994 = distinct !DISubprogram(name: "unwrap<&alloc::vec::Vec<u8, alloc::alloc::Global>>", linkageName: "_ZN4core6option15Option$LT$T$GT$6unwrap17h1e6ba99551e89b69E", scope: !703, file: !702, line: 1013, type: !12, scopeLine: 1013, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!2995 = !DILocation(line: 665, column: 74, scope: !1604)
!2996 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !2997)
!2997 = !DILocation(line: 607, column: 14, scope: !2998, inlinedAt: !2999)
!2998 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 226)
!2999 = !DILocation(line: 295, column: 20, scope: !3000, inlinedAt: !3001)
!3000 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 226)
!3001 = !DILocation(line: 1916, column: 18, scope: !3002, inlinedAt: !3003)
!3002 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 60)
!3003 = !DILocation(line: 1815, column: 76, scope: !3004, inlinedAt: !2986)
!3004 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 58)
!3005 = !DILocation(line: 282, column: 21, scope: !2990, inlinedAt: !2992)
!3006 = !DILocation(line: 1815, column: 86, scope: !3007, inlinedAt: !3008)
!3007 = distinct !DISubprogram(name: "as_slice<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$8as_slice17hc138f7c94566f8dcE", scope: !124, file: !123, line: 1798, type: !12, scopeLine: 1798, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3008 = !DILocation(line: 3729, column: 14, scope: !3009, inlinedAt: !3011)
!3009 = !DILexicalBlockFile(scope: !3010, file: !123, discriminator: 60)
!3010 = distinct !DISubprogram(name: "deref<u8, alloc::alloc::Global>", linkageName: "_ZN72_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..deref..Deref$GT$5deref17he3924f5dbf0eaac0E", scope: !163, file: !123, line: 3728, type: !12, scopeLine: 3728, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3011 = !DILocation(line: 665, column: 61, scope: !3012)
!3012 = !DILexicalBlockFile(scope: !1604, file: !8, discriminator: 2)
!3013 = !DILocation(line: 241, column: 16, scope: !1066, inlinedAt: !3014)
!3014 = distinct !DILocation(line: 235, column: 13, scope: !1069, inlinedAt: !3015)
!3015 = distinct !DILocation(line: 665, column: 28, scope: !1604)
!3016 = !DILocation(line: 612, column: 9, scope: !3017, inlinedAt: !3018)
!3017 = distinct !DISubprogram(name: "non_null<alloc::alloc::Global, u8>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8non_null17h8768ed1759daf052E", scope: !148, file: !147, line: 611, type: !12, scopeLine: 611, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3018 = !DILocation(line: 607, column: 14, scope: !3019, inlinedAt: !3021)
!3019 = !DILexicalBlockFile(scope: !3020, file: !147, discriminator: 228)
!3020 = distinct !DISubprogram(name: "ptr<alloc::alloc::Global, u8>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$3ptr17h8db0de610646a8bdE", scope: !148, file: !147, line: 606, type: !12, scopeLine: 606, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3021 = !DILocation(line: 295, column: 20, scope: !3022, inlinedAt: !3024)
!3022 = !DILexicalBlockFile(scope: !3023, file: !147, discriminator: 228)
!3023 = distinct !DISubprogram(name: "ptr<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$3ptr17h50726882601530acE", scope: !156, file: !147, line: 294, type: !12, scopeLine: 294, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3024 = !DILocation(line: 1916, column: 18, scope: !3025, inlinedAt: !3027)
!3025 = !DILexicalBlockFile(scope: !3026, file: !123, discriminator: 62)
!3026 = distinct !DISubprogram(name: "as_ptr<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$6as_ptr17h01d84e7f690e99d5E", scope: !124, file: !123, line: 1913, type: !12, scopeLine: 1913, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3027 = !DILocation(line: 1815, column: 76, scope: !3028, inlinedAt: !3008)
!3028 = !DILexicalBlockFile(scope: !3007, file: !123, discriminator: 60)
!3029 = !DILocation(line: 241, column: 28, scope: !1066, inlinedAt: !3014)
!3030 = !DILocation(line: 28, column: 31, scope: !1074, inlinedAt: !3031)
!3031 = distinct !DILocation(line: 236, column: 34, scope: !1079, inlinedAt: !3015)
!3032 = !{!3033}
!3033 = distinct !{!3033, !3034, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE: %v.0"}
!3034 = distinct !{!3034, !"_ZN7bitcoin9blockdata6script15read_scriptbool17h289fe16ff7d4941eE"}
!3035 = !DILocation(line: 178, column: 46, scope: !1084, inlinedAt: !3036)
!3036 = distinct !DILocation(line: 28, column: 17, scope: !1074, inlinedAt: !3031)
!3037 = !DILocation(line: 236, column: 33, scope: !1079, inlinedAt: !3015)
!3038 = !DILocation(line: 1720, column: 9, scope: !1090, inlinedAt: !3039)
!3039 = distinct !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !3040)
!3040 = distinct !DILocation(line: 314, column: 42, scope: !1096, inlinedAt: !3041)
!3041 = distinct !DILocation(line: 236, column: 71, scope: !1079, inlinedAt: !3015)
!3042 = !DILocation(line: 180, column: 28, scope: !1092, inlinedAt: !3040)
!3043 = !DILocation(line: 659, column: 28, scope: !1101, inlinedAt: !3044)
!3044 = distinct !DILocation(line: 185, column: 40, scope: !1092, inlinedAt: !3040)
!3045 = !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !3041)
!3046 = !{!3047}
!3047 = distinct !{!3047, !3048, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E: %self"}
!3048 = distinct !{!3048, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3all17h1d81d1c2a250e395E"}
!3049 = !DILocation(line: 236, column: 80, scope: !1108, inlinedAt: !3050)
!3050 = distinct !DILocation(line: 315, column: 25, scope: !1096, inlinedAt: !3041)
!3051 = !DILocation(line: 666, column: 59, scope: !1604)
!3052 = !DILocation(line: 667, column: 29, scope: !3053)
!3053 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 666, column: 29)
!3054 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3055)
!3055 = !DILocation(line: 667, column: 50, scope: !3053)
!3056 = !DILocation(line: 3002, column: 37, scope: !3057, inlinedAt: !3055)
!3057 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3058 = !DILocation(line: 3002, column: 18, scope: !3057, inlinedAt: !3055)
!3059 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3052)
!3060 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3052)
!3061 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3052)
!3062 = !DILocation(line: 667, column: 59, scope: !3053)
!3063 = !DILocation(line: 665, column: 25, scope: !1604)
!3064 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1829)
!3065 = !DILocation(line: 672, column: 73, scope: !1830)
!3066 = !DILocation(line: 673, column: 21, scope: !1604)
!3067 = !DILocation(line: 2175, column: 17, scope: !1764, inlinedAt: !1840)
!3068 = !DILocation(line: 675, column: 35, scope: !1604)
!3069 = !DILocation(line: 2189, column: 23, scope: !3070, inlinedAt: !3071)
!3070 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3071 = !DILocation(line: 675, column: 25, scope: !3072)
!3072 = !DILexicalBlockFile(scope: !3073, file: !8, discriminator: 2)
!3073 = distinct !DILexicalBlock(scope: !3074, file: !8, line: 675, column: 35)
!3074 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 675, column: 35)
!3075 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3076)
!3076 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3077)
!3077 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3078)
!3078 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3079)
!3079 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3080)
!3080 = distinct !DILocation(line: 675, column: 36, scope: !1604)
!3081 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3082)
!3082 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3083)
!3083 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3084)
!3084 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3085)
!3085 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3077)
!3086 = !{!3087}
!3087 = distinct !{!3087, !3088, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3088 = distinct !{!3088, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3089 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3083)
!3090 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1844)
!3091 = !DILocation(line: 678, column: 44, scope: !1604)
!3092 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !3093)
!3093 = !DILocation(line: 3729, column: 14, scope: !3094, inlinedAt: !3095)
!3094 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 192)
!3095 = !DILocation(line: 679, column: 33, scope: !1604)
!3096 = !DILocation(line: 282, column: 16, scope: !3097, inlinedAt: !3098)
!3097 = distinct !DILexicalBlock(scope: !2991, file: !181, line: 282, column: 34)
!3098 = !DILocation(line: 679, column: 39, scope: !1604)
!3099 = !DILocation(line: 1016, column: 21, scope: !2994, inlinedAt: !3100)
!3100 = !DILocation(line: 679, column: 46, scope: !1604)
!3101 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3102)
!3102 = !DILocation(line: 607, column: 14, scope: !3103, inlinedAt: !3104)
!3103 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 232)
!3104 = !DILocation(line: 295, column: 20, scope: !3105, inlinedAt: !3106)
!3105 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 232)
!3106 = !DILocation(line: 1916, column: 18, scope: !3107, inlinedAt: !3108)
!3107 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 194)
!3108 = !DILocation(line: 1815, column: 76, scope: !3109, inlinedAt: !3093)
!3109 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 192)
!3110 = !DILocation(line: 282, column: 21, scope: !3097, inlinedAt: !3098)
!3111 = !DILocation(line: 679, column: 55, scope: !1604)
!3112 = !DILocation(line: 680, column: 25, scope: !3113)
!3113 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 679, column: 25)
!3114 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3115)
!3115 = !DILocation(line: 680, column: 46, scope: !3113)
!3116 = !DILocation(line: 3002, column: 37, scope: !3117, inlinedAt: !3115)
!3117 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3118 = !DILocation(line: 3002, column: 18, scope: !3117, inlinedAt: !3115)
!3119 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3112)
!3120 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3112)
!3121 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3112)
!3122 = !DILocation(line: 680, column: 55, scope: !3113)
!3123 = !DILocation(line: 681, column: 21, scope: !1604)
!3124 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1851)
!3125 = !DILocation(line: 683, column: 44, scope: !1604)
!3126 = !DILocation(line: 684, column: 35, scope: !1604)
!3127 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !3126)
!3128 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !3126)
!3129 = !DILocation(line: 0, scope: !1764, inlinedAt: !3126)
!3130 = !DILocation(line: 684, column: 45, scope: !1604)
!3131 = !DILocation(line: 2189, column: 23, scope: !3132, inlinedAt: !3133)
!3132 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3133 = !DILocation(line: 684, column: 35, scope: !3134)
!3134 = !DILexicalBlockFile(scope: !3135, file: !8, discriminator: 2)
!3135 = distinct !DILexicalBlock(scope: !3136, file: !8, line: 684, column: 45)
!3136 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 684, column: 45)
!3137 = !DILocation(line: 685, column: 25, scope: !3138)
!3138 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 684, column: 25)
!3139 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !3137)
!3140 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !3137)
!3141 = !DILocation(line: 0, scope: !1764, inlinedAt: !3137)
!3142 = !DILocation(line: 2175, column: 17, scope: !1764, inlinedAt: !3137)
!3143 = !DILocation(line: 685, column: 35, scope: !3138)
!3144 = !DILocation(line: 2189, column: 23, scope: !3145, inlinedAt: !3146)
!3145 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3146 = !DILocation(line: 685, column: 25, scope: !3147)
!3147 = !DILexicalBlockFile(scope: !3148, file: !8, discriminator: 2)
!3148 = distinct !DILexicalBlock(scope: !3149, file: !8, line: 685, column: 35)
!3149 = distinct !DILexicalBlock(scope: !3138, file: !8, line: 685, column: 35)
!3150 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3151)
!3151 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3152)
!3152 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3153)
!3153 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3154)
!3154 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3155)
!3155 = distinct !DILocation(line: 687, column: 21, scope: !1604)
!3156 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3157)
!3157 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3158)
!3158 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3159)
!3159 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3160)
!3160 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3152)
!3161 = !{!3162}
!3162 = distinct !{!3162, !3163, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3163 = distinct !{!3163, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3164 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3158)
!3165 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3166)
!3166 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3167)
!3167 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3168)
!3168 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3169)
!3169 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3170)
!3170 = distinct !DILocation(line: 685, column: 36, scope: !3138)
!3171 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3172)
!3172 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3173)
!3173 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3174)
!3174 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3175)
!3175 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3167)
!3176 = !{!3177}
!3177 = distinct !{!3177, !3178, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3178 = distinct !{!3178, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3179 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3173)
!3180 = !DILocation(line: 686, column: 25, scope: !3138)
!3181 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3182)
!3182 = !DILocation(line: 686, column: 46, scope: !3138)
!3183 = !DILocation(line: 3002, column: 37, scope: !3184, inlinedAt: !3182)
!3184 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3185 = !DILocation(line: 3002, column: 18, scope: !3184, inlinedAt: !3182)
!3186 = !DILocation(line: 686, column: 53, scope: !3138)
!3187 = !DILocation(line: 686, column: 56, scope: !3138)
!3188 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3180)
!3189 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3180)
!3190 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3180)
!3191 = !DILocation(line: 686, column: 57, scope: !3138)
!3192 = !DILocation(line: 0, scope: !3193)
!3193 = !DILexicalBlockFile(scope: !3138, file: !74, discriminator: 0)
!3194 = !DILocation(line: 687, column: 21, scope: !1604)
!3195 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1858)
!3196 = !DILocation(line: 689, column: 44, scope: !1604)
!3197 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3198)
!3198 = !DILocation(line: 690, column: 45, scope: !1604)
!3199 = !DILocation(line: 3002, column: 37, scope: !3200, inlinedAt: !3198)
!3200 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3201 = !DILocation(line: 3002, column: 18, scope: !3200, inlinedAt: !3198)
!3202 = !DILocation(line: 690, column: 39, scope: !1604)
!3203 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !3204)
!3204 = !DILocation(line: 19, column: 15, scope: !3205, inlinedAt: !3206)
!3205 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 20)
!3206 = !DILocation(line: 3804, column: 9, scope: !3207, inlinedAt: !3208)
!3207 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 20)
!3208 = !DILocation(line: 690, column: 38, scope: !1604)
!3209 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3210)
!3210 = !DILocation(line: 607, column: 14, scope: !3211, inlinedAt: !3212)
!3211 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 234)
!3212 = !DILocation(line: 295, column: 20, scope: !3213, inlinedAt: !3214)
!3213 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 234)
!3214 = !DILocation(line: 1916, column: 18, scope: !3215, inlinedAt: !3216)
!3215 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 196)
!3216 = !DILocation(line: 1815, column: 76, scope: !3217, inlinedAt: !3218)
!3217 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 194)
!3218 = !DILocation(line: 3729, column: 14, scope: !3219, inlinedAt: !3220)
!3219 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 194)
!3220 = !DILocation(line: 3804, column: 23, scope: !3207, inlinedAt: !3208)
!3221 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !3204)
!3222 = !DILocation(line: 690, column: 56, scope: !1604)
!3223 = !DILocation(line: 691, column: 25, scope: !3224)
!3224 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 690, column: 25)
!3225 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3226)
!3226 = !DILocation(line: 691, column: 46, scope: !3224)
!3227 = !DILocation(line: 3002, column: 37, scope: !3228, inlinedAt: !3226)
!3228 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3229 = !DILocation(line: 3002, column: 18, scope: !3228, inlinedAt: !3226)
!3230 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3223)
!3231 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3223)
!3232 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3223)
!3233 = !DILocation(line: 691, column: 55, scope: !3224)
!3234 = !DILocation(line: 692, column: 21, scope: !1604)
!3235 = !DILocation(line: 2189, column: 23, scope: !3236, inlinedAt: !3237)
!3236 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3237 = !DILocation(line: 694, column: 45, scope: !3238)
!3238 = !DILexicalBlockFile(scope: !3239, file: !8, discriminator: 2)
!3239 = distinct !DILexicalBlock(scope: !3240, file: !8, line: 694, column: 55)
!3240 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 694, column: 55)
!3241 = !DILocation(line: 694, column: 61, scope: !1604)
!3242 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1865)
!3243 = distinct !DISubprogram(name: "branch<i64, rbitcoin_primitives::scriptnum::ScriptNumError>", linkageName: "_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$6branch17h28097484a4b16ac8E", scope: !1746, file: !384, line: 2172, type: !12, scopeLine: 2172, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3244 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1865)
!3245 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1865)
!3246 = !DILocation(line: 2189, column: 27, scope: !3247, inlinedAt: !3249)
!3247 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!3248 = distinct !DISubprogram(name: "from_residual<bool, rbitcoin_primitives::scriptnum::ScriptNumError, rbitcoin_consensus::error::ConsensusError>", linkageName: "_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17hc1fdac5cb922c6dfE", scope: !597, file: !384, line: 2187, type: !12, scopeLine: 2187, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3249 = !DILocation(line: 694, column: 33, scope: !3250)
!3250 = !DILexicalBlockFile(scope: !3251, file: !8, discriminator: 2)
!3251 = distinct !DILexicalBlock(scope: !3252, file: !8, line: 694, column: 61)
!3252 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 694, column: 61)
!3253 = !DILocation(line: 2189, column: 23, scope: !3247, inlinedAt: !3249)
!3254 = !DILocation(line: 2189, column: 40, scope: !3247, inlinedAt: !3249)
!3255 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3256)
!3256 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3257)
!3257 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3258)
!3258 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3259)
!3259 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3260)
!3260 = distinct !DILocation(line: 694, column: 62, scope: !1604)
!3261 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3262)
!3262 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3263)
!3263 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3264)
!3264 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3265)
!3265 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3257)
!3266 = !{!3267}
!3267 = distinct !{!3267, !3268, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3268 = distinct !{!3268, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3269 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3263)
!3270 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1865)
!3271 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3272)
!3272 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3273)
!3273 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3274)
!3274 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3275)
!3275 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3276)
!3276 = distinct !DILocation(line: 694, column: 62, scope: !1604)
!3277 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3278)
!3278 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3279)
!3279 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3280)
!3280 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3281)
!3281 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3273)
!3282 = !{!3283}
!3283 = distinct !{!3283, !3284, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3284 = distinct !{!3284, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3285 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3279)
!3286 = !DILocation(line: 695, column: 28, scope: !3287)
!3287 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 694, column: 25)
!3288 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3289)
!3289 = !DILocation(line: 695, column: 57, scope: !3287)
!3290 = !DILocation(line: 3002, column: 37, scope: !3291, inlinedAt: !3289)
!3291 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3292 = !DILocation(line: 3002, column: 18, scope: !3291, inlinedAt: !3289)
!3293 = !DILocation(line: 695, column: 37, scope: !3287)
!3294 = !DILocation(line: 0, scope: !199, inlinedAt: !3295)
!3295 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !3296)
!3296 = !DILocation(line: 177, column: 20, scope: !3297, inlinedAt: !3298)
!3297 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 28)
!3298 = !DILocation(line: 965, column: 20, scope: !3299, inlinedAt: !3300)
!3299 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 28)
!3300 = !DILocation(line: 448, column: 29, scope: !3301, inlinedAt: !3303)
!3301 = !DILexicalBlockFile(scope: !3302, file: !209, discriminator: 28)
!3302 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!3303 = !DILocation(line: 400, column: 16, scope: !3304, inlinedAt: !3305)
!3304 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 28)
!3305 = !DILocation(line: 376, column: 14, scope: !3306, inlinedAt: !3307)
!3306 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 28)
!3307 = !DILocation(line: 842, column: 14, scope: !3308, inlinedAt: !3309)
!3308 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 26)
!3309 = !DILocation(line: 211, column: 62, scope: !3310, inlinedAt: !3311)
!3310 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 26)
!3311 = !DILocation(line: 3114, column: 11, scope: !3312, inlinedAt: !3313)
!3312 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 26)
!3313 = !DILocation(line: 778, column: 9, scope: !3314, inlinedAt: !3315)
!3314 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 26)
!3315 = !DILocation(line: 696, column: 73, scope: !3287)
!3316 = !{!3317}
!3317 = distinct !{!3317, !3318, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!3318 = distinct !{!3318, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!3319 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !3320)
!3320 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !3321)
!3321 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !3322)
!3322 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !3323)
!3323 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !3295)
!3324 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !3295)
!3325 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !3295)
!3326 = !DILocation(line: 698, column: 39, scope: !3287)
!3327 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !3328)
!3328 = !DILocation(line: 19, column: 15, scope: !3329, inlinedAt: !3330)
!3329 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 22)
!3330 = !DILocation(line: 3804, column: 9, scope: !3331, inlinedAt: !3332)
!3331 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 22)
!3332 = !DILocation(line: 698, column: 38, scope: !3287)
!3333 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3334)
!3334 = !DILocation(line: 607, column: 14, scope: !3335, inlinedAt: !3336)
!3335 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 240)
!3336 = !DILocation(line: 295, column: 20, scope: !3337, inlinedAt: !3338)
!3337 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 240)
!3338 = !DILocation(line: 1916, column: 18, scope: !3339, inlinedAt: !3340)
!3339 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 200)
!3340 = !DILocation(line: 1815, column: 76, scope: !3341, inlinedAt: !3342)
!3341 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 198)
!3342 = !DILocation(line: 3729, column: 14, scope: !3343, inlinedAt: !3344)
!3343 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 198)
!3344 = !DILocation(line: 3804, column: 23, scope: !3331, inlinedAt: !3332)
!3345 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !3328)
!3346 = !DILocation(line: 698, column: 69, scope: !3287)
!3347 = !DILocation(line: 699, column: 25, scope: !3348)
!3348 = distinct !DILexicalBlock(scope: !3287, file: !8, line: 698, column: 25)
!3349 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3350)
!3350 = !DILocation(line: 699, column: 46, scope: !3348)
!3351 = !DILocation(line: 3002, column: 37, scope: !3352, inlinedAt: !3350)
!3352 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3353 = !DILocation(line: 3002, column: 18, scope: !3352, inlinedAt: !3350)
!3354 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3347)
!3355 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3347)
!3356 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3347)
!3357 = !DILocation(line: 699, column: 55, scope: !3348)
!3358 = !DILocation(line: 0, scope: !3359)
!3359 = !DILexicalBlockFile(scope: !3287, file: !74, discriminator: 0)
!3360 = !DILocation(line: 700, column: 21, scope: !1604)
!3361 = !DILocation(line: 441, column: 25, scope: !3362, inlinedAt: !3296)
!3362 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!3363 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !3364)
!3364 = !DILocation(line: 1252, column: 18, scope: !3365, inlinedAt: !3366)
!3365 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 28)
!3366 = !DILocation(line: 454, column: 36, scope: !3367, inlinedAt: !3303)
!3367 = !DILexicalBlockFile(scope: !3368, file: !209, discriminator: 28)
!3368 = distinct !DILexicalBlock(scope: !3302, file: !209, line: 448, column: 17)
!3369 = !DILocation(line: 696, column: 36, scope: !3287)
!3370 = !DILocation(line: 2189, column: 23, scope: !3371, inlinedAt: !3372)
!3371 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3372 = !DILocation(line: 702, column: 45, scope: !3373)
!3373 = !DILexicalBlockFile(scope: !3374, file: !8, discriminator: 2)
!3374 = distinct !DILexicalBlock(scope: !3375, file: !8, line: 702, column: 55)
!3375 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 702, column: 55)
!3376 = !DILocation(line: 702, column: 61, scope: !1604)
!3377 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1871)
!3378 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1871)
!3379 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1871)
!3380 = !DILocation(line: 2189, column: 27, scope: !3381, inlinedAt: !3382)
!3381 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!3382 = !DILocation(line: 702, column: 33, scope: !3383)
!3383 = !DILexicalBlockFile(scope: !3384, file: !8, discriminator: 2)
!3384 = distinct !DILexicalBlock(scope: !3385, file: !8, line: 702, column: 61)
!3385 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 702, column: 61)
!3386 = !DILocation(line: 2189, column: 23, scope: !3381, inlinedAt: !3382)
!3387 = !DILocation(line: 2189, column: 40, scope: !3381, inlinedAt: !3382)
!3388 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3389)
!3389 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3390)
!3390 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3391)
!3391 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3392)
!3392 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3393)
!3393 = distinct !DILocation(line: 702, column: 62, scope: !1604)
!3394 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3395)
!3395 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3396)
!3396 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3397)
!3397 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3398)
!3398 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3390)
!3399 = !{!3400}
!3400 = distinct !{!3400, !3401, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3401 = distinct !{!3401, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3402 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3396)
!3403 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1871)
!3404 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3405)
!3405 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3406)
!3406 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3407)
!3407 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3408)
!3408 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3409)
!3409 = distinct !DILocation(line: 702, column: 62, scope: !1604)
!3410 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3411)
!3411 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3412)
!3412 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3413)
!3413 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3414)
!3414 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3406)
!3415 = !{!3416}
!3416 = distinct !{!3416, !3417, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3417 = distinct !{!3417, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3418 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3412)
!3419 = !DILocation(line: 703, column: 28, scope: !3420)
!3420 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 702, column: 25)
!3421 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3422)
!3422 = !DILocation(line: 703, column: 57, scope: !3420)
!3423 = !DILocation(line: 3002, column: 37, scope: !3424, inlinedAt: !3422)
!3424 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3425 = !DILocation(line: 3002, column: 18, scope: !3424, inlinedAt: !3422)
!3426 = !DILocation(line: 703, column: 37, scope: !3420)
!3427 = !DILocation(line: 0, scope: !199, inlinedAt: !3428)
!3428 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !3429)
!3429 = !DILocation(line: 177, column: 20, scope: !3430, inlinedAt: !3431)
!3430 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 30)
!3431 = !DILocation(line: 965, column: 20, scope: !3432, inlinedAt: !3433)
!3432 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 30)
!3433 = !DILocation(line: 448, column: 29, scope: !3434, inlinedAt: !3436)
!3434 = !DILexicalBlockFile(scope: !3435, file: !209, discriminator: 30)
!3435 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!3436 = !DILocation(line: 400, column: 16, scope: !3437, inlinedAt: !3438)
!3437 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 30)
!3438 = !DILocation(line: 376, column: 14, scope: !3439, inlinedAt: !3440)
!3439 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 30)
!3440 = !DILocation(line: 842, column: 14, scope: !3441, inlinedAt: !3442)
!3441 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 28)
!3442 = !DILocation(line: 211, column: 62, scope: !3443, inlinedAt: !3444)
!3443 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 28)
!3444 = !DILocation(line: 3114, column: 11, scope: !3445, inlinedAt: !3446)
!3445 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 28)
!3446 = !DILocation(line: 778, column: 9, scope: !3447, inlinedAt: !3448)
!3447 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 28)
!3448 = !DILocation(line: 704, column: 73, scope: !3420)
!3449 = !{!3450}
!3450 = distinct !{!3450, !3451, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!3451 = distinct !{!3451, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!3452 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !3453)
!3453 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !3454)
!3454 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !3455)
!3455 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !3456)
!3456 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !3428)
!3457 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !3428)
!3458 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !3428)
!3459 = !DILocation(line: 706, column: 35, scope: !3420)
!3460 = !DILocation(line: 707, column: 39, scope: !3461)
!3461 = distinct !DILexicalBlock(scope: !3420, file: !8, line: 706, column: 25)
!3462 = !DILocation(line: 708, column: 25, scope: !3463)
!3463 = distinct !DILexicalBlock(scope: !3461, file: !8, line: 707, column: 25)
!3464 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3465)
!3465 = !DILocation(line: 708, column: 46, scope: !3463)
!3466 = !DILocation(line: 3002, column: 37, scope: !3467, inlinedAt: !3465)
!3467 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3468 = !DILocation(line: 3002, column: 18, scope: !3467, inlinedAt: !3465)
!3469 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3462)
!3470 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3462)
!3471 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3462)
!3472 = !DILocation(line: 708, column: 55, scope: !3463)
!3473 = !DILocation(line: 0, scope: !3474)
!3474 = !DILexicalBlockFile(scope: !3420, file: !74, discriminator: 0)
!3475 = !DILocation(line: 709, column: 21, scope: !1604)
!3476 = !DILocation(line: 441, column: 25, scope: !3477, inlinedAt: !3429)
!3477 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!3478 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !3479)
!3479 = !DILocation(line: 1252, column: 18, scope: !3480, inlinedAt: !3481)
!3480 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 30)
!3481 = !DILocation(line: 454, column: 36, scope: !3482, inlinedAt: !3436)
!3482 = !DILexicalBlockFile(scope: !3483, file: !209, discriminator: 30)
!3483 = distinct !DILexicalBlock(scope: !3435, file: !209, line: 448, column: 17)
!3484 = !DILocation(line: 704, column: 36, scope: !3420)
!3485 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1877)
!3486 = !DILocation(line: 711, column: 44, scope: !1604)
!3487 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3488)
!3488 = !DILocation(line: 712, column: 39, scope: !1604)
!3489 = !DILocation(line: 3002, column: 37, scope: !3490, inlinedAt: !3488)
!3490 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3491 = !DILocation(line: 3002, column: 18, scope: !3490, inlinedAt: !3488)
!3492 = !DILocation(line: 713, column: 36, scope: !3493)
!3493 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 712, column: 25)
!3494 = !DILocation(line: 713, column: 43, scope: !3493)
!3495 = !DILocation(line: 908, column: 27, scope: !2917, inlinedAt: !3496)
!3496 = !DILocation(line: 713, column: 31, scope: !3493)
!3497 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3498)
!3498 = !DILocation(line: 607, column: 14, scope: !3499, inlinedAt: !3500)
!3499 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 246)
!3500 = !DILocation(line: 295, column: 20, scope: !3501, inlinedAt: !3502)
!3501 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 246)
!3502 = !DILocation(line: 2000, column: 18, scope: !3503, inlinedAt: !3504)
!3503 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 42)
!3504 = !DILocation(line: 1851, column: 78, scope: !3505, inlinedAt: !3506)
!3505 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 10)
!3506 = !DILocation(line: 3737, column: 14, scope: !3507, inlinedAt: !3508)
!3507 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 10)
!3508 = !DILocation(line: 713, column: 25, scope: !3493)
!3509 = !DILocation(line: 908, column: 18, scope: !2917, inlinedAt: !3496)
!3510 = !DILocation(line: 909, column: 18, scope: !3511, inlinedAt: !3496)
!3511 = distinct !DILexicalBlock(scope: !2917, file: !181, line: 908, column: 9)
!3512 = !DILocation(line: 1302, column: 9, scope: !2935, inlinedAt: !3513)
!3513 = !DILocation(line: 915, column: 13, scope: !3514, inlinedAt: !3496)
!3514 = !DILexicalBlockFile(scope: !3515, file: !181, discriminator: 4)
!3515 = distinct !DILexicalBlock(scope: !3511, file: !181, line: 909, column: 9)
!3516 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3517)
!3517 = !DILocation(line: 1310, column: 9, scope: !3518, inlinedAt: !3513)
!3518 = !DILexicalBlockFile(scope: !3519, file: !306, discriminator: 4)
!3519 = distinct !DILexicalBlock(scope: !2935, file: !306, line: 1302, column: 5)
!3520 = !DILocation(line: 638, column: 9, scope: !2943, inlinedAt: !3521)
!3521 = !DILocation(line: 1311, column: 9, scope: !3518, inlinedAt: !3513)
!3522 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3523)
!3523 = !DILocation(line: 1312, column: 9, scope: !3518, inlinedAt: !3513)
!3524 = !DILocation(line: 1314, column: 1, scope: !2935, inlinedAt: !3513)
!3525 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3526)
!3526 = !DILocation(line: 607, column: 14, scope: !3527, inlinedAt: !3528)
!3527 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 248)
!3528 = !DILocation(line: 295, column: 20, scope: !3529, inlinedAt: !3530)
!3529 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 248)
!3530 = !DILocation(line: 2000, column: 18, scope: !3531, inlinedAt: !3532)
!3531 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 44)
!3532 = !DILocation(line: 1851, column: 78, scope: !3533, inlinedAt: !3534)
!3533 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 12)
!3534 = !DILocation(line: 3737, column: 14, scope: !3535, inlinedAt: !3536)
!3535 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 12)
!3536 = !DILocation(line: 714, column: 25, scope: !3493)
!3537 = !DILocation(line: 1851, column: 92, scope: !2779, inlinedAt: !3534)
!3538 = !DILocation(line: 714, column: 43, scope: !3493)
!3539 = !DILocation(line: 908, column: 27, scope: !2917, inlinedAt: !3540)
!3540 = !DILocation(line: 714, column: 31, scope: !3493)
!3541 = !DILocation(line: 909, column: 27, scope: !3542, inlinedAt: !3540)
!3542 = distinct !DILexicalBlock(scope: !2917, file: !181, line: 908, column: 9)
!3543 = !DILocation(line: 908, column: 18, scope: !2917, inlinedAt: !3540)
!3544 = !DILocation(line: 909, column: 18, scope: !3542, inlinedAt: !3540)
!3545 = !DILocation(line: 1302, column: 9, scope: !2935, inlinedAt: !3546)
!3546 = !DILocation(line: 915, column: 13, scope: !3547, inlinedAt: !3540)
!3547 = !DILexicalBlockFile(scope: !3548, file: !181, discriminator: 6)
!3548 = distinct !DILexicalBlock(scope: !3542, file: !181, line: 909, column: 9)
!3549 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3550)
!3550 = !DILocation(line: 1310, column: 9, scope: !3551, inlinedAt: !3546)
!3551 = !DILexicalBlockFile(scope: !3552, file: !306, discriminator: 6)
!3552 = distinct !DILexicalBlock(scope: !2935, file: !306, line: 1302, column: 5)
!3553 = !DILocation(line: 638, column: 9, scope: !2943, inlinedAt: !3554)
!3554 = !DILocation(line: 1311, column: 9, scope: !3551, inlinedAt: !3546)
!3555 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3556)
!3556 = !DILocation(line: 1312, column: 9, scope: !3551, inlinedAt: !3546)
!3557 = !DILocation(line: 1314, column: 1, scope: !2935, inlinedAt: !3546)
!3558 = !DILocation(line: 715, column: 21, scope: !1604)
!3559 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1884)
!3560 = !DILocation(line: 717, column: 44, scope: !1604)
!3561 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3562)
!3562 = !DILocation(line: 718, column: 39, scope: !1604)
!3563 = !DILocation(line: 3002, column: 37, scope: !3564, inlinedAt: !3562)
!3564 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3565 = !DILocation(line: 3002, column: 18, scope: !3564, inlinedAt: !3562)
!3566 = !DILocation(line: 719, column: 36, scope: !3567)
!3567 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 718, column: 25)
!3568 = !DILocation(line: 719, column: 43, scope: !3567)
!3569 = !DILocation(line: 908, column: 27, scope: !2917, inlinedAt: !3570)
!3570 = !DILocation(line: 719, column: 31, scope: !3567)
!3571 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3572)
!3572 = !DILocation(line: 607, column: 14, scope: !3573, inlinedAt: !3574)
!3573 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 250)
!3574 = !DILocation(line: 295, column: 20, scope: !3575, inlinedAt: !3576)
!3575 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 250)
!3576 = !DILocation(line: 2000, column: 18, scope: !3577, inlinedAt: !3578)
!3577 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 46)
!3578 = !DILocation(line: 1851, column: 78, scope: !3579, inlinedAt: !3580)
!3579 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 14)
!3580 = !DILocation(line: 3737, column: 14, scope: !3581, inlinedAt: !3582)
!3581 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 14)
!3582 = !DILocation(line: 719, column: 25, scope: !3567)
!3583 = !DILocation(line: 908, column: 18, scope: !2917, inlinedAt: !3570)
!3584 = !DILocation(line: 909, column: 18, scope: !3585, inlinedAt: !3570)
!3585 = distinct !DILexicalBlock(scope: !2917, file: !181, line: 908, column: 9)
!3586 = !DILocation(line: 1302, column: 9, scope: !2935, inlinedAt: !3587)
!3587 = !DILocation(line: 915, column: 13, scope: !3588, inlinedAt: !3570)
!3588 = !DILexicalBlockFile(scope: !3589, file: !181, discriminator: 8)
!3589 = distinct !DILexicalBlock(scope: !3585, file: !181, line: 909, column: 9)
!3590 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3591)
!3591 = !DILocation(line: 1310, column: 9, scope: !3592, inlinedAt: !3587)
!3592 = !DILexicalBlockFile(scope: !3593, file: !306, discriminator: 8)
!3593 = distinct !DILexicalBlock(scope: !2935, file: !306, line: 1302, column: 5)
!3594 = !DILocation(line: 638, column: 9, scope: !2943, inlinedAt: !3595)
!3595 = !DILocation(line: 1311, column: 9, scope: !3592, inlinedAt: !3587)
!3596 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3597)
!3597 = !DILocation(line: 1312, column: 9, scope: !3592, inlinedAt: !3587)
!3598 = !DILocation(line: 1314, column: 1, scope: !2935, inlinedAt: !3587)
!3599 = !DILocation(line: 720, column: 21, scope: !1604)
!3600 = !DILocation(line: 909, column: 27, scope: !3585, inlinedAt: !3570)
!3601 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1891)
!3602 = !DILocation(line: 722, column: 44, scope: !1604)
!3603 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3604)
!3604 = !DILocation(line: 723, column: 45, scope: !1604)
!3605 = !DILocation(line: 3002, column: 37, scope: !3606, inlinedAt: !3604)
!3606 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3607 = !DILocation(line: 3002, column: 18, scope: !3606, inlinedAt: !3604)
!3608 = !DILocation(line: 723, column: 39, scope: !1604)
!3609 = !DILocation(line: 272, column: 10, scope: !2356, inlinedAt: !3610)
!3610 = !DILocation(line: 19, column: 15, scope: !3611, inlinedAt: !3612)
!3611 = !DILexicalBlockFile(scope: !2358, file: !693, discriminator: 24)
!3612 = !DILocation(line: 3804, column: 9, scope: !3613, inlinedAt: !3614)
!3613 = !DILexicalBlockFile(scope: !2361, file: !123, discriminator: 24)
!3614 = !DILocation(line: 723, column: 38, scope: !1604)
!3615 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3616)
!3616 = !DILocation(line: 607, column: 14, scope: !3617, inlinedAt: !3618)
!3617 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 252)
!3618 = !DILocation(line: 295, column: 20, scope: !3619, inlinedAt: !3620)
!3619 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 252)
!3620 = !DILocation(line: 1916, column: 18, scope: !3621, inlinedAt: !3622)
!3621 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 204)
!3622 = !DILocation(line: 1815, column: 76, scope: !3623, inlinedAt: !3624)
!3623 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 202)
!3624 = !DILocation(line: 3729, column: 14, scope: !3625, inlinedAt: !3626)
!3625 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 202)
!3626 = !DILocation(line: 3804, column: 23, scope: !3613, inlinedAt: !3614)
!3627 = !DILocation(line: 272, column: 9, scope: !2356, inlinedAt: !3610)
!3628 = !DILocation(line: 723, column: 56, scope: !1604)
!3629 = !DILocation(line: 724, column: 25, scope: !3630)
!3630 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 723, column: 25)
!3631 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3632)
!3632 = !DILocation(line: 724, column: 46, scope: !3630)
!3633 = !DILocation(line: 3002, column: 37, scope: !3634, inlinedAt: !3632)
!3634 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3635 = !DILocation(line: 3002, column: 18, scope: !3634, inlinedAt: !3632)
!3636 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3629)
!3637 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3629)
!3638 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3629)
!3639 = !DILocation(line: 724, column: 55, scope: !3630)
!3640 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3641)
!3641 = !DILocation(line: 725, column: 39, scope: !3630)
!3642 = !DILocation(line: 3002, column: 37, scope: !3643, inlinedAt: !3641)
!3643 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3644 = !DILocation(line: 3002, column: 18, scope: !3643, inlinedAt: !3641)
!3645 = !DILocation(line: 726, column: 36, scope: !3646)
!3646 = distinct !DILexicalBlock(scope: !3630, file: !8, line: 725, column: 25)
!3647 = !DILocation(line: 908, column: 27, scope: !2917, inlinedAt: !3648)
!3648 = !DILocation(line: 726, column: 31, scope: !3646)
!3649 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3650)
!3650 = !DILocation(line: 607, column: 14, scope: !3651, inlinedAt: !3652)
!3651 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 254)
!3652 = !DILocation(line: 295, column: 20, scope: !3653, inlinedAt: !3654)
!3653 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 254)
!3654 = !DILocation(line: 2000, column: 18, scope: !3655, inlinedAt: !3656)
!3655 = !DILexicalBlockFile(scope: !2777, file: !123, discriminator: 48)
!3656 = !DILocation(line: 1851, column: 78, scope: !3657, inlinedAt: !3658)
!3657 = !DILexicalBlockFile(scope: !2779, file: !123, discriminator: 16)
!3658 = !DILocation(line: 3737, column: 14, scope: !3659, inlinedAt: !3660)
!3659 = !DILexicalBlockFile(scope: !2781, file: !123, discriminator: 16)
!3660 = !DILocation(line: 726, column: 25, scope: !3646)
!3661 = !DILocation(line: 908, column: 18, scope: !2917, inlinedAt: !3648)
!3662 = !DILocation(line: 909, column: 18, scope: !3663, inlinedAt: !3648)
!3663 = distinct !DILexicalBlock(scope: !2917, file: !181, line: 908, column: 9)
!3664 = !DILocation(line: 1302, column: 9, scope: !2935, inlinedAt: !3665)
!3665 = !DILocation(line: 915, column: 13, scope: !3666, inlinedAt: !3648)
!3666 = !DILexicalBlockFile(scope: !3667, file: !181, discriminator: 10)
!3667 = distinct !DILexicalBlock(scope: !3663, file: !181, line: 909, column: 9)
!3668 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3669)
!3669 = !DILocation(line: 1310, column: 9, scope: !3670, inlinedAt: !3665)
!3670 = !DILexicalBlockFile(scope: !3671, file: !306, discriminator: 10)
!3671 = distinct !DILexicalBlock(scope: !2935, file: !306, line: 1302, column: 5)
!3672 = !DILocation(line: 638, column: 9, scope: !2943, inlinedAt: !3673)
!3673 = !DILocation(line: 1311, column: 9, scope: !3670, inlinedAt: !3665)
!3674 = !DILocation(line: 547, column: 14, scope: !2939, inlinedAt: !3675)
!3675 = !DILocation(line: 1312, column: 9, scope: !3670, inlinedAt: !3665)
!3676 = !DILocation(line: 1314, column: 1, scope: !2935, inlinedAt: !3665)
!3677 = !DILocation(line: 727, column: 21, scope: !1604)
!3678 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1898)
!3679 = !DILocation(line: 729, column: 44, scope: !1604)
!3680 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !3681)
!3681 = !DILocation(line: 3729, column: 14, scope: !3682, inlinedAt: !3683)
!3682 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 204)
!3683 = !DILocation(line: 730, column: 34, scope: !1604)
!3684 = !DILocation(line: 282, column: 16, scope: !3685, inlinedAt: !3686)
!3685 = distinct !DILexicalBlock(scope: !2991, file: !181, line: 282, column: 34)
!3686 = !DILocation(line: 730, column: 40, scope: !1604)
!3687 = !DILocation(line: 1016, column: 21, scope: !2994, inlinedAt: !3688)
!3688 = !DILocation(line: 730, column: 47, scope: !1604)
!3689 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !3690)
!3690 = !DILocation(line: 607, column: 14, scope: !3691, inlinedAt: !3692)
!3691 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 320)
!3692 = !DILocation(line: 295, column: 20, scope: !3693, inlinedAt: !3694)
!3693 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 320)
!3694 = !DILocation(line: 1916, column: 18, scope: !3695, inlinedAt: !3696)
!3695 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 206)
!3696 = !DILocation(line: 1815, column: 76, scope: !3697, inlinedAt: !3681)
!3697 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 204)
!3698 = !DILocation(line: 282, column: 21, scope: !3685, inlinedAt: !3686)
!3699 = !DILocation(line: 2997, column: 19, scope: !263, inlinedAt: !3700)
!3700 = !DILocation(line: 730, column: 56, scope: !1604)
!3701 = !DILocation(line: 3002, column: 37, scope: !3702, inlinedAt: !3700)
!3702 = distinct !DILexicalBlock(scope: !263, file: !123, line: 2997, column: 9)
!3703 = !DILocation(line: 3002, column: 18, scope: !3702, inlinedAt: !3700)
!3704 = !DILocation(line: 731, column: 25, scope: !3705)
!3705 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 730, column: 25)
!3706 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3707)
!3707 = !DILocation(line: 731, column: 46, scope: !3705)
!3708 = !DILocation(line: 3002, column: 37, scope: !3709, inlinedAt: !3707)
!3709 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3710 = !DILocation(line: 3002, column: 18, scope: !3709, inlinedAt: !3707)
!3711 = !DILocation(line: 731, column: 53, scope: !3705)
!3712 = !DILocation(line: 731, column: 73, scope: !3705)
!3713 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3704)
!3714 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3704)
!3715 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3704)
!3716 = !DILocation(line: 731, column: 74, scope: !3705)
!3717 = !DILocation(line: 732, column: 21, scope: !1604)
!3718 = !DILocation(line: 2189, column: 23, scope: !3719, inlinedAt: !3720)
!3719 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3720 = !DILocation(line: 734, column: 33, scope: !3721)
!3721 = !DILexicalBlockFile(scope: !3722, file: !8, discriminator: 2)
!3722 = distinct !DILexicalBlock(scope: !3723, file: !8, line: 734, column: 43)
!3723 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 734, column: 43)
!3724 = !DILocation(line: 735, column: 33, scope: !3725)
!3725 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 734, column: 25)
!3726 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !3724)
!3727 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !3724)
!3728 = !DILocation(line: 0, scope: !1764, inlinedAt: !3724)
!3729 = !DILocation(line: 735, column: 43, scope: !3725)
!3730 = !DILocation(line: 2189, column: 23, scope: !3731, inlinedAt: !3732)
!3731 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3732 = !DILocation(line: 735, column: 33, scope: !3733)
!3733 = !DILexicalBlockFile(scope: !3734, file: !8, discriminator: 2)
!3734 = distinct !DILexicalBlock(scope: !3735, file: !8, line: 735, column: 43)
!3735 = distinct !DILexicalBlock(scope: !3725, file: !8, line: 735, column: 43)
!3736 = !DILocation(line: 0, scope: !3737)
!3737 = !DILexicalBlockFile(scope: !3725, file: !74, discriminator: 0)
!3738 = !DILocation(line: 736, column: 25, scope: !3739)
!3739 = distinct !DILexicalBlock(scope: !3725, file: !8, line: 735, column: 25)
!3740 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !3741)
!3741 = !DILocation(line: 736, column: 46, scope: !3739)
!3742 = !DILocation(line: 3002, column: 37, scope: !3743, inlinedAt: !3741)
!3743 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!3744 = !DILocation(line: 3002, column: 18, scope: !3743, inlinedAt: !3741)
!3745 = !DILocation(line: 736, column: 53, scope: !3739)
!3746 = !DILocation(line: 20, column: 12, scope: !3747, inlinedAt: !3752)
!3747 = distinct !DILexicalBlock(scope: !3749, file: !3748, line: 19, column: 9)
!3748 = !DIFile(filename: "library/core/src/slice/cmp.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "c2f5b99832caffafc77a42276fe818e1")
!3749 = distinct !DISubprogram(name: "eq<u8, u8>", linkageName: "_ZN4core5slice3cmp81_$LT$impl$u20$core..cmp..PartialEq$LT$$u5b$U$u5d$$GT$$u20$for$u20$$u5b$T$u5d$$GT$2eq17h82832e86c0b36bd5E", scope: !3750, file: !3748, line: 18, type: !12, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3750 = !DINamespace(name: "{impl#0}", scope: !3751)
!3751 = !DINamespace(name: "cmp", scope: !178)
!3752 = !DILocation(line: 15, column: 50, scope: !3753, inlinedAt: !3757)
!3753 = distinct !DISubprogram(name: "eq<u8, u8, alloc::alloc::Global, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec10partial_eq117_$LT$impl$u20$core..cmp..PartialEq$LT$alloc..vec..Vec$LT$U$C$A2$GT$$GT$$u20$for$u20$alloc..vec..Vec$LT$T$C$A1$GT$$GT$2eq17he266223c5396fa28E", scope: !3755, file: !3754, line: 15, type: !12, scopeLine: 15, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3754 = !DIFile(filename: "library/alloc/src/vec/partial_eq.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "d323cd3dd2305534fb6b6dc7fa47f815")
!3755 = !DINamespace(name: "{impl#0}", scope: !3756)
!3756 = !DINamespace(name: "partial_eq", scope: !125)
!3757 = !DILocation(line: 736, column: 65, scope: !3739)
!3758 = !DILocation(line: 154, column: 13, scope: !3759, inlinedAt: !3762)
!3759 = distinct !DILexicalBlock(scope: !3760, file: !3748, line: 153, column: 13)
!3760 = distinct !DISubprogram(name: "equal_same_length<u8, u8>", linkageName: "_ZN63_$LT$A$u20$as$u20$core..slice..cmp..SlicePartialEq$LT$B$GT$$GT$17equal_same_length17hdffef4513bd63d68E", scope: !3761, file: !3748, line: 148, type: !12, scopeLine: 148, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3761 = !DINamespace(name: "{impl#5}", scope: !3751)
!3762 = !DILocation(line: 23, column: 22, scope: !3747, inlinedAt: !3752)
!3763 = !DILocation(line: 20, column: 9, scope: !3747, inlinedAt: !3752)
!3764 = !DILocation(line: 0, scope: !3747, inlinedAt: !3752)
!3765 = !DILocation(line: 736, column: 72, scope: !3739)
!3766 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !3738)
!3767 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !3738)
!3768 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !3738)
!3769 = !DILocation(line: 736, column: 73, scope: !3739)
!3770 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3771)
!3771 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3772)
!3772 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3773)
!3773 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3774)
!3774 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3775)
!3775 = distinct !DILocation(line: 737, column: 21, scope: !3725)
!3776 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3777)
!3777 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3778)
!3778 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3779)
!3779 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3780)
!3780 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3772)
!3781 = !{!3782}
!3782 = distinct !{!3782, !3783, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3783 = distinct !{!3783, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3784 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3778)
!3785 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3786)
!3786 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3787)
!3787 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3788)
!3788 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3789)
!3789 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3790)
!3790 = distinct !DILocation(line: 737, column: 21, scope: !3725)
!3791 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3792)
!3792 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3793)
!3793 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3794)
!3794 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3795)
!3795 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3787)
!3796 = !{!3797}
!3797 = distinct !{!3797, !3798, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3798 = distinct !{!3798, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3799 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3793)
!3800 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3801)
!3801 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3802)
!3802 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3803)
!3803 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3804)
!3804 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3805)
!3805 = distinct !DILocation(line: 737, column: 21, scope: !1604)
!3806 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3807)
!3807 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3808)
!3808 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3809)
!3809 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3810)
!3810 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3802)
!3811 = !{!3812}
!3812 = distinct !{!3812, !3813, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3813 = distinct !{!3813, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3814 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3808)
!3815 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3816)
!3816 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3817)
!3817 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3818)
!3818 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3819)
!3819 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3820)
!3820 = distinct !DILocation(line: 737, column: 21, scope: !1604)
!3821 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3822)
!3822 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3823)
!3823 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3824)
!3824 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3825)
!3825 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3817)
!3826 = !{!3827}
!3827 = distinct !{!3827, !3828, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3828 = distinct !{!3828, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3829 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3823)
!3830 = !DILocation(line: 2189, column: 23, scope: !3831, inlinedAt: !3832)
!3831 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3832 = !DILocation(line: 739, column: 33, scope: !3833)
!3833 = !DILexicalBlockFile(scope: !3834, file: !8, discriminator: 2)
!3834 = distinct !DILexicalBlock(scope: !3835, file: !8, line: 739, column: 43)
!3835 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 739, column: 43)
!3836 = !DILocation(line: 740, column: 33, scope: !3837)
!3837 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 739, column: 25)
!3838 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !3836)
!3839 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !3836)
!3840 = !DILocation(line: 0, scope: !1764, inlinedAt: !3836)
!3841 = !DILocation(line: 740, column: 43, scope: !3837)
!3842 = !DILocation(line: 2189, column: 23, scope: !3843, inlinedAt: !3844)
!3843 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3844 = !DILocation(line: 740, column: 33, scope: !3845)
!3845 = !DILexicalBlockFile(scope: !3846, file: !8, discriminator: 2)
!3846 = distinct !DILexicalBlock(scope: !3847, file: !8, line: 740, column: 43)
!3847 = distinct !DILexicalBlock(scope: !3837, file: !8, line: 740, column: 43)
!3848 = !DILocation(line: 0, scope: !3849)
!3849 = !DILexicalBlockFile(scope: !3837, file: !74, discriminator: 0)
!3850 = !DILocation(line: 20, column: 12, scope: !3851, inlinedAt: !3852)
!3851 = distinct !DILexicalBlock(scope: !3749, file: !3748, line: 19, column: 9)
!3852 = !DILocation(line: 265, column: 15, scope: !3853, inlinedAt: !3854)
!3853 = distinct !DISubprogram(name: "ne<[u8], [u8]>", linkageName: "_ZN4core3cmp9PartialEq2ne17h7b314ddbfaa14d37E", scope: !1521, file: !35, line: 264, type: !12, scopeLine: 264, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3854 = !DILocation(line: 17, column: 50, scope: !3855, inlinedAt: !3856)
!3855 = distinct !DISubprogram(name: "ne<u8, u8, alloc::alloc::Global, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec10partial_eq117_$LT$impl$u20$core..cmp..PartialEq$LT$alloc..vec..Vec$LT$U$C$A2$GT$$GT$$u20$for$u20$alloc..vec..Vec$LT$T$C$A1$GT$$GT$2ne17h9096e7642cacd090E", scope: !3755, file: !3754, line: 17, type: !12, scopeLine: 17, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!3856 = !DILocation(line: 741, column: 28, scope: !3857)
!3857 = distinct !DILexicalBlock(scope: !3837, file: !8, line: 740, column: 25)
!3858 = !DILocation(line: 154, column: 13, scope: !3859, inlinedAt: !3860)
!3859 = distinct !DILexicalBlock(scope: !3760, file: !3748, line: 153, column: 13)
!3860 = !DILocation(line: 23, column: 22, scope: !3861, inlinedAt: !3852)
!3861 = !DILexicalBlockFile(scope: !3851, file: !3748, discriminator: 2)
!3862 = !DILocation(line: 0, scope: !199, inlinedAt: !3863)
!3863 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !3864)
!3864 = !DILocation(line: 177, column: 20, scope: !3865, inlinedAt: !3866)
!3865 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 32)
!3866 = !DILocation(line: 965, column: 20, scope: !3867, inlinedAt: !3868)
!3867 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 32)
!3868 = !DILocation(line: 448, column: 29, scope: !3869, inlinedAt: !3871)
!3869 = !DILexicalBlockFile(scope: !3870, file: !209, discriminator: 32)
!3870 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!3871 = !DILocation(line: 400, column: 16, scope: !3872, inlinedAt: !3873)
!3872 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 32)
!3873 = !DILocation(line: 376, column: 14, scope: !3874, inlinedAt: !3875)
!3874 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 32)
!3875 = !DILocation(line: 842, column: 14, scope: !3876, inlinedAt: !3877)
!3876 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 30)
!3877 = !DILocation(line: 211, column: 62, scope: !3878, inlinedAt: !3879)
!3878 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 30)
!3879 = !DILocation(line: 3114, column: 11, scope: !3880, inlinedAt: !3881)
!3880 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 30)
!3881 = !DILocation(line: 778, column: 9, scope: !3882, inlinedAt: !3883)
!3882 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 30)
!3883 = !DILocation(line: 742, column: 80, scope: !3857)
!3884 = !{!3885}
!3885 = distinct !{!3885, !3886, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!3886 = distinct !{!3886, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!3887 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !3888)
!3888 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !3889)
!3889 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !3890)
!3890 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !3891)
!3891 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !3863)
!3892 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !3863)
!3893 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !3863)
!3894 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3895)
!3895 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3896)
!3896 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3897)
!3897 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3898)
!3898 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3899)
!3899 = distinct !DILocation(line: 744, column: 21, scope: !3837)
!3900 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3901)
!3901 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3902)
!3902 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3903)
!3903 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3904)
!3904 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3896)
!3905 = !{!3906}
!3906 = distinct !{!3906, !3907, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3907 = distinct !{!3907, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3908 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3902)
!3909 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3910)
!3910 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3911)
!3911 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3912)
!3912 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3913)
!3913 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3914)
!3914 = distinct !DILocation(line: 744, column: 21, scope: !1604)
!3915 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3916)
!3916 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3917)
!3917 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3918)
!3918 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3919)
!3919 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3911)
!3920 = !{!3921}
!3921 = distinct !{!3921, !3922, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3922 = distinct !{!3922, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3923 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3917)
!3924 = !DILocation(line: 441, column: 25, scope: !3925, inlinedAt: !3864)
!3925 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!3926 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !3927)
!3927 = !DILocation(line: 1252, column: 18, scope: !3928, inlinedAt: !3929)
!3928 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 32)
!3929 = !DILocation(line: 454, column: 36, scope: !3930, inlinedAt: !3871)
!3930 = !DILexicalBlockFile(scope: !3931, file: !209, discriminator: 32)
!3931 = distinct !DILexicalBlock(scope: !3870, file: !209, line: 448, column: 17)
!3932 = !DILocation(line: 742, column: 36, scope: !3857)
!3933 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3934)
!3934 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3935)
!3935 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3936)
!3936 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3937)
!3937 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3938)
!3938 = distinct !DILocation(line: 744, column: 21, scope: !3837)
!3939 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3940)
!3940 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3941)
!3941 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3942)
!3942 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3943)
!3943 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3935)
!3944 = !{!3945}
!3945 = distinct !{!3945, !3946, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3946 = distinct !{!3946, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3947 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3941)
!3948 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3949)
!3949 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3950)
!3950 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3951)
!3951 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3952)
!3952 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3953)
!3953 = distinct !DILocation(line: 744, column: 21, scope: !1604)
!3954 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3955)
!3955 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3956)
!3956 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3957)
!3957 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3958)
!3958 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3950)
!3959 = !{!3960}
!3960 = distinct !{!3960, !3961, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3961 = distinct !{!3961, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3962 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3956)
!3963 = !DILocation(line: 2189, column: 23, scope: !3964, inlinedAt: !3965)
!3964 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!3965 = !DILocation(line: 746, column: 45, scope: !3966)
!3966 = !DILexicalBlockFile(scope: !3967, file: !8, discriminator: 2)
!3967 = distinct !DILexicalBlock(scope: !3968, file: !8, line: 746, column: 55)
!3968 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 746, column: 55)
!3969 = !DILocation(line: 746, column: 61, scope: !1604)
!3970 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1915)
!3971 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1915)
!3972 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1915)
!3973 = !DILocation(line: 2189, column: 27, scope: !3974, inlinedAt: !3975)
!3974 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!3975 = !DILocation(line: 746, column: 33, scope: !3976)
!3976 = !DILexicalBlockFile(scope: !3977, file: !8, discriminator: 2)
!3977 = distinct !DILexicalBlock(scope: !3978, file: !8, line: 746, column: 61)
!3978 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 746, column: 61)
!3979 = !DILocation(line: 2189, column: 23, scope: !3974, inlinedAt: !3975)
!3980 = !DILocation(line: 2189, column: 40, scope: !3974, inlinedAt: !3975)
!3981 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3982)
!3982 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3983)
!3983 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !3984)
!3984 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !3985)
!3985 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !3986)
!3986 = distinct !DILocation(line: 746, column: 62, scope: !1604)
!3987 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !3988)
!3988 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !3989)
!3989 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !3990)
!3990 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !3991)
!3991 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3983)
!3992 = !{!3993}
!3993 = distinct !{!3993, !3994, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!3994 = distinct !{!3994, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!3995 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !3989)
!3996 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1915)
!3997 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !3998)
!3998 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !3999)
!3999 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4000)
!4000 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4001)
!4001 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4002)
!4002 = distinct !DILocation(line: 746, column: 62, scope: !1604)
!4003 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4004)
!4004 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4005)
!4005 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4006)
!4006 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4007)
!4007 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !3999)
!4008 = !{!4009}
!4009 = distinct !{!4009, !4010, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4010 = distinct !{!4010, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4011 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4005)
!4012 = !DILocation(line: 747, column: 25, scope: !4013)
!4013 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 746, column: 25)
!4014 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4015)
!4015 = !DILocation(line: 747, column: 46, scope: !4013)
!4016 = !DILocation(line: 3002, column: 37, scope: !4017, inlinedAt: !4015)
!4017 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4018 = !DILocation(line: 3002, column: 18, scope: !4017, inlinedAt: !4015)
!4019 = !DILocation(line: 747, column: 53, scope: !4013)
!4020 = !DILocation(line: 1895, column: 13, scope: !4021, inlinedAt: !4024)
!4021 = distinct !DISubprogram(name: "saturating_add", linkageName: "_RNvMs1_NtCsgEmfK2I1SDS_4core3numx14saturating_add", scope: !4023, file: !4022, line: 1894, type: !12, scopeLine: 1894, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!4022 = !DIFile(filename: "library/core/src/num/int_macros.rs", directory: "/rustc/59807616e1fa2540724bfbac14d7976d7e4a3860", checksumkind: CSK_MD5, checksum: "25372f0d2fb76edc2f95599cb5b8df1b")
!4023 = !DINamespace(name: "{impl#3}", scope: !67)
!4024 = !DILocation(line: 747, column: 72, scope: !4013)
!4025 = !DILocation(line: 747, column: 90, scope: !4013)
!4026 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4012)
!4027 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4012)
!4028 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4012)
!4029 = !DILocation(line: 747, column: 91, scope: !4013)
!4030 = !DILocation(line: 0, scope: !4031)
!4031 = !DILexicalBlockFile(scope: !4013, file: !74, discriminator: 0)
!4032 = !DILocation(line: 748, column: 21, scope: !1604)
!4033 = !DILocation(line: 2189, column: 23, scope: !4034, inlinedAt: !4035)
!4034 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4035 = !DILocation(line: 750, column: 45, scope: !4036)
!4036 = !DILexicalBlockFile(scope: !4037, file: !8, discriminator: 2)
!4037 = distinct !DILexicalBlock(scope: !4038, file: !8, line: 750, column: 55)
!4038 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 750, column: 55)
!4039 = !DILocation(line: 750, column: 61, scope: !1604)
!4040 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1921)
!4041 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1921)
!4042 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1921)
!4043 = !DILocation(line: 2189, column: 27, scope: !4044, inlinedAt: !4045)
!4044 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4045 = !DILocation(line: 750, column: 33, scope: !4046)
!4046 = !DILexicalBlockFile(scope: !4047, file: !8, discriminator: 2)
!4047 = distinct !DILexicalBlock(scope: !4048, file: !8, line: 750, column: 61)
!4048 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 750, column: 61)
!4049 = !DILocation(line: 2189, column: 23, scope: !4044, inlinedAt: !4045)
!4050 = !DILocation(line: 2189, column: 40, scope: !4044, inlinedAt: !4045)
!4051 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4052)
!4052 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4053)
!4053 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4054)
!4054 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4055)
!4055 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4056)
!4056 = distinct !DILocation(line: 750, column: 62, scope: !1604)
!4057 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4058)
!4058 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4059)
!4059 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4060)
!4060 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4061)
!4061 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4053)
!4062 = !{!4063}
!4063 = distinct !{!4063, !4064, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4064 = distinct !{!4064, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4065 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4059)
!4066 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1921)
!4067 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4068)
!4068 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4069)
!4069 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4070)
!4070 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4071)
!4071 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4072)
!4072 = distinct !DILocation(line: 750, column: 62, scope: !1604)
!4073 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4074)
!4074 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4075)
!4075 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4076)
!4076 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4077)
!4077 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4069)
!4078 = !{!4079}
!4079 = distinct !{!4079, !4080, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4080 = distinct !{!4080, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4081 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4075)
!4082 = !DILocation(line: 751, column: 25, scope: !4083)
!4083 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 750, column: 25)
!4084 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4085)
!4085 = !DILocation(line: 751, column: 46, scope: !4083)
!4086 = !DILocation(line: 3002, column: 37, scope: !4087, inlinedAt: !4085)
!4087 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4088 = !DILocation(line: 3002, column: 18, scope: !4087, inlinedAt: !4085)
!4089 = !DILocation(line: 751, column: 53, scope: !4083)
!4090 = !DILocation(line: 1937, column: 13, scope: !4091, inlinedAt: !4092)
!4091 = distinct !DISubprogram(name: "saturating_sub", linkageName: "_RNvMs1_NtCsgEmfK2I1SDS_4core3numx14saturating_sub", scope: !4023, file: !4022, line: 1936, type: !12, scopeLine: 1936, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!4092 = !DILocation(line: 751, column: 72, scope: !4083)
!4093 = !DILocation(line: 751, column: 90, scope: !4083)
!4094 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4082)
!4095 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4082)
!4096 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4082)
!4097 = !DILocation(line: 751, column: 91, scope: !4083)
!4098 = !DILocation(line: 0, scope: !4099)
!4099 = !DILexicalBlockFile(scope: !4083, file: !74, discriminator: 0)
!4100 = !DILocation(line: 752, column: 21, scope: !1604)
!4101 = !DILocation(line: 2189, column: 23, scope: !4102, inlinedAt: !4103)
!4102 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4103 = !DILocation(line: 754, column: 45, scope: !4104)
!4104 = !DILexicalBlockFile(scope: !4105, file: !8, discriminator: 2)
!4105 = distinct !DILexicalBlock(scope: !4106, file: !8, line: 754, column: 55)
!4106 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 754, column: 55)
!4107 = !DILocation(line: 754, column: 61, scope: !1604)
!4108 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1927)
!4109 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1927)
!4110 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1927)
!4111 = !DILocation(line: 2189, column: 27, scope: !4112, inlinedAt: !4113)
!4112 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4113 = !DILocation(line: 754, column: 33, scope: !4114)
!4114 = !DILexicalBlockFile(scope: !4115, file: !8, discriminator: 2)
!4115 = distinct !DILexicalBlock(scope: !4116, file: !8, line: 754, column: 61)
!4116 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 754, column: 61)
!4117 = !DILocation(line: 2189, column: 23, scope: !4112, inlinedAt: !4113)
!4118 = !DILocation(line: 2189, column: 40, scope: !4112, inlinedAt: !4113)
!4119 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4120)
!4120 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4121)
!4121 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4122)
!4122 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4123)
!4123 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4124)
!4124 = distinct !DILocation(line: 754, column: 62, scope: !1604)
!4125 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4126)
!4126 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4127)
!4127 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4128)
!4128 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4129)
!4129 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4121)
!4130 = !{!4131}
!4131 = distinct !{!4131, !4132, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4132 = distinct !{!4132, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4133 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4127)
!4134 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1927)
!4135 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4136)
!4136 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4137)
!4137 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4138)
!4138 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4139)
!4139 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4140)
!4140 = distinct !DILocation(line: 754, column: 62, scope: !1604)
!4141 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4142)
!4142 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4143)
!4143 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4144)
!4144 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4145)
!4145 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4137)
!4146 = !{!4147}
!4147 = distinct !{!4147, !4148, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4148 = distinct !{!4148, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4149 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4143)
!4150 = !DILocation(line: 755, column: 25, scope: !4151)
!4151 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 754, column: 25)
!4152 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4153)
!4153 = !DILocation(line: 755, column: 46, scope: !4151)
!4154 = !DILocation(line: 3002, column: 37, scope: !4155, inlinedAt: !4153)
!4155 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4156 = !DILocation(line: 3002, column: 18, scope: !4155, inlinedAt: !4153)
!4157 = !DILocation(line: 755, column: 53, scope: !4151)
!4158 = !DILocation(line: 755, column: 70, scope: !4151)
!4159 = !DILocation(line: 755, column: 73, scope: !4151)
!4160 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4150)
!4161 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4150)
!4162 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4150)
!4163 = !DILocation(line: 755, column: 74, scope: !4151)
!4164 = !DILocation(line: 0, scope: !4165)
!4165 = !DILexicalBlockFile(scope: !4151, file: !74, discriminator: 0)
!4166 = !DILocation(line: 756, column: 21, scope: !1604)
!4167 = !DILocation(line: 2189, column: 23, scope: !4168, inlinedAt: !4169)
!4168 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4169 = !DILocation(line: 758, column: 45, scope: !4170)
!4170 = !DILexicalBlockFile(scope: !4171, file: !8, discriminator: 2)
!4171 = distinct !DILexicalBlock(scope: !4172, file: !8, line: 758, column: 55)
!4172 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 758, column: 55)
!4173 = !DILocation(line: 758, column: 61, scope: !1604)
!4174 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1933)
!4175 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1933)
!4176 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1933)
!4177 = !DILocation(line: 2189, column: 27, scope: !4178, inlinedAt: !4179)
!4178 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4179 = !DILocation(line: 758, column: 33, scope: !4180)
!4180 = !DILexicalBlockFile(scope: !4181, file: !8, discriminator: 2)
!4181 = distinct !DILexicalBlock(scope: !4182, file: !8, line: 758, column: 61)
!4182 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 758, column: 61)
!4183 = !DILocation(line: 2189, column: 23, scope: !4178, inlinedAt: !4179)
!4184 = !DILocation(line: 2189, column: 40, scope: !4178, inlinedAt: !4179)
!4185 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4186)
!4186 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4187)
!4187 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4188)
!4188 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4189)
!4189 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4190)
!4190 = distinct !DILocation(line: 758, column: 62, scope: !1604)
!4191 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4192)
!4192 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4193)
!4193 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4194)
!4194 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4195)
!4195 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4187)
!4196 = !{!4197}
!4197 = distinct !{!4197, !4198, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4198 = distinct !{!4198, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4199 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4193)
!4200 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1933)
!4201 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4202)
!4202 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4203)
!4203 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4204)
!4204 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4205)
!4205 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4206)
!4206 = distinct !DILocation(line: 758, column: 62, scope: !1604)
!4207 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4208)
!4208 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4209)
!4209 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4210)
!4210 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4211)
!4211 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4203)
!4212 = !{!4213}
!4213 = distinct !{!4213, !4214, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4214 = distinct !{!4214, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4215 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4209)
!4216 = !DILocation(line: 759, column: 25, scope: !4217)
!4217 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 758, column: 25)
!4218 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4219)
!4219 = !DILocation(line: 759, column: 46, scope: !4217)
!4220 = !DILocation(line: 3002, column: 37, scope: !4221, inlinedAt: !4219)
!4221 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4222 = !DILocation(line: 3002, column: 18, scope: !4221, inlinedAt: !4219)
!4223 = !DILocation(line: 759, column: 53, scope: !4217)
!4224 = !DILocation(line: 3608, column: 16, scope: !4225, inlinedAt: !4226)
!4225 = distinct !DISubprogram(name: "abs", linkageName: "_RNvMs1_NtCsgEmfK2I1SDS_4core3numx3abs", scope: !4023, file: !4022, line: 3604, type: !12, scopeLine: 3604, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!4226 = !DILocation(line: 759, column: 72, scope: !4217)
!4227 = !DILocation(line: 759, column: 78, scope: !4217)
!4228 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4216)
!4229 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4216)
!4230 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4216)
!4231 = !DILocation(line: 759, column: 79, scope: !4217)
!4232 = !DILocation(line: 0, scope: !4233)
!4233 = !DILexicalBlockFile(scope: !4217, file: !74, discriminator: 0)
!4234 = !DILocation(line: 760, column: 21, scope: !1604)
!4235 = !DILocation(line: 2189, column: 23, scope: !4236, inlinedAt: !4237)
!4236 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4237 = !DILocation(line: 762, column: 45, scope: !4238)
!4238 = !DILexicalBlockFile(scope: !4239, file: !8, discriminator: 2)
!4239 = distinct !DILexicalBlock(scope: !4240, file: !8, line: 762, column: 55)
!4240 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 762, column: 55)
!4241 = !DILocation(line: 762, column: 61, scope: !1604)
!4242 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1939)
!4243 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1939)
!4244 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1939)
!4245 = !DILocation(line: 2189, column: 27, scope: !4246, inlinedAt: !4247)
!4246 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4247 = !DILocation(line: 762, column: 33, scope: !4248)
!4248 = !DILexicalBlockFile(scope: !4249, file: !8, discriminator: 2)
!4249 = distinct !DILexicalBlock(scope: !4250, file: !8, line: 762, column: 61)
!4250 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 762, column: 61)
!4251 = !DILocation(line: 2189, column: 23, scope: !4246, inlinedAt: !4247)
!4252 = !DILocation(line: 2189, column: 40, scope: !4246, inlinedAt: !4247)
!4253 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4254)
!4254 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4255)
!4255 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4256)
!4256 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4257)
!4257 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4258)
!4258 = distinct !DILocation(line: 762, column: 62, scope: !1604)
!4259 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4260)
!4260 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4261)
!4261 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4262)
!4262 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4263)
!4263 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4255)
!4264 = !{!4265}
!4265 = distinct !{!4265, !4266, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4266 = distinct !{!4266, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4267 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4261)
!4268 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1939)
!4269 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4270)
!4270 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4271)
!4271 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4272)
!4272 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4273)
!4273 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4274)
!4274 = distinct !DILocation(line: 762, column: 62, scope: !1604)
!4275 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4276)
!4276 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4277)
!4277 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4278)
!4278 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4279)
!4279 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4271)
!4280 = !{!4281}
!4281 = distinct !{!4281, !4282, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4282 = distinct !{!4282, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4283 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4277)
!4284 = !DILocation(line: 763, column: 25, scope: !4285)
!4285 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 762, column: 25)
!4286 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4287)
!4287 = !DILocation(line: 763, column: 46, scope: !4285)
!4288 = !DILocation(line: 3002, column: 37, scope: !4289, inlinedAt: !4287)
!4289 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4290 = !DILocation(line: 3002, column: 18, scope: !4289, inlinedAt: !4287)
!4291 = !DILocation(line: 763, column: 53, scope: !4285)
!4292 = !DILocation(line: 763, column: 65, scope: !4285)
!4293 = !DILocation(line: 763, column: 72, scope: !4285)
!4294 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4284)
!4295 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4284)
!4296 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4284)
!4297 = !DILocation(line: 763, column: 73, scope: !4285)
!4298 = !DILocation(line: 0, scope: !4299)
!4299 = !DILexicalBlockFile(scope: !4285, file: !74, discriminator: 0)
!4300 = !DILocation(line: 764, column: 21, scope: !1604)
!4301 = !DILocation(line: 2189, column: 23, scope: !4302, inlinedAt: !4303)
!4302 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4303 = !DILocation(line: 766, column: 45, scope: !4304)
!4304 = !DILexicalBlockFile(scope: !4305, file: !8, discriminator: 2)
!4305 = distinct !DILexicalBlock(scope: !4306, file: !8, line: 766, column: 55)
!4306 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 766, column: 55)
!4307 = !DILocation(line: 766, column: 61, scope: !1604)
!4308 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1945)
!4309 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1945)
!4310 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1945)
!4311 = !DILocation(line: 2189, column: 27, scope: !4312, inlinedAt: !4313)
!4312 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4313 = !DILocation(line: 766, column: 33, scope: !4314)
!4314 = !DILexicalBlockFile(scope: !4315, file: !8, discriminator: 2)
!4315 = distinct !DILexicalBlock(scope: !4316, file: !8, line: 766, column: 61)
!4316 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 766, column: 61)
!4317 = !DILocation(line: 2189, column: 23, scope: !4312, inlinedAt: !4313)
!4318 = !DILocation(line: 2189, column: 40, scope: !4312, inlinedAt: !4313)
!4319 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4320)
!4320 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4321)
!4321 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4322)
!4322 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4323)
!4323 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4324)
!4324 = distinct !DILocation(line: 766, column: 62, scope: !1604)
!4325 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4326)
!4326 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4327)
!4327 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4328)
!4328 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4329)
!4329 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4321)
!4330 = !{!4331}
!4331 = distinct !{!4331, !4332, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4332 = distinct !{!4332, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4333 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4327)
!4334 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1945)
!4335 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4336)
!4336 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4337)
!4337 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4338)
!4338 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4339)
!4339 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4340)
!4340 = distinct !DILocation(line: 766, column: 62, scope: !1604)
!4341 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4342)
!4342 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4343)
!4343 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4344)
!4344 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4345)
!4345 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4337)
!4346 = !{!4347}
!4347 = distinct !{!4347, !4348, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4348 = distinct !{!4348, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4349 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4343)
!4350 = !DILocation(line: 767, column: 25, scope: !4351)
!4351 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 766, column: 25)
!4352 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4353)
!4353 = !DILocation(line: 767, column: 46, scope: !4351)
!4354 = !DILocation(line: 3002, column: 37, scope: !4355, inlinedAt: !4353)
!4355 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4356 = !DILocation(line: 3002, column: 18, scope: !4355, inlinedAt: !4353)
!4357 = !DILocation(line: 767, column: 53, scope: !4351)
!4358 = !DILocation(line: 767, column: 65, scope: !4351)
!4359 = !DILocation(line: 767, column: 72, scope: !4351)
!4360 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4350)
!4361 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4350)
!4362 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4350)
!4363 = !DILocation(line: 767, column: 73, scope: !4351)
!4364 = !DILocation(line: 0, scope: !4365)
!4365 = !DILexicalBlockFile(scope: !4351, file: !74, discriminator: 0)
!4366 = !DILocation(line: 768, column: 21, scope: !1604)
!4367 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1951)
!4368 = !DILocation(line: 769, column: 79, scope: !1604)
!4369 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1959)
!4370 = !DILocation(line: 770, column: 79, scope: !1604)
!4371 = !DILocation(line: 2189, column: 23, scope: !4372, inlinedAt: !4373)
!4372 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4373 = !DILocation(line: 772, column: 45, scope: !4374)
!4374 = !DILexicalBlockFile(scope: !4375, file: !8, discriminator: 2)
!4375 = distinct !DILexicalBlock(scope: !4376, file: !8, line: 772, column: 55)
!4376 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 772, column: 55)
!4377 = !DILocation(line: 772, column: 61, scope: !1604)
!4378 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1967)
!4379 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1967)
!4380 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1967)
!4381 = !DILocation(line: 2189, column: 27, scope: !4382, inlinedAt: !4383)
!4382 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4383 = !DILocation(line: 772, column: 33, scope: !4384)
!4384 = !DILexicalBlockFile(scope: !4385, file: !8, discriminator: 2)
!4385 = distinct !DILexicalBlock(scope: !4386, file: !8, line: 772, column: 61)
!4386 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 772, column: 61)
!4387 = !DILocation(line: 2189, column: 23, scope: !4382, inlinedAt: !4383)
!4388 = !DILocation(line: 2189, column: 40, scope: !4382, inlinedAt: !4383)
!4389 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4390)
!4390 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4391)
!4391 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4392)
!4392 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4393)
!4393 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4394)
!4394 = distinct !DILocation(line: 772, column: 62, scope: !1604)
!4395 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4396)
!4396 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4397)
!4397 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4398)
!4398 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4399)
!4399 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4391)
!4400 = !{!4401}
!4401 = distinct !{!4401, !4402, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4402 = distinct !{!4402, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4403 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4397)
!4404 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1967)
!4405 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4406)
!4406 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4407)
!4407 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4408)
!4408 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4409)
!4409 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4410)
!4410 = distinct !DILocation(line: 772, column: 62, scope: !1604)
!4411 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4412)
!4412 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4413)
!4413 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4414)
!4414 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4415)
!4415 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4407)
!4416 = !{!4417}
!4417 = distinct !{!4417, !4418, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4418 = distinct !{!4418, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4419 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4413)
!4420 = !DILocation(line: 773, column: 33, scope: !4421)
!4421 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 772, column: 25)
!4422 = !DILocation(line: 773, column: 45, scope: !4421)
!4423 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !4422)
!4424 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !4422)
!4425 = !DILocation(line: 0, scope: !1764, inlinedAt: !4422)
!4426 = !DILocation(line: 773, column: 55, scope: !4421)
!4427 = !DILocation(line: 2189, column: 23, scope: !4428, inlinedAt: !4429)
!4428 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4429 = !DILocation(line: 773, column: 45, scope: !4430)
!4430 = !DILexicalBlockFile(scope: !4431, file: !8, discriminator: 2)
!4431 = distinct !DILexicalBlock(scope: !4432, file: !8, line: 773, column: 55)
!4432 = distinct !DILexicalBlock(scope: !4421, file: !8, line: 773, column: 55)
!4433 = !DILocation(line: 773, column: 61, scope: !4421)
!4434 = !DILocation(line: 0, scope: !4435)
!4435 = !DILexicalBlockFile(scope: !4421, file: !74, discriminator: 0)
!4436 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !4420)
!4437 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !4420)
!4438 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !4420)
!4439 = !DILocation(line: 2189, column: 27, scope: !4440, inlinedAt: !4441)
!4440 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4441 = !DILocation(line: 773, column: 33, scope: !4442)
!4442 = !DILexicalBlockFile(scope: !4443, file: !8, discriminator: 2)
!4443 = distinct !DILexicalBlock(scope: !4444, file: !8, line: 773, column: 61)
!4444 = distinct !DILexicalBlock(scope: !4421, file: !8, line: 773, column: 61)
!4445 = !DILocation(line: 2189, column: 23, scope: !4440, inlinedAt: !4441)
!4446 = !DILocation(line: 2189, column: 40, scope: !4440, inlinedAt: !4441)
!4447 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4448)
!4448 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4449)
!4449 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4450)
!4450 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4451)
!4451 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4452)
!4452 = distinct !DILocation(line: 773, column: 62, scope: !4421)
!4453 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4454)
!4454 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4455)
!4455 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4456)
!4456 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4457)
!4457 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4449)
!4458 = !{!4459}
!4459 = distinct !{!4459, !4460, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4460 = distinct !{!4460, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4461 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4455)
!4462 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !4420)
!4463 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4464)
!4464 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4465)
!4465 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4466)
!4466 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4467)
!4467 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4468)
!4468 = distinct !DILocation(line: 773, column: 62, scope: !4421)
!4469 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4470)
!4470 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4471)
!4471 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4472)
!4472 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4473)
!4473 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4465)
!4474 = !{!4475}
!4475 = distinct !{!4475, !4476, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4476 = distinct !{!4476, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4477 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4471)
!4478 = !DILocation(line: 774, column: 25, scope: !4479)
!4479 = distinct !DILexicalBlock(scope: !4421, file: !8, line: 773, column: 25)
!4480 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4481)
!4481 = !DILocation(line: 774, column: 46, scope: !4479)
!4482 = !DILocation(line: 3002, column: 37, scope: !4483, inlinedAt: !4481)
!4483 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4484 = !DILocation(line: 3002, column: 18, scope: !4483, inlinedAt: !4481)
!4485 = !DILocation(line: 774, column: 53, scope: !4479)
!4486 = !DILocation(line: 774, column: 65, scope: !4479)
!4487 = !DILocation(line: 774, column: 82, scope: !4479)
!4488 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4478)
!4489 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4478)
!4490 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4478)
!4491 = !DILocation(line: 774, column: 83, scope: !4479)
!4492 = !DILocation(line: 0, scope: !4493)
!4493 = !DILexicalBlockFile(scope: !4479, file: !74, discriminator: 0)
!4494 = !DILocation(line: 775, column: 21, scope: !1604)
!4495 = !DILocation(line: 2189, column: 23, scope: !4496, inlinedAt: !4497)
!4496 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4497 = !DILocation(line: 777, column: 45, scope: !4498)
!4498 = !DILexicalBlockFile(scope: !4499, file: !8, discriminator: 2)
!4499 = distinct !DILexicalBlock(scope: !4500, file: !8, line: 777, column: 55)
!4500 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 777, column: 55)
!4501 = !DILocation(line: 777, column: 61, scope: !1604)
!4502 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1973)
!4503 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1973)
!4504 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1973)
!4505 = !DILocation(line: 2189, column: 27, scope: !4506, inlinedAt: !4507)
!4506 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4507 = !DILocation(line: 777, column: 33, scope: !4508)
!4508 = !DILexicalBlockFile(scope: !4509, file: !8, discriminator: 2)
!4509 = distinct !DILexicalBlock(scope: !4510, file: !8, line: 777, column: 61)
!4510 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 777, column: 61)
!4511 = !DILocation(line: 2189, column: 23, scope: !4506, inlinedAt: !4507)
!4512 = !DILocation(line: 2189, column: 40, scope: !4506, inlinedAt: !4507)
!4513 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4514)
!4514 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4515)
!4515 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4516)
!4516 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4517)
!4517 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4518)
!4518 = distinct !DILocation(line: 777, column: 62, scope: !1604)
!4519 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4520)
!4520 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4521)
!4521 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4522)
!4522 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4523)
!4523 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4515)
!4524 = !{!4525}
!4525 = distinct !{!4525, !4526, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4526 = distinct !{!4526, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4527 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4521)
!4528 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1973)
!4529 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4530)
!4530 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4531)
!4531 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4532)
!4532 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4533)
!4533 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4534)
!4534 = distinct !DILocation(line: 777, column: 62, scope: !1604)
!4535 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4536)
!4536 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4537)
!4537 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4538)
!4538 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4539)
!4539 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4531)
!4540 = !{!4541}
!4541 = distinct !{!4541, !4542, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4542 = distinct !{!4542, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4543 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4537)
!4544 = !DILocation(line: 778, column: 33, scope: !4545)
!4545 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 777, column: 25)
!4546 = !DILocation(line: 778, column: 45, scope: !4545)
!4547 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !4546)
!4548 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !4546)
!4549 = !DILocation(line: 0, scope: !1764, inlinedAt: !4546)
!4550 = !DILocation(line: 778, column: 55, scope: !4545)
!4551 = !DILocation(line: 2189, column: 23, scope: !4552, inlinedAt: !4553)
!4552 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4553 = !DILocation(line: 778, column: 45, scope: !4554)
!4554 = !DILexicalBlockFile(scope: !4555, file: !8, discriminator: 2)
!4555 = distinct !DILexicalBlock(scope: !4556, file: !8, line: 778, column: 55)
!4556 = distinct !DILexicalBlock(scope: !4545, file: !8, line: 778, column: 55)
!4557 = !DILocation(line: 778, column: 61, scope: !4545)
!4558 = !DILocation(line: 0, scope: !4559)
!4559 = !DILexicalBlockFile(scope: !4545, file: !74, discriminator: 0)
!4560 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !4544)
!4561 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !4544)
!4562 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !4544)
!4563 = !DILocation(line: 2189, column: 27, scope: !4564, inlinedAt: !4565)
!4564 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4565 = !DILocation(line: 778, column: 33, scope: !4566)
!4566 = !DILexicalBlockFile(scope: !4567, file: !8, discriminator: 2)
!4567 = distinct !DILexicalBlock(scope: !4568, file: !8, line: 778, column: 61)
!4568 = distinct !DILexicalBlock(scope: !4545, file: !8, line: 778, column: 61)
!4569 = !DILocation(line: 2189, column: 23, scope: !4564, inlinedAt: !4565)
!4570 = !DILocation(line: 2189, column: 40, scope: !4564, inlinedAt: !4565)
!4571 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4572)
!4572 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4573)
!4573 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4574)
!4574 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4575)
!4575 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4576)
!4576 = distinct !DILocation(line: 778, column: 62, scope: !4545)
!4577 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4578)
!4578 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4579)
!4579 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4580)
!4580 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4581)
!4581 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4573)
!4582 = !{!4583}
!4583 = distinct !{!4583, !4584, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4584 = distinct !{!4584, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4585 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4579)
!4586 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !4544)
!4587 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4588)
!4588 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4589)
!4589 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4590)
!4590 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4591)
!4591 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4592)
!4592 = distinct !DILocation(line: 778, column: 62, scope: !4545)
!4593 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4594)
!4594 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4595)
!4595 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4596)
!4596 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4597)
!4597 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4589)
!4598 = !{!4599}
!4599 = distinct !{!4599, !4600, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4600 = distinct !{!4600, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4601 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4595)
!4602 = !DILocation(line: 779, column: 25, scope: !4603)
!4603 = distinct !DILexicalBlock(scope: !4545, file: !8, line: 778, column: 25)
!4604 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4605)
!4605 = !DILocation(line: 779, column: 46, scope: !4603)
!4606 = !DILocation(line: 3002, column: 37, scope: !4607, inlinedAt: !4605)
!4607 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4608 = !DILocation(line: 3002, column: 18, scope: !4607, inlinedAt: !4605)
!4609 = !DILocation(line: 779, column: 53, scope: !4603)
!4610 = !DILocation(line: 779, column: 65, scope: !4603)
!4611 = !DILocation(line: 779, column: 82, scope: !4603)
!4612 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4602)
!4613 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4602)
!4614 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4602)
!4615 = !DILocation(line: 779, column: 83, scope: !4603)
!4616 = !DILocation(line: 0, scope: !4617)
!4617 = !DILexicalBlockFile(scope: !4603, file: !74, discriminator: 0)
!4618 = !DILocation(line: 780, column: 21, scope: !1604)
!4619 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1979)
!4620 = !DILocation(line: 781, column: 78, scope: !1604)
!4621 = !DILocation(line: 2189, column: 23, scope: !4622, inlinedAt: !4623)
!4622 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4623 = !DILocation(line: 783, column: 45, scope: !4624)
!4624 = !DILexicalBlockFile(scope: !4625, file: !8, discriminator: 2)
!4625 = distinct !DILexicalBlock(scope: !4626, file: !8, line: 783, column: 55)
!4626 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 783, column: 55)
!4627 = !DILocation(line: 783, column: 61, scope: !1604)
!4628 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !1987)
!4629 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !1987)
!4630 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !1987)
!4631 = !DILocation(line: 2189, column: 27, scope: !4632, inlinedAt: !4633)
!4632 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4633 = !DILocation(line: 783, column: 33, scope: !4634)
!4634 = !DILexicalBlockFile(scope: !4635, file: !8, discriminator: 2)
!4635 = distinct !DILexicalBlock(scope: !4636, file: !8, line: 783, column: 61)
!4636 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 783, column: 61)
!4637 = !DILocation(line: 2189, column: 23, scope: !4632, inlinedAt: !4633)
!4638 = !DILocation(line: 2189, column: 40, scope: !4632, inlinedAt: !4633)
!4639 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4640)
!4640 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4641)
!4641 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4642)
!4642 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4643)
!4643 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4644)
!4644 = distinct !DILocation(line: 783, column: 62, scope: !1604)
!4645 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4646)
!4646 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4647)
!4647 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4648)
!4648 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4649)
!4649 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4641)
!4650 = !{!4651}
!4651 = distinct !{!4651, !4652, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4652 = distinct !{!4652, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4653 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4647)
!4654 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !1987)
!4655 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4656)
!4656 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4657)
!4657 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4658)
!4658 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4659)
!4659 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4660)
!4660 = distinct !DILocation(line: 783, column: 62, scope: !1604)
!4661 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4662)
!4662 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4663)
!4663 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4664)
!4664 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4665)
!4665 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4657)
!4666 = !{!4667}
!4667 = distinct !{!4667, !4668, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4668 = distinct !{!4668, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4669 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4663)
!4670 = !DILocation(line: 784, column: 33, scope: !4671)
!4671 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 783, column: 25)
!4672 = !DILocation(line: 784, column: 45, scope: !4671)
!4673 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !4672)
!4674 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !4672)
!4675 = !DILocation(line: 0, scope: !1764, inlinedAt: !4672)
!4676 = !DILocation(line: 784, column: 55, scope: !4671)
!4677 = !DILocation(line: 2189, column: 23, scope: !4678, inlinedAt: !4679)
!4678 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4679 = !DILocation(line: 784, column: 45, scope: !4680)
!4680 = !DILexicalBlockFile(scope: !4681, file: !8, discriminator: 2)
!4681 = distinct !DILexicalBlock(scope: !4682, file: !8, line: 784, column: 55)
!4682 = distinct !DILexicalBlock(scope: !4671, file: !8, line: 784, column: 55)
!4683 = !DILocation(line: 784, column: 61, scope: !4671)
!4684 = !DILocation(line: 0, scope: !4685)
!4685 = !DILexicalBlockFile(scope: !4671, file: !74, discriminator: 0)
!4686 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !4670)
!4687 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !4670)
!4688 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !4670)
!4689 = !DILocation(line: 2189, column: 27, scope: !4690, inlinedAt: !4691)
!4690 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4691 = !DILocation(line: 784, column: 33, scope: !4692)
!4692 = !DILexicalBlockFile(scope: !4693, file: !8, discriminator: 2)
!4693 = distinct !DILexicalBlock(scope: !4694, file: !8, line: 784, column: 61)
!4694 = distinct !DILexicalBlock(scope: !4671, file: !8, line: 784, column: 61)
!4695 = !DILocation(line: 2189, column: 23, scope: !4690, inlinedAt: !4691)
!4696 = !DILocation(line: 2189, column: 40, scope: !4690, inlinedAt: !4691)
!4697 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4698)
!4698 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4699)
!4699 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4700)
!4700 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4701)
!4701 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4702)
!4702 = distinct !DILocation(line: 784, column: 62, scope: !4671)
!4703 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4704)
!4704 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4705)
!4705 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4706)
!4706 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4707)
!4707 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4699)
!4708 = !{!4709}
!4709 = distinct !{!4709, !4710, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4710 = distinct !{!4710, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4711 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4705)
!4712 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !4670)
!4713 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4714)
!4714 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4715)
!4715 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4716)
!4716 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4717)
!4717 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4718)
!4718 = distinct !DILocation(line: 784, column: 62, scope: !4671)
!4719 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4720)
!4720 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4721)
!4721 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4722)
!4722 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4723)
!4723 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4715)
!4724 = !{!4725}
!4725 = distinct !{!4725, !4726, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4726 = distinct !{!4726, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4727 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4721)
!4728 = !DILocation(line: 785, column: 28, scope: !4729)
!4729 = distinct !DILexicalBlock(scope: !4671, file: !8, line: 784, column: 25)
!4730 = !DILocation(line: 0, scope: !199, inlinedAt: !4731)
!4731 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !4732)
!4732 = !DILocation(line: 177, column: 20, scope: !4733, inlinedAt: !4734)
!4733 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 34)
!4734 = !DILocation(line: 965, column: 20, scope: !4735, inlinedAt: !4736)
!4735 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 34)
!4736 = !DILocation(line: 448, column: 29, scope: !4737, inlinedAt: !4739)
!4737 = !DILexicalBlockFile(scope: !4738, file: !209, discriminator: 34)
!4738 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!4739 = !DILocation(line: 400, column: 16, scope: !4740, inlinedAt: !4741)
!4740 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 34)
!4741 = !DILocation(line: 376, column: 14, scope: !4742, inlinedAt: !4743)
!4742 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 34)
!4743 = !DILocation(line: 842, column: 14, scope: !4744, inlinedAt: !4745)
!4744 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 32)
!4745 = !DILocation(line: 211, column: 62, scope: !4746, inlinedAt: !4747)
!4746 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 32)
!4747 = !DILocation(line: 3114, column: 11, scope: !4748, inlinedAt: !4749)
!4748 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 32)
!4749 = !DILocation(line: 778, column: 9, scope: !4750, inlinedAt: !4751)
!4750 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 32)
!4751 = !DILocation(line: 786, column: 83, scope: !4729)
!4752 = !{!4753}
!4753 = distinct !{!4753, !4754, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!4754 = distinct !{!4754, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!4755 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !4756)
!4756 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !4757)
!4757 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !4758)
!4758 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !4759)
!4759 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !4731)
!4760 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !4731)
!4761 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !4731)
!4762 = !DILocation(line: 441, column: 25, scope: !4763, inlinedAt: !4732)
!4763 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!4764 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !4765)
!4765 = !DILocation(line: 1252, column: 18, scope: !4766, inlinedAt: !4767)
!4766 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 34)
!4767 = !DILocation(line: 454, column: 36, scope: !4768, inlinedAt: !4739)
!4768 = !DILexicalBlockFile(scope: !4769, file: !209, discriminator: 34)
!4769 = distinct !DILexicalBlock(scope: !4738, file: !209, line: 448, column: 17)
!4770 = !DILocation(line: 786, column: 36, scope: !4729)
!4771 = !DILocation(line: 0, scope: !4772)
!4772 = !DILexicalBlockFile(scope: !4729, file: !74, discriminator: 0)
!4773 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1993)
!4774 = !DILocation(line: 789, column: 78, scope: !1604)
!4775 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2001)
!4776 = !DILocation(line: 790, column: 77, scope: !1604)
!4777 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2009)
!4778 = !DILocation(line: 791, column: 77, scope: !1604)
!4779 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2017)
!4780 = !DILocation(line: 792, column: 78, scope: !1604)
!4781 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2025)
!4782 = !DILocation(line: 793, column: 78, scope: !1604)
!4783 = !DILocation(line: 2189, column: 23, scope: !4784, inlinedAt: !4785)
!4784 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4785 = !DILocation(line: 795, column: 45, scope: !4786)
!4786 = !DILexicalBlockFile(scope: !4787, file: !8, discriminator: 2)
!4787 = distinct !DILexicalBlock(scope: !4788, file: !8, line: 795, column: 55)
!4788 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 795, column: 55)
!4789 = !DILocation(line: 795, column: 61, scope: !1604)
!4790 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !2033)
!4791 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !2033)
!4792 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !2033)
!4793 = !DILocation(line: 2189, column: 27, scope: !4794, inlinedAt: !4795)
!4794 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4795 = !DILocation(line: 795, column: 33, scope: !4796)
!4796 = !DILexicalBlockFile(scope: !4797, file: !8, discriminator: 2)
!4797 = distinct !DILexicalBlock(scope: !4798, file: !8, line: 795, column: 61)
!4798 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 795, column: 61)
!4799 = !DILocation(line: 2189, column: 23, scope: !4794, inlinedAt: !4795)
!4800 = !DILocation(line: 2189, column: 40, scope: !4794, inlinedAt: !4795)
!4801 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4802)
!4802 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4803)
!4803 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4804)
!4804 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4805)
!4805 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4806)
!4806 = distinct !DILocation(line: 795, column: 62, scope: !1604)
!4807 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4808)
!4808 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4809)
!4809 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4810)
!4810 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4811)
!4811 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4803)
!4812 = !{!4813}
!4813 = distinct !{!4813, !4814, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4814 = distinct !{!4814, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4815 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4809)
!4816 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !2033)
!4817 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4818)
!4818 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4819)
!4819 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4820)
!4820 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4821)
!4821 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4822)
!4822 = distinct !DILocation(line: 795, column: 62, scope: !1604)
!4823 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4824)
!4824 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4825)
!4825 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4826)
!4826 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4827)
!4827 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4819)
!4828 = !{!4829}
!4829 = distinct !{!4829, !4830, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4830 = distinct !{!4830, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4831 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4825)
!4832 = !DILocation(line: 796, column: 33, scope: !4833)
!4833 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 795, column: 25)
!4834 = !DILocation(line: 796, column: 45, scope: !4833)
!4835 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !4834)
!4836 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !4834)
!4837 = !DILocation(line: 0, scope: !1764, inlinedAt: !4834)
!4838 = !DILocation(line: 796, column: 55, scope: !4833)
!4839 = !DILocation(line: 2189, column: 23, scope: !4840, inlinedAt: !4841)
!4840 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4841 = !DILocation(line: 796, column: 45, scope: !4842)
!4842 = !DILexicalBlockFile(scope: !4843, file: !8, discriminator: 2)
!4843 = distinct !DILexicalBlock(scope: !4844, file: !8, line: 796, column: 55)
!4844 = distinct !DILexicalBlock(scope: !4833, file: !8, line: 796, column: 55)
!4845 = !DILocation(line: 796, column: 61, scope: !4833)
!4846 = !DILocation(line: 0, scope: !4847)
!4847 = !DILexicalBlockFile(scope: !4833, file: !74, discriminator: 0)
!4848 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !4832)
!4849 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !4832)
!4850 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !4832)
!4851 = !DILocation(line: 2189, column: 27, scope: !4852, inlinedAt: !4853)
!4852 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4853 = !DILocation(line: 796, column: 33, scope: !4854)
!4854 = !DILexicalBlockFile(scope: !4855, file: !8, discriminator: 2)
!4855 = distinct !DILexicalBlock(scope: !4856, file: !8, line: 796, column: 61)
!4856 = distinct !DILexicalBlock(scope: !4833, file: !8, line: 796, column: 61)
!4857 = !DILocation(line: 2189, column: 23, scope: !4852, inlinedAt: !4853)
!4858 = !DILocation(line: 2189, column: 40, scope: !4852, inlinedAt: !4853)
!4859 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4860)
!4860 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4861)
!4861 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4862)
!4862 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4863)
!4863 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4864)
!4864 = distinct !DILocation(line: 796, column: 62, scope: !4833)
!4865 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4866)
!4866 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4867)
!4867 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4868)
!4868 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4869)
!4869 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4861)
!4870 = !{!4871}
!4871 = distinct !{!4871, !4872, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4872 = distinct !{!4872, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4873 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4867)
!4874 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !4832)
!4875 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4876)
!4876 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4877)
!4877 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4878)
!4878 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4879)
!4879 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4880)
!4880 = distinct !DILocation(line: 796, column: 62, scope: !4833)
!4881 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4882)
!4882 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4883)
!4883 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4884)
!4884 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4885)
!4885 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4877)
!4886 = !{!4887}
!4887 = distinct !{!4887, !4888, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4888 = distinct !{!4888, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4889 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4883)
!4890 = !DILocation(line: 797, column: 25, scope: !4891)
!4891 = distinct !DILexicalBlock(scope: !4833, file: !8, line: 796, column: 25)
!4892 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !4893)
!4893 = !DILocation(line: 797, column: 46, scope: !4891)
!4894 = !DILocation(line: 3002, column: 37, scope: !4895, inlinedAt: !4893)
!4895 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!4896 = !DILocation(line: 3002, column: 18, scope: !4895, inlinedAt: !4893)
!4897 = !DILocation(line: 797, column: 53, scope: !4891)
!4898 = !DILocation(line: 1077, column: 5, scope: !4899, inlinedAt: !4901)
!4899 = distinct !DISubprogram(name: "min<i64>", linkageName: "_ZN4core3cmp3Ord3min17h0cf1699bde7f75f2E", scope: !4900, file: !35, line: 1072, type: !12, scopeLine: 1072, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!4900 = !DINamespace(name: "Ord", scope: !38)
!4901 = distinct !DILocation(line: 797, column: 72, scope: !4891)
!4902 = !DILocation(line: 797, column: 79, scope: !4891)
!4903 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !4890)
!4904 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !4890)
!4905 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !4890)
!4906 = !DILocation(line: 797, column: 80, scope: !4891)
!4907 = !DILocation(line: 0, scope: !4908)
!4908 = !DILexicalBlockFile(scope: !4891, file: !74, discriminator: 0)
!4909 = !DILocation(line: 798, column: 21, scope: !1604)
!4910 = !DILocation(line: 2189, column: 23, scope: !4911, inlinedAt: !4912)
!4911 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4912 = !DILocation(line: 800, column: 45, scope: !4913)
!4913 = !DILexicalBlockFile(scope: !4914, file: !8, discriminator: 2)
!4914 = distinct !DILexicalBlock(scope: !4915, file: !8, line: 800, column: 55)
!4915 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 800, column: 55)
!4916 = !DILocation(line: 800, column: 61, scope: !1604)
!4917 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !2039)
!4918 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !2039)
!4919 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !2039)
!4920 = !DILocation(line: 2189, column: 27, scope: !4921, inlinedAt: !4922)
!4921 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4922 = !DILocation(line: 800, column: 33, scope: !4923)
!4923 = !DILexicalBlockFile(scope: !4924, file: !8, discriminator: 2)
!4924 = distinct !DILexicalBlock(scope: !4925, file: !8, line: 800, column: 61)
!4925 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 800, column: 61)
!4926 = !DILocation(line: 2189, column: 23, scope: !4921, inlinedAt: !4922)
!4927 = !DILocation(line: 2189, column: 40, scope: !4921, inlinedAt: !4922)
!4928 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4929)
!4929 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4930)
!4930 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4931)
!4931 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4932)
!4932 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4933)
!4933 = distinct !DILocation(line: 800, column: 62, scope: !1604)
!4934 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4935)
!4935 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4936)
!4936 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4937)
!4937 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4938)
!4938 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4930)
!4939 = !{!4940}
!4940 = distinct !{!4940, !4941, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4941 = distinct !{!4941, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4942 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4936)
!4943 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !2039)
!4944 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4945)
!4945 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4946)
!4946 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4947)
!4947 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4948)
!4948 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4949)
!4949 = distinct !DILocation(line: 800, column: 62, scope: !1604)
!4950 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4951)
!4951 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4952)
!4952 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4953)
!4953 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4954)
!4954 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4946)
!4955 = !{!4956}
!4956 = distinct !{!4956, !4957, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4957 = distinct !{!4957, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!4958 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4952)
!4959 = !DILocation(line: 801, column: 33, scope: !4960)
!4960 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 800, column: 25)
!4961 = !DILocation(line: 801, column: 45, scope: !4960)
!4962 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !4961)
!4963 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !4961)
!4964 = !DILocation(line: 0, scope: !1764, inlinedAt: !4961)
!4965 = !DILocation(line: 801, column: 55, scope: !4960)
!4966 = !DILocation(line: 2189, column: 23, scope: !4967, inlinedAt: !4968)
!4967 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!4968 = !DILocation(line: 801, column: 45, scope: !4969)
!4969 = !DILexicalBlockFile(scope: !4970, file: !8, discriminator: 2)
!4970 = distinct !DILexicalBlock(scope: !4971, file: !8, line: 801, column: 55)
!4971 = distinct !DILexicalBlock(scope: !4960, file: !8, line: 801, column: 55)
!4972 = !DILocation(line: 801, column: 61, scope: !4960)
!4973 = !DILocation(line: 0, scope: !4974)
!4974 = !DILexicalBlockFile(scope: !4960, file: !74, discriminator: 0)
!4975 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !4959)
!4976 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !4959)
!4977 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !4959)
!4978 = !DILocation(line: 2189, column: 27, scope: !4979, inlinedAt: !4980)
!4979 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!4980 = !DILocation(line: 801, column: 33, scope: !4981)
!4981 = !DILexicalBlockFile(scope: !4982, file: !8, discriminator: 2)
!4982 = distinct !DILexicalBlock(scope: !4983, file: !8, line: 801, column: 61)
!4983 = distinct !DILexicalBlock(scope: !4960, file: !8, line: 801, column: 61)
!4984 = !DILocation(line: 2189, column: 23, scope: !4979, inlinedAt: !4980)
!4985 = !DILocation(line: 2189, column: 40, scope: !4979, inlinedAt: !4980)
!4986 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !4987)
!4987 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !4988)
!4988 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !4989)
!4989 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !4990)
!4990 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !4991)
!4991 = distinct !DILocation(line: 801, column: 62, scope: !4960)
!4992 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !4993)
!4993 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !4994)
!4994 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !4995)
!4995 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !4996)
!4996 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !4988)
!4997 = !{!4998}
!4998 = distinct !{!4998, !4999, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!4999 = distinct !{!4999, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5000 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !4994)
!5001 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !4959)
!5002 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5003)
!5003 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5004)
!5004 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5005)
!5005 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5006)
!5006 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5007)
!5007 = distinct !DILocation(line: 801, column: 62, scope: !4960)
!5008 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5009)
!5009 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5010)
!5010 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5011)
!5011 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5012)
!5012 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5004)
!5013 = !{!5014}
!5014 = distinct !{!5014, !5015, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5015 = distinct !{!5015, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5016 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5010)
!5017 = !DILocation(line: 802, column: 25, scope: !5018)
!5018 = distinct !DILexicalBlock(scope: !4960, file: !8, line: 801, column: 25)
!5019 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5020)
!5020 = !DILocation(line: 802, column: 46, scope: !5018)
!5021 = !DILocation(line: 3002, column: 37, scope: !5022, inlinedAt: !5020)
!5022 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5023 = !DILocation(line: 3002, column: 18, scope: !5022, inlinedAt: !5020)
!5024 = !DILocation(line: 802, column: 53, scope: !5018)
!5025 = !DILocation(line: 1038, column: 5, scope: !5026, inlinedAt: !5027)
!5026 = distinct !DISubprogram(name: "max<i64>", linkageName: "_ZN4core3cmp3Ord3max17h0824547c0746d9e3E", scope: !4900, file: !35, line: 1033, type: !12, scopeLine: 1033, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5027 = distinct !DILocation(line: 802, column: 72, scope: !5018)
!5028 = !DILocation(line: 802, column: 79, scope: !5018)
!5029 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5017)
!5030 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5017)
!5031 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5017)
!5032 = !DILocation(line: 802, column: 80, scope: !5018)
!5033 = !DILocation(line: 0, scope: !5034)
!5034 = !DILexicalBlockFile(scope: !5018, file: !74, discriminator: 0)
!5035 = !DILocation(line: 803, column: 21, scope: !1604)
!5036 = !DILocation(line: 2189, column: 23, scope: !5037, inlinedAt: !5038)
!5037 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5038 = !DILocation(line: 805, column: 47, scope: !5039)
!5039 = !DILexicalBlockFile(scope: !5040, file: !8, discriminator: 2)
!5040 = distinct !DILexicalBlock(scope: !5041, file: !8, line: 805, column: 57)
!5041 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 805, column: 57)
!5042 = !DILocation(line: 805, column: 63, scope: !1604)
!5043 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !2045)
!5044 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !2045)
!5045 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !2045)
!5046 = !DILocation(line: 2189, column: 27, scope: !5047, inlinedAt: !5048)
!5047 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!5048 = !DILocation(line: 805, column: 35, scope: !5049)
!5049 = !DILexicalBlockFile(scope: !5050, file: !8, discriminator: 2)
!5050 = distinct !DILexicalBlock(scope: !5051, file: !8, line: 805, column: 63)
!5051 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 805, column: 63)
!5052 = !DILocation(line: 2189, column: 23, scope: !5047, inlinedAt: !5048)
!5053 = !DILocation(line: 2189, column: 40, scope: !5047, inlinedAt: !5048)
!5054 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5055)
!5055 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5056)
!5056 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5057)
!5057 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5058)
!5058 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5059)
!5059 = distinct !DILocation(line: 805, column: 64, scope: !1604)
!5060 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5061)
!5061 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5062)
!5062 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5063)
!5063 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5064)
!5064 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5056)
!5065 = !{!5066}
!5066 = distinct !{!5066, !5067, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5067 = distinct !{!5067, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5068 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5062)
!5069 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !2045)
!5070 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5071)
!5071 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5072)
!5072 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5073)
!5073 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5074)
!5074 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5075)
!5075 = distinct !DILocation(line: 805, column: 64, scope: !1604)
!5076 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5077)
!5077 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5078)
!5078 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5079)
!5079 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5080)
!5080 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5072)
!5081 = !{!5082}
!5082 = distinct !{!5082, !5083, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5083 = distinct !{!5083, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5084 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5078)
!5085 = !DILocation(line: 806, column: 35, scope: !5086)
!5086 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 805, column: 25)
!5087 = !DILocation(line: 806, column: 47, scope: !5086)
!5088 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !5087)
!5089 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !5087)
!5090 = !DILocation(line: 0, scope: !1764, inlinedAt: !5087)
!5091 = !DILocation(line: 806, column: 57, scope: !5086)
!5092 = !DILocation(line: 2189, column: 23, scope: !5093, inlinedAt: !5094)
!5093 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5094 = !DILocation(line: 806, column: 47, scope: !5095)
!5095 = !DILexicalBlockFile(scope: !5096, file: !8, discriminator: 2)
!5096 = distinct !DILexicalBlock(scope: !5097, file: !8, line: 806, column: 57)
!5097 = distinct !DILexicalBlock(scope: !5086, file: !8, line: 806, column: 57)
!5098 = !DILocation(line: 806, column: 63, scope: !5086)
!5099 = !DILocation(line: 0, scope: !5100)
!5100 = !DILexicalBlockFile(scope: !5086, file: !74, discriminator: 0)
!5101 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !5085)
!5102 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !5085)
!5103 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !5085)
!5104 = !DILocation(line: 2189, column: 27, scope: !5105, inlinedAt: !5106)
!5105 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!5106 = !DILocation(line: 806, column: 35, scope: !5107)
!5107 = !DILexicalBlockFile(scope: !5108, file: !8, discriminator: 2)
!5108 = distinct !DILexicalBlock(scope: !5109, file: !8, line: 806, column: 63)
!5109 = distinct !DILexicalBlock(scope: !5086, file: !8, line: 806, column: 63)
!5110 = !DILocation(line: 2189, column: 23, scope: !5105, inlinedAt: !5106)
!5111 = !DILocation(line: 2189, column: 40, scope: !5105, inlinedAt: !5106)
!5112 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5113)
!5113 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5114)
!5114 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5115)
!5115 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5116)
!5116 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5117)
!5117 = distinct !DILocation(line: 806, column: 64, scope: !5086)
!5118 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5119)
!5119 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5120)
!5120 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5121)
!5121 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5122)
!5122 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5114)
!5123 = !{!5124}
!5124 = distinct !{!5124, !5125, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5125 = distinct !{!5125, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5126 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5120)
!5127 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !5085)
!5128 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5129)
!5129 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5130)
!5130 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5131)
!5131 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5132)
!5132 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5133)
!5133 = distinct !DILocation(line: 806, column: 64, scope: !5086)
!5134 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5135)
!5135 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5136)
!5136 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5137)
!5137 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5138)
!5138 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5130)
!5139 = !{!5140}
!5140 = distinct !{!5140, !5141, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5141 = distinct !{!5141, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5142 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5136)
!5143 = !DILocation(line: 807, column: 33, scope: !5144)
!5144 = distinct !DILexicalBlock(scope: !5086, file: !8, line: 806, column: 25)
!5145 = !DILocation(line: 807, column: 45, scope: !5144)
!5146 = !DILocation(line: 2173, column: 15, scope: !1764, inlinedAt: !5145)
!5147 = !DILocation(line: 2173, column: 9, scope: !1764, inlinedAt: !5145)
!5148 = !DILocation(line: 0, scope: !1764, inlinedAt: !5145)
!5149 = !DILocation(line: 807, column: 55, scope: !5144)
!5150 = !DILocation(line: 2189, column: 23, scope: !5151, inlinedAt: !5152)
!5151 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5152 = !DILocation(line: 807, column: 45, scope: !5153)
!5153 = !DILexicalBlockFile(scope: !5154, file: !8, discriminator: 2)
!5154 = distinct !DILexicalBlock(scope: !5155, file: !8, line: 807, column: 55)
!5155 = distinct !DILexicalBlock(scope: !5144, file: !8, line: 807, column: 55)
!5156 = !DILocation(line: 807, column: 61, scope: !5144)
!5157 = !DILocation(line: 0, scope: !5158)
!5158 = !DILexicalBlockFile(scope: !5144, file: !74, discriminator: 0)
!5159 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !5143)
!5160 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !5143)
!5161 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !5143)
!5162 = !DILocation(line: 2189, column: 27, scope: !5163, inlinedAt: !5164)
!5163 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!5164 = !DILocation(line: 807, column: 33, scope: !5165)
!5165 = !DILexicalBlockFile(scope: !5166, file: !8, discriminator: 2)
!5166 = distinct !DILexicalBlock(scope: !5167, file: !8, line: 807, column: 61)
!5167 = distinct !DILexicalBlock(scope: !5144, file: !8, line: 807, column: 61)
!5168 = !DILocation(line: 2189, column: 23, scope: !5163, inlinedAt: !5164)
!5169 = !DILocation(line: 2189, column: 40, scope: !5163, inlinedAt: !5164)
!5170 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5171)
!5171 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5172)
!5172 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5173)
!5173 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5174)
!5174 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5175)
!5175 = distinct !DILocation(line: 807, column: 62, scope: !5144)
!5176 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5177)
!5177 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5178)
!5178 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5179)
!5179 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5180)
!5180 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5172)
!5181 = !{!5182}
!5182 = distinct !{!5182, !5183, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5183 = distinct !{!5183, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5184 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5178)
!5185 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !5143)
!5186 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5187)
!5187 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5188)
!5188 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5189)
!5189 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5190)
!5190 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5191)
!5191 = distinct !DILocation(line: 807, column: 62, scope: !5144)
!5192 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5193)
!5193 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5194)
!5194 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5195)
!5195 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5196)
!5196 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5188)
!5197 = !{!5198}
!5198 = distinct !{!5198, !5199, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5199 = distinct !{!5199, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5200 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5194)
!5201 = !DILocation(line: 808, column: 25, scope: !5202)
!5202 = distinct !DILexicalBlock(scope: !5144, file: !8, line: 807, column: 25)
!5203 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5204)
!5204 = !DILocation(line: 808, column: 46, scope: !5202)
!5205 = !DILocation(line: 3002, column: 37, scope: !5206, inlinedAt: !5204)
!5206 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5207 = !DILocation(line: 3002, column: 18, scope: !5206, inlinedAt: !5204)
!5208 = !DILocation(line: 808, column: 53, scope: !5202)
!5209 = !DILocation(line: 808, column: 65, scope: !5202)
!5210 = !DILocation(line: 808, column: 85, scope: !5202)
!5211 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5201)
!5212 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5201)
!5213 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5201)
!5214 = !DILocation(line: 808, column: 86, scope: !5202)
!5215 = !DILocation(line: 0, scope: !5216)
!5216 = !DILexicalBlockFile(scope: !5202, file: !74, discriminator: 0)
!5217 = !DILocation(line: 809, column: 21, scope: !1604)
!5218 = !DILocation(line: 2189, column: 23, scope: !5219, inlinedAt: !5220)
!5219 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5220 = !DILocation(line: 811, column: 33, scope: !5221)
!5221 = !DILexicalBlockFile(scope: !5222, file: !8, discriminator: 2)
!5222 = distinct !DILexicalBlock(scope: !5223, file: !8, line: 811, column: 43)
!5223 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 811, column: 43)
!5224 = !DILocation(line: 813, column: 29, scope: !5225)
!5225 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 811, column: 25)
!5226 = !DILocation(line: 813, column: 38, scope: !5225)
!5227 = !DILocation(line: 814, column: 25, scope: !5228)
!5228 = distinct !DILexicalBlock(scope: !5225, file: !8, line: 813, column: 25)
!5229 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5230)
!5230 = !DILocation(line: 814, column: 46, scope: !5228)
!5231 = !DILocation(line: 3002, column: 37, scope: !5232, inlinedAt: !5230)
!5232 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5233 = !DILocation(line: 3002, column: 18, scope: !5232, inlinedAt: !5230)
!5234 = !DILocation(line: 814, column: 53, scope: !5228)
!5235 = !DILocation(line: 0, scope: !199, inlinedAt: !5236)
!5236 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5237)
!5237 = !DILocation(line: 177, column: 20, scope: !5238, inlinedAt: !5239)
!5238 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 36)
!5239 = !DILocation(line: 965, column: 20, scope: !5240, inlinedAt: !5241)
!5240 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 36)
!5241 = !DILocation(line: 448, column: 29, scope: !5242, inlinedAt: !5244)
!5242 = !DILexicalBlockFile(scope: !5243, file: !209, discriminator: 36)
!5243 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5244 = !DILocation(line: 400, column: 16, scope: !5245, inlinedAt: !5246)
!5245 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 36)
!5246 = !DILocation(line: 376, column: 14, scope: !5247, inlinedAt: !5248)
!5247 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 36)
!5248 = !DILocation(line: 814, column: 60, scope: !5228)
!5249 = !{!5250}
!5250 = distinct !{!5250, !5251, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5251 = distinct !{!5251, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5252 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5253)
!5253 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5254)
!5254 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5255)
!5255 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5256)
!5256 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5236)
!5257 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5236)
!5258 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5236)
!5259 = !DILocation(line: 441, column: 25, scope: !5260, inlinedAt: !5237)
!5260 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5261 = !DILocation(line: 965, column: 9, scope: !206, inlinedAt: !5241)
!5262 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5263)
!5263 = !DILocation(line: 1252, column: 18, scope: !5264, inlinedAt: !5265)
!5264 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 36)
!5265 = !DILocation(line: 454, column: 36, scope: !5266, inlinedAt: !5244)
!5266 = !DILexicalBlockFile(scope: !5267, file: !209, discriminator: 36)
!5267 = distinct !DILexicalBlock(scope: !5243, file: !209, line: 448, column: 17)
!5268 = !DILocation(line: 2168, column: 9, scope: !5269, inlinedAt: !5270)
!5269 = distinct !DISubprogram(name: "set_len<u8, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$7set_len17hcbf3b6a7588cdd72E", scope: !124, file: !123, line: 2161, type: !12, scopeLine: 2161, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5270 = !DILocation(line: 455, column: 27, scope: !5266, inlinedAt: !5244)
!5271 = !DILocation(line: 814, column: 68, scope: !5228)
!5272 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5227)
!5273 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5227)
!5274 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5227)
!5275 = !DILocation(line: 814, column: 69, scope: !5228)
!5276 = !DILocation(line: 815, column: 21, scope: !5225)
!5277 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5278)
!5278 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5279)
!5279 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5280)
!5280 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5281)
!5281 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5282)
!5282 = distinct !DILocation(line: 815, column: 21, scope: !1604)
!5283 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5284)
!5284 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5285)
!5285 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5286)
!5286 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5287)
!5287 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5279)
!5288 = !{!5289}
!5289 = distinct !{!5289, !5290, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5290 = distinct !{!5290, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5291 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5285)
!5292 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5293)
!5293 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5294)
!5294 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5295)
!5295 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5296)
!5296 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5297)
!5297 = distinct !DILocation(line: 815, column: 21, scope: !1604)
!5298 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5299)
!5299 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5300)
!5300 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5301)
!5301 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5302)
!5302 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5294)
!5303 = !{!5304}
!5304 = distinct !{!5304, !5305, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5305 = distinct !{!5305, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5306 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5300)
!5307 = !DILocation(line: 2189, column: 23, scope: !5308, inlinedAt: !5309)
!5308 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5309 = !DILocation(line: 818, column: 33, scope: !5310)
!5310 = !DILexicalBlockFile(scope: !5311, file: !8, discriminator: 2)
!5311 = distinct !DILexicalBlock(scope: !5312, file: !8, line: 818, column: 43)
!5312 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 818, column: 43)
!5313 = !DILocation(line: 819, column: 25, scope: !5314)
!5314 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 818, column: 25)
!5315 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5316)
!5316 = !DILocation(line: 819, column: 46, scope: !5314)
!5317 = !DILocation(line: 3002, column: 37, scope: !5318, inlinedAt: !5316)
!5318 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5319 = !DILocation(line: 3002, column: 18, scope: !5318, inlinedAt: !5316)
!5320 = !DILocation(line: 819, column: 53, scope: !5314)
!5321 = !DILocation(line: 0, scope: !199, inlinedAt: !5322)
!5322 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5323)
!5323 = !DILocation(line: 177, column: 20, scope: !5324, inlinedAt: !5325)
!5324 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 38)
!5325 = !DILocation(line: 965, column: 20, scope: !5326, inlinedAt: !5327)
!5326 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 38)
!5327 = !DILocation(line: 448, column: 29, scope: !5328, inlinedAt: !5330)
!5328 = !DILexicalBlockFile(scope: !5329, file: !209, discriminator: 38)
!5329 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5330 = !DILocation(line: 400, column: 16, scope: !5331, inlinedAt: !5332)
!5331 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 38)
!5332 = !DILocation(line: 376, column: 14, scope: !5333, inlinedAt: !5334)
!5333 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 38)
!5334 = !DILocation(line: 819, column: 70, scope: !5314)
!5335 = !{!5336}
!5336 = distinct !{!5336, !5337, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5337 = distinct !{!5337, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5338 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5339)
!5339 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5340)
!5340 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5341)
!5341 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5342)
!5342 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5322)
!5343 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5322)
!5344 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5322)
!5345 = !DILocation(line: 441, column: 25, scope: !5346, inlinedAt: !5323)
!5346 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5347 = !DILocation(line: 965, column: 9, scope: !206, inlinedAt: !5327)
!5348 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5349)
!5349 = !DILocation(line: 1252, column: 18, scope: !5350, inlinedAt: !5351)
!5350 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 38)
!5351 = !DILocation(line: 454, column: 36, scope: !5352, inlinedAt: !5330)
!5352 = !DILexicalBlockFile(scope: !5353, file: !209, discriminator: 38)
!5353 = distinct !DILexicalBlock(scope: !5329, file: !209, line: 448, column: 17)
!5354 = !DILocation(line: 2168, column: 9, scope: !5269, inlinedAt: !5355)
!5355 = !DILocation(line: 455, column: 27, scope: !5352, inlinedAt: !5330)
!5356 = !DILocation(line: 819, column: 78, scope: !5314)
!5357 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5313)
!5358 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5313)
!5359 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5313)
!5360 = !DILocation(line: 819, column: 79, scope: !5314)
!5361 = !DILocation(line: 819, column: 80, scope: !5314)
!5362 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5363)
!5363 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5364)
!5364 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5365)
!5365 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5366)
!5366 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5367)
!5367 = distinct !DILocation(line: 820, column: 21, scope: !1604)
!5368 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5369)
!5369 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5370)
!5370 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5371)
!5371 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5372)
!5372 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5364)
!5373 = !{!5374}
!5374 = distinct !{!5374, !5375, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5375 = distinct !{!5375, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5376 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5370)
!5377 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5378)
!5378 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5379)
!5379 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5380)
!5380 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5381)
!5381 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5382)
!5382 = distinct !DILocation(line: 820, column: 21, scope: !1604)
!5383 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5384)
!5384 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5385)
!5385 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5386)
!5386 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5387)
!5387 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5379)
!5388 = !{!5389}
!5389 = distinct !{!5389, !5390, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5390 = distinct !{!5390, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5391 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5385)
!5392 = !DILocation(line: 2189, column: 23, scope: !5393, inlinedAt: !5394)
!5393 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5394 = !DILocation(line: 822, column: 33, scope: !5395)
!5395 = !DILexicalBlockFile(scope: !5396, file: !8, discriminator: 2)
!5396 = distinct !DILexicalBlock(scope: !5397, file: !8, line: 822, column: 43)
!5397 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 822, column: 43)
!5398 = !DILocation(line: 823, column: 25, scope: !5399)
!5399 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 822, column: 25)
!5400 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5401)
!5401 = !DILocation(line: 823, column: 46, scope: !5399)
!5402 = !DILocation(line: 3002, column: 37, scope: !5403, inlinedAt: !5401)
!5403 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5404 = !DILocation(line: 3002, column: 18, scope: !5403, inlinedAt: !5401)
!5405 = !DILocation(line: 823, column: 53, scope: !5399)
!5406 = !DILocation(line: 0, scope: !199, inlinedAt: !5407)
!5407 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5408)
!5408 = !DILocation(line: 177, column: 20, scope: !5409, inlinedAt: !5410)
!5409 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 40)
!5410 = !DILocation(line: 965, column: 20, scope: !5411, inlinedAt: !5412)
!5411 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 40)
!5412 = !DILocation(line: 448, column: 29, scope: !5413, inlinedAt: !5415)
!5413 = !DILexicalBlockFile(scope: !5414, file: !209, discriminator: 40)
!5414 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5415 = !DILocation(line: 400, column: 16, scope: !5416, inlinedAt: !5417)
!5416 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 40)
!5417 = !DILocation(line: 376, column: 14, scope: !5418, inlinedAt: !5419)
!5418 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 40)
!5419 = !DILocation(line: 823, column: 72, scope: !5399)
!5420 = !{!5421}
!5421 = distinct !{!5421, !5422, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5422 = distinct !{!5422, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5423 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5424)
!5424 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5425)
!5425 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5426)
!5426 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5427)
!5427 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5407)
!5428 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5407)
!5429 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5407)
!5430 = !DILocation(line: 441, column: 25, scope: !5431, inlinedAt: !5408)
!5431 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5432 = !DILocation(line: 965, column: 9, scope: !206, inlinedAt: !5412)
!5433 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5434)
!5434 = !DILocation(line: 1252, column: 18, scope: !5435, inlinedAt: !5436)
!5435 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 40)
!5436 = !DILocation(line: 454, column: 36, scope: !5437, inlinedAt: !5415)
!5437 = !DILexicalBlockFile(scope: !5438, file: !209, discriminator: 40)
!5438 = distinct !DILexicalBlock(scope: !5414, file: !209, line: 448, column: 17)
!5439 = !DILocation(line: 2168, column: 9, scope: !5269, inlinedAt: !5440)
!5440 = !DILocation(line: 455, column: 27, scope: !5437, inlinedAt: !5415)
!5441 = !DILocation(line: 823, column: 80, scope: !5399)
!5442 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5398)
!5443 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5398)
!5444 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5398)
!5445 = !DILocation(line: 823, column: 81, scope: !5399)
!5446 = !DILocation(line: 823, column: 82, scope: !5399)
!5447 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5448)
!5448 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5449)
!5449 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5450)
!5450 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5451)
!5451 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5452)
!5452 = distinct !DILocation(line: 824, column: 21, scope: !1604)
!5453 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5454)
!5454 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5455)
!5455 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5456)
!5456 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5457)
!5457 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5449)
!5458 = !{!5459}
!5459 = distinct !{!5459, !5460, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5460 = distinct !{!5460, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5461 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5455)
!5462 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5463)
!5463 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5464)
!5464 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5465)
!5465 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5466)
!5466 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5467)
!5467 = distinct !DILocation(line: 824, column: 21, scope: !1604)
!5468 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5469)
!5469 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5470)
!5470 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5471)
!5471 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5472)
!5472 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5464)
!5473 = !{!5474}
!5474 = distinct !{!5474, !5475, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5475 = distinct !{!5475, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5476 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5470)
!5477 = !DILocation(line: 2189, column: 23, scope: !5478, inlinedAt: !5479)
!5478 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5479 = !DILocation(line: 826, column: 33, scope: !5480)
!5480 = !DILexicalBlockFile(scope: !5481, file: !8, discriminator: 2)
!5481 = distinct !DILexicalBlock(scope: !5482, file: !8, line: 826, column: 43)
!5482 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 826, column: 43)
!5483 = !DILocation(line: 827, column: 25, scope: !5484)
!5484 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 826, column: 25)
!5485 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5486)
!5486 = !DILocation(line: 827, column: 46, scope: !5484)
!5487 = !DILocation(line: 3002, column: 37, scope: !5488, inlinedAt: !5486)
!5488 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5489 = !DILocation(line: 3002, column: 18, scope: !5488, inlinedAt: !5486)
!5490 = !DILocation(line: 827, column: 53, scope: !5484)
!5491 = !DILocation(line: 0, scope: !199, inlinedAt: !5492)
!5492 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5493)
!5493 = !DILocation(line: 177, column: 20, scope: !5494, inlinedAt: !5495)
!5494 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 42)
!5495 = !DILocation(line: 965, column: 20, scope: !5496, inlinedAt: !5497)
!5496 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 42)
!5497 = !DILocation(line: 448, column: 29, scope: !5498, inlinedAt: !5500)
!5498 = !DILexicalBlockFile(scope: !5499, file: !209, discriminator: 42)
!5499 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5500 = !DILocation(line: 400, column: 16, scope: !5501, inlinedAt: !5502)
!5501 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 42)
!5502 = !DILocation(line: 376, column: 14, scope: !5503, inlinedAt: !5504)
!5503 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 42)
!5504 = !DILocation(line: 827, column: 73, scope: !5484)
!5505 = !{!5506}
!5506 = distinct !{!5506, !5507, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5507 = distinct !{!5507, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5508 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5509)
!5509 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5510)
!5510 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5511)
!5511 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5512)
!5512 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5492)
!5513 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5492)
!5514 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5492)
!5515 = !DILocation(line: 441, column: 25, scope: !5516, inlinedAt: !5493)
!5516 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5517 = !DILocation(line: 965, column: 9, scope: !206, inlinedAt: !5497)
!5518 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5519)
!5519 = !DILocation(line: 1252, column: 18, scope: !5520, inlinedAt: !5521)
!5520 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 42)
!5521 = !DILocation(line: 454, column: 36, scope: !5522, inlinedAt: !5500)
!5522 = !DILexicalBlockFile(scope: !5523, file: !209, discriminator: 42)
!5523 = distinct !DILexicalBlock(scope: !5499, file: !209, line: 448, column: 17)
!5524 = !DILocation(line: 2168, column: 9, scope: !5269, inlinedAt: !5525)
!5525 = !DILocation(line: 455, column: 27, scope: !5522, inlinedAt: !5500)
!5526 = !DILocation(line: 827, column: 81, scope: !5484)
!5527 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5483)
!5528 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5483)
!5529 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5483)
!5530 = !DILocation(line: 827, column: 82, scope: !5484)
!5531 = !DILocation(line: 827, column: 83, scope: !5484)
!5532 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5533)
!5533 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5534)
!5534 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5535)
!5535 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5536)
!5536 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5537)
!5537 = distinct !DILocation(line: 828, column: 21, scope: !1604)
!5538 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5539)
!5539 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5540)
!5540 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5541)
!5541 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5542)
!5542 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5534)
!5543 = !{!5544}
!5544 = distinct !{!5544, !5545, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5545 = distinct !{!5545, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5546 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5540)
!5547 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5548)
!5548 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5549)
!5549 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5550)
!5550 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5551)
!5551 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5552)
!5552 = distinct !DILocation(line: 828, column: 21, scope: !1604)
!5553 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5554)
!5554 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5555)
!5555 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5556)
!5556 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5557)
!5557 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5549)
!5558 = !{!5559}
!5559 = distinct !{!5559, !5560, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5560 = distinct !{!5560, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5561 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5555)
!5562 = !DILocation(line: 2189, column: 23, scope: !5563, inlinedAt: !5564)
!5563 = distinct !DILexicalBlock(scope: !596, file: !384, line: 2189, column: 13)
!5564 = !DILocation(line: 830, column: 33, scope: !5565)
!5565 = !DILexicalBlockFile(scope: !5566, file: !8, discriminator: 2)
!5566 = distinct !DILexicalBlock(scope: !5567, file: !8, line: 830, column: 43)
!5567 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 830, column: 43)
!5568 = !DILocation(line: 832, column: 29, scope: !5569)
!5569 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 830, column: 25)
!5570 = !DILocation(line: 832, column: 38, scope: !5569)
!5571 = !DILocation(line: 833, column: 25, scope: !5572)
!5572 = distinct !DILexicalBlock(scope: !5569, file: !8, line: 832, column: 25)
!5573 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5574)
!5574 = !DILocation(line: 833, column: 46, scope: !5572)
!5575 = !DILocation(line: 3002, column: 37, scope: !5576, inlinedAt: !5574)
!5576 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5577 = !DILocation(line: 3002, column: 18, scope: !5576, inlinedAt: !5574)
!5578 = !DILocation(line: 833, column: 53, scope: !5572)
!5579 = !DILocation(line: 0, scope: !199, inlinedAt: !5580)
!5580 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5581)
!5581 = !DILocation(line: 177, column: 20, scope: !5582, inlinedAt: !5583)
!5582 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 44)
!5583 = !DILocation(line: 965, column: 20, scope: !5584, inlinedAt: !5585)
!5584 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 44)
!5585 = !DILocation(line: 448, column: 29, scope: !5586, inlinedAt: !5588)
!5586 = !DILexicalBlockFile(scope: !5587, file: !209, discriminator: 44)
!5587 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5588 = !DILocation(line: 400, column: 16, scope: !5589, inlinedAt: !5590)
!5589 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 44)
!5590 = !DILocation(line: 376, column: 14, scope: !5591, inlinedAt: !5592)
!5591 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 44)
!5592 = !DILocation(line: 833, column: 60, scope: !5572)
!5593 = !{!5594}
!5594 = distinct !{!5594, !5595, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5595 = distinct !{!5595, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5596 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5597)
!5597 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5598)
!5598 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5599)
!5599 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5600)
!5600 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5580)
!5601 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5580)
!5602 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5580)
!5603 = !DILocation(line: 441, column: 25, scope: !5604, inlinedAt: !5581)
!5604 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5605 = !DILocation(line: 965, column: 9, scope: !206, inlinedAt: !5585)
!5606 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5607)
!5607 = !DILocation(line: 1252, column: 18, scope: !5608, inlinedAt: !5609)
!5608 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 44)
!5609 = !DILocation(line: 454, column: 36, scope: !5610, inlinedAt: !5588)
!5610 = !DILexicalBlockFile(scope: !5611, file: !209, discriminator: 44)
!5611 = distinct !DILexicalBlock(scope: !5587, file: !209, line: 448, column: 17)
!5612 = !DILocation(line: 2168, column: 9, scope: !5269, inlinedAt: !5613)
!5613 = !DILocation(line: 455, column: 27, scope: !5610, inlinedAt: !5588)
!5614 = !DILocation(line: 833, column: 68, scope: !5572)
!5615 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5571)
!5616 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5571)
!5617 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5571)
!5618 = !DILocation(line: 833, column: 69, scope: !5572)
!5619 = !DILocation(line: 834, column: 21, scope: !5569)
!5620 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5621)
!5621 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5622)
!5622 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5623)
!5623 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5624)
!5624 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5625)
!5625 = distinct !DILocation(line: 834, column: 21, scope: !1604)
!5626 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5627)
!5627 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5628)
!5628 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5629)
!5629 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5630)
!5630 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5622)
!5631 = !{!5632}
!5632 = distinct !{!5632, !5633, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5633 = distinct !{!5633, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5634 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5628)
!5635 = !DILocation(line: 632, column: 39, scope: !454, inlinedAt: !5636)
!5636 = distinct !DILocation(line: 872, column: 52, scope: !456, inlinedAt: !5637)
!5637 = distinct !DILocation(line: 423, column: 29, scope: !459, inlinedAt: !5638)
!5638 = distinct !DILocation(line: 805, column: 1, scope: !462, inlinedAt: !5639)
!5639 = distinct !DILocation(line: 805, column: 1, scope: !449, inlinedAt: !5640)
!5640 = distinct !DILocation(line: 834, column: 21, scope: !1604)
!5641 = !DILocation(line: 115, column: 14, scope: !465, inlinedAt: !5642)
!5642 = distinct !DILocation(line: 209, column: 22, scope: !467, inlinedAt: !5643)
!5643 = distinct !DILocation(line: 324, column: 9, scope: !469, inlinedAt: !5644)
!5644 = distinct !DILocation(line: 442, column: 23, scope: !471, inlinedAt: !5645)
!5645 = distinct !DILocation(line: 874, column: 28, scope: !456, inlinedAt: !5637)
!5646 = !{!5647}
!5647 = distinct !{!5647, !5648, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E: %_1"}
!5648 = distinct !{!5648, !"_ZN4core3ptr46drop_in_place$LT$alloc..vec..Vec$LT$u8$GT$$GT$17habf1172fc55987e2E"}
!5649 = !DILocation(line: 200, column: 9, scope: !467, inlinedAt: !5643)
!5650 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2103)
!5651 = !DILocation(line: 842, column: 75, scope: !1604)
!5652 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !2111)
!5653 = !DILocation(line: 843, column: 74, scope: !1604)
!5654 = !DILocation(line: 848, column: 25, scope: !1604)
!5655 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5656)
!5656 = !DILocation(line: 848, column: 56, scope: !1604)
!5657 = !DILocation(line: 3002, column: 37, scope: !5658, inlinedAt: !5656)
!5658 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5659 = !DILocation(line: 3002, column: 18, scope: !5658, inlinedAt: !5656)
!5660 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5654)
!5661 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5654)
!5662 = !DILocation(line: 0, scope: !199, inlinedAt: !5663)
!5663 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5664)
!5664 = !DILocation(line: 177, column: 20, scope: !5665, inlinedAt: !5666)
!5665 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 46)
!5666 = !DILocation(line: 965, column: 20, scope: !5667, inlinedAt: !5668)
!5667 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 46)
!5668 = !DILocation(line: 448, column: 29, scope: !5669, inlinedAt: !5671)
!5669 = !DILexicalBlockFile(scope: !5670, file: !209, discriminator: 46)
!5670 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5671 = !DILocation(line: 400, column: 16, scope: !5672, inlinedAt: !5673)
!5672 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 46)
!5673 = !DILocation(line: 376, column: 14, scope: !5674, inlinedAt: !5675)
!5674 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 46)
!5675 = !DILocation(line: 842, column: 14, scope: !5676, inlinedAt: !5677)
!5676 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 34)
!5677 = !DILocation(line: 211, column: 62, scope: !5678, inlinedAt: !5679)
!5678 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 34)
!5679 = !DILocation(line: 3114, column: 11, scope: !5680, inlinedAt: !5681)
!5680 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 34)
!5681 = !DILocation(line: 778, column: 9, scope: !5682, inlinedAt: !5683)
!5682 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 34)
!5683 = !DILocation(line: 846, column: 85, scope: !1604)
!5684 = !{!5685}
!5685 = distinct !{!5685, !5686, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5686 = distinct !{!5686, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5687 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5688)
!5688 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5689)
!5689 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5690)
!5690 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5691)
!5691 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5663)
!5692 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5663)
!5693 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5663)
!5694 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5654)
!5695 = !DILocation(line: 848, column: 67, scope: !1604)
!5696 = !DILocation(line: 844, column: 29, scope: !1604)
!5697 = !DILocation(line: 441, column: 25, scope: !5698, inlinedAt: !5664)
!5698 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5699 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5700)
!5700 = !DILocation(line: 1252, column: 18, scope: !5701, inlinedAt: !5702)
!5701 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 46)
!5702 = !DILocation(line: 454, column: 36, scope: !5703, inlinedAt: !5671)
!5703 = !DILexicalBlockFile(scope: !5704, file: !209, discriminator: 46)
!5704 = distinct !DILexicalBlock(scope: !5670, file: !209, line: 448, column: 17)
!5705 = !DILocation(line: 846, column: 36, scope: !1604)
!5706 = !DILocation(line: 852, column: 34, scope: !1604)
!5707 = !DILocation(line: 857, column: 25, scope: !5708)
!5708 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 852, column: 25)
!5709 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5710)
!5710 = !DILocation(line: 857, column: 58, scope: !5708)
!5711 = !DILocation(line: 3002, column: 37, scope: !5712, inlinedAt: !5710)
!5712 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5713 = !DILocation(line: 3002, column: 18, scope: !5712, inlinedAt: !5710)
!5714 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5707)
!5715 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5707)
!5716 = !DILocation(line: 0, scope: !199, inlinedAt: !5717)
!5717 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5718)
!5718 = !DILocation(line: 177, column: 20, scope: !5719, inlinedAt: !5720)
!5719 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 48)
!5720 = !DILocation(line: 965, column: 20, scope: !5721, inlinedAt: !5722)
!5721 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 48)
!5722 = !DILocation(line: 448, column: 29, scope: !5723, inlinedAt: !5725)
!5723 = !DILexicalBlockFile(scope: !5724, file: !209, discriminator: 48)
!5724 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5725 = !DILocation(line: 400, column: 16, scope: !5726, inlinedAt: !5727)
!5726 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 48)
!5727 = !DILocation(line: 376, column: 14, scope: !5728, inlinedAt: !5729)
!5728 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 48)
!5729 = !DILocation(line: 842, column: 14, scope: !5730, inlinedAt: !5731)
!5730 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 36)
!5731 = !DILocation(line: 211, column: 62, scope: !5732, inlinedAt: !5733)
!5732 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 36)
!5733 = !DILocation(line: 3114, column: 11, scope: !5734, inlinedAt: !5735)
!5734 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 36)
!5735 = !DILocation(line: 778, column: 9, scope: !5736, inlinedAt: !5737)
!5736 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 36)
!5737 = !DILocation(line: 854, column: 71, scope: !1604)
!5738 = !{!5739}
!5739 = distinct !{!5739, !5740, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5740 = distinct !{!5740, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5741 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5742)
!5742 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5743)
!5743 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5744)
!5744 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5745)
!5745 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5717)
!5746 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5717)
!5747 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5717)
!5748 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5707)
!5749 = !DILocation(line: 857, column: 96, scope: !5708)
!5750 = !DILocation(line: 858, column: 21, scope: !1604)
!5751 = !DILocation(line: 441, column: 25, scope: !5752, inlinedAt: !5718)
!5752 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5753 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5754)
!5754 = !DILocation(line: 1252, column: 18, scope: !5755, inlinedAt: !5756)
!5755 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 48)
!5756 = !DILocation(line: 454, column: 36, scope: !5757, inlinedAt: !5725)
!5757 = !DILexicalBlockFile(scope: !5758, file: !209, discriminator: 48)
!5758 = distinct !DILexicalBlock(scope: !5724, file: !209, line: 448, column: 17)
!5759 = !DILocation(line: 853, column: 36, scope: !1604)
!5760 = !DILocation(line: 860, column: 34, scope: !1604)
!5761 = !DILocation(line: 865, column: 25, scope: !5762)
!5762 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 860, column: 25)
!5763 = !DILocation(line: 2997, column: 19, scope: !122, inlinedAt: !5764)
!5764 = !DILocation(line: 865, column: 58, scope: !5762)
!5765 = !DILocation(line: 3002, column: 37, scope: !5766, inlinedAt: !5764)
!5766 = distinct !DILexicalBlock(scope: !122, file: !123, line: 2997, column: 9)
!5767 = !DILocation(line: 3002, column: 18, scope: !5766, inlinedAt: !5764)
!5768 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5761)
!5769 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5761)
!5770 = !DILocation(line: 0, scope: !199, inlinedAt: !5771)
!5771 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5772)
!5772 = !DILocation(line: 177, column: 20, scope: !5773, inlinedAt: !5774)
!5773 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 50)
!5774 = !DILocation(line: 965, column: 20, scope: !5775, inlinedAt: !5776)
!5775 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 50)
!5776 = !DILocation(line: 448, column: 29, scope: !5777, inlinedAt: !5779)
!5777 = !DILexicalBlockFile(scope: !5778, file: !209, discriminator: 50)
!5778 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5779 = !DILocation(line: 400, column: 16, scope: !5780, inlinedAt: !5781)
!5780 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 50)
!5781 = !DILocation(line: 376, column: 14, scope: !5782, inlinedAt: !5783)
!5782 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 50)
!5783 = !DILocation(line: 842, column: 14, scope: !5784, inlinedAt: !5785)
!5784 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 38)
!5785 = !DILocation(line: 211, column: 62, scope: !5786, inlinedAt: !5787)
!5786 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 38)
!5787 = !DILocation(line: 3114, column: 11, scope: !5788, inlinedAt: !5789)
!5788 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 38)
!5789 = !DILocation(line: 778, column: 9, scope: !5790, inlinedAt: !5791)
!5790 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 38)
!5791 = !DILocation(line: 862, column: 77, scope: !1604)
!5792 = !{!5793}
!5793 = distinct !{!5793, !5794, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5794 = distinct !{!5794, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5795 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5796)
!5796 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5797)
!5797 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5798)
!5798 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5799)
!5799 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5771)
!5800 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5771)
!5801 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5771)
!5802 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5761)
!5803 = !DILocation(line: 865, column: 95, scope: !5762)
!5804 = !DILocation(line: 866, column: 21, scope: !1604)
!5805 = !DILocation(line: 441, column: 25, scope: !5806, inlinedAt: !5772)
!5806 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!5807 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !5808)
!5808 = !DILocation(line: 1252, column: 18, scope: !5809, inlinedAt: !5810)
!5809 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 50)
!5810 = !DILocation(line: 454, column: 36, scope: !5811, inlinedAt: !5779)
!5811 = !DILexicalBlockFile(scope: !5812, file: !209, discriminator: 50)
!5812 = distinct !DILexicalBlock(scope: !5778, file: !209, line: 448, column: 17)
!5813 = !DILocation(line: 861, column: 36, scope: !1604)
!5814 = !DILocation(line: 872, column: 25, scope: !1604)
!5815 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !5816)
!5816 = !DILocation(line: 3729, column: 14, scope: !5817, inlinedAt: !5818)
!5817 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 326)
!5818 = !DILocation(line: 872, column: 35, scope: !1604)
!5819 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !5814)
!5820 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !5814)
!5821 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !5814)
!5822 = !DILocation(line: 872, column: 44, scope: !1604)
!5823 = !DILocation(line: 874, column: 40, scope: !1604)
!5824 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !5825)
!5825 = !DILocation(line: 3729, column: 14, scope: !5826, inlinedAt: !5827)
!5826 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 328)
!5827 = !DILocation(line: 874, column: 63, scope: !1604)
!5828 = !DILocation(line: 282, column: 16, scope: !5829, inlinedAt: !5830)
!5829 = distinct !DILexicalBlock(scope: !2991, file: !181, line: 282, column: 34)
!5830 = !DILocation(line: 874, column: 69, scope: !1604)
!5831 = !DILocation(line: 1016, column: 21, scope: !2994, inlinedAt: !5832)
!5832 = !DILocation(line: 874, column: 76, scope: !1604)
!5833 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !5834)
!5834 = !DILocation(line: 607, column: 14, scope: !5835, inlinedAt: !5836)
!5835 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 464)
!5836 = !DILocation(line: 295, column: 20, scope: !5837, inlinedAt: !5838)
!5837 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 464)
!5838 = !DILocation(line: 1916, column: 18, scope: !5839, inlinedAt: !5840)
!5839 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 330)
!5840 = !DILocation(line: 1815, column: 76, scope: !5841, inlinedAt: !5825)
!5841 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 328)
!5842 = !DILocation(line: 282, column: 21, scope: !5829, inlinedAt: !5830)
!5843 = !DILocation(line: 612, column: 9, scope: !3017, inlinedAt: !5844)
!5844 = !DILocation(line: 607, column: 14, scope: !5845, inlinedAt: !5846)
!5845 = !DILexicalBlockFile(scope: !3020, file: !147, discriminator: 466)
!5846 = !DILocation(line: 295, column: 20, scope: !5847, inlinedAt: !5848)
!5847 = !DILexicalBlockFile(scope: !3023, file: !147, discriminator: 466)
!5848 = !DILocation(line: 1916, column: 18, scope: !5849, inlinedAt: !5850)
!5849 = !DILexicalBlockFile(scope: !3026, file: !123, discriminator: 332)
!5850 = !DILocation(line: 1815, column: 76, scope: !5851, inlinedAt: !5852)
!5851 = !DILexicalBlockFile(scope: !3007, file: !123, discriminator: 330)
!5852 = !DILocation(line: 3729, column: 14, scope: !5853, inlinedAt: !5854)
!5853 = !DILexicalBlockFile(scope: !3010, file: !123, discriminator: 330)
!5854 = !DILocation(line: 874, column: 63, scope: !3012)
!5855 = !DILocation(line: 1815, column: 86, scope: !3007, inlinedAt: !5852)
!5856 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !5823)
!5857 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !5823)
!5858 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !5823)
!5859 = !DILocation(line: 874, column: 92, scope: !1604)
!5860 = !DILocation(line: 2189, column: 27, scope: !5861, inlinedAt: !5862)
!5861 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!5862 = !DILocation(line: 874, column: 40, scope: !5863)
!5863 = !DILexicalBlockFile(scope: !5864, file: !8, discriminator: 2)
!5864 = distinct !DILexicalBlock(scope: !5865, file: !8, line: 874, column: 92)
!5865 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 874, column: 92)
!5866 = !DILocation(line: 2189, column: 23, scope: !5861, inlinedAt: !5862)
!5867 = !DILocation(line: 2189, column: 40, scope: !5861, inlinedAt: !5862)
!5868 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !5823)
!5869 = !DILocation(line: 875, column: 28, scope: !5870)
!5870 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 874, column: 25)
!5871 = !DILocation(line: 878, column: 39, scope: !5870)
!5872 = !{i64 8}
!5873 = !DILocation(line: 879, column: 44, scope: !5874)
!5874 = distinct !DILexicalBlock(scope: !5870, file: !8, line: 878, column: 25)
!5875 = !DILocation(line: 880, column: 42, scope: !5876)
!5876 = distinct !DILexicalBlock(scope: !5874, file: !8, line: 879, column: 25)
!5877 = !DILocation(line: 881, column: 28, scope: !5878)
!5878 = distinct !DILexicalBlock(scope: !5876, file: !8, line: 880, column: 25)
!5879 = !DILocation(line: 0, scope: !199, inlinedAt: !5880)
!5880 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5881)
!5881 = !DILocation(line: 177, column: 20, scope: !5882, inlinedAt: !5883)
!5882 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 52)
!5883 = !DILocation(line: 965, column: 20, scope: !5884, inlinedAt: !5885)
!5884 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 52)
!5885 = !DILocation(line: 448, column: 29, scope: !5886, inlinedAt: !5888)
!5886 = !DILexicalBlockFile(scope: !5887, file: !209, discriminator: 52)
!5887 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5888 = !DILocation(line: 400, column: 16, scope: !5889, inlinedAt: !5890)
!5889 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 52)
!5890 = !DILocation(line: 376, column: 14, scope: !5891, inlinedAt: !5892)
!5891 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 52)
!5892 = !DILocation(line: 842, column: 14, scope: !5893, inlinedAt: !5894)
!5893 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 40)
!5894 = !DILocation(line: 211, column: 62, scope: !5895, inlinedAt: !5896)
!5895 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 40)
!5896 = !DILocation(line: 3114, column: 11, scope: !5897, inlinedAt: !5898)
!5897 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 40)
!5898 = !DILocation(line: 778, column: 9, scope: !5899, inlinedAt: !5900)
!5899 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 40)
!5900 = !DILocation(line: 876, column: 79, scope: !5870)
!5901 = !{!5902}
!5902 = distinct !{!5902, !5903, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5903 = distinct !{!5903, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5904 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5905)
!5905 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5906)
!5906 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5907)
!5907 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5908)
!5908 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5880)
!5909 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5880)
!5910 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5880)
!5911 = !DILocation(line: 884, column: 28, scope: !5878)
!5912 = !DILocation(line: 0, scope: !199, inlinedAt: !5913)
!5913 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5914)
!5914 = !DILocation(line: 177, column: 20, scope: !5915, inlinedAt: !5916)
!5915 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 54)
!5916 = !DILocation(line: 965, column: 20, scope: !5917, inlinedAt: !5918)
!5917 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 54)
!5918 = !DILocation(line: 448, column: 29, scope: !5919, inlinedAt: !5921)
!5919 = !DILexicalBlockFile(scope: !5920, file: !209, discriminator: 54)
!5920 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5921 = !DILocation(line: 400, column: 16, scope: !5922, inlinedAt: !5923)
!5922 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 54)
!5923 = !DILocation(line: 376, column: 14, scope: !5924, inlinedAt: !5925)
!5924 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 54)
!5925 = !DILocation(line: 842, column: 14, scope: !5926, inlinedAt: !5927)
!5926 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 42)
!5927 = !DILocation(line: 211, column: 62, scope: !5928, inlinedAt: !5929)
!5928 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 42)
!5929 = !DILocation(line: 3114, column: 11, scope: !5930, inlinedAt: !5931)
!5930 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 42)
!5931 = !DILocation(line: 778, column: 9, scope: !5932, inlinedAt: !5933)
!5932 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 42)
!5933 = !DILocation(line: 882, column: 75, scope: !5878)
!5934 = !{!5935}
!5935 = distinct !{!5935, !5936, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5936 = distinct !{!5936, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5937 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5938)
!5938 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5939)
!5939 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5940)
!5940 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5941)
!5941 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5913)
!5942 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5913)
!5943 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5913)
!5944 = !DILocation(line: 887, column: 41, scope: !5878)
!5945 = !DILocation(line: 1815, column: 86, scope: !5946, inlinedAt: !5947)
!5946 = distinct !DISubprogram(name: "as_slice<bitcoin::blockdata::transaction::TxIn, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$8as_slice17h8e871f48c41e319eE", scope: !124, file: !123, line: 1798, type: !12, scopeLine: 1798, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5947 = !DILocation(line: 3729, column: 14, scope: !5948, inlinedAt: !5950)
!5948 = !DILexicalBlockFile(scope: !5949, file: !123, discriminator: 332)
!5949 = distinct !DISubprogram(name: "deref<bitcoin::blockdata::transaction::TxIn, alloc::alloc::Global>", linkageName: "_ZN72_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..deref..Deref$GT$5deref17h1c8e9854ce12f650E", scope: !163, file: !123, line: 3728, type: !12, scopeLine: 3728, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5950 = !DILocation(line: 3804, column: 23, scope: !5951, inlinedAt: !5953)
!5951 = !DILexicalBlockFile(scope: !5952, file: !123, discriminator: 34)
!5952 = distinct !DISubprogram(name: "index<bitcoin::blockdata::transaction::TxIn, usize, alloc::alloc::Global>", linkageName: "_ZN81_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..ops..index..Index$LT$I$GT$$GT$5index17h3f5d4587c91257adE", scope: !2362, file: !123, line: 3803, type: !12, scopeLine: 3803, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5953 = !DILocation(line: 887, column: 40, scope: !5878)
!5954 = !DILocation(line: 272, column: 10, scope: !5955, inlinedAt: !5956)
!5955 = distinct !DISubprogram(name: "index<bitcoin::blockdata::transaction::TxIn>", linkageName: "_ZN75_$LT$usize$u20$as$u20$core..slice..index..SliceIndex$LT$$u5b$T$u5d$$GT$$GT$5index17h88c1853dd51324e7E", scope: !694, file: !693, line: 270, type: !12, scopeLine: 270, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5956 = !DILocation(line: 19, column: 15, scope: !5957, inlinedAt: !5959)
!5957 = !DILexicalBlockFile(scope: !5958, file: !693, discriminator: 34)
!5958 = distinct !DISubprogram(name: "index<bitcoin::blockdata::transaction::TxIn, usize>", linkageName: "_ZN4core5slice5index74_$LT$impl$u20$core..ops..index..Index$LT$I$GT$$u20$for$u20$$u5b$T$u5d$$GT$5index17h1537bf0085d4f141E", scope: !2359, file: !693, line: 18, type: !12, scopeLine: 18, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5959 = !DILocation(line: 3804, column: 9, scope: !5951, inlinedAt: !5953)
!5960 = !DILocation(line: 0, scope: !199, inlinedAt: !5961)
!5961 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !5962)
!5962 = !DILocation(line: 177, column: 20, scope: !5963, inlinedAt: !5964)
!5963 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 56)
!5964 = !DILocation(line: 965, column: 20, scope: !5965, inlinedAt: !5966)
!5965 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 56)
!5966 = !DILocation(line: 448, column: 29, scope: !5967, inlinedAt: !5969)
!5967 = !DILexicalBlockFile(scope: !5968, file: !209, discriminator: 56)
!5968 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!5969 = !DILocation(line: 400, column: 16, scope: !5970, inlinedAt: !5971)
!5970 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 56)
!5971 = !DILocation(line: 376, column: 14, scope: !5972, inlinedAt: !5973)
!5972 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 56)
!5973 = !DILocation(line: 842, column: 14, scope: !5974, inlinedAt: !5975)
!5974 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 44)
!5975 = !DILocation(line: 211, column: 62, scope: !5976, inlinedAt: !5977)
!5976 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 44)
!5977 = !DILocation(line: 3114, column: 11, scope: !5978, inlinedAt: !5979)
!5978 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 44)
!5979 = !DILocation(line: 778, column: 9, scope: !5980, inlinedAt: !5981)
!5980 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 44)
!5981 = !DILocation(line: 885, column: 70, scope: !5878)
!5982 = !{!5983}
!5983 = distinct !{!5983, !5984, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!5984 = distinct !{!5984, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!5985 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !5986)
!5986 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !5987)
!5987 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !5988)
!5988 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !5989)
!5989 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !5961)
!5990 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !5961)
!5991 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !5961)
!5992 = !DILocation(line: 612, column: 9, scope: !5993, inlinedAt: !5994)
!5993 = distinct !DISubprogram(name: "non_null<alloc::alloc::Global, bitcoin::blockdata::transaction::TxIn>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$8non_null17h0ed4a2dc5b28c292E", scope: !148, file: !147, line: 611, type: !12, scopeLine: 611, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5994 = !DILocation(line: 607, column: 14, scope: !5995, inlinedAt: !5997)
!5995 = !DILexicalBlockFile(scope: !5996, file: !147, discriminator: 474)
!5996 = distinct !DISubprogram(name: "ptr<alloc::alloc::Global, bitcoin::blockdata::transaction::TxIn>", linkageName: "_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$3ptr17h32c11e42bba2cffaE", scope: !148, file: !147, line: 606, type: !12, scopeLine: 606, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!5997 = !DILocation(line: 295, column: 20, scope: !5998, inlinedAt: !6000)
!5998 = !DILexicalBlockFile(scope: !5999, file: !147, discriminator: 474)
!5999 = distinct !DISubprogram(name: "ptr<bitcoin::blockdata::transaction::TxIn, alloc::alloc::Global>", linkageName: "_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$3ptr17hc69229468e8cd842E", scope: !156, file: !147, line: 294, type: !12, scopeLine: 294, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6000 = !DILocation(line: 1916, column: 18, scope: !6001, inlinedAt: !6003)
!6001 = !DILexicalBlockFile(scope: !6002, file: !123, discriminator: 334)
!6002 = distinct !DISubprogram(name: "as_ptr<bitcoin::blockdata::transaction::TxIn, alloc::alloc::Global>", linkageName: "_ZN5alloc3vec16Vec$LT$T$C$A$GT$6as_ptr17h9d50f630fd779db1E", scope: !124, file: !123, line: 1913, type: !12, scopeLine: 1913, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6003 = !DILocation(line: 1815, column: 76, scope: !6004, inlinedAt: !5947)
!6004 = !DILexicalBlockFile(scope: !5946, file: !123, discriminator: 332)
!6005 = !DILocation(line: 272, column: 9, scope: !5955, inlinedAt: !5956)
!6006 = !DILocation(line: 343, column: 23, scope: !6007, inlinedAt: !6011)
!6007 = distinct !DISubprogram(name: "eq", linkageName: "_ZN82_$LT$bitcoin..blockdata..transaction..Sequence$u20$as$u20$core..cmp..PartialEq$GT$2eq17hc330f69d47003988E", scope: !6009, file: !6008, line: 343, type: !12, scopeLine: 343, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6008 = !DIFile(filename: "src/blockdata/transaction.rs", directory: "/home/ubuntu/.cargo/registry/src/index.crates.io-1949cf8c6b5b557f/bitcoin-0.32.102", checksumkind: CSK_MD5, checksum: "5a3470065a613bef1811c2740cfe2f02")
!6009 = !DINamespace(name: "{impl#120}", scope: !6010)
!6010 = !DINamespace(name: "transaction", scope: !367)
!6011 = !DILocation(line: 265, column: 15, scope: !6012, inlinedAt: !6014)
!6012 = !DILexicalBlockFile(scope: !6013, file: !35, discriminator: 2)
!6013 = distinct !DISubprogram(name: "ne<bitcoin::blockdata::transaction::Sequence, bitcoin::blockdata::transaction::Sequence>", linkageName: "_ZN4core3cmp9PartialEq2ne17hd980a2d73342f18fE", scope: !1521, file: !35, line: 264, type: !12, scopeLine: 264, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6014 = !DILocation(line: 382, column: 56, scope: !6015, inlinedAt: !6017)
!6015 = distinct !DISubprogram(name: "enables_absolute_lock_time", linkageName: "_ZN7bitcoin9blockdata11transaction8Sequence26enables_absolute_lock_time17hf767ee251c1181b9E", scope: !6016, file: !6008, line: 382, type: !12, scopeLine: 382, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6016 = !DINamespace(name: "Sequence", scope: !6010)
!6017 = !DILocation(line: 404, column: 44, scope: !6018, inlinedAt: !6019)
!6018 = distinct !DISubprogram(name: "is_final", linkageName: "_ZN7bitcoin9blockdata11transaction8Sequence8is_final17hfa7a98212528bcebE", scope: !6016, file: !6008, line: 404, type: !12, scopeLine: 404, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6019 = !DILocation(line: 887, column: 67, scope: !5878)
!6020 = !DILocation(line: 887, column: 28, scope: !5878)
!6021 = !DILocation(line: 0, scope: !199, inlinedAt: !6022)
!6022 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !6023)
!6023 = !DILocation(line: 177, column: 20, scope: !6024, inlinedAt: !6025)
!6024 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 58)
!6025 = !DILocation(line: 965, column: 20, scope: !6026, inlinedAt: !6027)
!6026 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 58)
!6027 = !DILocation(line: 448, column: 29, scope: !6028, inlinedAt: !6030)
!6028 = !DILexicalBlockFile(scope: !6029, file: !209, discriminator: 58)
!6029 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!6030 = !DILocation(line: 400, column: 16, scope: !6031, inlinedAt: !6032)
!6031 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 58)
!6032 = !DILocation(line: 376, column: 14, scope: !6033, inlinedAt: !6034)
!6033 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 58)
!6034 = !DILocation(line: 842, column: 14, scope: !6035, inlinedAt: !6036)
!6035 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 46)
!6036 = !DILocation(line: 211, column: 62, scope: !6037, inlinedAt: !6038)
!6037 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 46)
!6038 = !DILocation(line: 3114, column: 11, scope: !6039, inlinedAt: !6040)
!6039 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 46)
!6040 = !DILocation(line: 778, column: 9, scope: !6041, inlinedAt: !6042)
!6041 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 46)
!6042 = !DILocation(line: 888, column: 85, scope: !5878)
!6043 = !{!6044}
!6044 = distinct !{!6044, !6045, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!6045 = distinct !{!6045, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!6046 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !6047)
!6047 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !6048)
!6048 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !6049)
!6049 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !6050)
!6050 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !6022)
!6051 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !6022)
!6052 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !6022)
!6053 = !DILocation(line: 441, column: 25, scope: !6054, inlinedAt: !6023)
!6054 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6055 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6056)
!6056 = !DILocation(line: 1252, column: 18, scope: !6057, inlinedAt: !6058)
!6057 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 58)
!6058 = !DILocation(line: 454, column: 36, scope: !6059, inlinedAt: !6030)
!6059 = !DILexicalBlockFile(scope: !6060, file: !209, discriminator: 58)
!6060 = distinct !DILexicalBlock(scope: !6029, file: !209, line: 448, column: 17)
!6061 = !DILocation(line: 888, column: 36, scope: !5878)
!6062 = !DILocation(line: 0, scope: !6063)
!6063 = !DILexicalBlockFile(scope: !5878, file: !74, discriminator: 0)
!6064 = !DILocation(line: 441, column: 25, scope: !6065, inlinedAt: !5962)
!6065 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6066 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6067)
!6067 = !DILocation(line: 1252, column: 18, scope: !6068, inlinedAt: !6069)
!6068 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 56)
!6069 = !DILocation(line: 454, column: 36, scope: !6070, inlinedAt: !5969)
!6070 = !DILexicalBlockFile(scope: !6071, file: !209, discriminator: 56)
!6071 = distinct !DILexicalBlock(scope: !5968, file: !209, line: 448, column: 17)
!6072 = !DILocation(line: 885, column: 36, scope: !5878)
!6073 = !DILocation(line: 441, column: 25, scope: !6074, inlinedAt: !5914)
!6074 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6075 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6076)
!6076 = !DILocation(line: 1252, column: 18, scope: !6077, inlinedAt: !6078)
!6077 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 54)
!6078 = !DILocation(line: 454, column: 36, scope: !6079, inlinedAt: !5921)
!6079 = !DILexicalBlockFile(scope: !6080, file: !209, discriminator: 54)
!6080 = distinct !DILexicalBlock(scope: !5920, file: !209, line: 448, column: 17)
!6081 = !DILocation(line: 882, column: 36, scope: !5878)
!6082 = !DILocation(line: 441, column: 25, scope: !6083, inlinedAt: !5881)
!6083 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6084 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6085)
!6085 = !DILocation(line: 1252, column: 18, scope: !6086, inlinedAt: !6087)
!6086 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 52)
!6087 = !DILocation(line: 454, column: 36, scope: !6088, inlinedAt: !5888)
!6088 = !DILexicalBlockFile(scope: !6089, file: !209, discriminator: 52)
!6089 = distinct !DILexicalBlock(scope: !5887, file: !209, line: 448, column: 17)
!6090 = !DILocation(line: 876, column: 36, scope: !5870)
!6091 = !DILocation(line: 0, scope: !6092)
!6092 = !DILexicalBlockFile(scope: !5870, file: !74, discriminator: 0)
!6093 = !DILocation(line: 897, column: 25, scope: !1604)
!6094 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !6095)
!6095 = !DILocation(line: 3729, column: 14, scope: !6096, inlinedAt: !6097)
!6096 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 334)
!6097 = !DILocation(line: 897, column: 35, scope: !1604)
!6098 = !DILocation(line: 2173, column: 15, scope: !1745, inlinedAt: !6093)
!6099 = !DILocation(line: 2173, column: 9, scope: !1745, inlinedAt: !6093)
!6100 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !6093)
!6101 = !DILocation(line: 897, column: 44, scope: !1604)
!6102 = !DILocation(line: 898, column: 35, scope: !1604)
!6103 = !DILocation(line: 1815, column: 86, scope: !160, inlinedAt: !6104)
!6104 = !DILocation(line: 3729, column: 14, scope: !6105, inlinedAt: !6106)
!6105 = !DILexicalBlockFile(scope: !162, file: !123, discriminator: 336)
!6106 = !DILocation(line: 898, column: 58, scope: !1604)
!6107 = !DILocation(line: 282, column: 16, scope: !6108, inlinedAt: !6109)
!6108 = distinct !DILexicalBlock(scope: !2991, file: !181, line: 282, column: 34)
!6109 = !DILocation(line: 898, column: 64, scope: !1604)
!6110 = !DILocation(line: 1016, column: 21, scope: !2994, inlinedAt: !6111)
!6111 = !DILocation(line: 898, column: 71, scope: !1604)
!6112 = !DILocation(line: 612, column: 9, scope: !146, inlinedAt: !6113)
!6113 = !DILocation(line: 607, column: 14, scope: !6114, inlinedAt: !6115)
!6114 = !DILexicalBlockFile(scope: !152, file: !147, discriminator: 480)
!6115 = !DILocation(line: 295, column: 20, scope: !6116, inlinedAt: !6117)
!6116 = !DILexicalBlockFile(scope: !155, file: !147, discriminator: 480)
!6117 = !DILocation(line: 1916, column: 18, scope: !6118, inlinedAt: !6119)
!6118 = !DILexicalBlockFile(scope: !158, file: !123, discriminator: 338)
!6119 = !DILocation(line: 1815, column: 76, scope: !6120, inlinedAt: !6104)
!6120 = !DILexicalBlockFile(scope: !160, file: !123, discriminator: 336)
!6121 = !DILocation(line: 282, column: 21, scope: !6108, inlinedAt: !6109)
!6122 = !DILocation(line: 612, column: 9, scope: !3017, inlinedAt: !6123)
!6123 = !DILocation(line: 607, column: 14, scope: !6124, inlinedAt: !6125)
!6124 = !DILexicalBlockFile(scope: !3020, file: !147, discriminator: 482)
!6125 = !DILocation(line: 295, column: 20, scope: !6126, inlinedAt: !6127)
!6126 = !DILexicalBlockFile(scope: !3023, file: !147, discriminator: 482)
!6127 = !DILocation(line: 1916, column: 18, scope: !6128, inlinedAt: !6129)
!6128 = !DILexicalBlockFile(scope: !3026, file: !123, discriminator: 340)
!6129 = !DILocation(line: 1815, column: 76, scope: !6130, inlinedAt: !6131)
!6130 = !DILexicalBlockFile(scope: !3007, file: !123, discriminator: 338)
!6131 = !DILocation(line: 3729, column: 14, scope: !6132, inlinedAt: !6133)
!6132 = !DILexicalBlockFile(scope: !3010, file: !123, discriminator: 338)
!6133 = !DILocation(line: 898, column: 58, scope: !3012)
!6134 = !DILocation(line: 1815, column: 86, scope: !3007, inlinedAt: !6131)
!6135 = !DILocation(line: 2173, column: 15, scope: !3243, inlinedAt: !6102)
!6136 = !DILocation(line: 2173, column: 9, scope: !3243, inlinedAt: !6102)
!6137 = !DILocation(line: 2175, column: 17, scope: !3243, inlinedAt: !6102)
!6138 = !DILocation(line: 898, column: 87, scope: !1604)
!6139 = !DILocation(line: 2189, column: 27, scope: !6140, inlinedAt: !6141)
!6140 = distinct !DILexicalBlock(scope: !3248, file: !384, line: 2189, column: 13)
!6141 = !DILocation(line: 898, column: 35, scope: !6142)
!6142 = !DILexicalBlockFile(scope: !6143, file: !8, discriminator: 2)
!6143 = distinct !DILexicalBlock(scope: !6144, file: !8, line: 898, column: 87)
!6144 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 898, column: 87)
!6145 = !DILocation(line: 2189, column: 23, scope: !6140, inlinedAt: !6141)
!6146 = !DILocation(line: 2189, column: 40, scope: !6140, inlinedAt: !6141)
!6147 = !DILocation(line: 2174, column: 16, scope: !3243, inlinedAt: !6102)
!6148 = !DILocation(line: 899, column: 28, scope: !6149)
!6149 = distinct !DILexicalBlock(scope: !1604, file: !8, line: 898, column: 25)
!6150 = !DILocation(line: 902, column: 28, scope: !6149)
!6151 = !DILocation(line: 0, scope: !199, inlinedAt: !6152)
!6152 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !6153)
!6153 = !DILocation(line: 177, column: 20, scope: !6154, inlinedAt: !6155)
!6154 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 60)
!6155 = !DILocation(line: 965, column: 20, scope: !6156, inlinedAt: !6157)
!6156 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 60)
!6157 = !DILocation(line: 448, column: 29, scope: !6158, inlinedAt: !6160)
!6158 = !DILexicalBlockFile(scope: !6159, file: !209, discriminator: 60)
!6159 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!6160 = !DILocation(line: 400, column: 16, scope: !6161, inlinedAt: !6162)
!6161 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 60)
!6162 = !DILocation(line: 376, column: 14, scope: !6163, inlinedAt: !6164)
!6163 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 60)
!6164 = !DILocation(line: 842, column: 14, scope: !6165, inlinedAt: !6166)
!6165 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 48)
!6166 = !DILocation(line: 211, column: 62, scope: !6167, inlinedAt: !6168)
!6167 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 48)
!6168 = !DILocation(line: 3114, column: 11, scope: !6169, inlinedAt: !6170)
!6169 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 48)
!6170 = !DILocation(line: 778, column: 9, scope: !6171, inlinedAt: !6172)
!6171 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 48)
!6172 = !DILocation(line: 900, column: 78, scope: !6149)
!6173 = !{!6174}
!6174 = distinct !{!6174, !6175, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!6175 = distinct !{!6175, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!6176 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !6177)
!6177 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !6178)
!6178 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !6179)
!6179 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !6180)
!6180 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !6152)
!6181 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !6152)
!6182 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !6152)
!6183 = !DILocation(line: 907, column: 29, scope: !6149)
!6184 = !DILocation(line: 907, column: 28, scope: !6149)
!6185 = !DILocation(line: 910, column: 48, scope: !6149)
!6186 = !DILocation(line: 1815, column: 86, scope: !5946, inlinedAt: !6187)
!6187 = !DILocation(line: 3729, column: 14, scope: !6188, inlinedAt: !6189)
!6188 = !DILexicalBlockFile(scope: !5949, file: !123, discriminator: 340)
!6189 = !DILocation(line: 3804, column: 23, scope: !6190, inlinedAt: !6191)
!6190 = !DILexicalBlockFile(scope: !5952, file: !123, discriminator: 36)
!6191 = !DILocation(line: 910, column: 47, scope: !6149)
!6192 = !DILocation(line: 272, column: 10, scope: !5955, inlinedAt: !6193)
!6193 = !DILocation(line: 19, column: 15, scope: !6194, inlinedAt: !6195)
!6194 = !DILexicalBlockFile(scope: !5958, file: !693, discriminator: 36)
!6195 = !DILocation(line: 3804, column: 9, scope: !6190, inlinedAt: !6191)
!6196 = !DILocation(line: 0, scope: !199, inlinedAt: !6197)
!6197 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !6198)
!6198 = !DILocation(line: 177, column: 20, scope: !6199, inlinedAt: !6200)
!6199 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 62)
!6200 = !DILocation(line: 965, column: 20, scope: !6201, inlinedAt: !6202)
!6201 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 62)
!6202 = !DILocation(line: 448, column: 29, scope: !6203, inlinedAt: !6205)
!6203 = !DILexicalBlockFile(scope: !6204, file: !209, discriminator: 62)
!6204 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!6205 = !DILocation(line: 400, column: 16, scope: !6206, inlinedAt: !6207)
!6206 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 62)
!6207 = !DILocation(line: 376, column: 14, scope: !6208, inlinedAt: !6209)
!6208 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 62)
!6209 = !DILocation(line: 842, column: 14, scope: !6210, inlinedAt: !6211)
!6210 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 50)
!6211 = !DILocation(line: 211, column: 62, scope: !6212, inlinedAt: !6213)
!6212 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 50)
!6213 = !DILocation(line: 3114, column: 11, scope: !6214, inlinedAt: !6215)
!6214 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 50)
!6215 = !DILocation(line: 778, column: 9, scope: !6216, inlinedAt: !6217)
!6216 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 50)
!6217 = !DILocation(line: 908, column: 77, scope: !6149)
!6218 = !{!6219}
!6219 = distinct !{!6219, !6220, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!6220 = distinct !{!6220, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!6221 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !6222)
!6222 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !6223)
!6223 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !6224)
!6224 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !6225)
!6225 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !6197)
!6226 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !6197)
!6227 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !6197)
!6228 = !DILocation(line: 612, column: 9, scope: !5993, inlinedAt: !6229)
!6229 = !DILocation(line: 607, column: 14, scope: !6230, inlinedAt: !6231)
!6230 = !DILexicalBlockFile(scope: !5996, file: !147, discriminator: 488)
!6231 = !DILocation(line: 295, column: 20, scope: !6232, inlinedAt: !6233)
!6232 = !DILexicalBlockFile(scope: !5999, file: !147, discriminator: 488)
!6233 = !DILocation(line: 1916, column: 18, scope: !6234, inlinedAt: !6235)
!6234 = !DILexicalBlockFile(scope: !6002, file: !123, discriminator: 342)
!6235 = !DILocation(line: 1815, column: 76, scope: !6236, inlinedAt: !6187)
!6236 = !DILexicalBlockFile(scope: !5946, file: !123, discriminator: 340)
!6237 = !DILocation(line: 272, column: 9, scope: !5955, inlinedAt: !6193)
!6238 = !DILocation(line: 910, column: 35, scope: !6149)
!6239 = !DILocation(line: 942, column: 8, scope: !6240, inlinedAt: !6242)
!6240 = distinct !DILexicalBlock(scope: !6241, file: !8, line: 941, column: 5)
!6241 = distinct !DISubprogram(name: "sequence_csv_ok", linkageName: "_ZN18rbitcoin_consensus6script11interpreter15sequence_csv_ok17h5764dc0d818dfb98E", scope: !9, file: !8, line: 940, type: !12, scopeLine: 940, flags: DIFlagPrototyped, spFlags: DISPFlagLocalToUnit | DISPFlagDefinition | DISPFlagOptimized, unit: !5, templateParams: !13)
!6242 = distinct !DILocation(line: 911, column: 29, scope: !6243)
!6243 = distinct !DILexicalBlock(scope: !6149, file: !8, line: 910, column: 25)
!6244 = !DILocation(line: 950, column: 8, scope: !6245, inlinedAt: !6242)
!6245 = distinct !DILexicalBlock(scope: !6246, file: !8, line: 949, column: 5)
!6246 = distinct !DILexicalBlock(scope: !6247, file: !8, line: 948, column: 5)
!6247 = distinct !DILexicalBlock(scope: !6248, file: !8, line: 947, column: 5)
!6248 = distinct !DILexicalBlock(scope: !6249, file: !8, line: 946, column: 5)
!6249 = distinct !DILexicalBlock(scope: !6240, file: !8, line: 945, column: 5)
!6250 = !DILocation(line: 953, column: 5, scope: !6245, inlinedAt: !6242)
!6251 = !DILocation(line: 953, column: 30, scope: !6245, inlinedAt: !6242)
!6252 = !DILocation(line: 911, column: 29, scope: !6243)
!6253 = !DILocation(line: 0, scope: !199, inlinedAt: !6254)
!6254 = distinct !DILocation(line: 433, column: 15, scope: !202, inlinedAt: !6255)
!6255 = !DILocation(line: 177, column: 20, scope: !6256, inlinedAt: !6257)
!6256 = !DILexicalBlockFile(scope: !204, file: !147, discriminator: 192)
!6257 = !DILocation(line: 965, column: 20, scope: !6258, inlinedAt: !6259)
!6258 = !DILexicalBlockFile(scope: !206, file: !123, discriminator: 192)
!6259 = !DILocation(line: 448, column: 29, scope: !6260, inlinedAt: !6262)
!6260 = !DILexicalBlockFile(scope: !6261, file: !209, discriminator: 192)
!6261 = distinct !DILexicalBlock(scope: !210, file: !209, line: 447, column: 17)
!6262 = !DILocation(line: 400, column: 16, scope: !6263, inlinedAt: !6264)
!6263 = !DILexicalBlockFile(scope: !216, file: !209, discriminator: 192)
!6264 = !DILocation(line: 376, column: 14, scope: !6265, inlinedAt: !6266)
!6265 = !DILexicalBlockFile(scope: !218, file: !209, discriminator: 192)
!6266 = !DILocation(line: 842, column: 14, scope: !6267, inlinedAt: !6268)
!6267 = !DILexicalBlockFile(scope: !220, file: !209, discriminator: 52)
!6268 = !DILocation(line: 211, column: 62, scope: !6269, inlinedAt: !6270)
!6269 = !DILexicalBlockFile(scope: !223, file: !224, discriminator: 52)
!6270 = !DILocation(line: 3114, column: 11, scope: !6271, inlinedAt: !6272)
!6271 = !DILexicalBlockFile(scope: !228, file: !229, discriminator: 52)
!6272 = !DILocation(line: 778, column: 9, scope: !6273, inlinedAt: !6274)
!6273 = !DILexicalBlockFile(scope: !233, file: !234, discriminator: 52)
!6274 = !DILocation(line: 912, column: 69, scope: !6243)
!6275 = !{!6276}
!6276 = distinct !{!6276, !6277, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E: %_0"}
!6277 = distinct !{!6277, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h863d84537b3ee1b3E"}
!6278 = !DILocation(line: 95, column: 9, scope: !242, inlinedAt: !6279)
!6279 = distinct !DILocation(line: 190, column: 73, scope: !246, inlinedAt: !6280)
!6280 = distinct !DILocation(line: 312, column: 9, scope: !250, inlinedAt: !6281)
!6281 = distinct !DILocation(line: 429, column: 14, scope: !252, inlinedAt: !6282)
!6282 = distinct !DILocation(line: 464, column: 47, scope: !199, inlinedAt: !6254)
!6283 = !DILocation(line: 468, column: 25, scope: !256, inlinedAt: !6254)
!6284 = !DILocation(line: 468, column: 19, scope: !256, inlinedAt: !6254)
!6285 = !DILocation(line: 441, column: 25, scope: !6286, inlinedAt: !6255)
!6286 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6287 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6288)
!6288 = !DILocation(line: 1252, column: 18, scope: !6289, inlinedAt: !6290)
!6289 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 192)
!6290 = !DILocation(line: 454, column: 36, scope: !6291, inlinedAt: !6262)
!6291 = !DILexicalBlockFile(scope: !6292, file: !209, discriminator: 192)
!6292 = distinct !DILexicalBlock(scope: !6261, file: !209, line: 448, column: 17)
!6293 = !DILocation(line: 912, column: 36, scope: !6243)
!6294 = !DILocation(line: 0, scope: !6295)
!6295 = !DILexicalBlockFile(scope: !6149, file: !74, discriminator: 0)
!6296 = !DILocation(line: 441, column: 25, scope: !6297, inlinedAt: !6198)
!6297 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6298 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6299)
!6299 = !DILocation(line: 1252, column: 18, scope: !6300, inlinedAt: !6301)
!6300 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 62)
!6301 = !DILocation(line: 454, column: 36, scope: !6302, inlinedAt: !6205)
!6302 = !DILexicalBlockFile(scope: !6303, file: !209, discriminator: 62)
!6303 = distinct !DILexicalBlock(scope: !6204, file: !209, line: 448, column: 17)
!6304 = !DILocation(line: 908, column: 36, scope: !6149)
!6305 = !DILocation(line: 441, column: 25, scope: !6306, inlinedAt: !6153)
!6306 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6307 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6308)
!6308 = !DILocation(line: 1252, column: 18, scope: !6309, inlinedAt: !6310)
!6309 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 60)
!6310 = !DILocation(line: 454, column: 36, scope: !6311, inlinedAt: !6160)
!6311 = !DILexicalBlockFile(scope: !6312, file: !209, discriminator: 60)
!6312 = distinct !DILexicalBlock(scope: !6159, file: !209, line: 448, column: 17)
!6313 = !DILocation(line: 900, column: 36, scope: !6149)
!6314 = !DILocation(line: 2175, column: 17, scope: !1745, inlinedAt: !1721)
!6315 = !DILocation(line: 600, column: 99, scope: !1722)
!6316 = !DILocation(line: 600, column: 99, scope: !1604)
!6317 = !DILocation(line: 441, column: 25, scope: !6318, inlinedAt: !914)
!6318 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6319 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6320)
!6320 = !DILocation(line: 1252, column: 18, scope: !6321, inlinedAt: !6322)
!6321 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 12)
!6322 = !DILocation(line: 454, column: 36, scope: !6323, inlinedAt: !921)
!6323 = !DILexicalBlockFile(scope: !6324, file: !209, discriminator: 12)
!6324 = distinct !DILexicalBlock(scope: !920, file: !209, line: 448, column: 17)
!6325 = !DILocation(line: 524, column: 32, scope: !623)
!6326 = !DILocation(line: 441, column: 25, scope: !6327, inlinedAt: !320)
!6327 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6328 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6329)
!6329 = !DILocation(line: 1252, column: 18, scope: !6330, inlinedAt: !6331)
!6330 = !DILexicalBlockFile(scope: !310, file: !309, discriminator: 4)
!6331 = !DILocation(line: 454, column: 36, scope: !6332, inlinedAt: !327)
!6332 = !DILexicalBlockFile(scope: !6333, file: !209, discriminator: 4)
!6333 = distinct !DILexicalBlock(scope: !326, file: !209, line: 448, column: 17)
!6334 = !DILocation(line: 476, column: 16, scope: !15)
!6335 = !DILocation(line: 441, column: 25, scope: !6336, inlinedAt: !203)
!6336 = distinct !DILexicalBlock(scope: !202, file: !147, line: 441, column: 13)
!6337 = !DILocation(line: 547, column: 14, scope: !305, inlinedAt: !6338)
!6338 = !DILocation(line: 1252, column: 18, scope: !310, inlinedAt: !6339)
!6339 = !DILocation(line: 454, column: 36, scope: !6340, inlinedAt: !215)
!6340 = distinct !DILexicalBlock(scope: !208, file: !209, line: 448, column: 17)
!6341 = !DILocation(line: 466, column: 20, scope: !15)
